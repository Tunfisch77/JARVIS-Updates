@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" call "%~dp0MODULE_INSTALLIEREN.bat" --auto
if not exist ".venv\Scripts\python.exe" exit /b 1
echo JARVIS v14 - Secrets in Windows Credential Manager verschieben
".venv\Scripts\python.exe" migrate_secrets_to_keyring.py
pause
