from __future__ import annotations

import socket
import subprocess
import sys
import time
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent
HOST = "127.0.0.1"
PORT = 8017


def server_ready() -> bool:
    try:
        with socket.create_connection((HOST, PORT), timeout=0.3):
            return True
    except OSError:
        return False


def main() -> None:
    try:
        import webview
    except ImportError as exc:
        raise SystemExit("pywebview fehlt. Fuehre zuerst INSTALLIEREN.bat aus.") from exc

    process: subprocess.Popen[bytes] | None = None
    if not server_ready():
        process = subprocess.Popen(
            [
                sys.executable,
                "-m",
                "uvicorn",
                "app:app",
                "--host",
                HOST,
                "--port",
                str(PORT),
            ],
            cwd=BASE_DIR,
        )
        deadline = time.monotonic() + 20
        while time.monotonic() < deadline and not server_ready():
            if process.poll() is not None:
                raise SystemExit("JARVIS-Server konnte nicht gestartet werden.")
            time.sleep(0.2)
        if not server_ready():
            process.terminate()
            raise SystemExit("JARVIS-Server antwortet nicht.")

    try:
        webview.create_window(
            "J.A.R.V.I.S v14.0.0 Communication OS",
            f"http://{HOST}:{PORT}/?v=14.0.0",
            width=1480,
            height=920,
            min_size=(1050, 720),
        )
        webview.start(private_mode=False)
    finally:
        if process and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=8)
            except subprocess.TimeoutExpired:
                process.kill()


if __name__ == "__main__":
    main()
