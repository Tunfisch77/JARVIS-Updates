from __future__ import annotations

import argparse
import os
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

from dotenv import load_dotenv

from browser_runtime import browser_label, launch_persistent_browser
from integration_hub import IntegrationConfig, IntegrationError, IntegrationHub
from mail_accounts import AccountIntegrationError, ConnectedAccountConfig, ConnectedAccounts
from secure_config import load_keyring_environment


BASE_DIR = Path(__file__).resolve().parent


def _accounts() -> ConnectedAccounts:
    load_dotenv(BASE_DIR / ".env")
    load_keyring_environment()
    return ConnectedAccounts(ConnectedAccountConfig.from_environment(BASE_DIR))


def setup_whatsapp() -> None:
    config = IntegrationConfig.from_environment(base_dir=BASE_DIR)
    _setup_web_profile(
        name="WhatsApp Web",
        url="https://web.whatsapp.com/",
        profile=config.whatsapp_profile_dir,
        ready_selector="#pane-side",
        login_hint="Scanne den QR-Code unter WhatsApp → Verknüpfte Geräte → Gerät hinzufügen.",
    )


def setup_snapchat() -> None:
    config = IntegrationConfig.from_environment(base_dir=BASE_DIR)
    _setup_web_profile(
        name="Snapchat Web",
        url="https://web.snapchat.com/",
        profile=config.snapchat_profile_dir,
        ready_selector=None,
        login_hint="Melde dich im sichtbaren Snapchat-Web-Fenster an.",
    )


def _snapchat_session_is_ready(current_url: str) -> bool:
    parsed = urlparse(current_url)
    hostname = str(parsed.hostname or "").casefold()
    path = str(parsed.path or "").casefold().rstrip("/")
    if parsed.scheme != "https":
        return False
    if hostname == "web.snapchat.com":
        return True
    if hostname in {"www.snapchat.com", "snapchat.com"} and (
        path == "/web" or path.startswith("/web/")
    ):
        return True
    return False


def _snapchat_page_has_chat_ui(page: object) -> bool:
    """Recognize the signed-in app without depending on Snapchat's current URL."""
    selectors = (
        "[data-testid*='conversation']",
        "[data-testid*='chat']",
        "[aria-label*='Chat' i]",
        "[aria-label*='Conversation' i]",
        "nav [role='button']",
    )
    for selector in selectors:
        try:
            locator = page.locator(selector)
            if locator.count() > 0:
                return True
        except Exception:
            continue
    return False


def _snapchat_page_is_ready(page: object) -> bool:
    return _snapchat_session_is_ready(
        str(getattr(page, "url", ""))
    ) or _snapchat_page_has_chat_ui(page)


def _find_ready_snapchat_page(pages: object) -> object | None:
    try:
        candidates = list(pages)  # type: ignore[arg-type]
    except TypeError:
        candidates = []
    for candidate in reversed(candidates):
        if _snapchat_page_is_ready(candidate):
            return candidate
    return None


def _confirm_web_profile_ready(page: object, *, name: str, ready_selector: str | None) -> None:
    if name == "Snapchat Web":
        if not _snapchat_page_is_ready(page):
            raise IntegrationError(
                "Snapchat Web ist noch nicht angemeldet. "
                "Lass die Chat-Übersicht geöffnet und starte SNAPCHAT_VERBINDEN.sh erneut."
            )
        return
    if ready_selector:
        page.locator(ready_selector).wait_for(state="visible", timeout=30_000)


def _setup_web_profile(
    *,
    name: str,
    url: str,
    profile: Path,
    ready_selector: str | None,
    login_hint: str,
) -> None:
    try:
        from playwright.sync_api import Error as PlaywrightError
        from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
        from playwright.sync_api import sync_playwright
    except ImportError as exc:
        raise IntegrationError("Playwright fehlt. Starte zuerst INSTALLIEREN.sh.") from exc
    profile.mkdir(parents=True, exist_ok=True)
    config = IntegrationConfig.from_environment(base_dir=BASE_DIR)
    profile_connected = False
    try:
        with sync_playwright() as playwright:
            context = launch_persistent_browser(
                playwright,
                profile,
                preference=config.browser_channel,
                headless=False,
            )
            try:
                page = context.pages[0] if context.pages else context.new_page()
                page.goto(url, wait_until="domcontentloaded", timeout=60_000)
                print(f"{name} wurde sichtbar in {browser_label(config.browser_channel)} geöffnet.")
                print(login_hint)
                input("Wenn die Chat-Übersicht vollständig sichtbar ist, drücke hier ENTER ... ")
                if name == "Snapchat Web":
                    page = _find_ready_snapchat_page(context.pages) or page
                _confirm_web_profile_ready(
                    page,
                    name=name,
                    ready_selector=ready_selector,
                )
                profile_connected = True
            finally:
                context.close()
            if profile_connected:
                (profile / ".jarvis_connected").write_text(
                    datetime.now().isoformat(),
                    encoding="utf-8",
                )
    except IntegrationError:
        raise
    except PlaywrightTimeoutError as exc:
        raise IntegrationError(
            f"{name} hat nicht rechtzeitig geladen. "
            "Prüfe die Internetverbindung und starte die Verbindungsskript erneut."
        ) from exc
    except PlaywrightError as exc:
        raise IntegrationError(f"{name} konnte nicht geöffnet werden: {exc}") from exc
    print(f"{name} ist verbunden. JARVIS verwendet dieses Profil später unsichtbar im Hintergrund.")


def main() -> None:
    parser = argparse.ArgumentParser(description="Einmalige App-/Web-/OAuth-Anmeldung für JARVIS v15")
    parser.add_argument("service", choices=("gmail", "outlook", "whatsapp", "snapchat", "status"))
    parser.add_argument(
        "--browser",
        choices=("auto", "brave", "chrome", "msedge", "chromium"),
        help="Browser für diesen Verbindungsstart ausdrücklich festlegen.",
    )
    args = parser.parse_args()
    load_dotenv(BASE_DIR / ".env")
    if args.browser:
        os.environ["JARVIS_BROWSER_CHANNEL"] = args.browser
    try:
        if args.service == "gmail":
            path = _accounts().setup_gmail()
            print(f"Gmail verbunden. Token lokal gespeichert: {path}")
        elif args.service == "outlook":
            accounts = _accounts()
            if accounts.config.outlook_mode == "web":
                path = accounts.setup_outlook_web()
                print(f"Outlook Web verbunden. Lokales Browserprofil gespeichert: {path}")
            else:
                path = accounts.setup_outlook()
                print(f"Outlook Graph verbunden. Token lokal gespeichert: {path}")
        elif args.service == "whatsapp":
            setup_whatsapp()
        elif args.service == "snapchat":
            setup_snapchat()
        else:
            print(_accounts().redacted_configuration())
    except (AccountIntegrationError, IntegrationError) as exc:
        raise SystemExit(f"FEHLER: {exc}") from exc


if __name__ == "__main__":
    main()
