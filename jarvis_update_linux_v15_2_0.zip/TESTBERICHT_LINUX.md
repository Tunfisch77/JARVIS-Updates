# JARVIS Linux v15.2.0 – Teststand

Datum: 24.09.2026. Testumgebung: Ubuntu 24.04, Python 3.12.14, x86-64. Ziel: Linux Mint 22.3 Cinnamon in VMware.

- 280 Python-Tests bestanden, zusätzlich 16 Untertests. Enthalten sind Regressionstests des Windows-Quellstands sowie neue Linux-Prüfungen für Programmstart, blockierte ausführbare Dateien, Eingabestopp, Wayland-Sperre, Privacy Lock, Prozesszuordnung und Linux-Updatekanal.
- Python-, Bash- und JavaScript-Syntax geprüft. Frische Python-Umgebung aufgebaut; `pip check` ohne Konflikte. Genaue Laufzeitversionen stehen in `requirements-linux-lock.txt`.
- Echter Hintergrundstart unter Linux; Oberfläche, Health, Versions-API, Stabilitätsstatus, Integration Hub, PC-Agent und Verbindungsübersicht liefern HTTP 200.
- Zweiter Start verwendet dieselbe Prozess-ID. Update während des Serverbetriebs wird blockiert. Sauberes Beenden entfernt den Laufmarker; erneuter Start bleibt außerhalb des Safe Modes.
- Update-Regression prüft SHA-256, Backups, Rollback bei Schreibfehlern, Schutz persönlicher Daten und Ablehnung eines Windows-Manifests.

## Grenzen des Tests

Die isolierte Testumgebung erlaubt keine zusätzliche X11-Paketinstallation; der Download des Playwright-Browsers war ebenfalls blockiert. Deshalb sind **grafischer Installer-Durchlauf, echte X11-Maus-/Tastatureingaben und Chromium-Sandbox auf Mint hier nicht praktisch verifiziert**. Die Desktop-Aufrufe wurden mit kontrollierten Test-Doubles geprüft; das ersetzt den Praxistest nicht.

OpenAI-Schlüssel, Sprachstreaming, Mikrofon/Lautsprecher der VMware-VM und echte Kontenanmeldungen wurden nicht verwendet oder getestet. Es wurden keine echten Nachrichten versendet.

## Kurzer Test in deiner VM

1. Installer ausführen und `DIAGNOSE.sh --browser` prüfen.
2. Starten; Versionsanzeige und Mikrofonverbindung prüfen.
3. Ein bekanntes Programm, einen ausdrücklich angegebenen Ordner und eine Webseite öffnen.
4. Bei aktivierter Desktop-Steuerung einen harmlosen Text im Editor eingeben und Not-Aus prüfen.
5. Bildschirmaufnahme bewusst freigeben; Antwort auf den tatsächlichen Bildinhalt prüfen.
6. Konten einzeln verbinden, zuerst Lesen/Entwurf prüfen und einen Versand nur bewusst an ein eigenes Testziel auslösen.
7. Stoppen und neu starten; Einstellungen und Verlauf müssen erhalten bleiben.

Bei Fehlern: genaue Meldung oder `data/linux-diagnose.json` übermitteln. Den API-Schlüssel niemals mitschicken.
