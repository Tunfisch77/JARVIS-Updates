from __future__ import annotations

import os
import shutil
import webbrowser
from pathlib import Path
from typing import Any


AUTO_BROWSER_VALUES = {"", "auto", "default", "system", "standard"}
UNSAFE_SANDBOX_FLAGS = {"--no-sandbox", "--disable-setuid-sandbox"}


def channel_from_progid(progid: str) -> str | None:
    """Map the Windows HTTPS association to a Playwright browser channel."""
    normalized = str(progid or "").strip().casefold()
    if "brave" in normalized:
        return "brave"
    if "chrome" in normalized:
        return "chrome"
    if "msedge" in normalized or normalized.startswith("microsoftedge"):
        return "msedge"
    return None


def windows_default_browser_channel() -> str | None:
    if os.name != "nt":
        return None
    try:
        import winreg

        key_path = (
            r"Software\Microsoft\Windows\Shell\Associations"
            r"\UrlAssociations\https\UserChoice"
        )
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path) as key:
            progid, _ = winreg.QueryValueEx(key, "ProgId")
    except (ImportError, OSError):
        return None
    return channel_from_progid(str(progid))


def brave_executable_path() -> Path | None:
    """Find Brave without reusing the user's normal browser profile."""
    configured = str(os.getenv("JARVIS_BRAVE_EXECUTABLE") or "").strip().strip('"')
    if configured:
        candidate = Path(configured).expanduser()
        if candidate.is_file():
            return candidate

    paths: list[Path] = []
    for variable in ("LOCALAPPDATA", "PROGRAMFILES", "PROGRAMFILES(X86)"):
        base = str(os.getenv(variable) or "").strip()
        if base:
            paths.append(
                Path(base) / "BraveSoftware" / "Brave-Browser" / "Application" / "brave.exe"
            )
    for candidate in paths:
        if candidate.is_file():
            return candidate

    for command in ("brave-browser", "brave-browser-stable", "brave.exe", "brave"):
        located = shutil.which(command)
        if located:
            return Path(located)
    return None


def prefer_external_browser(preference: str) -> None:
    """Make OAuth browser openings use the requested browser explicitly."""
    channel = browser_candidates(preference)[0]
    if channel != "brave":
        return
    executable = brave_executable_path()
    if executable is None:
        raise RuntimeError(
            "Brave wurde nicht gefunden. Prüfe die Installation oder setze "
            "JARVIS_BRAVE_EXECUTABLE auf den vollständigen Pfad zur Brave-Programmdatei."
        )
    webbrowser.register(
        "jarvis-brave",
        None,
        webbrowser.BackgroundBrowser(str(executable)),
        preferred=True,
    )


def browser_candidates(preference: str, *, detected_channel: str | None = None) -> tuple[str | None, ...]:
    """Return browser choices in order; None means Playwright's bundled Chromium."""
    normalized = str(preference or "").strip().casefold()
    if normalized in AUTO_BROWSER_VALUES:
        detected = detected_channel if detected_channel is not None else windows_default_browser_channel()
        choices: list[str | None] = [detected, None] if detected else [None]
    elif normalized == "brave":
        choices = ["brave"]
    elif normalized in {"chromium", "bundled"}:
        choices = [None]
    else:
        choices = [normalized, None]
    return tuple(dict.fromkeys(choices))


def _browser_missing(error: Exception) -> bool:
    message = str(error or "").casefold()
    return any(
        marker in message
        for marker in (
            "executable doesn't exist",
            "executable does not exist",
            "distribution",
            "browser executable",
            "could not find browser",
        )
    )


def launch_persistent_browser(
    playwright: Any,
    profile: Path | str,
    *,
    preference: str = "auto",
    headless: bool = False,
    **kwargs: Any,
) -> Any:
    """Launch a persistent browser with Chromium's security sandbox enabled."""
    last_error: Exception | None = None
    for browser in browser_candidates(preference):
        options = dict(kwargs)
        options["headless"] = headless
        options["chromium_sandbox"] = True
        custom_args = options.get("args")
        if custom_args:
            options["args"] = [
                argument
                for argument in custom_args
                if str(argument).strip().casefold() not in UNSAFE_SANDBOX_FLAGS
            ]
        if browser == "brave":
            executable = brave_executable_path()
            if executable is None:
                last_error = RuntimeError("Brave browser executable could not be found")
                continue
            options["executable_path"] = str(executable)
        elif browser:
            options["channel"] = browser
        try:
            return playwright.chromium.launch_persistent_context(
                str(Path(profile).resolve()),
                **options,
            )
        except Exception as exc:
            last_error = exc
            if browser is None or not _browser_missing(exc):
                raise
    if last_error is not None:
        raise last_error
    raise RuntimeError("Kein kompatibler Browser wurde gefunden.")


def browser_label(preference: str) -> str:
    channel = browser_candidates(preference)[0]
    if channel == "brave":
        return "Brave"
    if channel == "chrome":
        return "Google Chrome"
    if channel == "msedge":
        return "Microsoft Edge"
    return "JARVIS-Browser"
