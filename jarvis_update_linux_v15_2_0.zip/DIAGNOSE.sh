#!/usr/bin/env bash
set -Eeuo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
umask 077
if [[ ! -x .venv/bin/python ]]; then
  echo "Python-Umgebung fehlt. Bitte zuerst: bash INSTALLIEREN.sh" >&2
  exit 1
fi
exec .venv/bin/python linux_diagnostics.py "$@"
