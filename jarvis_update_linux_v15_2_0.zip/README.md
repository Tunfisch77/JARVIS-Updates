# JARVIS Linux v15.2.0

Eigenständiges Komplettpaket auf Basis von v15.1.0, vorbereitet für Linux Mint 22.3 Cinnamon / Ubuntu 24.04, x86-64, Python 3.12. Für den ersten Test in deiner VMware-VM. Version 16 (persönliche Routinen) ist damit noch nicht umgesetzt.

## Einrichten

1. ZIP **in Linux** in deinen persönlichen Ordner entpacken, z. B. nach `~/JARVIS_Linux_v15_2_0`. Nicht im ZIP oder im VMware-Freigabeordner `/mnt/hgfs` starten.
2. Diesen Ordner im Dateimanager öffnen, Rechtsklick → „Im Terminal öffnen“.
3. `bash INSTALLIEREN.sh` ausführen. Ohne `sudo` davor; nur die Systempakete verlangen dein Linux-Passwort. Internet ist erforderlich. Python-Pakete und Chromium werden nachgeladen, daher ist die ZIP selbst klein.
4. Deinen OpenAI-API-Schlüssel bei der lokalen Abfrage eingeben. Die Eingabe bleibt unsichtbar. Enter überspringt die Eingabe. Später: `bash API_SCHLUESSEL_EINTRAGEN.sh`.
5. `bash STARTEN.sh` ausführen. Oberfläche: **http://127.0.0.1:8017**. Die Versionsanzeige muss 15.2.0 zeigen. Im Browser Mikrofon erlauben und wie bisher verbinden.

Die Oberfläche startet im Standardbrowser von Mint (z. B. Firefox oder Brave). Für automatisierte Web-Verbindungen wird ein getrenntes Chromium-Profil benutzt. Bei vorhandenem Brave kann in `.env` `JARVIS_BROWSER_CHANNEL=brave` gesetzt werden. Browserprofile werden nicht mit deinem normalen Browserprofil vermischt.

Nach der Installation gibt es im Mint-Startmenü auch **JARVIS Linux**. Wenn du den Programmordner verschiebst, `INSTALLIEREN.sh` erneut ausführen, damit der Menüeintrag aktualisiert wird.

## Im Alltag

| Befehl im JARVIS-Ordner | Funktion |
| --- | --- |
| `bash STARTEN.sh` | Backend starten und Oberfläche öffnen |
| `bash STARTEN.sh --no-browser` | Nur Backend starten |
| `bash STOPPEN.sh` | Backend sauber beenden |
| `bash STATUS.sh` | Laufenden Server prüfen |
| `bash DIAGNOSE.sh` | System, Datenbank und Voraussetzungen prüfen |
| `bash DIAGNOSE.sh --browser` | Zusätzlich einen leeren Browser mit Sandbox testen |
| `bash UPDATE_JARVIS.sh` | JARVIS beenden und eigenen Linux-Updatekanal prüfen |
| `bash AUTOSTART_AN.sh` | Backend nach deiner Desktop-Anmeldung starten |
| `bash AUTOSTART_AUS.sh` | Autostart entfernen |

**Hintergrundbetrieb:** Das Backend läuft nach Schließen des Terminals weiter. Für Mikrofon, Sprachverbindung und gesprochene Antworten muss die Browseroberfläche geöffnet und verbunden bleiben. Der Autostart startet nur das Backend. Diese Ausgabe ist noch kein ständig lauschender Sprachdienst und keine iPhone-App. Nach Abmelden oder Herunterfahren läuft der Desktop-Agent nicht weiter.

Die Startskripte erkennen doppelte Starts, prüfen die laufende Version und öffnen keinen zweiten Server auf demselben Port. `STOPPEN.sh` lässt Datenbank und Hintergrundaufgaben sauber schließen. Nach hartem Ausschalten kann weiterhin der vorhandene Safe Mode greifen.

## Linux-Funktionen und Grenzen

- Chat, Sprache, Gedächtnis, Missionen, Dateien und Communication Hub aus v15.1 bleiben enthalten. Cloud-KI benötigt deinen eigenen gültigen API-Schlüssel und Zugriff auf die konfigurierten Modelle. Modellnamen können in `.env` angepasst werden.
- Linux-Programme werden über bekannte Namen geöffnet: Rechner, Editor, Explorer/Dateien, Einstellungen, Systemüberwachung, Firefox, Brave, Chrome, Chromium, LibreOffice, Thunderbird, VLC, Spotify, Kamera, Fotos, Zeichenprogramm. Das jeweilige Programm muss installiert sein. Der Installer installiert diese optionalen Programme nicht pauschal. Beliebige ausführbare Dateien werden nicht als Dokument gestartet.
- Dateien/Ordner brauchen Linux-Pfade wie `/home/deinname/Dokumente/Datei.pdf`; Windows-Pfade funktionieren nicht.
- Maus, Tastatur, Scrollen, Fensterfokus und native Bildschirmaufnahme nutzen **X11**. In Mint die normale Sitzung **Cinnamon** verwenden, nicht „Cinnamon (Wayland)“. Die Desktop-Steuerung muss wie bisher in den PC-Agent-Einstellungen aktiviert sein; Bestätigungen und Not-Aus bleiben erhalten.
- Klicks anhand von Koordinaten sind umgesetzt. Windows-UI-Elemente per Namen (`click_control`) werden unter Linux ausdrücklich abgelehnt, bevor ein solcher Plan beginnt. Unter Wayland bleibt die Browser-Bildschirmfreigabe als Alternative zur nativen Aufnahme.
- Bildschirmaufnahmen werden von JARVIS nicht als Datei abgelegt. Bei einer KI-Analyse wird das bestätigte Standbild wie bisher an den konfigurierten Cloud-Dienst übermittelt.
- Der Privacy Lock fragt den Linux-Bildschirmsperrdienst ab. Ist der Sperrzustand unbekannt, bleiben Nachrichtenvorschauen bei aktiviertem Privacy Lock verborgen. Die Diagnose zeigt Hinweise zur Desktop-Sitzung.
- Windows-Module wie pywinauto, PyWinRT, Pycaw und die Windows-App-Shell sind unter Linux als nicht unterstützt markiert.
- Die alten `.bat`-/PowerShell-Dateien und Windows-Historie sind nur als Bestand des Quellpakets für Regressionstests enthalten. Unter Linux die `.sh`-Dateien verwenden. Optionale v11-Experimentmodule sind nicht alle installiert oder portiert.

## Konten verbinden

Konten müssen in der VM neu verbunden werden. Das Paket enthält keine Laptop-Logins, Browserprofile, Kontakte oder Datenbank.

- WhatsApp: `bash WHATSAPP_VERBINDEN.sh` → QR-Code in WhatsApp über „Verknüpfte Geräte“ scannen → nach erfolgreicher Anmeldung Enter im Terminal. Linux verwendet **WhatsApp Web**, nicht die Windows-App.
- Outlook: `bash OUTLOOK_VERBINDEN.sh` → im Browser anmelden → Enter im Terminal. Ein vorhandenes Schul-/Firmenkonto kann zusätzliche Anmeldevorgaben haben.
- Gmail: benötigt wie bisher eine eigene Google-OAuth-Desktop-Clientdatei. Den Pfad in `.env` unter `JARVIS_GMAIL_CLIENT_SECRET=` eintragen und `bash GMAIL_VERBINDEN.sh` starten. Das Paket enthält keine OAuth-Zugangsdaten.
- Snapchat: `bash SNAPCHAT_VERBINDEN.sh`; nur Anmelde-/Status-Erkennung, kein vollständiger Nachrichtenversand oder garantierter Inhaltszugriff.

Auch die Verbinden-Schaltflächen der Oberfläche öffnen unter Mint ein Terminal für den Anmeldeablauf. Währenddessen pausiert das Backend, damit kein zweiter Prozess dasselbe Browserprofil belegt; danach startet ein zuvor laufendes Backend wieder. Die Sprachverbindung anschließend neu verbinden. WhatsApp-/Outlook-Webfunktionen hängen weiterhin vom jeweiligen Webdienst ab und wurden hier nicht an deinen Konten getestet.

## Daten, Updates und Diagnose

- Eigene Einstellungen: `.env` (nur für deinen Benutzer lesbar).
- Gedächtnis/Datenbank: `data/` im Programmordner.
- Browserprofile und Kontokonfiguration: standardmäßig `~/.jarvis/`.
- Vor Umzug/Neuinstallation JARVIS stoppen und den Programmordner sowie `~/.jarvis/` privat sichern. Nie öffentlich hochladen.
- Linux-Updates nutzen `manifest-linux.json` im bestehenden Update-Repository. Windows-Pakete werden abgelehnt. Updates erstellen ein Backup der ersetzten Dateien und schützen `.env`, Daten und Python-Umgebung.
- Nach einem Update JARVIS erneut starten. Falls ein zukünftiges Update neue Abhängigkeiten mitbringt, `INSTALLIEREN.sh` erneut ausführen.
- Bei Problemen zuerst `bash DIAGNOSE.sh --browser`. Der Bericht liegt in `data/linux-diagnose.json`; technische Startfehler stehen in `data/linux-server.log`. Diagnoseberichte enthalten keine API-Schlüssel oder Nachrichten. Serverprotokolle vor dem Teilen auf persönliche Inhalte prüfen.
- Wenn Chromium durch die lokale Sandbox-/AppArmor-Konfiguration nicht startet, zeigt der Browsertest einen Fehler. Keine globale Sandbox-Abschaltung verwenden. Bei installiertem Brave zuerst den oben genannten Browserwechsel prüfen.

## Was geprüft wurde

Siehe `TESTBERICHT_LINUX.md`. Automatisierte Tests und ein echter Linux-Backendstart sind erfolgt. Deine VMware-Grafik, Mikrofon-/Audioverbindung, Kontenanmeldungen und Desktop-Eingaben müssen im VM-Praxistest geprüft werden. Diese Ausgabe ist eine Linux-Testversion, keine Zusage vollständiger Hardware- oder Dienstkompatibilität.

Technische Referenzen: [Playwright-Browserinstallation](https://playwright.dev/python/docs/browsers), [X11-Steuerung](https://github.com/jordansissel/xdotool), [Bildschirmaufnahme](https://python-mss.readthedocs.io/latest/examples.html), [Cinnamon-Bildschirmsperre](https://github.com/linuxmint/cinnamon-screensaver).
