#!/usr/bin/env bash
set -Eeuo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
umask 077
if [[ ! -x .venv/bin/python ]]; then
  echo "Python-Umgebung fehlt. Bitte zuerst: bash INSTALLIEREN.sh" >&2
  exit 1
fi
.venv/bin/python jarvis_linux.py stop
.venv/bin/python jarvis_updater.py "$@"
echo "Updateprüfung abgeschlossen. Starten: bash STARTEN.sh"
