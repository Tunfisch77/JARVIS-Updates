#!/usr/bin/env bash
set -Eeuo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
umask 077
trap 'echo "Installation gestoppt (Zeile $LINENO). Die Fehlermeldung darüber ist entscheidend. Nach Behebung INSTALLIEREN.sh erneut starten; vorhandene Daten bleiben erhalten." >&2' ERR
skip_system=0
no_input=0
for arg in "$@"; do
  case "$arg" in --skip-system) skip_system=1;; --no-input) no_input=1;; *) echo "Unbekannte Option: $arg" >&2; exit 1;; esac
done
if [[ "$EUID" -eq 0 ]]; then
  echo "Bitte als normaler Mint-Benutzer starten, ohne sudo vor INSTALLIEREN.sh." >&2
  exit 1
fi
if [[ "$(uname -s)" != Linux ]]; then echo "Dieses Paket benötigt Linux." >&2; exit 1; fi
# Installation belongs in the Linux home directory, not a Windows shared folder.
if [[ "$PWD" == /mnt/hgfs/* || "$PWD" == /media/* ]]; then
  echo "Den JARVIS-Ordner zuerst in deinen persönlichen Linux-Ordner kopieren." >&2
  exit 1
fi
if [[ -x .venv/bin/python ]] && .venv/bin/python -c 'import psutil' 2>/dev/null; then
  .venv/bin/python jarvis_linux.py stop
fi
if [[ "$skip_system" == 0 ]]; then
  sudo apt-get update
  sudo apt-get install -y python3 python3-venv python3-pip xdg-utils xdotool wmctrl libsecret-1-0 libglib2.0-bin
fi
python3 -c 'import sys; assert (3,11) <= sys.version_info[:2] < (3,14), "Python 3.11–3.13 benötigt; Mint 22 verwendet Python 3.12."'
if [[ ! -x .venv/bin/python ]]; then python3 -m venv .venv; fi
.venv/bin/python -m pip install -r requirements-linux-lock.txt
.venv/bin/python -m pip check
if [[ "$skip_system" == 0 ]]; then
  sudo "${PWD}/.venv/bin/python" -m playwright install-deps chromium
fi
.venv/bin/python -m playwright install chromium
if [[ ! -f .env ]]; then cp -- .env.example .env; fi
chmod 600 .env
if [[ "$no_input" == 0 ]]; then
  .venv/bin/python jarvis_linux.py configure
fi
.venv/bin/python jarvis_linux.py shortcut
.venv/bin/python linux_diagnostics.py --browser
printf '\nInstallation abgeschlossen. Starten mit: bash STARTEN.sh\n'
