"""Linux launcher, background process ownership and local configuration."""
from __future__ import annotations

import argparse
import contextlib
import fcntl
import getpass
import hashlib
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
import webbrowser

VERSION = "15.2.0"
ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
PORT = 8017
URL = f"http://127.0.0.1:{PORT}"
IDENTITY = hashlib.sha256(str(ROOT).encode()).hexdigest()[:16]


class LaunchError(RuntimeError):
    pass


@contextlib.contextmanager
def lock_file(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with path.open("a+") as handle:
        try:
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise LaunchError("JARVIS führt bereits einen Start-, Stopp- oder Updatevorgang aus.") from exc
        try:
            yield handle
        finally:
            fcntl.flock(handle, fcntl.LOCK_UN)


def read_server() -> dict:
    try:
        # Local requests must not go through an environment HTTP proxy.
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(URL + "/version", timeout=1) as response:
            return json.loads(response.read(4096))
    except (OSError, ValueError, urllib.error.URLError):
        return {}


def same_installation(server: dict) -> bool:
    return server.get("edition") == "linux" and server.get("installation_id") == IDENTITY


def owned_process():
    import psutil
    try:
        info = json.loads((DATA / "linux-server.json").read_text())
        process = psutil.Process(int(info["pid"]))
        if abs(process.create_time() - float(info["created"])) > 0.01:
            return None
        command = process.cmdline()
        if str(ROOT / "jarvis_linux.py") not in command or "serve" not in command:
            return None
        if process.status() == psutil.STATUS_ZOMBIE:
            return None
        return process
    except (OSError, ValueError, KeyError, TypeError, psutil.Error):
        return None


def start(*, browser: bool = True) -> None:
    with lock_file(DATA / "linux-launcher.lock"):
        server = read_server()
        if server and not same_installation(server):
            raise LaunchError("Port 8017 gehört einer anderen Installation. Diese zuerst beenden.")
        if server and server.get("version") != VERSION:
            raise LaunchError("Eine ältere JARVIS-Version läuft noch. STOPPEN.sh und danach STARTEN.sh ausführen.")
        if not server:
            if (ROOT / ".update.lock").exists():
                raise LaunchError("Ein Update läuft. Bitte dessen Abschluss abwarten.")
            with socket.socket() as probe:
                if probe.connect_ex(("127.0.0.1", PORT)) == 0:
                    raise LaunchError("Port 8017 ist belegt. Es wurde kein zweiter Server gestartet.")
            if owned_process():
                raise LaunchError("JARVIS startet noch oder reagiert nicht. STATUS.sh und data/linux-server.log prüfen.")
            log = DATA / "linux-server.log"
            if log.exists() and log.stat().st_size > 5 * 1024 * 1024:
                log.replace(DATA / "linux-server.previous.log")
            with log.open("ab") as output:
                process = subprocess.Popen([sys.executable, str(ROOT / "jarvis_linux.py"), "serve"],
                                           cwd=ROOT, stdin=subprocess.DEVNULL, stdout=output,
                                           stderr=subprocess.STDOUT, start_new_session=True)
            deadline = time.monotonic() + 30
            while time.monotonic() < deadline:
                if process.poll() is not None:
                    raise LaunchError("JARVIS konnte nicht starten. DIAGNOSE.sh ausführen; Details in data/linux-server.log.")
                server = read_server()
                if same_installation(server) and server.get("version") == VERSION:
                    break
                time.sleep(0.25)
            else:
                # Terminate only the exact child created by this call.
                process.terminate()
                try:
                    process.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    pass
                raise LaunchError("JARVIS war nach 30 Sekunden nicht bereit. DIAGNOSE.sh ausführen.")
        print(f"JARVIS Linux v{VERSION} läuft: {URL}")
        print("Backend läuft im Hintergrund. Zum Beenden: bash STOPPEN.sh")
        if browser:
            if not (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")):
                print("Kein grafischer Desktop erkannt. Oberfläche lokal im Browser öffnen.")
            elif not webbrowser.open(URL, new=2):
                print(f"Bitte {URL} im Browser öffnen.")


def stop() -> None:
    import psutil
    with lock_file(DATA / "linux-launcher.lock"):
        process = owned_process()
        if process is None:
            if read_server():
                raise LaunchError("Der laufende Server gehört nicht zu diesem Launcher. Bitte in dessen Startfenster beenden.")
            print("JARVIS läuft nicht.")
            return
        process.terminate()  # SIGTERM lets Uvicorn finish the FastAPI lifespan.
        try:
            process.wait(timeout=20)
        except psutil.TimeoutExpired as exc:
            raise LaunchError("JARVIS beendet noch laufende Arbeit. Bitte kurz warten und STATUS.sh prüfen.") from exc
        print("JARVIS wurde sauber beendet.")


def serve() -> None:
    import psutil
    import uvicorn
    with lock_file(DATA / "linux-server.lock"):
        if (ROOT / ".update.lock").exists():
            raise LaunchError("Während eines Updates wird kein Server gestartet.")
        process = psutil.Process()
        marker = DATA / "linux-server.json"
        marker.write_text(json.dumps({"pid": process.pid, "created": process.create_time()}))
        try:
            uvicorn.run("app:app", host="127.0.0.1", port=PORT, access_log=False,
                        timeout_graceful_shutdown=12, log_level="warning")
        finally:
            marker.unlink(missing_ok=True)


def configure() -> None:
    from dotenv import dotenv_values, set_key
    config = ROOT / ".env"
    if not config.exists():
        # Creation is exclusive so a concurrent installer cannot overwrite it.
        try:
            with config.open("x") as output:
                output.write((ROOT / ".env.example").read_text())
        except FileExistsError:
            pass
    config.chmod(0o600)
    if not sys.stdin.isatty():
        print("API-Schlüssel später lokal eintragen: bash API_SCHLUESSEL_EINTRAGEN.sh")
        return
    existing = bool(dotenv_values(config).get("OPENAI_API_KEY"))
    prompt = "Neuer OpenAI-API-Schlüssel (Enter = vorhandenen behalten): " if existing else "OpenAI-API-Schlüssel (Eingabe unsichtbar, Enter = später): "
    key = getpass.getpass(prompt).strip()
    if key:
        if any(c.isspace() for c in key):
            raise LaunchError("Der API-Schlüssel darf keine Leerzeichen oder Zeilenumbrüche enthalten.")
        set_key(str(config), "OPENAI_API_KEY", key)
        config.chmod(0o600)
        print("Schlüssel lokal gespeichert. Einen laufenden JARVIS danach neu starten.")


def desktop_entry(*, background: bool = False) -> str:
    path = str(ROOT / "STARTEN.sh")
    if "\n" in path or "\r" in path:
        raise LaunchError("Der Installationspfad darf keine Zeilenumbrüche enthalten.")
    # Desktop Entry Exec quoting, including literal field-code percent signs.
    escaped = path.replace("\\", "\\\\").replace('"', '\\"').replace("`", "\\`").replace("$", "\\$").replace("%", "%%")
    suffix = " --no-browser" if background else ""
    return ("[Desktop Entry]\nType=Application\nName=JARVIS Linux\n"
            f'Exec=bash "{escaped}"{suffix}\n'
            "Icon=audio-input-microphone\nTerminal=false\nCategories=Utility;\n"
            "X-GNOME-Autostart-enabled=true\nX-GNOME-Autostart-Delay=10\n")


def install_shortcut() -> None:
    target = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local/share") / "applications/jarvis-linux.desktop"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(desktop_entry())
    target.chmod(0o700)
    print("Startmenü-Eintrag JARVIS Linux angelegt.")


def autostart(enable: bool) -> None:
    target = Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config") / "autostart/jarvis-linux.desktop"
    if enable:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(desktop_entry(background=True))
        target.chmod(0o600)
    else:
        target.unlink(missing_ok=True)
    print("Autostart nach der Desktop-Anmeldung " + ("aktiviert." if enable else "deaktiviert."))


def main() -> int:
    parser = argparse.ArgumentParser(description="JARVIS Linux starten, stoppen und einrichten")
    parser.add_argument("command", choices=["start", "stop", "status", "serve", "configure", "shortcut", "autostart-on", "autostart-off"])
    parser.add_argument("--no-browser", action="store_true")
    args = parser.parse_args()
    os.umask(0o077)
    if not sys.platform.startswith("linux"):
        raise LaunchError("Dieser Launcher ist für Linux vorgesehen.")
    if args.command == "start": start(browser=not args.no_browser)
    elif args.command == "stop": stop()
    elif args.command == "serve": serve()
    elif args.command == "configure": configure()
    elif args.command == "shortcut": install_shortcut()
    elif args.command.startswith("autostart-"): autostart(args.command.endswith("-on"))
    else:
        server = read_server()
        print(json.dumps({"running": same_installation(server), "url": URL, "server": server}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (LaunchError, OSError) as exc:
        print(f"JARVIS: {exc}", file=sys.stderr)
        sys.exit(1)
    except KeyboardInterrupt:
        sys.exit(130)
