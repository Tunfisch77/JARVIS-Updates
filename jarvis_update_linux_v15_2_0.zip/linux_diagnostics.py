"""Local checks: never sends account messages or prints credentials."""
from __future__ import annotations
import argparse
import importlib.util
import json
import os
from pathlib import Path
import platform
import shutil
import sqlite3
import sys
import tempfile

ROOT = Path(__file__).resolve().parent


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--browser", action="store_true", help="sandboxed blank-page browser self-test")
    args = parser.parse_args()
    checks = []
    def check(name, ok, hint="", required=True):
        checks.append(dict(name=name, ok=bool(ok), hint=hint, required=required))
    for module in ["fastapi", "uvicorn", "httpx", "dotenv", "psutil", "playwright", "mss", "google.auth", "msal"]:
        try:
            present = importlib.util.find_spec(module) is not None
        except ModuleNotFoundError:
            present = False
        check(module, present, "Bei Fehler: bash INSTALLIEREN.sh")
    check("Linux", sys.platform.startswith("linux"))
    check("Python 3.11–3.13", (3, 11) <= sys.version_info[:2] < (3, 14))
    check("Speicherplatz", shutil.disk_usage(ROOT).free > 1024 ** 3, "Mindestens 1 GB frei halten.")
    for command in ["xdg-open", "xdotool", "wmctrl"]:
        check(command, bool(shutil.which(command)), "INSTALLIEREN.sh installiert die Systempakete.")
    from linux_desktop import session_status
    session = session_status()
    check("X11-Desktop", session["session"] == "x11", session["hint"], required=False)
    if importlib.util.find_spec("dotenv"):
        from dotenv import dotenv_values, load_dotenv
        load_dotenv(ROOT / ".env")
        config = dotenv_values(ROOT / ".env")
        check("API-Schlüssel eingetragen", bool(config.get("OPENAI_API_KEY") or os.getenv("OPENAI_API_KEY")),
              "Lokal eintragen: bash API_SCHLUESSEL_EINTRAGEN.sh; Gültigkeit/Zugriff noch nicht online geprüft.", required=False)
    database = ROOT / "data/jarvis.db"
    if database.exists():
        try:
            with sqlite3.connect(database.as_uri() + "?mode=ro", uri=True, timeout=3) as db:
                ok = db.execute("PRAGMA quick_check").fetchone()[0] == "ok"
            check("Datenbank", ok)
        except sqlite3.Error:
            check("Datenbank", False, "JARVIS sauber stoppen und erneut prüfen.")
    if args.browser and importlib.util.find_spec("playwright"):
        try:
            from playwright.sync_api import sync_playwright
            from browser_runtime import launch_persistent_browser
            with tempfile.TemporaryDirectory(prefix="jarvis-browser-check-") as directory:
                with sync_playwright() as playwright:
                    context = launch_persistent_browser(playwright, directory,
                              preference=os.getenv("JARVIS_BROWSER_CHANNEL", "chromium"), headless=True)
                    try:
                        page = context.new_page()
                        page.set_content("<title>JARVIS Linux Browser Test</title>")
                        check("Browser mit Sandbox", page.title() == "JARVIS Linux Browser Test")
                    finally:
                        context.close()
        except Exception:
            check("Browser mit Sandbox", False,
                  "Chromium startet nicht. Bei installiertem Brave JARVIS_BROWSER_CHANNEL=brave in .env setzen und erneut prüfen. Die Browser-Sandbox bleibt aktiviert.")
    for item in checks:
        state = "OK" if item["ok"] else "FEHLER" if item["required"] else "HINWEIS"
        print(f"[{state}] {item['name']}" + (f" – {item['hint']}" if not item["ok"] else ""))
    target = ROOT / "data/linux-diagnose.json"
    target.parent.mkdir(mode=0o700, exist_ok=True)
    target.write_text(json.dumps({"version": "15.2.0", "os": platform.platform(), "session": session, "checks": checks}, ensure_ascii=False, indent=2))
    target.chmod(0o600)
    print("Bericht: data/linux-diagnose.json (enthält keine Schlüssel oder Nachrichten)")
    return 1 if any(c["required"] and not c["ok"] for c in checks) else 0


if __name__ == "__main__":
    os.umask(0o077)
    raise SystemExit(main())
