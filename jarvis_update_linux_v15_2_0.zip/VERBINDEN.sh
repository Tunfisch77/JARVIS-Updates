#!/usr/bin/env bash
set -Eeuo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
umask 077
if [[ ! -x .venv/bin/python ]]; then
  echo "Python-Umgebung fehlt. Bitte zuerst: bash INSTALLIEREN.sh" >&2
  exit 1
fi
service="${1:-}"
case "$service" in whatsapp|gmail|outlook|snapchat) ;; *) echo "Dienst angeben: whatsapp, gmail, outlook oder snapchat" >&2; exit 1;; esac
was_running="$(.venv/bin/python -c 'import jarvis_linux as j; print(int(j.same_installation(j.read_server())))')"
finish() {
  result=$?
  trap - EXIT
  if [[ "$was_running" == 1 ]]; then .venv/bin/python jarvis_linux.py start --no-browser || true; fi
  if [[ -t 0 ]]; then read -r -p "Enter zum Schließen ..." || true; fi
  exit "$result"
}
if [[ "$was_running" == 1 ]]; then .venv/bin/python jarvis_linux.py stop; fi
trap finish EXIT
.venv/bin/python integrations_setup.py "$service"
