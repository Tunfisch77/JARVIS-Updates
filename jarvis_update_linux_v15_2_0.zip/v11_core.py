from __future__ import annotations

import importlib.util
import hashlib
import json
import os
import platform
import re
import secrets
import shutil
import subprocess
import threading
import time
import webbrowser
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path, PurePosixPath
from typing import Any, Final


@dataclass(frozen=True)
class ComponentSpec:
    number: int
    key: str
    name: str
    category: str
    repository: str
    purpose: str
    adapter: str
    package: str = ""
    executable: str = ""
    risk: str = "low"
    default_enabled: bool = False
    setup: str = "optional"


COMPONENTS: Final[tuple[ComponentSpec, ...]] = (
    ComponentSpec(1, "ufo2", "Microsoft UFO²", "desktop", "https://github.com/microsoft/UFO", "Appübergreifende Windows-Missionen mit Ergebnisprüfung.", "builtin", risk="high"),
    ComponentSpec(2, "openadapt", "OpenAdapt", "desktop", "https://github.com/OpenAdaptAI/OpenAdapt", "Vorgeführte Abläufe aufzeichnen und wiederholen.", "openadapt", package="openadapt", risk="high"),
    ComponentSpec(3, "pywinauto", "pywinauto", "desktop", "https://github.com/pywinauto/pywinauto", "Windows-Fenster und echte UI-Elemente steuern.", "pywinauto", package="pywinauto", risk="medium", default_enabled=True, setup="desktop"),
    ComponentSpec(4, "playwright", "Playwright Python", "desktop", "https://github.com/microsoft/playwright-python", "Webseiten zuverlässig über DOM-Elemente bedienen.", "playwright", package="playwright", risk="medium", default_enabled=True, setup="core"),
    ComponentSpec(5, "omniparser", "OmniParser", "desktop", "https://github.com/microsoft/OmniParser", "Bedienelemente auf Screenshots als visueller Fallback erkennen.", "service", risk="high"),
    ComponentSpec(6, "pywinrt", "PyWinRT", "windows", "https://github.com/pywinrt/pywinrt", "Windows-Benachrichtigungen, Bluetooth und Capture-APIs.", "winrt", package="winrt-Windows.Foundation", risk="medium", setup="desktop"),
    ComponentSpec(7, "openai_agents", "OpenAI Agents SDK", "agents", "https://github.com/openai/openai-agents-python", "Spezialisierte Agenten mit Übergaben und Werkzeugen.", "agents", package="agents", default_enabled=True, setup="agents"),
    ComponentSpec(8, "realtime_agents", "OpenAI Realtime Agents", "agents", "https://github.com/openai/openai-realtime-agents", "Schnelle Sprache und Supervisor-Architektur.", "builtin", default_enabled=True),
    ComponentSpec(9, "langgraph", "LangGraph", "agents", "https://github.com/langchain-ai/langgraph", "Missionen pausieren, fortsetzen und checkpointen.", "langgraph", package="langgraph", setup="agents"),
    ComponentSpec(10, "tenacity", "Tenacity", "agents", "https://github.com/jd/tenacity", "Temporäre Fehler kontrolliert erneut versuchen.", "tenacity", package="tenacity", default_enabled=True, setup="core"),
    ComponentSpec(11, "mem0", "Mem0", "memory", "https://github.com/mem0ai/mem0", "Persönliches Langzeitgedächtnis mit Extraktion.", "mem0", package="mem0", risk="medium", setup="memory"),
    ComponentSpec(12, "sqlite_vec", "sqlite-vec", "memory", "https://github.com/asg017/sqlite-vec", "Semantische Suche direkt in der vorhandenen SQLite-Datenbank.", "sqlite_vec", package="sqlite_vec", setup="memory"),
    ComponentSpec(13, "graphiti", "Graphiti", "memory", "https://github.com/getzep/graphiti", "Zeitabhängige Beziehungen und Wissensgraphen.", "graphiti_core", package="graphiti-core", risk="medium", setup="memory"),
    ComponentSpec(14, "rapidfuzz", "RapidFuzz", "memory", "https://github.com/rapidfuzz/RapidFuzz", "Kontakte und Befehle trotz Schreib- oder Hörfehlern erkennen.", "rapidfuzz", package="rapidfuzz", default_enabled=True, setup="core"),
    ComponentSpec(15, "phonenumbers", "python-phonenumbers", "memory", "https://github.com/daviddrysdale/python-phonenumbers", "Telefonnummern prüfen und international normalisieren.", "phonenumbers", package="phonenumbers", default_enabled=True, setup="core"),
    ComponentSpec(16, "dateparser", "dateparser", "memory", "https://github.com/scrapinghub/dateparser", "Natürliche deutsche Datumsangaben verstehen.", "dateparser", package="dateparser", default_enabled=True, setup="core"),
    ComponentSpec(17, "markitdown", "MarkItDown", "files", "https://github.com/microsoft/markitdown", "Office-, PDF-, Mail- und Archivdateien in Text umwandeln.", "markitdown", package="markitdown", default_enabled=True, setup="files"),
    ComponentSpec(18, "watchdog", "Watchdog", "files", "https://github.com/gorakhargosh/watchdog", "Neue Downloads und geänderte Dateien erkennen.", "watchdog", package="watchdog", setup="files"),
    ComponentSpec(19, "openwakeword", "openWakeWord", "voice", "https://github.com/dscripka/openWakeWord", "Lokales Wakeword „Hey JARVIS“.", "openwakeword", package="openwakeword", setup="voice"),
    ComponentSpec(20, "silero_vad", "Silero VAD", "voice", "https://github.com/snakers4/silero-vad", "Lokal Beginn und Ende von Sprache erkennen.", "torch", package="torch", setup="voice"),
    ComponentSpec(21, "rnnoise", "RNNoise", "voice", "https://github.com/xiph/rnnoise", "Lüfter, Tastatur und Hintergrundgeräusche filtern.", "rnnoise", package="pyrnnoise", setup="voice"),
    ComponentSpec(22, "faster_whisper", "faster-whisper", "voice", "https://github.com/SYSTRAN/faster-whisper", "Lokale deutsche Spracherkennung als Offline-Fallback.", "faster_whisper", package="faster-whisper", setup="voice"),
    ComponentSpec(23, "piper", "Piper", "voice", "https://github.com/OHF-Voice/piper1-gpl", "Lokale Sprachausgabe ohne Cloud.", "piper", executable="piper", setup="voice"),
    ComponentSpec(24, "sherpa_onnx", "sherpa-onnx", "voice", "https://github.com/k2-fsa/sherpa-onnx", "Offline-STT, TTS, Wakeword, VAD und Sprechererkennung.", "sherpa_onnx", package="sherpa-onnx", setup="voice"),
    ComponentSpec(25, "openvoiceos", "OpenVoiceOS", "voice", "https://github.com/OpenVoiceOS/ovos-core", "Skills und Offline-Sprachassistent als optionaler Dienst.", "ovos_core", package="ovos-core", risk="medium", setup="voice"),
    ComponentSpec(26, "keyring", "keyring", "security", "https://github.com/jaraco/keyring", "Secrets im Windows Credential Manager speichern.", "keyring", package="keyring", default_enabled=True, setup="core"),
    ComponentSpec(27, "sqlcipher", "SQLCipher", "security", "https://github.com/sqlcipher/sqlcipher", "Lokale Kontakte und Erinnerungen verschlüsseln.", "sqlcipher3", package="sqlcipher3-wheels", risk="medium", setup="security"),
    ComponentSpec(28, "apscheduler", "APScheduler", "automation", "https://github.com/agronholm/apscheduler", "Routinen nach Neustarts zuverlässig planen.", "apscheduler", package="apscheduler", default_enabled=True, setup="core"),
    ComponentSpec(29, "mcp_sdk", "MCP Python SDK", "plugins", "https://github.com/modelcontextprotocol/python-sdk", "Externe Fähigkeiten als standardisierte Werkzeuge anbinden.", "mcp", package="mcp", risk="medium", setup="agents"),
    ComponentSpec(30, "pluggy", "Pluggy", "plugins", "https://github.com/pytest-dev/pluggy", "Lokales, kontrolliertes Erweiterungssystem.", "pluggy", package="pluggy", default_enabled=True, setup="core"),
    ComponentSpec(31, "langfuse", "Langfuse", "observability", "https://github.com/langfuse/langfuse", "Agentenentscheidungen und Fehler im Entwicklungsmodus nachvollziehen.", "langfuse", package="langfuse", risk="medium", setup="dev"),
    ComponentSpec(32, "litellm", "LiteLLM", "agents", "https://github.com/BerriAI/litellm", "Modelle abhängig von Kosten, Tempo und Aufgabe routen.", "litellm", package="litellm", risk="medium", setup="agents"),
    ComponentSpec(33, "ollama", "Ollama", "local_ai", "https://github.com/ollama/ollama", "Private und einfache Aufgaben lokal ausführen.", "service", executable="ollama", risk="medium", setup="local-ai"),
    ComponentSpec(34, "pywebview", "pywebview", "ui", "https://github.com/r0x0r/pywebview", "JARVIS als richtige Windows-App ohne Browserleiste starten.", "webview", package="pywebview", default_enabled=True, setup="desktop"),
    ComponentSpec(35, "fluent_ui", "Fluent UI", "ui", "https://github.com/microsoft/fluentui", "Klare Windows-nahe UI-Komponenten.", "frontend", default_enabled=True),
    ComponentSpec(36, "lottie", "Lottie Web", "ui", "https://github.com/airbnb/lottie-web", "Flüssige Zustandsanimationen.", "frontend", default_enabled=True),
    ComponentSpec(37, "tauri", "Tauri", "ui", "https://github.com/tauri-apps/tauri", "Optionale native Shell mit Tray und Updates.", "service", executable="cargo", risk="medium"),
    ComponentSpec(38, "mediapipe", "MediaPipe", "vision", "https://github.com/google-ai-edge/mediapipe", "Anwesenheit, Gesichter und Handgesten lokal erkennen.", "mediapipe", package="mediapipe", risk="medium", setup="vision"),
    ComponentSpec(39, "pycaw", "Pycaw", "windows", "https://github.com/AndreMiras/pycaw", "Windows-Lautstärke insgesamt und pro App steuern.", "pycaw", package="pycaw", default_enabled=True, setup="desktop"),
    ComponentSpec(40, "spotipy", "Spotipy", "media", "https://github.com/spotipy-dev/spotipy", "Spotify suchen, abspielen und Geräte auswählen.", "spotipy", package="spotipy", risk="medium", setup="media"),
    ComponentSpec(41, "home_assistant", "Home Assistant", "smart_home", "https://github.com/home-assistant/core", "Licht, Steckdosen, Sensoren und Szenen steuern.", "builtin", risk="high", default_enabled=True),
    ComponentSpec(42, "browser_use", "Browser Use", "experimental", "https://github.com/browser-use/browser-use", "Unbekannte Webseiten autonom bedienen.", "browser_use", package="browser-use", risk="high", setup="experimental"),
    ComponentSpec(43, "ui_tars", "UI-TARS Desktop", "experimental", "https://github.com/bytedance/UI-TARS-desktop", "Visueller Computer-Agent als optionaler externer Dienst.", "service", risk="critical"),
    ComponentSpec(44, "open_interpreter", "Open Interpreter", "experimental", "https://github.com/openinterpreter/open-interpreter", "Bestätigte Terminal- und Codeaktionen in einer Sandbox.", "interpreter", package="open-interpreter", risk="critical", setup="experimental"),
    ComponentSpec(45, "whatsapp_web_js", "whatsapp-web.js", "experimental", "https://github.com/wwebjs/whatsapp-web.js", "Nachrichten, Gruppen und Medien über einen optionalen lokalen Dienst.", "service", executable="node", risk="high", setup="experimental"),
)


DEFAULT_V11_SETTINGS: Final[dict[str, Any]] = {
    "safety_profile": "balanced",
    "desktop_control_enabled": False,
    "vision_fallback_enabled": False,
    "learning_mode_enabled": False,
    "offline_fallback_enabled": True,
    "allow_terminal": False,
    "allow_installs": False,
    "allow_deletes": False,
    "max_desktop_steps": 30,
    "require_confirmation_for_input": True,
    "emergency_hotkey": "CTRL+ALT+PAUSE",
}


def _module_available(module_name: str) -> bool:
    if not module_name:
        return False
    try:
        return importlib.util.find_spec(module_name) is not None
    except (ImportError, ModuleNotFoundError, ValueError):
        return False


class V11CapabilityManager:
    def __init__(self, state_store: Any, base_dir: Path) -> None:
        self.state_store = state_store
        self.base_dir = base_dir
        current = state_store.get_setting("v11_settings")
        if not isinstance(current, dict):
            state_store.set_setting("v11_settings", dict(DEFAULT_V11_SETTINGS))
        component_state = state_store.get_setting("v11_components")
        if not isinstance(component_state, dict):
            state_store.set_setting(
                "v11_components",
                {item.key: item.default_enabled for item in COMPONENTS},
            )

    def settings(self) -> dict[str, Any]:
        stored = self.state_store.get_setting("v11_settings", {})
        return {**DEFAULT_V11_SETTINGS, **(stored if isinstance(stored, dict) else {})}

    def update_settings(self, changes: dict[str, Any]) -> dict[str, Any]:
        allowed = set(DEFAULT_V11_SETTINGS)
        item = self.settings()
        for key, value in changes.items():
            if key not in allowed:
                continue
            item[key] = value
        profile = str(item.get("safety_profile") or "balanced")
        if profile not in {"strict", "balanced", "trusted", "developer"}:
            raise ValueError("Unbekanntes v11-Sicherheitsprofil.")
        item["safety_profile"] = profile
        item["max_desktop_steps"] = max(1, min(80, int(item.get("max_desktop_steps") or 30)))
        for key in (
            "desktop_control_enabled",
            "vision_fallback_enabled",
            "learning_mode_enabled",
            "offline_fallback_enabled",
            "allow_terminal",
            "allow_installs",
            "allow_deletes",
            "require_confirmation_for_input",
        ):
            item[key] = bool(item.get(key))
        if profile == "strict":
            item.update(
                {
                    "allow_terminal": False,
                    "allow_installs": False,
                    "allow_deletes": False,
                    "require_confirmation_for_input": True,
                }
            )
        self.state_store.set_setting("v11_settings", item)
        return item

    def _installed(self, component: ComponentSpec) -> bool:
        if component.adapter in {"builtin", "frontend"}:
            return True
        scripts_dir = "Scripts" if os.name == "nt" else "bin"
        executable_suffix = ".exe" if os.name == "nt" else ""
        isolated: dict[str, str] = {
            "open_interpreter": "open-interpreter",
            "openadapt": "openadapt",
            "openvoiceos": "ovos",
        }
        isolated_environment = isolated.get(component.key)
        if isolated_environment:
            environment_dir = self.base_dir / ".jarvis_envs" / isolated_environment
            python = environment_dir / scripts_dir / (
                "python.exe" if os.name == "nt" else "python"
            )
            browser_ready = (
                component.key != "openadapt"
                or (environment_dir / ".jarvis-playwright-ready").exists()
            )
            return (environment_dir / ".jarvis-installed").exists() and python.exists() and browser_ready
        if component.key == "whatsapp_web_js":
            return (
                shutil.which("node") is not None
                and (self.base_dir / "services" / "whatsapp-webjs" / "node_modules").is_dir()
            )
        if component.executable:
            local_command = (
                self.base_dir
                / ".venv"
                / scripts_dir
                / f"{component.executable}{executable_suffix}"
            )
            if local_command.exists():
                return True
        if component.adapter == "service":
            if component.executable:
                return shutil.which(component.executable) is not None
            return self._configured(component)
        if component.executable and shutil.which(component.executable):
            return True
        return _module_available(component.adapter)

    def _configured(self, component: ComponentSpec) -> bool:
        environment_requirements: dict[str, tuple[str, ...]] = {
            "langfuse": ("LANGFUSE_PUBLIC_KEY", "LANGFUSE_SECRET_KEY"),
            "spotipy": ("SPOTIPY_CLIENT_ID", "SPOTIPY_CLIENT_SECRET"),
            "home_assistant": ("HOME_ASSISTANT_URL", "HOME_ASSISTANT_TOKEN"),
            "ollama": ("OLLAMA_HOST",),
            "omniparser": ("OMNIPARSER_URL",),
            "ui_tars": ("UI_TARS_URL",),
            "whatsapp_web_js": ("JARVIS_WWEBJS_URL",),
        }
        names = environment_requirements.get(component.key)
        if not names:
            return True
        if component.key == "ollama":
            return bool(os.getenv("OLLAMA_HOST", "").strip()) or self._installed(component)
        return all(bool(os.getenv(name, "").strip()) for name in names)

    def list_components(self, query: str = "", category: str = "") -> list[dict[str, Any]]:
        enabled_state = self.state_store.get_setting("v11_components", {})
        if not isinstance(enabled_state, dict):
            enabled_state = {}
        needle = query.strip().casefold()
        selected_category = category.strip().casefold()
        results: list[dict[str, Any]] = []
        for component in COMPONENTS:
            if selected_category and component.category != selected_category:
                continue
            searchable = " ".join(
                (component.name, component.key, component.category, component.purpose, component.repository)
            ).casefold()
            if needle and needle not in searchable:
                continue
            installed = self._installed(component)
            configured = self._configured(component)
            item = asdict(component)
            item.update(
                {
                    "enabled": bool(enabled_state.get(component.key, component.default_enabled)),
                    "installed": installed,
                    "configured": configured,
                    "ready": installed and configured,
                    "status": "ready" if installed and configured else "setup_required",
                }
            )
            if os.name != "nt" and component.key in {"ufo2", "pywinauto", "pywinrt", "pycaw", "pywebview"}:
                item.update(enabled=False, ready=False, status="unsupported_platform",
                            setup_note="Windows-Modul; Linux verwendet Browser und X11-Adapter.")
            results.append(item)
        return results

    def set_component_enabled(self, key: str, enabled: bool) -> dict[str, Any]:
        component = next((item for item in COMPONENTS if item.key == key), None)
        if not component:
            raise KeyError("Unbekanntes v11-Modul.")
        if enabled and os.name != "nt" and key in {"ufo2", "pywinauto", "pywinrt", "pycaw", "pywebview"}:
            raise PermissionError("Dieses Modul ist in der Linux-Ausgabe nicht verfügbar.")
        settings = self.settings()
        if enabled and component.risk == "critical" and settings["safety_profile"] != "developer":
            raise PermissionError("Kritische Module lassen sich nur im Entwicklerprofil aktivieren.")
        current = self.state_store.get_setting("v11_components", {})
        if not isinstance(current, dict):
            current = {}
        current[key] = bool(enabled)
        self.state_store.set_setting("v11_components", current)
        return next(item for item in self.list_components() if item["key"] == key)

    def enable_all_ready(self) -> dict[str, Any]:
        settings = self.settings()
        current = self.state_store.get_setting("v11_components", {})
        if not isinstance(current, dict):
            current = {}
        enabled: list[str] = []
        already_enabled: list[str] = []
        not_ready: list[str] = []
        blocked: list[str] = []
        for item in self.list_components():
            key = str(item["key"])
            if not bool(item["ready"]):
                not_ready.append(key)
                continue
            if item["risk"] == "critical" and settings["safety_profile"] != "developer":
                blocked.append(key)
                continue
            if bool(item["enabled"]):
                already_enabled.append(key)
            else:
                enabled.append(key)
            current[key] = True
        self.state_store.set_setting("v11_components", current)
        return {
            "enabled": enabled,
            "already_enabled": already_enabled,
            "not_ready": not_ready,
            "blocked": blocked,
            "enabled_count": len(enabled),
            "active_ready_count": len(enabled) + len(already_enabled),
            "restart_required": False,
            "reconnect_recommended": True,
        }

    def overview(self) -> dict[str, Any]:
        items = self.list_components()
        return {
            "version": "15.2.0",
            "edition": "Agent OS",
            "platform": platform.system(),
            "components": {
                "total": len(items),
                "enabled": sum(bool(item["enabled"]) for item in items),
                "ready": sum(bool(item["ready"]) for item in items),
                "setup_required": sum(not bool(item["ready"]) for item in items),
                "high_risk_enabled": sum(
                    bool(item["enabled"]) and item["risk"] in {"high", "critical"} for item in items
                ),
            },
            "settings": self.settings(),
            "categories": sorted({item.category for item in COMPONENTS}),
        }

    def search(self, query: str) -> list[dict[str, str]]:
        needle = query.strip().casefold()
        if not needle:
            return []
        matches: list[dict[str, str]] = []
        for item in self.list_components(query):
            matches.append(
                {
                    "kind": "module",
                    "key": item["key"],
                    "title": item["name"],
                    "subtitle": f"{item['category']} · {item['purpose']}",
                }
            )
        for key, value in self.settings().items():
            label = key.replace("_", " ")
            if needle in label.casefold() or needle in str(value).casefold():
                matches.append(
                    {
                        "kind": "setting",
                        "key": key,
                        "title": label,
                        "subtitle": str(value),
                    }
                )
        return matches[:100]


class DesktopControlError(RuntimeError):
    pass


class DesktopStopRequested(DesktopControlError):
    pass


SAFE_DESKTOP_ACTIONS: Final = {
    "wait",
    "open",
    "focus_window",
    "click_control",
    "click_point",
    "type_text",
    "press",
    "hotkey",
    "scroll",
}

SAFE_PROJECT_SUFFIXES: Final = {
    ".c",
    ".cfg",
    ".conf",
    ".cpp",
    ".cs",
    ".css",
    ".csv",
    ".go",
    ".h",
    ".hpp",
    ".htm",
    ".html",
    ".ini",
    ".java",
    ".js",
    ".json",
    ".jsx",
    ".lua",
    ".md",
    ".mjs",
    ".php",
    ".properties",
    ".py",
    ".rb",
    ".rs",
    ".scss",
    ".sql",
    ".svg",
    ".toml",
    ".ts",
    ".tsx",
    ".txt",
    ".vue",
    ".xml",
    ".yaml",
    ".yml",
}
SAFE_PROJECT_NAMES: Final = {
    ".editorconfig",
    ".gitignore",
    "dockerfile",
    "license",
    "makefile",
    "readme",
}
SENSITIVE_PROJECT_NAMES: Final = {
    ".env",
    ".npmrc",
    ".pypirc",
    "authorized_keys",
    "credentials",
    "gmail_token.json",
    "google_client_secret.json",
    "id_dsa",
    "id_ecdsa",
    "id_ed25519",
    "id_rsa",
    "outlook_token_cache.json",
    "secrets.json",
}
WINDOWS_RESERVED_NAMES: Final = {
    "aux",
    "clock$",
    "con",
    "nul",
    "prn",
    *(f"com{index}" for index in range(1, 10)),
    *(f"lpt{index}" for index in range(1, 10)),
}


class DesktopController:
    """Windows desktop control with a hard stop and no implicit shell execution."""

    def __init__(self, state_store: Any, capability_manager: V11CapabilityManager, base_dir: Path) -> None:
        self.state_store = state_store
        self.capability_manager = capability_manager
        self.base_dir = base_dir
        self._stop = threading.Event()
        self._lock = threading.Lock()
        self._state_lock = threading.Lock()
        self._active_run_id = ""
        self._active_step = 0
        self._active_total = 0
        self.stop_file = base_dir / "data" / "DESKTOP_STOP"

    def validate_plan(self, actions: list[dict[str, Any]]) -> list[dict[str, Any]]:
        settings = self.capability_manager.settings()
        maximum = int(settings["max_desktop_steps"])
        if not 1 <= len(actions) <= maximum:
            raise DesktopControlError(f"Ein Desktop-Plan benötigt 1 bis {maximum} Schritte.")
        cleaned: list[dict[str, Any]] = []
        active_window = ""
        for index, raw in enumerate(actions):
            action = str(raw.get("action") or "").strip().casefold()
            if action not in SAFE_DESKTOP_ACTIONS:
                raise DesktopControlError(f"Desktop-Schritt {index + 1} ist nicht freigegeben.")
            item = {"action": action}
            if action == "wait":
                item["seconds"] = max(0.05, min(10.0, float(raw.get("seconds") or 0.5)))
            elif action == "open":
                target = str(raw.get("target") or "").strip()
                if not target or len(target) > 2_000:
                    raise DesktopControlError(f"Desktop-Schritt {index + 1} enthält kein gültiges Ziel.")
                item["target"] = target
                if not re.match(r"^https?://", target, flags=re.I):
                    active_window = Path(target).stem[:300]
            elif action in {"focus_window", "click_control"}:
                item["window"] = str(raw.get("window") or active_window).strip()[:300]
                item["control"] = str(raw.get("control") or "").strip()[:300]
                if not item["window"]:
                    raise DesktopControlError(f"Desktop-Schritt {index + 1} benötigt einen Fensternamen.")
                if action == "click_control" and not item["control"]:
                    raise DesktopControlError(f"Desktop-Schritt {index + 1} benötigt den Namen eines Bedienelements.")
                active_window = item["window"]
            elif action == "click_point":
                item["x"] = max(0, min(20_000, int(raw.get("x") or 0)))
                item["y"] = max(0, min(20_000, int(raw.get("y") or 0)))
                item["button"] = str(raw.get("button") or "left").casefold()
                if item["button"] not in {"left", "right", "middle"}:
                    raise DesktopControlError("Unbekannte Maustaste.")
            elif action == "type_text":
                text = str(raw.get("text") or "")
                if not text or len(text) > 10_000:
                    raise DesktopControlError(f"Desktop-Schritt {index + 1} enthält keinen gültigen Text.")
                item["text"] = text
            elif action == "press":
                item["key"] = str(raw.get("key") or "").strip().casefold()[:40]
                if not re.fullmatch(r"[a-z0-9_+ -]{1,40}", item["key"]):
                    raise DesktopControlError("Ungültige Taste.")
            elif action == "hotkey":
                keys = raw.get("keys") if isinstance(raw.get("keys"), list) else []
                item["keys"] = [str(key).strip().casefold()[:30] for key in keys[:5]]
                if not item["keys"]:
                    raise DesktopControlError("Für den Hotkey fehlen Tasten.")
            elif action == "scroll":
                item["amount"] = max(-20, min(20, int(raw.get("amount") or 0)))
            cleaned.append(item)
        return cleaned

    @staticmethod
    def _safe_folder_name(raw_name: str) -> str:
        name = str(raw_name or "").strip()
        if (
            not name
            or len(name) > 120
            or name in {".", ".."}
            or any(char in name for char in '<>:"/\\|?*')
            or any(ord(char) < 32 for char in name)
            or name.endswith((" ", "."))
            or name.split(".", 1)[0].casefold() in WINDOWS_RESERVED_NAMES
        ):
            raise DesktopControlError("Der gewünschte Projektordnername ist unter Windows nicht sicher.")
        return name

    @staticmethod
    def _safe_project_path(raw_path: str) -> str:
        value = str(raw_path or "").replace("\\", "/").strip().strip("/")
        if not value or len(value) > 500 or "\x00" in value:
            raise DesktopControlError("Das Projekt enthält einen ungültigen Dateipfad.")
        path = PurePosixPath(value)
        if path.is_absolute() or any(part in {"", ".", ".."} for part in path.parts):
            raise DesktopControlError("Ein Projektpfad würde den neuen Ordner verlassen.")
        for part in path.parts:
            if (
                ":" in part
                or any(ord(char) < 32 for char in part)
                or part.endswith((" ", "."))
                or part.split(".", 1)[0].casefold() in WINDOWS_RESERVED_NAMES
            ):
                raise DesktopControlError("Das Projekt enthält einen unter Windows ungültigen Dateipfad.")
        name = path.name.casefold()
        lowered_parts = {part.casefold() for part in path.parts}
        if (
            name in SENSITIVE_PROJECT_NAMES
            or name.startswith(".env")
            or name.startswith(("credentials.", "secrets."))
            or path.suffix.casefold() in {".exe", ".bat", ".cmd", ".com", ".dll", ".msi", ".ps1", ".key", ".pem", ".p12", ".pfx"}
            or lowered_parts & {".aws", ".gnupg", ".ssh", "secrets"}
        ):
            raise DesktopControlError("Geheime oder ausführbare Projektdateien dürfen nicht automatisch erzeugt werden.")
        if path.suffix.casefold() not in SAFE_PROJECT_SUFFIXES and name not in SAFE_PROJECT_NAMES:
            raise DesktopControlError(f"Nicht freigegebener Projektdateityp: {path.suffix or 'ohne Endung'}")
        return path.as_posix()

    @classmethod
    def project_destination(cls, raw_target_path: str) -> Path:
        value = str(raw_target_path or "").strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
            value = value[1:-1].strip()
        if not value:
            raise DesktopControlError(
                "Der Zielpfad fehlt. Bitte gib den vollständigen Pfad inklusive neuem Projektordner an."
            )
        if len(value) > 1_000 or "\x00" in value or any(char in value for char in "*?"):
            raise DesktopControlError("Der angegebene Projektzielpfad ist ungültig.")
        expanded = os.path.expandvars(value)
        candidate = Path(expanded).expanduser()
        if not candidate.is_absolute():
            raise DesktopControlError(
                "Bitte gib einen vollständigen absoluten Zielpfad inklusive neuem Projektordner an."
            )
        try:
            destination = candidate.resolve(strict=False)
        except OSError as exc:
            raise DesktopControlError("Der angegebene Projektzielpfad konnte nicht aufgelöst werden.") from exc
        if destination == destination.parent:
            raise DesktopControlError("Ein Laufwerks- oder Dateisystemstamm darf kein Projektordner sein.")
        cls._safe_folder_name(destination.name)
        return destination

    def create_project(
        self,
        target_path: str,
        files: list[dict[str, Any]],
        *,
        open_after_create: bool = True,
    ) -> dict[str, Any]:
        """Create a new text/code project atomically at an explicit absolute path."""
        destination = self.project_destination(target_path)
        name = destination.name
        if not files or len(files) > 30:
            raise DesktopControlError("Ein Projekt benötigt 1 bis 30 sichere Text- oder Codedateien.")
        normalized: list[tuple[str, bytes]] = []
        seen: set[str] = set()
        total_bytes = 0
        for raw in files:
            relative = self._safe_project_path(str(raw.get("path") or ""))
            key = relative.casefold()
            if key in seen:
                raise DesktopControlError(f"Doppelter Projektpfad: {relative}")
            seen.add(key)
            data = raw.get("data")
            if isinstance(data, str):
                encoded = data.encode("utf-8")
            elif isinstance(data, bytes):
                encoded = data
                try:
                    encoded.decode("utf-8")
                except UnicodeDecodeError as exc:
                    raise DesktopControlError(f"Die Projektdatei {relative} ist kein UTF-8-Text.") from exc
            else:
                content = raw.get("content")
                if not isinstance(content, str):
                    raise DesktopControlError(f"Für die Projektdatei {relative} fehlt der Inhalt.")
                encoded = content.encode("utf-8")
            if len(encoded) > 2 * 1024 * 1024:
                raise DesktopControlError(f"Die Projektdatei {relative} ist größer als 2 MB.")
            total_bytes += len(encoded)
            if total_bytes > 10 * 1024 * 1024:
                raise DesktopControlError("Das neue Projekt ist zusammen größer als 10 MB.")
            normalized.append((relative, encoded))

        if destination.exists():
            raise DesktopControlError(
                f"Der Zielordner „{destination}“ existiert bereits. Er wurde zum Schutz nicht überschrieben."
            )
        root = destination.parent
        try:
            root.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            raise DesktopControlError(f"Der übergeordnete Zielpfad „{root}“ konnte nicht erstellt werden.") from exc
        if not root.is_dir():
            raise DesktopControlError(f"Der übergeordnete Zielpfad „{root}“ ist kein Ordner.")
        temporary = root / f".{name}.jarvis-{secrets.token_hex(6)}"
        try:
            temporary.mkdir(parents=False, exist_ok=False)
            for relative, encoded in normalized:
                target = temporary.joinpath(*PurePosixPath(relative).parts)
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(encoded)
                if target.read_bytes() != encoded:
                    raise DesktopControlError(f"Die Projektdatei {relative} konnte nicht sicher geprüft werden.")
            temporary.replace(destination)
        except Exception as exc:
            shutil.rmtree(temporary, ignore_errors=True)
            if isinstance(exc, DesktopControlError):
                raise
            raise DesktopControlError(f"Das Projekt konnte unter „{destination}“ nicht erstellt werden: {exc}") from exc

        manifest = [
            {
                "path": relative,
                "bytes": len(encoded),
                "sha256": hashlib.sha256(encoded).hexdigest(),
            }
            for relative, encoded in normalized
        ]
        opened = False
        if open_after_create:
            startfile = getattr(os, "startfile", None)
            if callable(startfile):
                try:
                    startfile(str(destination))
                    opened = True
                except OSError:
                    opened = False
        if open_after_create and os.name != "nt":
            from linux_desktop import LinuxDesktopError, open_document
            try:
                open_document(str(destination))
                opened = True
            except (LinuxDesktopError, OSError):
                opened = False
        return {
            "ok": True,
            "folder_name": name,
            "location": "explicit_path",
            "path": str(destination),
            "file_count": len(manifest),
            "total_bytes": total_bytes,
            "files": manifest,
            "opened": opened,
            "verification": "Alle Dateien wurden atomar geschrieben und bytegenau geprüft.",
        }

    @staticmethod
    def plan_requires_confirmation(actions: list[dict[str, Any]]) -> bool:
        return any(
            item["action"] in {"click_control", "click_point", "type_text", "press", "hotkey"}
            for item in actions
        )

    def request_stop(self, run_id: str = "") -> bool:
        with self._state_lock:
            active_run_id = self._active_run_id
        if run_id and active_run_id != run_id:
            return False
        self._stop.set()
        try:
            self.stop_file.parent.mkdir(parents=True, exist_ok=True)
            self.stop_file.touch(exist_ok=True)
        except OSError:
            pass
        return bool(active_run_id)

    def clear_stop(self) -> None:
        self._stop.clear()
        try:
            self.stop_file.unlink(missing_ok=True)
        except OSError:
            pass

    def _check_stop(self) -> None:
        if self._stop.is_set() or self.stop_file.exists():
            raise DesktopStopRequested("Desktop-Steuerung wurde über den Not-Aus beendet.")

    def status(self) -> dict[str, Any]:
        with self._state_lock:
            return {
                "running": bool(self._active_run_id),
                "run_id": self._active_run_id,
                "step": self._active_step,
                "total_steps": self._active_total,
                "stop_requested": self._stop.is_set() or self.stop_file.exists(),
            }

    def execute(self, actions: list[dict[str, Any]], *, run_id: str = "") -> dict[str, Any]:
        settings = self.capability_manager.settings()
        if not settings["desktop_control_enabled"]:
            raise DesktopControlError("Desktop-Steuerung ist im PC-Agenten deaktiviert.")
        plan = self.validate_plan(actions)
        if os.name != "nt":
            from linux_desktop import LinuxDesktopError, validate_actions
            try:
                validate_actions(plan)
            except LinuxDesktopError as exc:
                raise DesktopControlError(str(exc)) from exc
        if not self._lock.acquire(blocking=False):
            raise DesktopControlError("Es läuft bereits eine andere Desktop-Aufgabe.")
        try:
            self.clear_stop()
            with self._state_lock:
                self._active_run_id = str(run_id or "")
                self._active_step = 0
                self._active_total = len(plan)
            completed: list[dict[str, Any]] = []
            started = time.monotonic()
            for index, action in enumerate(plan):
                with self._state_lock:
                    self._active_step = index + 1
                self._check_stop()
                self._execute_action(action)
                completed.append({"index": index, "action": action["action"], "status": "success"})
            return {
                "ok": True,
                "run_id": str(run_id or ""),
                "completed": completed,
                "duration_ms": round((time.monotonic() - started) * 1000),
                "verification": "Alle strukturierten Desktop-Schritte wurden ohne Laufzeitfehler abgeschlossen.",
            }
        finally:
            with self._state_lock:
                self._active_run_id = ""
                self._active_step = 0
                self._active_total = 0
            self._lock.release()

    def _execute_action(self, action: dict[str, Any]) -> None:
        kind = action["action"]
        if kind == "wait":
            deadline = time.monotonic() + float(action["seconds"])
            while time.monotonic() < deadline:
                self._check_stop()
                time.sleep(min(0.1, deadline - time.monotonic()))
            return
        if os.name != "nt":
            from linux_desktop import LinuxDesktopError, execute_action
            from v15_core import PcAgentController, PcAgentError
            try:
                if kind == "open":
                    PcAgentController(self.capability_manager, self.base_dir).open_target(action["target"])
                else:
                    execute_action(action, self._check_stop)
            except (LinuxDesktopError, PcAgentError, OSError) as exc:
                raise DesktopControlError(str(exc)) from exc
            return
        if kind == "open":
            target = str(action["target"])
            if re.match(r"^https?://", target, flags=re.I):
                webbrowser.open(target)
            else:
                startfile = getattr(os, "startfile", None)
                if not callable(startfile):
                    raise DesktopControlError("Windows kann das Ziel nicht öffnen.")
                startfile(target)
            return
        try:
            from pywinauto import Desktop, keyboard, mouse
        except ImportError as exc:
            raise DesktopControlError(
                "Für Maus- und Tastatursteuerung fehlt pywinauto. Starte MODULE_INSTALLIEREN.bat."
            ) from exc
        if kind == "focus_window":
            window = Desktop(backend="uia").window(title_re=f".*{re.escape(action['window'])}.*")
            window.wait("visible", timeout=8)
            window.set_focus()
        elif kind == "click_control":
            window = Desktop(backend="uia").window(title_re=f".*{re.escape(action['window'])}.*")
            window.wait("visible", timeout=8)
            control_name = str(action.get("control") or "")
            control = window.child_window(title_re=f".*{re.escape(control_name)}.*")
            control.wait("enabled", timeout=8)
            control.click_input()
        elif kind == "click_point":
            mouse.click(button=action["button"], coords=(int(action["x"]), int(action["y"])))
        elif kind == "type_text":
            keyboard.send_keys(str(action["text"]), with_spaces=True, pause=0.01)
        elif kind == "press":
            keyboard.send_keys("{" + str(action["key"]).upper() + "}")
        elif kind == "hotkey":
            mapping = {"ctrl": "^", "alt": "%", "shift": "+", "win": "{VK_LWIN down}"}
            keys = list(action["keys"])
            sequence = "".join(mapping.get(key, "{" + key.upper() + "}") for key in keys)
            keyboard.send_keys(sequence)
            if "win" in keys:
                keyboard.send_keys("{VK_LWIN up}")
        elif kind == "scroll":
            mouse.scroll(wheel_dist=int(action["amount"]))


def dependency_report() -> dict[str, Any]:
    base_dir = Path(__file__).resolve().parent
    scripts_dir = "Scripts" if os.name == "nt" else "bin"
    def isolated(environment: str, *, browser_required: bool = False) -> bool:
        path = base_dir / ".jarvis_envs" / environment
        return (
            (path / ".jarvis-installed").exists()
            and (path / scripts_dir / ("python.exe" if os.name == "nt" else "python")).exists()
            and (not browser_required or (path / ".jarvis-playwright-ready").exists())
        )

    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "timestamp": datetime.now(UTC).isoformat(timespec="seconds"),
        "executables": {
            "node": bool(shutil.which("node")),
            "ollama": bool(shutil.which("ollama")),
            "piper": bool(shutil.which("piper")),
            "cargo": bool(shutil.which("cargo")),
        },
        "environment": {
            "home_assistant": bool(os.getenv("HOME_ASSISTANT_URL", "").strip()),
            "spotify": bool(os.getenv("SPOTIPY_CLIENT_ID", "").strip()),
            "langfuse": bool(os.getenv("LANGFUSE_PUBLIC_KEY", "").strip()),
            "omniparser": bool(os.getenv("OMNIPARSER_URL", "").strip()),
            "ui_tars": bool(os.getenv("UI_TARS_URL", "").strip()),
        },
        "isolated_environments": {
            "open_interpreter": isolated("open-interpreter"),
            "openadapt": isolated("openadapt", browser_required=True),
            "openvoiceos": isolated("ovos"),
        },
    }
