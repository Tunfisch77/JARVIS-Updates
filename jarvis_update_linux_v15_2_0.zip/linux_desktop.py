"""Linux desktop adapters. No shell interpretation; X11 input stays explicit."""
from __future__ import annotations

import importlib.util
import os
import re
import shutil
import subprocess
import time
from pathlib import Path
from typing import Callable


class LinuxDesktopError(RuntimeError):
    pass


# Only known desktop applications can be started as programs. Arbitrary binaries,
# scripts and .desktop files are not treated as documents.
PROGRAMS = {
    "explorer": ("Dateien", ("nemo", "nautilus", "thunar", "dolphin")),
    "editor": ("Texteditor", ("xed", "gedit", "mousepad", "kate")),
    "rechner": ("Rechner", ("gnome-calculator", "mate-calc", "kcalc")),
    "einstellungen": ("Einstellungen", ("cinnamon-settings", "gnome-control-center")),
    "taskmanager": ("Systemüberwachung", ("gnome-system-monitor", "mate-system-monitor")),
    "fotos": ("Bildbetrachter", ("xviewer", "eog", "ristretto")),
    "firefox": ("Firefox", ("firefox",)),
    "brave": ("Brave", ("brave-browser", "brave-browser-stable", "brave")),
    "chrome": ("Chrome", ("google-chrome", "google-chrome-stable")),
    "chromium": ("Chromium", ("chromium", "chromium-browser")),
    "libreoffice": ("LibreOffice", ("libreoffice",)),
    "thunderbird": ("Thunderbird", ("thunderbird",)),
    "vlc": ("VLC", ("vlc",)),
    "spotify": ("Spotify", ("spotify",)),
    "kamera": ("Kamera", ("cheese", "guvcview")),
    "paint": ("Zeichenprogramm", ("drawing", "pinta", "gimp")),
    "terminal": ("Terminal", ("gnome-terminal", "xfce4-terminal", "konsole", "x-terminal-emulator")),
}
ALIASES = {"dateien": "explorer", "datei explorer": "explorer", "dateiexplorer": "explorer",
           "dateimanager": "explorer", "nemo": "explorer", "notepad": "editor", "xed": "editor",
           "texteditor": "editor", "task manager": "taskmanager", "calculator": "rechner"}
BLOCKED_SUFFIXES = {".sh", ".bash", ".zsh", ".fish", ".desktop", ".appimage", ".run", ".bin",
                    ".deb", ".rpm", ".py", ".pyw", ".pl", ".rb", ".so", ".exe"}


def session_status() -> dict:
    session = os.environ.get("XDG_SESSION_TYPE", "").casefold()
    wayland = session == "wayland" or (not session and bool(os.environ.get("WAYLAND_DISPLAY")))
    display = bool(os.environ.get("DISPLAY"))
    x11 = display and not wayland
    return {
        "system": "linux", "session": "wayland" if wayland else "x11" if display else "headless",
        "desktop_input": x11 and bool(shutil.which("xdotool")),
        "native_screenshot": x11 and importlib.util.find_spec("mss") is not None,
        "window_focus": x11 and bool(shutil.which("wmctrl")),
        "named_controls": False,
        "browser_screen_selection": True,
        "hint": "" if x11 else "Für Maus/Tastatur und native Aufnahme bei Mint in Cinnamon (X11) anmelden. Bildschirmfreigabe im Browser bleibt möglich.",
    }


def require_x11() -> None:
    if session_status()["session"] != "x11":
        raise LinuxDesktopError("Diese Desktop-Aktion benötigt Cinnamon mit X11. Unter Wayland bitte die Bildschirmfreigabe im Browser nutzen.")


def session_locked() -> bool:
    """Ask the desktop locker; unknown states keep message previews private."""
    if not os.environ.get("DBUS_SESSION_BUS_ADDRESS") or not shutil.which("gdbus"):
        return True
    for service, path in [("org.cinnamon.ScreenSaver", "/org/cinnamon/ScreenSaver"),
                          ("org.gnome.ScreenSaver", "/org/gnome/ScreenSaver"),
                          ("org.freedesktop.ScreenSaver", "/org/freedesktop/ScreenSaver")]:
        try:
            result = subprocess.run(["gdbus", "call", "--session", "--dest", service,
                                     "--object-path", path, "--method", service + ".GetActive"],
                                    capture_output=True, text=True, timeout=0.6, check=True)
            if result.stdout.strip() in {"(true,)", "(false,)"}:
                return result.stdout.strip() == "(true,)"
        except (OSError, subprocess.SubprocessError):
            continue
    return True


def resolve_program(name: str, *, allow_terminal: bool = False) -> dict | None:
    key = ALIASES.get(name, name)
    spec = PROGRAMS.get(key)
    if not spec:
        return None
    if key == "terminal" and not allow_terminal:
        raise LinuxDesktopError("Das Terminal ist in den Agent-OS-Sicherheitseinstellungen deaktiviert.")
    label, candidates = spec
    executable = next((path for cmd in candidates if (path := shutil.which(cmd))), None)
    if not executable:
        raise LinuxDesktopError(f"{label} ist auf diesem Linux-System nicht installiert.")
    return {"mode": "command", "kind": "program", "value": [executable], "label": label}


def program_catalog() -> list[dict]:
    return [{"alias": alias, "label": label} for alias, (label, commands) in PROGRAMS.items()
            if any(shutil.which(command) for command in commands)]


def validate_document(path: Path) -> None:
    if path.suffix.casefold() in BLOCKED_SUFFIXES:
        raise LinuxDesktopError("Skripte, Installer und ausführbare Dateien werden nicht als Dokument geöffnet. Programme bitte über ihren Namen wählen.")
    with path.open("rb") as source:
        prefix = source.read(4)
    if prefix.startswith((b"#!", b"\x7fELF", b"MZ")):
        raise LinuxDesktopError("Diese Datei enthält ausführbaren Code und wird nicht als Dokument geöffnet.")


def open_document(path: str) -> None:
    target = Path(path).resolve(strict=True)
    if target.is_file():
        validate_document(target)
    command = shutil.which("xdg-open")
    if not command:
        raise LinuxDesktopError("xdg-open fehlt. Bitte INSTALLIEREN.sh erneut ausführen.")
    try:
        subprocess.run([command, str(target)], check=True, timeout=10, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    except (OSError, subprocess.SubprocessError) as exc:
        raise LinuxDesktopError("Das Ziel konnte mit der zugeordneten Linux-Anwendung nicht geöffnet werden.") from exc


def capture_screen() -> bytes:
    require_x11()
    try:
        import mss
        import mss.tools
        with mss.mss() as capture:
            shot = capture.grab(capture.monitors[0])
            return mss.tools.to_png(shot.rgb, shot.size)
    except Exception as exc:
        raise LinuxDesktopError("Keine Bildschirmaufnahme möglich. DIAGNOSE.sh prüfen oder die Browser-Bildschirmfreigabe verwenden.") from exc


def visible_windows(limit: int = 12) -> list[dict]:
    if session_status()["session"] != "x11" or not shutil.which("wmctrl"):
        return []
    try:
        result = subprocess.run(["wmctrl", "-l"], capture_output=True, text=True, timeout=3, check=True)
        items = []
        for line in result.stdout.splitlines():
            fields = line.split(None, 3)
            if len(fields) == 4 and re.fullmatch(r"0x[0-9a-fA-F]+", fields[0]):
                items.append({"id": fields[0], "title": fields[3][:300]})
        return items[:max(1, min(100, limit))]
    except (OSError, subprocess.SubprocessError):
        return []


KEYS = {"ctrl": "ctrl", "control": "ctrl", "alt": "alt", "shift": "shift", "win": "super",
        "super": "super", "enter": "Return", "return": "Return", "esc": "Escape", "escape": "Escape",
        "tab": "Tab", "space": "space", "backspace": "BackSpace", "delete": "Delete", "del": "Delete",
        "up": "Up", "down": "Down", "left": "Left", "right": "Right", "home": "Home", "end": "End",
        "pageup": "Page_Up", "pagedown": "Page_Down", "insert": "Insert"}


def key_name(value: str) -> str:
    value = value.casefold().strip()
    if value in KEYS:
        return KEYS[value]
    if re.fullmatch(r"[a-z0-9]|f(?:[1-9]|1[0-2])", value):
        return value.upper() if value.startswith("f") and len(value) > 1 else value
    raise LinuxDesktopError(f"Nicht unterstützte Taste: {value}")


def validate_actions(actions: list[dict]) -> None:
    # Fail before an earlier step changes anything.
    for action in actions:
        kind = action["action"]
        if kind == "click_control":
            raise LinuxDesktopError("Linux unterstützt hier Klicks auf Koordinaten, noch keine Bedienelemente per Namen. Bitte click_point verwenden.")
        if kind not in {"open", "wait"}:
            require_x11()
            required = "wmctrl" if kind == "focus_window" else "xdotool"
            if not shutil.which(required):
                raise LinuxDesktopError(f"{required} fehlt. Bitte INSTALLIEREN.sh erneut ausführen.")
        if kind == "press":
            for key in action["key"].split("+"):
                key_name(key)
        if kind == "hotkey":
            for key in action["keys"]:
                key_name(key)


def run_interruptible(command: list[str], check_stop: Callable[[], None], *, text: str | None = None) -> None:
    check_stop()
    process = subprocess.Popen(command, stdin=subprocess.PIPE if text is not None else subprocess.DEVNULL,
                               stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True, shell=False)
    deadline = time.monotonic() + 20
    first = True
    try:
        while True:
            check_stop()
            try:
                _, error = process.communicate(input=text if first else None, timeout=0.1)
                break
            except subprocess.TimeoutExpired:
                first = False
                if time.monotonic() >= deadline:
                    raise LinuxDesktopError("Desktop-Schritt hat das Zeitlimit überschritten.")
        if process.returncode:
            raise LinuxDesktopError("Der Linux-Desktop hat den Steuerbefehl nicht ausgeführt.")
    finally:
        if process.poll() is None:
            process.terminate()
            try:
                process.communicate(timeout=2)
            except subprocess.TimeoutExpired:
                process.kill()
                process.communicate(timeout=2)


def execute_action(action: dict, check_stop: Callable[[], None]) -> None:
    validate_actions([action])
    kind = action["action"]
    command = ["xdotool"]
    text = None
    if kind == "focus_window":
        needle = action["window"].casefold()
        windows = visible_windows(100)
        matches = [w for w in windows if w["title"].casefold() == needle]
        matches = matches or [w for w in windows if needle in w["title"].casefold()]
        if len(matches) != 1:
            raise LinuxDesktopError("Das Fenster wurde nicht eindeutig gefunden. Bitte einen eindeutigen Fenstertitel angeben.")
        command = ["wmctrl", "-ia", matches[0]["id"]]
    elif kind == "click_point":
        command += ["mousemove", "--sync", str(action["x"]), str(action["y"]), "click", {"left": "1", "middle": "2", "right": "3"}[action["button"]]]
    elif kind == "type_text":
        command += ["type", "--clearmodifiers", "--delay", "1", "--file", "-"]
        text = action["text"]
    elif kind in {"press", "hotkey"}:
        keys = action["key"].split("+") if kind == "press" else action["keys"]
        command += ["key", "--clearmodifiers", "+".join(key_name(k) for k in keys)]
    elif kind == "scroll":
        amount = int(action["amount"])
        if not amount:
            return
        command += ["click", "--repeat", str(abs(amount)), "--delay", "30", "4" if amount > 0 else "5"]
    else:
        raise LinuxDesktopError("Unbekannter Linux-Desktop-Schritt.")
    run_interruptible(command, check_stop, text=text)


def launch_setup_terminal(script: Path) -> bool:
    if not os.environ.get("DISPLAY") and not os.environ.get("WAYLAND_DISPLAY"):
        return False
    terminal = shutil.which("x-terminal-emulator")
    if not terminal:
        return False
    subprocess.Popen([terminal, "-e", "bash", str(script)], cwd=script.parent, start_new_session=True)
    return True
