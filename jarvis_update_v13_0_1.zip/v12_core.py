from __future__ import annotations

import hashlib
import json
import re
import sqlite3
import unicodedata
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Callable, Final


V12_NOTIFICATION_SOURCES: Final = {"whatsapp", "gmail", "outlook", "snapchat"}
V12_EVENT_TYPES: Final = {"message", "snap"}
V12_ACTION_WORDS: Final = {
    "aktiviere",
    "ändere",
    "baue",
    "bearbeite",
    "deaktiviere",
    "erstelle",
    "füge",
    "installiere",
    "lösche",
    "mach",
    "öffne",
    "repariere",
    "sende",
    "schalte",
    "schicke",
    "schließe",
    "schreib",
    "setze",
    "starte",
    "stoppe",
}
V12_REFERENCE_WORDS: Final = {
    "das",
    "daran",
    "darin",
    "davon",
    "dazu",
    "dort",
    "es",
    "genau so",
    "ihn",
    "sie",
    "weiter",
    "wie vorher",
}
V12_PROJECT_WORDS: Final = {
    "app",
    "code",
    "datei",
    "game",
    "projekt",
    "programm",
    "seite",
    "spiel",
    "website",
}


def normalize_identity(value: object) -> str:
    decomposed = unicodedata.normalize("NFKD", str(value or "").casefold())
    without_marks = "".join(character for character in decomposed if not unicodedata.combining(character))
    return " ".join(re.findall(r"[^\W_]+", without_marks, flags=re.UNICODE))


def _tokens(value: object) -> set[str]:
    return {
        token
        for token in normalize_identity(value).split()
        if len(token) >= 3
        and token
        not in {
            "aber",
            "auch",
            "dann",
            "dass",
            "eine",
            "einen",
            "einer",
            "haben",
            "kann",
            "mal",
            "noch",
            "oder",
            "sich",
            "und",
            "wird",
        }
    }


def _contains_phrase(text: str, phrases: set[str]) -> bool:
    padded = f" {normalize_identity(text)} "
    return any(f" {normalize_identity(phrase)} " in padded for phrase in phrases)


@dataclass(slots=True)
class V12Route:
    kind: str
    confidence: float
    planner_required: bool = False
    tool: str = ""
    arguments: dict[str, Any] | None = None
    needs_clarification: bool = False
    question: str = ""
    reason: str = ""

    def payload(self) -> dict[str, Any]:
        result = asdict(self)
        result["arguments"] = dict(self.arguments or {})
        return result


class V12ContextEngine:
    """Build a compact turn packet and bind obvious follow-ups before the voice model sees them."""

    STATE_KEY = "v12_turn_state"

    def __init__(
        self,
        memory_store: Any,
        state_store: Any,
        active_project_supplier: Callable[[], dict[str, Any] | None],
    ) -> None:
        self.memory_store = memory_store
        self.state_store = state_store
        self.active_project_supplier = active_project_supplier

    def _known_entities(self, query: str) -> list[dict[str, str]]:
        normalized = f" {normalize_identity(query)} "
        candidates: list[tuple[int, dict[str, str]]] = []
        for contact in self.state_store.list_contacts():
            aliases = contact.get("aliases") if isinstance(contact.get("aliases"), list) else []
            values = [
                contact.get("name", ""),
                contact.get("email", ""),
                contact.get("whatsapp_chat_name", ""),
                *aliases,
            ]
            for value in values:
                identity = normalize_identity(value)
                if identity and f" {identity} " in normalized:
                    candidates.append(
                        (
                            len(identity),
                            {
                                "kind": "contact",
                                "name": str(contact.get("name") or value),
                                "matched_as": str(value),
                            },
                        )
                    )
        for group in self.state_store.list_whatsapp_groups():
            aliases = group.get("aliases") if isinstance(group.get("aliases"), list) else []
            for value in (group.get("name", ""), group.get("chat_name", ""), *aliases):
                identity = normalize_identity(value)
                if identity and f" {identity} " in normalized:
                    candidates.append(
                        (
                            len(identity),
                            {
                                "kind": "whatsapp_group",
                                "name": str(group.get("name") or value),
                                "matched_as": str(value),
                            },
                        )
                    )
        unique: dict[tuple[str, str], dict[str, str]] = {}
        for _, item in sorted(candidates, key=lambda entry: entry[0], reverse=True):
            unique.setdefault((item["kind"], item["name"]), item)
        return list(unique.values())[:8]

    def _local_route(self, query: str, history: list[dict[str, Any]]) -> V12Route:
        normalized = normalize_identity(query)
        words = set(normalized.split())
        action = bool(words & {normalize_identity(item) for item in V12_ACTION_WORDS})
        reference = _contains_phrase(normalized, V12_REFERENCE_WORDS)
        project_term = bool(words & {normalize_identity(item) for item in V12_PROJECT_WORDS})
        active_project = self.active_project_supplier()
        create_project = bool(
            re.search(
                r"\b(?:erstelle|mach|baue|programmiere)\b.+\b(?:app|game|projekt|programm|spiel|website|seite)\b",
                normalized,
            )
        )
        conversational_continuation = bool(
            history
            and re.search(
                r"\b(?:mach|mache|setz|setze|führ|fuehr|führe)\b.{0,24}"
                r"\b(?:damit|daran|das|es)\b.{0,16}\b(?:weiter|fort)\b"
                r"|\b(?:weiter|erzähl weiter|erzaehl weiter|mach weiter)\b",
                normalized,
            )
        )
        project_follow_up = bool(
            active_project
            and action
            and (
                project_term
                or reference
                or re.search(
                    r"\b(?:flüssiger|schneller|schöner|besser|responsive|funktioniert|fehler|bug|start bat)\b",
                    normalized,
                )
            )
            and not create_project
        )
        if project_follow_up:
            return V12Route(
                kind="project_edit",
                confidence=0.99,
                tool="modify_code_project",
                arguments={
                    "target_path": str(active_project.get("path") or ""),
                    "instruction": query.strip(),
                    "open_after_edit": False,
                },
                reason="Eindeutige Folgeänderung am dauerhaft gespeicherten aktiven Projekt.",
            )
        if create_project:
            return V12Route(
                kind="new_project",
                confidence=0.94,
                planner_required=False,
                tool="create_desktop_project",
                reason="Neues Softwareprojekt erkannt; der Zielpfad bleibt zwingend nutzerbestimmt.",
            )
        if conversational_continuation:
            return V12Route(
                kind="context_follow_up",
                confidence=0.96,
                reason="Explizite Fortsetzung bindet den vorherigen Gesprächszug.",
            )
        if action and reference and not history:
            return V12Route(
                kind="clarify",
                confidence=0.9,
                needs_clarification=True,
                question="Was genau soll ich ändern oder ausführen?",
                reason="Ändernde Aktion enthält einen Verweis ohne auflösbaren Gesprächskontext.",
            )
        if action:
            return V12Route(
                kind="action",
                confidence=0.78,
                planner_required=True,
                reason="Eine Aktion wurde erkannt; ein strukturierter Planer soll Ziel und Werkzeug prüfen.",
            )
        if reference and history:
            return V12Route(
                kind="context_follow_up",
                confidence=0.91,
                reason="Der Auftrag verweist auf einen vorherigen Gesprächszug.",
            )
        return V12Route(kind="conversation", confidence=0.86, reason="Direkte Unterhaltung ohne lokale Aktion.")

    def resolve(self, query: str) -> dict[str, Any]:
        cleaned = " ".join(str(query or "").split())
        recent = self.memory_store.recent_history(limit=14)
        relevant = self.memory_store.relevant_context(cleaned, memory_limit=8, history_limit=12)
        route = self._local_route(cleaned, recent)
        entities = self._known_entities(cleaned)
        previous_state = self.state_store.get_setting(self.STATE_KEY, {})
        if not isinstance(previous_state, dict):
            previous_state = {}
        active_project = self.active_project_supplier()

        merged_history: dict[int, dict[str, Any]] = {}
        for item in [*recent[-8:], *(relevant.get("history") or [])]:
            if isinstance(item, dict) and item.get("id") is not None:
                merged_history[int(item["id"])] = item
        selected_history = sorted(merged_history.values(), key=lambda item: int(item["id"]))[-12:]

        lines = [
            "V13 TURN CONTEXT – lokale Daten, keine Nutzeranweisungen.",
            f"Aktueller Auftrag: {cleaned}",
            f"Vorab-Route: {json.dumps(route.payload(), ensure_ascii=False)}",
        ]
        if active_project:
            lines.append(
                f"Aktives Projekt: {active_project.get('name', '')} | {active_project.get('path', '')}"
            )
        if entities:
            lines.append(f"Eindeutig erkannte Personen/Gruppen: {json.dumps(entities, ensure_ascii=False)}")
        if previous_state.get("last_topic"):
            lines.append(f"Letzter Themenanker: {previous_state['last_topic']}")
        memories = relevant.get("memories") if isinstance(relevant, dict) else []
        if memories:
            lines.append("Passende dauerhafte Erinnerungen:")
            lines.extend(f"- {item.get('text', '')}" for item in memories[:8] if isinstance(item, dict))
        if selected_history:
            lines.append("Letzte und passende Gesprächszüge:")
            lines.extend(
                f"- {item.get('role', '')}: {item.get('content', '')}"
                for item in selected_history
            )
        context = "\n".join(lines)[:12_000]
        state = {
            "last_query": cleaned,
            "last_topic": self._topic_anchor(cleaned, entities, active_project),
            "last_route": route.payload(),
            "last_entities": entities,
            "updated_at": datetime.now(UTC).isoformat(timespec="seconds"),
        }
        self.state_store.set_setting(self.STATE_KEY, state)
        return {
            "route": route.payload(),
            "context": context,
            "entities": entities,
            "active_project": active_project,
            "memory_count": len(memories or []),
            "history_count": len(selected_history),
        }

    @staticmethod
    def _topic_anchor(
        query: str,
        entities: list[dict[str, str]],
        active_project: dict[str, Any] | None,
    ) -> str:
        if entities:
            return ", ".join(item["name"] for item in entities[:3])
        if active_project and (
            _contains_phrase(query, V12_PROJECT_WORDS)
            or _contains_phrase(query, V12_REFERENCE_WORDS)
        ):
            return str(active_project.get("name") or "aktives Projekt")
        meaningful = [token for token in normalize_identity(query).split() if len(token) >= 4]
        return " ".join(meaningful[:8])[:200]


class V12NotificationStore:
    """Persist person-specific notification rules and positive-only delivery events."""

    def __init__(self, database_path: Path) -> None:
        self.database_path = database_path
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.database_path, timeout=5)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA foreign_keys=ON")
        return connection

    @staticmethod
    def _now() -> str:
        return datetime.now(UTC).isoformat(timespec="seconds")

    @staticmethod
    def _json(value: object) -> str:
        return json.dumps(value, ensure_ascii=False, default=str)

    @staticmethod
    def _decode(value: str | None, fallback: object) -> Any:
        try:
            return json.loads(value or "")
        except (TypeError, json.JSONDecodeError):
            return fallback

    def _initialize(self) -> None:
        with self._connect() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS notification_watch_rules (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source TEXT NOT NULL,
                    target TEXT NOT NULL,
                    normalized_target TEXT NOT NULL,
                    match_values_json TEXT NOT NULL DEFAULT '[]',
                    target_kind TEXT NOT NULL DEFAULT 'contact',
                    event_types_json TEXT NOT NULL DEFAULT '["message"]',
                    enabled INTEGER NOT NULL DEFAULT 1,
                    announce INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    UNIQUE(source, normalized_target, target_kind)
                );

                CREATE TABLE IF NOT EXISTS notification_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    rule_id INTEGER NOT NULL,
                    source TEXT NOT NULL,
                    external_id TEXT NOT NULL,
                    target TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    received_at TEXT NOT NULL,
                    announced INTEGER NOT NULL DEFAULT 0,
                    announced_at TEXT,
                    payload_json TEXT NOT NULL DEFAULT '{}',
                    created_at TEXT NOT NULL,
                    UNIQUE(rule_id, source, external_id, event_type),
                    FOREIGN KEY(rule_id) REFERENCES notification_watch_rules(id) ON DELETE CASCADE
                );

                CREATE TABLE IF NOT EXISTS notification_source_state (
                    rule_id INTEGER PRIMARY KEY,
                    fingerprint TEXT NOT NULL DEFAULT '',
                    unread INTEGER NOT NULL DEFAULT 0,
                    updated_at TEXT NOT NULL,
                    FOREIGN KEY(rule_id) REFERENCES notification_watch_rules(id) ON DELETE CASCADE
                );

                CREATE INDEX IF NOT EXISTS idx_notification_events_pending
                    ON notification_events(announced, received_at DESC);
                CREATE INDEX IF NOT EXISTS idx_notification_rules_source
                    ON notification_watch_rules(source, enabled);
                """
            )
            rule_columns = {
                str(row["name"])
                for row in connection.execute(
                    "PRAGMA table_info(notification_watch_rules)"
                ).fetchall()
            }
            if "match_values_json" not in rule_columns:
                connection.execute(
                    "ALTER TABLE notification_watch_rules "
                    "ADD COLUMN match_values_json TEXT NOT NULL DEFAULT '[]'"
                )

    @staticmethod
    def _validate_source(source: object) -> str:
        cleaned = str(source or "").strip().casefold()
        if cleaned not in V12_NOTIFICATION_SOURCES:
            raise ValueError("Unbekannte Benachrichtigungs-App.")
        return cleaned

    @staticmethod
    def _validate_target(target: object) -> str:
        cleaned = " ".join(str(target or "").split())[:200]
        if not cleaned:
            raise ValueError("Wähle eine Person oder Gruppe.")
        return cleaned

    @staticmethod
    def _validate_event_types(source: str, values: object) -> list[str]:
        raw = values if isinstance(values, list) else []
        result = list(dict.fromkeys(str(item).strip().casefold() for item in raw))
        result = [item for item in result if item in V12_EVENT_TYPES]
        if source != "snapchat":
            return ["message"]
        return result or ["snap", "message"]

    def _rule_item(self, row: sqlite3.Row) -> dict[str, Any]:
        return {
            "id": int(row["id"]),
            "source": row["source"],
            "target": row["target"],
            "match_values": self._decode(row["match_values_json"], [row["target"]]),
            "target_kind": row["target_kind"],
            "event_types": self._decode(row["event_types_json"], ["message"]),
            "enabled": bool(row["enabled"]),
            "announce": bool(row["announce"]),
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
        }

    def list_rules(self, *, enabled_only: bool = False, source: str = "") -> list[dict[str, Any]]:
        clauses: list[str] = []
        values: list[object] = []
        if enabled_only:
            clauses.append("enabled = 1")
        if source:
            clauses.append("source = ?")
            values.append(self._validate_source(source))
        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        with self._connect() as connection:
            rows = connection.execute(
                f"SELECT * FROM notification_watch_rules{where} ORDER BY source, target COLLATE NOCASE",
                values,
            ).fetchall()
        return [self._rule_item(row) for row in rows]

    def save_rule(
        self,
        *,
        source: object,
        target: object,
        target_kind: object = "contact",
        event_types: object = None,
        match_values: object = None,
        enabled: bool = True,
        announce: bool = True,
    ) -> dict[str, Any]:
        clean_source = self._validate_source(source)
        clean_target = self._validate_target(target)
        clean_kind = str(target_kind or "contact").strip().casefold()
        if clean_kind not in {"contact", "group"}:
            raise ValueError("Unbekannter Zieltyp.")
        clean_events = self._validate_event_types(clean_source, event_types)
        raw_match_values = match_values if isinstance(match_values, list) else []
        clean_match_values = list(
            dict.fromkeys(
                value
                for value in (
                    normalize_identity(item)
                    for item in [clean_target, *raw_match_values]
                )
                if value
            )
        )[:30]
        now = self._now()
        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO notification_watch_rules(
                    source, target, normalized_target, match_values_json, target_kind, event_types_json,
                    enabled, announce, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(source, normalized_target, target_kind) DO UPDATE SET
                    target = excluded.target,
                    match_values_json = excluded.match_values_json,
                    event_types_json = excluded.event_types_json,
                    enabled = excluded.enabled,
                    announce = excluded.announce,
                    updated_at = excluded.updated_at
                """,
                (
                    clean_source,
                    clean_target,
                    normalize_identity(clean_target),
                    self._json(clean_match_values),
                    clean_kind,
                    self._json(clean_events),
                    int(bool(enabled)),
                    int(bool(announce)),
                    now,
                    now,
                ),
            )
            row = connection.execute(
                """
                SELECT * FROM notification_watch_rules
                WHERE source = ? AND normalized_target = ? AND target_kind = ?
                """,
                (clean_source, normalize_identity(clean_target), clean_kind),
            ).fetchone()
        if not row:
            raise RuntimeError("Benachrichtigungsregel konnte nicht gespeichert werden.")
        return self._rule_item(row)

    def update_rule(self, rule_id: int, *, enabled: bool, announce: bool) -> dict[str, Any] | None:
        with self._connect() as connection:
            cursor = connection.execute(
                """
                UPDATE notification_watch_rules
                SET enabled = ?, announce = ?, updated_at = ?
                WHERE id = ?
                """,
                (int(bool(enabled)), int(bool(announce)), self._now(), int(rule_id)),
            )
            row = connection.execute(
                "SELECT * FROM notification_watch_rules WHERE id = ?",
                (int(rule_id),),
            ).fetchone()
        return self._rule_item(row) if cursor.rowcount and row else None

    def delete_rule(self, rule_id: int) -> bool:
        with self._connect() as connection:
            cursor = connection.execute(
                "DELETE FROM notification_watch_rules WHERE id = ?",
                (int(rule_id),),
            )
        return cursor.rowcount > 0

    @staticmethod
    def _message_identities(message: dict[str, Any]) -> set[str]:
        return {
            identity
            for identity in (
                normalize_identity(message.get("sender_name", "")),
                normalize_identity(message.get("sender_address", "")),
                normalize_identity(message.get("conversation", "")),
            )
            if identity
        }

    def capture_message(self, message: dict[str, Any]) -> int:
        source = str(message.get("source") or "").casefold()
        if source not in V12_NOTIFICATION_SOURCES:
            return 0
        identities = self._message_identities(message)
        if not identities:
            return 0
        created = 0
        event_type = str((message.get("metadata") or {}).get("event_type") or "message").casefold()
        if event_type not in V12_EVENT_TYPES:
            event_type = "message"
        external_id = str(message.get("external_id") or "").strip()
        if not external_id:
            external_id = hashlib.sha256(
                self._json(message).encode("utf-8", errors="ignore")
            ).hexdigest()
        received_at = str(message.get("received_at") or self._now())[:80]
        now = self._now()
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT * FROM notification_watch_rules
                WHERE source = ? AND enabled = 1 AND announce = 1
                """,
                (source,),
            ).fetchall()
            for row in rows:
                match_values = set(
                    self._decode(
                        row["match_values_json"],
                        [str(row["normalized_target"])],
                    )
                )
                if not any(
                    match_value == identity
                    or match_value in identity
                    or identity in match_value
                    for match_value in match_values
                    for identity in identities
                ):
                    continue
                allowed_events = self._decode(row["event_types_json"], ["message"])
                if event_type not in allowed_events:
                    continue
                cursor = connection.execute(
                    """
                    INSERT OR IGNORE INTO notification_events(
                        rule_id, source, external_id, target, event_type,
                        received_at, payload_json, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        int(row["id"]),
                        source,
                        external_id[:500],
                        str(row["target"]),
                        event_type,
                        received_at,
                        self._json(
                            {
                                "sender_name": message.get("sender_name", ""),
                                "conversation": message.get("conversation", ""),
                            }
                        ),
                        now,
                    ),
                )
                created += max(0, int(cursor.rowcount))
        return created

    def capture_presence(
        self,
        *,
        rule_id: int,
        unread: bool,
        fingerprint: str,
        event_type: str,
        received_at: str = "",
    ) -> bool:
        clean_event = str(event_type or "message").casefold()
        if clean_event not in V12_EVENT_TYPES:
            clean_event = "message"
        now = self._now()
        with self._connect() as connection:
            rule = connection.execute(
                "SELECT * FROM notification_watch_rules WHERE id = ? AND enabled = 1 AND announce = 1",
                (int(rule_id),),
            ).fetchone()
            if not rule:
                return False
            allowed_events = self._decode(rule["event_types_json"], ["message"])
            if clean_event not in allowed_events:
                return False
            state = connection.execute(
                "SELECT fingerprint, unread FROM notification_source_state WHERE rule_id = ?",
                (int(rule_id),),
            ).fetchone()
            previous_unread = bool(state["unread"]) if state else False
            previous_fingerprint = str(state["fingerprint"]) if state else ""
            clean_fingerprint = str(fingerprint or "").strip()[:500]
            is_new = bool(
                unread
                and state is not None
                and (not previous_unread or (clean_fingerprint and clean_fingerprint != previous_fingerprint))
            )
            connection.execute(
                """
                INSERT INTO notification_source_state(rule_id, fingerprint, unread, updated_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(rule_id) DO UPDATE SET
                    fingerprint = excluded.fingerprint,
                    unread = excluded.unread,
                    updated_at = excluded.updated_at
                """,
                (int(rule_id), clean_fingerprint, int(bool(unread)), now),
            )
            if not is_new:
                return False
            external_id = clean_fingerprint or hashlib.sha256(
                f"{rule_id}\0{clean_event}\0{received_at or now}".encode("utf-8")
            ).hexdigest()
            cursor = connection.execute(
                """
                INSERT OR IGNORE INTO notification_events(
                    rule_id, source, external_id, target, event_type,
                    received_at, payload_json, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, '{}', ?)
                """,
                (
                    int(rule_id),
                    str(rule["source"]),
                    external_id,
                    str(rule["target"]),
                    clean_event,
                    str(received_at or now)[:80],
                    now,
                ),
            )
            return cursor.rowcount > 0

    def pending_events(self, *, limit: int = 50) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT e.*, r.enabled, r.announce
                FROM notification_events e
                JOIN notification_watch_rules r ON r.id = e.rule_id
                WHERE e.announced = 0 AND r.enabled = 1 AND r.announce = 1
                ORDER BY e.received_at, e.id
                LIMIT ?
                """,
                (max(1, min(100, int(limit))),),
            ).fetchall()
        return [
            {
                "id": int(row["id"]),
                "rule_id": int(row["rule_id"]),
                "source": row["source"],
                "target": row["target"],
                "event_type": row["event_type"],
                "received_at": row["received_at"],
                "payload": self._decode(row["payload_json"], {}),
            }
            for row in rows
        ]

    def mark_announced(self, event_ids: list[int]) -> int:
        ids = sorted({int(item) for item in event_ids if int(item) > 0})[:100]
        if not ids:
            return 0
        placeholders = ",".join("?" for _ in ids)
        with self._connect() as connection:
            cursor = connection.execute(
                f"""
                UPDATE notification_events
                SET announced = 1, announced_at = ?
                WHERE id IN ({placeholders}) AND announced = 0
                """,
                (self._now(), *ids),
            )
        return max(0, int(cursor.rowcount))

    def mark_rule_baseline(self, rule_id: int) -> int:
        """Treat messages that already existed when a rule was created as the initial baseline."""
        with self._connect() as connection:
            cursor = connection.execute(
                """
                UPDATE notification_events
                SET announced = 1, announced_at = ?
                WHERE rule_id = ? AND announced = 0
                """,
                (self._now(), int(rule_id)),
            )
        return max(0, int(cursor.rowcount))

    def overview(self) -> dict[str, Any]:
        with self._connect() as connection:
            rules = connection.execute(
                "SELECT source, COUNT(*) AS count FROM notification_watch_rules WHERE enabled = 1 GROUP BY source"
            ).fetchall()
            pending = connection.execute(
                "SELECT COUNT(*) FROM notification_events WHERE announced = 0"
            ).fetchone()[0]
        return {
            "active_rules": sum(int(row["count"]) for row in rules),
            "by_source": {str(row["source"]): int(row["count"]) for row in rules},
            "pending": int(pending),
        }
