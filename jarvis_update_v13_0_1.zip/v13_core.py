from __future__ import annotations

import hashlib
import re
from dataclasses import asdict, dataclass
from typing import Any, Final


MISSION_STEP_KINDS: Final = {
    "check_messages",
    "search_web",
    "send_whatsapp_message",
    "send_email",
    "create_calendar_event",
    "create_timer",
    "open_app_or_website",
    "remember_user_fact",
    "desktop_plan",
}

ACTION_ROOTS: Final = (
    "aktualis",
    "erinner",
    "erstell",
    "füg",
    "hol",
    "leg",
    "lies",
    "mach",
    "merk",
    "öffn",
    "plan",
    "prüf",
    "ruf",
    "schalt",
    "schick",
    "schreib",
    "send",
    "setz",
    "start",
    "such",
    "trag",
)

MULTI_STEP_CONNECTOR = re.compile(
    r"(?:[,;]\s*|\b)(?:und\s+dann|danach|anschließend|anschliessend|zusätzlich|zusaetzlich|"
    r"außerdem|ausserdem|sowie|und)\b",
    flags=re.IGNORECASE,
)


def _clean(value: object, *, limit: int = 2_000) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()[:limit]


def _words(value: object) -> list[str]:
    return re.findall(r"[a-zäöüß]+", str(value or "").casefold())


def _action_positions(text: str) -> list[int]:
    positions: list[int] = []
    for match in re.finditer(r"[a-zäöüß]+", text.casefold()):
        if any(match.group(0).startswith(root) for root in ACTION_ROOTS):
            positions.append(match.start())
    return positions


def looks_like_multistep_request(text: str) -> bool:
    """Recognize multiple explicit actions without treating every sentence with "und" as a mission."""
    cleaned = _clean(text)
    positions = _action_positions(cleaned)
    if len(positions) < 2:
        return False
    for connector in MULTI_STEP_CONNECTOR.finditer(cleaned):
        if any(position < connector.start() for position in positions) and any(
            position > connector.end() for position in positions
        ):
            return True
    return False


@dataclass(frozen=True, slots=True)
class CorrectionRule:
    key: str
    instruction: str
    source_text: str

    def payload(self) -> dict[str, str]:
        return asdict(self)


def _correction_key(category: str, instruction: str) -> str:
    if category:
        return category
    digest = hashlib.sha256(instruction.casefold().encode("utf-8")).hexdigest()[:16]
    return f"behavior-{digest}"


def detect_explicit_correction(text: str) -> CorrectionRule | None:
    """Extract only durable, assistant-directed corrections; ordinary factual corrections stay transient."""
    cleaned = _clean(text, limit=600).strip(" .")
    if len(cleaned) < 5:
        return None
    normalized = cleaned.casefold()

    name_match = re.search(
        r"\bnenn(?:e)?\s+mich\s+(?:bitte\s+)?(?:nie\s+wieder|nicht\s+mehr|nicht)\s+"
        r"(.+?)(?:\s+sondern\s+(.+))?$",
        cleaned,
        flags=re.IGNORECASE,
    )
    if name_match:
        blocked = _clean(name_match.group(1), limit=80).strip(" .,!?:;\"'„“")
        replacement = _clean(name_match.group(2), limit=80).strip(" .,!?:;\"'„“")
        if not blocked:
            return None
        instruction = f"Nenne den Nutzer niemals {blocked}."
        if replacement:
            instruction = f"Nenne den Nutzer nicht {blocked}, sondern {replacement}."
        return CorrectionRule("addressing", instruction, cleaned)

    durable = bool(
        re.search(
            r"\b(?:ab\s+jetzt|in\s+zukunft|künftig|kuenftig|immer|nie|nicht\s+mehr|nicht\s+immer)\b",
            normalized,
        )
    )
    behavior = bool(
        re.search(
            r"\b(?:antwort|frag|nenn|schreib|sprich|sag|mach|verwende|benutze|erklär|erklaer)",
            normalized,
        )
    )
    explicit_memory = bool(re.search(r"\b(?:merk|merke)\s+dir\b", normalized))
    if not behavior or not (durable or explicit_memory):
        return None

    category = ""
    if re.search(r"\b(?:antwort|kurz|knapp|ausführlich|ausfuehrlich|länge|laenge)\b", normalized):
        category = "response_style"
    elif re.search(r"\b(?:frag|rückfrag|rueckfrag)\b", normalized):
        category = "clarification_style"
    elif re.search(r"\b(?:sprich|sag|schreib|formuliere)\b", normalized):
        category = "communication_style"

    instruction = cleaned
    instruction = re.sub(
        r"^(?:nein[,:\s]+)?(?:(?:merk|merke)\s+dir[,:\s]+(?:dass\s+)?)",
        "",
        instruction,
        flags=re.IGNORECASE,
    )
    instruction = _clean(instruction, limit=500).strip(" .")
    if not instruction:
        return None
    instruction = instruction[0].upper() + instruction[1:] + "."
    return CorrectionRule(_correction_key(category, instruction), instruction, cleaned)


@dataclass(frozen=True, slots=True)
class MissionValidation:
    arguments: dict[str, Any]
    valid: bool
    question: str
    missing: str


def _missing_question(kind: str, field: str, index: int) -> str:
    step = f"Schritt {index + 1}"
    questions = {
        ("send_whatsapp_message", "target"): "An wen soll ich die WhatsApp-Nachricht senden?",
        ("send_whatsapp_message", "message"): "Was soll ich in der WhatsApp-Nachricht mitteilen?",
        ("send_email", "target"): "An wen soll ich die E-Mail senden?",
        ("send_email", "message"): "Was soll ich in der E-Mail mitteilen?",
        ("create_calendar_event", "title"): "Wie soll der Termin heißen?",
        ("create_calendar_event", "start"): "Wann beginnt der Termin?",
        ("create_calendar_event", "end"): "Wann endet der Termin?",
        ("create_timer", "seconds"): "Wie lange soll der Timer laufen?",
        ("search_web", "query"): "Wonach soll ich im Internet suchen?",
        ("open_app_or_website", "target"): "Welche freigegebene App oder Webseite soll ich öffnen?",
        ("remember_user_fact", "fact"): "Welche Information soll ich mir merken?",
        ("desktop_plan", "actions"): "Welche konkreten Desktop-Schritte soll ich vorbereiten?",
    }
    return questions.get((kind, field), f"Welche Angabe fehlt noch für {step}?")


def _required_fields(kind: str, payload: dict[str, Any]) -> tuple[str, ...]:
    required = {
        "check_messages": (),
        "search_web": ("query",),
        "send_whatsapp_message": ("target", "message"),
        "send_email": ("target", "message"),
        "create_calendar_event": ("title", "start", "end"),
        "create_timer": ("seconds",),
        "open_app_or_website": ("target",),
        "remember_user_fact": ("fact",),
        "desktop_plan": ("actions",),
    }
    fields = required.get(kind, ())
    if kind == "remember_user_fact" and not payload.get("fact") and payload.get("text"):
        payload["fact"] = payload["text"]
    return fields


def normalize_mission_arguments(
    arguments: object,
    *,
    original_request: str,
    max_steps: int = 12,
) -> MissionValidation:
    """Validate a generated mission and return one blocking clarification at most."""
    raw = dict(arguments) if isinstance(arguments, dict) else {}
    raw_steps = raw.get("steps") if isinstance(raw.get("steps"), list) else []
    safe_max = max(1, min(20, int(max_steps)))
    if not raw_steps:
        return MissionValidation({}, False, "Welche einzelnen Schritte soll ich ausführen?", "steps")
    if len(raw_steps) > safe_max:
        return MissionValidation(
            {},
            False,
            f"Der Auftrag hat mehr als {safe_max} Schritte. Welche Schritte sind wirklich nötig?",
            "steps",
        )

    normalized_steps: list[dict[str, Any]] = []
    for index, raw_step in enumerate(raw_steps):
        if not isinstance(raw_step, dict):
            return MissionValidation(
                {},
                False,
                f"Welche konkrete Aktion soll Schritt {index + 1} ausführen?",
                f"steps[{index}]",
            )
        kind = _clean(raw_step.get("kind"), limit=80).casefold()
        if kind not in MISSION_STEP_KINDS:
            return MissionValidation(
                {},
                False,
                f"Welche konkrete freigegebene Aktion soll Schritt {index + 1} ausführen?",
                f"steps[{index}].kind",
            )
        payload = dict(raw_step.get("payload")) if isinstance(raw_step.get("payload"), dict) else {}
        for field in _required_fields(kind, payload):
            value = payload.get(field)
            missing = not value
            if field == "seconds" and not missing:
                try:
                    missing = int(value) <= 0
                except (TypeError, ValueError):
                    missing = True
            if missing:
                return MissionValidation(
                    {},
                    False,
                    _missing_question(kind, field, index),
                    f"steps[{index}].payload.{field}",
                )
        if kind == "send_email" and not _clean(payload.get("subject"), limit=200):
            payload["subject"] = "Nachricht"
        title = _clean(raw_step.get("title"), limit=180) or kind.replace("_", " ").title()
        normalized_steps.append(
            {
                "kind": kind,
                "title": title,
                "payload": payload,
            }
        )

    request = _clean(original_request, limit=2_000)
    title = _clean(raw.get("title"), limit=160) or "Mehrschritt-Auftrag"
    goal = _clean(raw.get("goal"), limit=2_000) or request
    safety_level = _clean(raw.get("safety_level"), limit=20).casefold()
    if safety_level not in {"strict", "balanced", "trusted"}:
        safety_level = "balanced"
    normalized = {
        "title": title,
        "goal": goal,
        "steps": normalized_steps,
        "safety_level": safety_level,
        "auto_start": bool(raw.get("auto_start")),
    }
    return MissionValidation(normalized, True, "", "")
