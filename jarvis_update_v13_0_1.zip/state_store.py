from __future__ import annotations

import json
import secrets
import sqlite3
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any


DEFAULT_PERMISSIONS: dict[str, tuple[bool, bool]] = {
    "solve_complex_task": (True, False),
    "remember_user_fact": (True, False),
    "recall_user_memory": (True, False),
    "get_home_state": (True, False),
    "control_home_device": (True, True),
    "get_recent_camera_events": (True, False),
    "create_timer": (True, False),
    "cancel_timer": (True, True),
    "get_system_diagnostics": (True, False),
    "search_web": (True, False),
    "analyze_attachments": (True, False),
    "list_contacts": (True, False),
    "manage_contacts": (True, False),
    "check_new_messages": (True, False),
    "search_messages": (True, False),
    "read_message": (True, False),
    "reply_to_message": (True, True),
    "create_mission": (True, False),
    "list_missions": (True, False),
    "send_whatsapp_message": (True, True),
    "send_telegram_message": (True, True),
    "send_email": (True, True),
    "create_calendar_event": (True, True),
    "trigger_webhook": (True, True),
    "open_app_or_website": (True, True),
    "restore_backup": (True, True),
    "clear_safe_mode": (True, True),
    "manage_background_jobs": (True, False),
    "manage_code_workspaces": (True, False),
    "apply_code_changes": (True, True),
    "restore_code_snapshot": (True, True),
    "delete_code_workspace": (True, True),
    "desktop_observe": (True, False),
    "create_desktop_project": (True, True),
    "modify_code_project": (True, True),
    "create_desktop_plan": (True, False),
    "desktop_control": (True, True),
    "browser_agent": (True, True),
    "manage_v11_modules": (True, True),
    "manage_learned_workflows": (True, True),
    "file_automation": (True, True),
    "media_control": (True, True),
    "terminal_agent": (False, True),
    "install_software": (False, True),
    "delete_files": (False, True),
}


DEFAULT_SIMULATION_DEVICES: tuple[tuple[str, str, str, str, dict[str, Any]], ...] = (
    ("light.schreibtisch", "light", "Schreibtischlicht", "off", {"brightness_pct": 70}),
    ("switch.pc", "switch", "Computer", "off", {}),
    ("cover.tuer", "cover", "Zimmertür", "closed", {}),
    ("binary_sensor.motion", "binary_sensor", "Bewegung", "off", {}),
    ("camera.tuer", "camera", "Türkamera", "idle", {}),
    ("climate.zimmer", "climate", "Raumtemperatur", "heat", {"temperature": 21.0}),
)


class JarvisStateStore:
    """Persistent local state for software-only JARVIS features."""

    def __init__(self, database_path: Path) -> None:
        self.database_path = database_path
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.database_path, timeout=5)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA foreign_keys=ON")
        return connection

    @staticmethod
    def _now() -> datetime:
        return datetime.now(UTC)

    @classmethod
    def _now_text(cls) -> str:
        return cls._now().isoformat(timespec="seconds")

    def _initialize(self) -> None:
        with self._connect() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value_json TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS permissions (
                    tool_name TEXT PRIMARY KEY,
                    enabled INTEGER NOT NULL DEFAULT 1,
                    requires_confirmation INTEGER NOT NULL DEFAULT 0,
                    updated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS timers (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    label TEXT NOT NULL,
                    due_at TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'active',
                    created_at TEXT NOT NULL,
                    fired_at TEXT,
                    acknowledged_at TEXT
                );

                CREATE TABLE IF NOT EXISTS contacts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL COLLATE NOCASE UNIQUE,
                    aliases_json TEXT NOT NULL DEFAULT '[]',
                    whatsapp_number TEXT NOT NULL DEFAULT '',
                    whatsapp_chat_name TEXT NOT NULL DEFAULT '',
                    email TEXT NOT NULL DEFAULT '',
                    preferred_email_account TEXT NOT NULL DEFAULT 'auto',
                    telegram_chat_id TEXT NOT NULL DEFAULT '',
                    relationship TEXT NOT NULL DEFAULT '',
                    organization TEXT NOT NULL DEFAULT '',
                    preferred_channel TEXT NOT NULL DEFAULT 'auto',
                    notes TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    last_used_at TEXT,
                    use_count INTEGER NOT NULL DEFAULT 0
                );

                CREATE TABLE IF NOT EXISTS whatsapp_groups (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL COLLATE NOCASE UNIQUE,
                    aliases_json TEXT NOT NULL DEFAULT '[]',
                    chat_name TEXT NOT NULL,
                    notes TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    last_used_at TEXT,
                    use_count INTEGER NOT NULL DEFAULT 0
                );

                CREATE TABLE IF NOT EXISTS audit_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tool_name TEXT NOT NULL,
                    action TEXT NOT NULL,
                    status TEXT NOT NULL,
                    details_json TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS error_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source TEXT NOT NULL,
                    message TEXT NOT NULL,
                    context_json TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS simulation_devices (
                    entity_id TEXT PRIMARY KEY,
                    domain TEXT NOT NULL,
                    name TEXT NOT NULL,
                    state TEXT NOT NULL,
                    attributes_json TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS simulation_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_type TEXT NOT NULL,
                    entity_id TEXT,
                    message TEXT NOT NULL,
                    data_json TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS proactive_suggestions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    suggestion_key TEXT NOT NULL UNIQUE,
                    title TEXT NOT NULL,
                    prompt TEXT NOT NULL,
                    reason TEXT NOT NULL,
                    priority INTEGER NOT NULL DEFAULT 1,
                    status TEXT NOT NULL DEFAULT 'active',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    shown_at TEXT,
                    snoozed_until TEXT
                );

                CREATE TABLE IF NOT EXISTS confirmations (
                    token_hash TEXT PRIMARY KEY,
                    tool_name TEXT NOT NULL,
                    payload_hash TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    used_at TEXT,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS trusted_action_grants (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tool_name TEXT NOT NULL,
                    scope_key TEXT NOT NULL,
                    scope_label TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    last_used_at TEXT,
                    use_count INTEGER NOT NULL DEFAULT 0,
                    UNIQUE(tool_name, scope_key)
                );

                CREATE TABLE IF NOT EXISTS action_receipts (
                    idempotency_key TEXT PRIMARY KEY,
                    action_name TEXT NOT NULL,
                    payload_hash TEXT NOT NULL,
                    result_json TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS action_runs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    request_id TEXT NOT NULL UNIQUE,
                    parent_id INTEGER,
                    tool_name TEXT NOT NULL,
                    label TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'running',
                    mode TEXT NOT NULL DEFAULT '',
                    verification TEXT NOT NULL DEFAULT '',
                    result_summary TEXT NOT NULL DEFAULT '',
                    error TEXT NOT NULL DEFAULT '',
                    attempts INTEGER NOT NULL DEFAULT 1,
                    max_attempts INTEGER NOT NULL DEFAULT 3,
                    app_closed INTEGER NOT NULL DEFAULT 0,
                    authorization TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    finished_at TEXT
                );

                CREATE TABLE IF NOT EXISTS routines (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL COLLATE NOCASE UNIQUE,
                    tool_name TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    schedule TEXT NOT NULL,
                    time_of_day TEXT NOT NULL,
                    weekday INTEGER NOT NULL DEFAULT 0,
                    enabled INTEGER NOT NULL DEFAULT 1,
                    next_run_at TEXT NOT NULL,
                    last_run_at TEXT,
                    last_status TEXT NOT NULL DEFAULT 'never',
                    last_error TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS rate_limit_attempts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    scope TEXT NOT NULL,
                    client_key TEXT NOT NULL,
                    attempted_at REAL NOT NULL
                );

                CREATE TABLE IF NOT EXISTS request_metrics (
                    method TEXT NOT NULL,
                    route TEXT NOT NULL,
                    calls INTEGER NOT NULL DEFAULT 0,
                    errors INTEGER NOT NULL DEFAULT 0,
                    total_latency_ms REAL NOT NULL DEFAULT 0,
                    max_latency_ms REAL NOT NULL DEFAULT 0,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY(method, route)
                );

                CREATE TABLE IF NOT EXISTS model_usage (
                    workload TEXT PRIMARY KEY,
                    calls INTEGER NOT NULL DEFAULT 0,
                    input_tokens INTEGER NOT NULL DEFAULT 0,
                    output_tokens INTEGER NOT NULL DEFAULT 0,
                    updated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS usage_events (
                    event_key TEXT PRIMARY KEY,
                    workload TEXT NOT NULL,
                    model TEXT NOT NULL,
                    input_tokens INTEGER NOT NULL DEFAULT 0,
                    output_tokens INTEGER NOT NULL DEFAULT 0,
                    total_tokens INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS background_jobs (
                    id TEXT PRIMARY KEY,
                    kind TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    status TEXT NOT NULL,
                    result_json TEXT,
                    error TEXT,
                    attempts INTEGER NOT NULL DEFAULT 0,
                    max_attempts INTEGER NOT NULL DEFAULT 3,
                    not_before TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    started_at TEXT,
                    finished_at TEXT
                );

                CREATE TABLE IF NOT EXISTS circuit_breakers (
                    name TEXT PRIMARY KEY,
                    failure_count INTEGER NOT NULL DEFAULT 0,
                    open_until TEXT,
                    last_error TEXT,
                    updated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS schema_migrations (
                    name TEXT PRIMARY KEY,
                    applied_at TEXT NOT NULL
                );

                CREATE INDEX IF NOT EXISTS idx_timers_due ON timers(status, due_at);
                CREATE INDEX IF NOT EXISTS idx_contacts_name ON contacts(name COLLATE NOCASE);
                CREATE INDEX IF NOT EXISTS idx_whatsapp_groups_name ON whatsapp_groups(name COLLATE NOCASE);
                CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_log(created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_errors_created ON error_log(created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_sim_events_created ON simulation_events(created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_suggestions_status ON proactive_suggestions(status, snoozed_until);
                CREATE INDEX IF NOT EXISTS idx_confirmations_expiry ON confirmations(expires_at);
                CREATE INDEX IF NOT EXISTS idx_trusted_actions_tool ON trusted_action_grants(tool_name);
                CREATE INDEX IF NOT EXISTS idx_receipts_expiry ON action_receipts(expires_at);
                CREATE INDEX IF NOT EXISTS idx_action_runs_created ON action_runs(created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_action_runs_status ON action_runs(status, created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_routines_due ON routines(enabled, next_run_at);
                CREATE INDEX IF NOT EXISTS idx_rate_limits ON rate_limit_attempts(scope, client_key, attempted_at);
                CREATE INDEX IF NOT EXISTS idx_usage_created ON usage_events(created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_jobs_status ON background_jobs(status, not_before, created_at);
                """
            )

            contact_columns = {
                str(row[1]) for row in connection.execute("PRAGMA table_info(contacts)").fetchall()
            }
            if "preferred_email_account" not in contact_columns:
                connection.execute(
                    "ALTER TABLE contacts ADD COLUMN preferred_email_account TEXT NOT NULL DEFAULT 'auto'"
                )
            contact_column_migrations = {
                "whatsapp_chat_name": "TEXT NOT NULL DEFAULT ''",
                "relationship": "TEXT NOT NULL DEFAULT ''",
                "organization": "TEXT NOT NULL DEFAULT ''",
                "preferred_channel": "TEXT NOT NULL DEFAULT 'auto'",
                "last_used_at": "TEXT",
                "use_count": "INTEGER NOT NULL DEFAULT 0",
            }
            for column, declaration in contact_column_migrations.items():
                if column not in contact_columns:
                    connection.execute(f"ALTER TABLE contacts ADD COLUMN {column} {declaration}")

            now = self._now_text()
            for tool_name, (enabled, requires_confirmation) in DEFAULT_PERMISSIONS.items():
                connection.execute(
                    """
                    INSERT INTO permissions(tool_name, enabled, requires_confirmation, updated_at)
                    VALUES (?, ?, ?, ?)
                    ON CONFLICT(tool_name) DO NOTHING
                    """,
                    (tool_name, int(enabled), int(requires_confirmation), now),
                )

            for entity_id, domain, name, state, attributes in DEFAULT_SIMULATION_DEVICES:
                connection.execute(
                    """
                    INSERT INTO simulation_devices(entity_id, domain, name, state, attributes_json, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?)
                    ON CONFLICT(entity_id) DO NOTHING
                    """,
                    (entity_id, domain, name, state, json.dumps(attributes), now),
                )

            connection.execute(
                """
                UPDATE proactive_suggestions
                SET status = 'dismissed', updated_at = ?
                WHERE suggestion_key LIKE 'continue-project-%'
                """,
                (now,),
            )

        if self.get_setting("personality") is None:
            self.set_setting(
                "personality",
                {"mode": "normal", "response_length": "short", "humor": 1},
            )
        if self.get_setting("simulation_enabled") is None:
            self.set_setting("simulation_enabled", True)
        if self.get_setting("capabilities") is None:
            self.set_setting("capabilities", {})
        if self.get_setting("proactivity") is None:
            self.set_setting(
                "proactivity",
                {
                    "enabled": True,
                    "quiet_start": "22:00",
                    "quiet_end": "07:00",
                    "min_interval_minutes": 30,
                    "max_visible": 3,
                },
            )
        if self.get_setting("privacy_retention") is None:
            self.set_setting(
                "privacy_retention",
                {"history_days": 30, "audit_days": 30, "error_days": 14},
            )
        if self.get_setting("budget") is None:
            self.set_setting(
                "budget",
                {
                    "daily_token_limit": 250_000,
                    "monthly_token_limit": 3_000_000,
                    "warning_percent": 80,
                    "hard_stop": True,
                },
            )
        if self.get_setting("automation_preferences") is None:
            self.set_setting(
                "automation_preferences",
                {
                    "close_launched_apps": True,
                    "action_retry_limit": 3,
                },
            )
        if self.get_setting("message_assistant") is None:
            self.set_setting(
                "message_assistant",
                {
                    "enabled": True,
                    "auto_refresh": True,
                    "poll_interval_seconds": 120,
                    "announce_new": True,
                    "ask_before_reading": True,
                    "confirm_replies": True,
                    "privacy_when_locked": True,
                    "sources": ["whatsapp", "gmail", "outlook"],
                },
            )
        if self.get_setting("mission_preferences") is None:
            self.set_setting(
                "mission_preferences",
                {
                    "default_safety_level": "balanced",
                    "auto_start": False,
                    "max_steps": 12,
                    "stop_on_error": True,
                },
            )
        self.record_migration("v9.4.1-stability-schema")
        self.record_migration("v9.5.0-code-workspace-schema")
        self.record_migration("v9.5.1-continuous-conversation")
        self.record_migration("v9.6.0-integration-hub")
        self.record_migration("v9.6.1-trusted-actions")
        self.record_migration("v9.7.0-autonomy-connected-accounts")
        self.record_migration("v9.7.2-contacts-and-whatsapp-groups")
        self.record_migration("v9.8.0-action-center-routines")
        self.record_migration("v10.0.0-mission-control-message-assistant")
        self.record_migration("v13.0.1-multistep-correction-learning")

    def get_setting(self, key: str, default: Any = None) -> Any:
        with self._connect() as connection:
            row = connection.execute("SELECT value_json FROM settings WHERE key = ?", (key,)).fetchone()
        if not row:
            return default
        try:
            return json.loads(row["value_json"])
        except json.JSONDecodeError:
            return default

    def set_setting(self, key: str, value: Any) -> Any:
        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO settings(key, value_json, updated_at) VALUES (?, ?, ?)
                ON CONFLICT(key) DO UPDATE SET value_json = excluded.value_json, updated_at = excluded.updated_at
                """,
                (key, json.dumps(value, ensure_ascii=False), self._now_text()),
            )
        return value

    def list_contacts(self) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT id, name, aliases_json, whatsapp_number, whatsapp_chat_name, email,
                       preferred_email_account, telegram_chat_id, relationship, organization,
                       preferred_channel, notes, created_at, updated_at, last_used_at, use_count
                FROM contacts
                ORDER BY use_count DESC, name COLLATE NOCASE
                """
            ).fetchall()
        items: list[dict[str, Any]] = []
        for row in rows:
            try:
                aliases = json.loads(row["aliases_json"])
            except json.JSONDecodeError:
                aliases = []
            items.append(
                {
                    "id": int(row["id"]),
                    "name": row["name"],
                    "aliases": aliases if isinstance(aliases, list) else [],
                    "whatsapp_number": row["whatsapp_number"],
                    "whatsapp_chat_name": row["whatsapp_chat_name"],
                    "email": row["email"],
                    "preferred_email_account": row["preferred_email_account"],
                    "telegram_chat_id": row["telegram_chat_id"],
                    "relationship": row["relationship"],
                    "organization": row["organization"],
                    "preferred_channel": row["preferred_channel"],
                    "notes": row["notes"],
                    "created_at": row["created_at"],
                    "updated_at": row["updated_at"],
                    "last_used_at": row["last_used_at"],
                    "use_count": int(row["use_count"] or 0),
                }
            )
        return items

    def get_contact(self, contact_id: int) -> dict[str, Any] | None:
        return next((item for item in self.list_contacts() if item["id"] == contact_id), None)

    def save_contact(
        self,
        *,
        name: str,
        aliases: list[str] | None = None,
        whatsapp_number: str = "",
        whatsapp_chat_name: str = "",
        email: str = "",
        preferred_email_account: str = "auto",
        telegram_chat_id: str = "",
        relationship: str = "",
        organization: str = "",
        preferred_channel: str = "auto",
        notes: str = "",
        contact_id: int | None = None,
    ) -> dict[str, Any]:
        now = self._now_text()
        clean_aliases = list(dict.fromkeys(str(item).strip() for item in (aliases or []) if str(item).strip()))[:20]
        values = (
            name.strip(),
            json.dumps(clean_aliases, ensure_ascii=False),
            whatsapp_number.strip(),
            whatsapp_chat_name.strip(),
            email.strip(),
            preferred_email_account.strip().casefold(),
            telegram_chat_id.strip(),
            relationship.strip(),
            organization.strip(),
            preferred_channel.strip().casefold(),
            notes.strip(),
            now,
        )
        with self._connect() as connection:
            if contact_id is None:
                cursor = connection.execute(
                    """
                    INSERT INTO contacts(
                        name, aliases_json, whatsapp_number, whatsapp_chat_name, email,
                        preferred_email_account, telegram_chat_id, relationship, organization,
                        preferred_channel, notes, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (*values[:-1], now, now),
                )
                contact_id = int(cursor.lastrowid)
            else:
                cursor = connection.execute(
                    """
                    UPDATE contacts
                    SET name = ?, aliases_json = ?, whatsapp_number = ?, whatsapp_chat_name = ?, email = ?,
                        preferred_email_account = ?, telegram_chat_id = ?, relationship = ?, organization = ?,
                        preferred_channel = ?, notes = ?, updated_at = ?
                    WHERE id = ?
                    """,
                    (*values, contact_id),
                )
                if cursor.rowcount == 0:
                    raise KeyError("Kontakt wurde nicht gefunden.")
        item = self.get_contact(contact_id)
        if not item:
            raise KeyError("Kontakt konnte nicht gespeichert werden.")
        return item

    def delete_contact(self, contact_id: int) -> bool:
        with self._connect() as connection:
            cursor = connection.execute("DELETE FROM contacts WHERE id = ?", (contact_id,))
        return cursor.rowcount > 0

    def list_whatsapp_groups(self) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT id, name, aliases_json, chat_name, notes, created_at, updated_at, last_used_at, use_count
                FROM whatsapp_groups
                ORDER BY use_count DESC, name COLLATE NOCASE
                """
            ).fetchall()
        items: list[dict[str, Any]] = []
        for row in rows:
            try:
                aliases = json.loads(row["aliases_json"])
            except json.JSONDecodeError:
                aliases = []
            items.append(
                {
                    "id": int(row["id"]),
                    "name": row["name"],
                    "aliases": aliases if isinstance(aliases, list) else [],
                    "chat_name": row["chat_name"],
                    "notes": row["notes"],
                    "created_at": row["created_at"],
                    "updated_at": row["updated_at"],
                    "last_used_at": row["last_used_at"],
                    "use_count": int(row["use_count"] or 0),
                }
            )
        return items

    def get_whatsapp_group(self, group_id: int) -> dict[str, Any] | None:
        return next((item for item in self.list_whatsapp_groups() if item["id"] == group_id), None)

    def save_whatsapp_group(
        self,
        *,
        name: str,
        chat_name: str,
        aliases: list[str] | None = None,
        notes: str = "",
        group_id: int | None = None,
    ) -> dict[str, Any]:
        now = self._now_text()
        clean_aliases = list(dict.fromkeys(str(item).strip() for item in (aliases or []) if str(item).strip()))[:20]
        values = (
            name.strip(),
            json.dumps(clean_aliases, ensure_ascii=False),
            chat_name.strip(),
            notes.strip(),
            now,
        )
        with self._connect() as connection:
            if group_id is None:
                cursor = connection.execute(
                    """
                    INSERT INTO whatsapp_groups(name, aliases_json, chat_name, notes, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (*values[:-1], now, now),
                )
                group_id = int(cursor.lastrowid)
            else:
                cursor = connection.execute(
                    """
                    UPDATE whatsapp_groups
                    SET name = ?, aliases_json = ?, chat_name = ?, notes = ?, updated_at = ?
                    WHERE id = ?
                    """,
                    (*values, group_id),
                )
                if cursor.rowcount == 0:
                    raise KeyError("WhatsApp-Gruppe wurde nicht gefunden.")
        item = self.get_whatsapp_group(group_id)
        if not item:
            raise KeyError("WhatsApp-Gruppe konnte nicht gespeichert werden.")
        return item

    def delete_whatsapp_group(self, group_id: int) -> bool:
        with self._connect() as connection:
            cursor = connection.execute("DELETE FROM whatsapp_groups WHERE id = ?", (group_id,))
        return cursor.rowcount > 0

    def touch_communication_target(self, target_kind: str, target_id: int, channel: str = "") -> None:
        table = "contacts" if target_kind == "contact" else "whatsapp_groups" if target_kind == "group" else ""
        if not table:
            return
        with self._connect() as connection:
            connection.execute(
                f"UPDATE {table} SET last_used_at = ?, use_count = use_count + 1 WHERE id = ?",
                (self._now_text(), target_id),
            )
            if table == "contacts" and channel in {"whatsapp", "email", "telegram"}:
                connection.execute(
                    """
                    UPDATE contacts SET preferred_channel = ?
                    WHERE id = ? AND preferred_channel = 'auto'
                    """,
                    (channel, target_id),
                )

    def list_permissions(self) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT tool_name, enabled, requires_confirmation, updated_at FROM permissions ORDER BY tool_name"
            ).fetchall()
        return [
            {
                "tool_name": row["tool_name"],
                "enabled": bool(row["enabled"]),
                "requires_confirmation": bool(row["requires_confirmation"]),
                "updated_at": row["updated_at"],
            }
            for row in rows
        ]

    def permission(self, tool_name: str) -> dict[str, Any]:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT tool_name, enabled, requires_confirmation FROM permissions WHERE tool_name = ?",
                (tool_name,),
            ).fetchone()
        if not row:
            return {"tool_name": tool_name, "enabled": False, "requires_confirmation": True}
        return {
            "tool_name": row["tool_name"],
            "enabled": bool(row["enabled"]),
            "requires_confirmation": bool(row["requires_confirmation"]),
        }

    def update_permission(
        self,
        tool_name: str,
        *,
        enabled: bool,
        requires_confirmation: bool,
    ) -> dict[str, Any]:
        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO permissions(tool_name, enabled, requires_confirmation, updated_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(tool_name) DO UPDATE SET
                    enabled = excluded.enabled,
                    requires_confirmation = excluded.requires_confirmation,
                    updated_at = excluded.updated_at
                """,
                (tool_name, int(enabled), int(requires_confirmation), self._now_text()),
            )
        return self.permission(tool_name)

    def add_audit(self, tool_name: str, action: str, status: str, details: dict[str, Any] | None = None) -> None:
        with self._connect() as connection:
            connection.execute(
                "INSERT INTO audit_log(tool_name, action, status, details_json, created_at) VALUES (?, ?, ?, ?, ?)",
                (
                    tool_name[:80],
                    action[:160],
                    status[:40],
                    json.dumps(details or {}, ensure_ascii=False, default=str),
                    self._now_text(),
                ),
            )

    def recent_audit(self, limit: int = 30) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT id, tool_name, action, status, details_json, created_at FROM audit_log ORDER BY id DESC LIMIT ?",
                (max(1, min(200, limit)),),
            ).fetchall()
        return [
            {
                "id": row["id"],
                "tool_name": row["tool_name"],
                "action": row["action"],
                "status": row["status"],
                "details": json.loads(row["details_json"]),
                "created_at": row["created_at"],
            }
            for row in rows
        ]

    def add_error(self, source: str, message: str, context: dict[str, Any] | None = None) -> None:
        with self._connect() as connection:
            connection.execute(
                "INSERT INTO error_log(source, message, context_json, created_at) VALUES (?, ?, ?, ?)",
                (
                    source[:80],
                    message[:2_000],
                    json.dumps(context or {}, ensure_ascii=False, default=str),
                    self._now_text(),
                ),
            )

    def recent_errors(self, limit: int = 20) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT id, source, message, context_json, created_at FROM error_log ORDER BY id DESC LIMIT ?",
                (max(1, min(100, limit)),),
            ).fetchall()
        return [
            {
                "id": row["id"],
                "source": row["source"],
                "message": row["message"],
                "context": json.loads(row["context_json"]),
                "created_at": row["created_at"],
            }
            for row in rows
        ]

    def cleanup_logs(self, *, audit_days: int, error_days: int) -> dict[str, int]:
        audit_cutoff = (self._now() - timedelta(days=max(1, audit_days))).isoformat(timespec="seconds")
        error_cutoff = (self._now() - timedelta(days=max(1, error_days))).isoformat(timespec="seconds")
        with self._connect() as connection:
            audit = connection.execute("DELETE FROM audit_log WHERE created_at < ?", (audit_cutoff,)).rowcount
            errors = connection.execute("DELETE FROM error_log WHERE created_at < ?", (error_cutoff,)).rowcount
        return {"audit_deleted": max(0, int(audit)), "errors_deleted": max(0, int(errors))}

    def allow_rate_limit(
        self,
        scope: str,
        client_key: str,
        *,
        limit: int,
        window_seconds: float,
    ) -> bool:
        """Atomically persist a bounded sliding-window rate limit across restarts and workers."""
        now = self._now().timestamp()
        cutoff = now - max(1.0, float(window_seconds))
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                "DELETE FROM rate_limit_attempts WHERE attempted_at < ?",
                (now - 86_400,),
            )
            connection.execute(
                "DELETE FROM rate_limit_attempts WHERE scope = ? AND client_key = ? AND attempted_at < ?",
                (scope[:80], client_key[:128], cutoff),
            )
            count = connection.execute(
                "SELECT COUNT(*) FROM rate_limit_attempts WHERE scope = ? AND client_key = ?",
                (scope[:80], client_key[:128]),
            ).fetchone()[0]
            if int(count) >= max(1, limit):
                return False
            connection.execute(
                "INSERT INTO rate_limit_attempts(scope, client_key, attempted_at) VALUES (?, ?, ?)",
                (scope[:80], client_key[:128], now),
            )
        return True

    def record_request_metric(self, method: str, route: str, latency_ms: float, status_code: int) -> None:
        latency = max(0.0, float(latency_ms))
        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO request_metrics(method, route, calls, errors, total_latency_ms, max_latency_ms, updated_at)
                VALUES (?, ?, 1, ?, ?, ?, ?)
                ON CONFLICT(method, route) DO UPDATE SET
                    calls = request_metrics.calls + 1,
                    errors = request_metrics.errors + excluded.errors,
                    total_latency_ms = request_metrics.total_latency_ms + excluded.total_latency_ms,
                    max_latency_ms = MAX(request_metrics.max_latency_ms, excluded.max_latency_ms),
                    updated_at = excluded.updated_at
                """,
                (
                    method[:12],
                    route[:200],
                    int(status_code >= 400),
                    latency,
                    latency,
                    self._now_text(),
                ),
            )

    def request_metrics(self, limit: int = 40) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT method, route, calls, errors, total_latency_ms, max_latency_ms, updated_at
                FROM request_metrics ORDER BY updated_at DESC LIMIT ?
                """,
                (max(1, min(100, limit)),),
            ).fetchall()
        return [
            {
                "method": row["method"],
                "route": row["route"],
                "calls": int(row["calls"]),
                "errors": int(row["errors"]),
                "average_latency_ms": round(float(row["total_latency_ms"]) / max(1, int(row["calls"])), 1),
                "max_latency_ms": round(float(row["max_latency_ms"]), 1),
                "updated_at": row["updated_at"],
            }
            for row in rows
        ]

    def record_model_usage(
        self,
        workload: str,
        usage: dict[str, Any] | None,
        *,
        model: str = "",
        event_key: str | None = None,
    ) -> bool:
        data = usage or {}
        input_tokens = max(0, int(data.get("input_tokens", 0) or 0))
        output_tokens = max(0, int(data.get("output_tokens", 0) or 0))
        total_tokens = max(input_tokens + output_tokens, int(data.get("total_tokens", 0) or 0))
        key = (event_key or secrets.token_urlsafe(18))[:180]
        with self._connect() as connection:
            inserted = connection.execute(
                """
                INSERT OR IGNORE INTO usage_events(
                    event_key, workload, model, input_tokens, output_tokens, total_tokens, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    key,
                    workload[:80],
                    model[:120],
                    input_tokens,
                    output_tokens,
                    total_tokens,
                    self._now_text(),
                ),
            ).rowcount
            if not inserted:
                return False
            connection.execute(
                """
                INSERT INTO model_usage(workload, calls, input_tokens, output_tokens, updated_at)
                VALUES (?, 1, ?, ?, ?)
                ON CONFLICT(workload) DO UPDATE SET
                    calls = model_usage.calls + 1,
                    input_tokens = model_usage.input_tokens + excluded.input_tokens,
                    output_tokens = model_usage.output_tokens + excluded.output_tokens,
                    updated_at = excluded.updated_at
                """,
                (workload[:80], input_tokens, output_tokens, self._now_text()),
            )
            connection.execute(
                "DELETE FROM usage_events WHERE created_at < ?",
                ((self._now() - timedelta(days=400)).isoformat(timespec="seconds"),),
            )
        return True

    def model_usage(self) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT workload, calls, input_tokens, output_tokens, updated_at FROM model_usage ORDER BY workload"
            ).fetchall()
        return [dict(row) for row in rows]

    def budget_status(self, settings: dict[str, Any] | None = None) -> dict[str, Any]:
        item = settings or self.get_setting(
            "budget",
            {"daily_token_limit": 250_000, "monthly_token_limit": 3_000_000, "warning_percent": 80, "hard_stop": True},
        )
        now = self._now()
        day_start = now.replace(hour=0, minute=0, second=0, microsecond=0).isoformat(timespec="seconds")
        month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0).isoformat(timespec="seconds")
        with self._connect() as connection:
            daily = connection.execute(
                "SELECT COALESCE(SUM(total_tokens), 0) FROM usage_events WHERE created_at >= ?",
                (day_start,),
            ).fetchone()[0]
            monthly = connection.execute(
                "SELECT COALESCE(SUM(total_tokens), 0) FROM usage_events WHERE created_at >= ?",
                (month_start,),
            ).fetchone()[0]
        daily_limit = max(0, int(item.get("daily_token_limit", 0) or 0))
        monthly_limit = max(0, int(item.get("monthly_token_limit", 0) or 0))
        warning_percent = max(1, min(100, int(item.get("warning_percent", 80) or 80)))
        daily_percent = round((int(daily) / daily_limit) * 100, 2) if daily_limit else 0.0
        monthly_percent = round((int(monthly) / monthly_limit) * 100, 2) if monthly_limit else 0.0
        daily_exceeded = bool(daily_limit and int(daily) >= daily_limit)
        monthly_exceeded = bool(monthly_limit and int(monthly) >= monthly_limit)
        return {
            "daily_tokens": int(daily),
            "monthly_tokens": int(monthly),
            "daily_token_limit": daily_limit,
            "monthly_token_limit": monthly_limit,
            "warning_percent": warning_percent,
            "daily_percent": daily_percent,
            "monthly_percent": monthly_percent,
            "warning": bool(
                (daily_limit and daily_percent >= warning_percent)
                or (monthly_limit and monthly_percent >= warning_percent)
            ),
            "hard_stop": bool(item.get("hard_stop", True)),
            "exceeded": daily_exceeded or monthly_exceeded,
            "daily_exceeded": daily_exceeded,
            "monthly_exceeded": monthly_exceeded,
        }

    def enqueue_job(self, kind: str, payload: dict[str, Any], *, max_attempts: int = 3) -> dict[str, Any]:
        job_id = secrets.token_urlsafe(18)
        now = self._now_text()
        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO background_jobs(
                    id, kind, payload_json, status, attempts, max_attempts, not_before, created_at, updated_at
                ) VALUES (?, ?, ?, 'queued', 0, ?, ?, ?, ?)
                """,
                (job_id, kind[:80], json.dumps(payload, ensure_ascii=False), max(1, min(5, max_attempts)), now, now, now),
            )
        return self.get_job(job_id) or {}

    @staticmethod
    def _job_from_row(row: sqlite3.Row | None) -> dict[str, Any] | None:
        if not row:
            return None
        item = dict(row)
        for source, target in (("payload_json", "payload"), ("result_json", "result")):
            raw = item.pop(source, None)
            try:
                item[target] = json.loads(raw) if raw else None
            except json.JSONDecodeError:
                item[target] = None
        return item

    def get_job(self, job_id: str) -> dict[str, Any] | None:
        with self._connect() as connection:
            row = connection.execute("SELECT * FROM background_jobs WHERE id = ?", (job_id,)).fetchone()
        return self._job_from_row(row)

    def list_jobs(self, limit: int = 30) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT * FROM background_jobs ORDER BY created_at DESC LIMIT ?",
                (max(1, min(100, limit)),),
            ).fetchall()
        return [item for row in rows if (item := self._job_from_row(row)) is not None]

    def recover_interrupted_jobs(self) -> int:
        now = self._now_text()
        with self._connect() as connection:
            failed = connection.execute(
                """
                UPDATE background_jobs SET status = 'failed', error = 'Maximale Versuche nach Neustart erreicht.',
                    finished_at = ?, updated_at = ?
                WHERE status = 'running' AND attempts >= max_attempts
                """,
                (now, now),
            ).rowcount
            queued = connection.execute(
                """
                UPDATE background_jobs SET status = 'queued', error = 'Nach Neustart wieder aufgenommen.',
                    not_before = ?, updated_at = ?
                WHERE status = 'running' AND attempts < max_attempts
                """,
                (now, now),
            ).rowcount
        return max(0, int(queued)) + max(0, int(failed))

    def claim_next_job(self) -> dict[str, Any] | None:
        now = self._now_text()
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                """
                SELECT * FROM background_jobs
                WHERE status = 'queued' AND not_before <= ?
                ORDER BY created_at LIMIT 1
                """,
                (now,),
            ).fetchone()
            if not row:
                return None
            connection.execute(
                """
                UPDATE background_jobs SET status = 'running', attempts = attempts + 1,
                    started_at = COALESCE(started_at, ?), updated_at = ? WHERE id = ? AND status = 'queued'
                """,
                (now, now, row["id"]),
            )
            claimed = connection.execute("SELECT * FROM background_jobs WHERE id = ?", (row["id"],)).fetchone()
        return self._job_from_row(claimed)

    def complete_job(self, job_id: str, result: dict[str, Any]) -> bool:
        now = self._now_text()
        with self._connect() as connection:
            cursor = connection.execute(
                """
                UPDATE background_jobs SET status = 'completed', result_json = ?, error = NULL,
                    finished_at = ?, updated_at = ? WHERE id = ? AND status = 'running'
                """,
                (json.dumps(result, ensure_ascii=False, default=str), now, now, job_id),
            )
        return cursor.rowcount > 0

    def fail_job(self, job_id: str, error: str, *, retry_delay_seconds: int = 0) -> str:
        now_value = self._now()
        now = now_value.isoformat(timespec="seconds")
        with self._connect() as connection:
            row = connection.execute(
                "SELECT attempts, max_attempts, status FROM background_jobs WHERE id = ?",
                (job_id,),
            ).fetchone()
            if not row or row["status"] == "cancelled":
                return "cancelled"
            retry = int(row["attempts"]) < int(row["max_attempts"])
            status = "queued" if retry else "failed"
            not_before = (now_value + timedelta(seconds=max(0, retry_delay_seconds))).isoformat(timespec="seconds")
            connection.execute(
                """
                UPDATE background_jobs SET status = ?, error = ?, not_before = ?,
                    finished_at = CASE WHEN ? = 'failed' THEN ? ELSE NULL END, updated_at = ? WHERE id = ?
                """,
                (status, error[:2000], not_before, status, now, now, job_id),
            )
        return status

    def cancel_job(self, job_id: str) -> bool:
        now = self._now_text()
        with self._connect() as connection:
            cursor = connection.execute(
                """
                UPDATE background_jobs SET status = 'cancelled', finished_at = ?, updated_at = ?
                WHERE id = ? AND status IN ('queued', 'running')
                """,
                (now, now, job_id),
            )
        return cursor.rowcount > 0

    def retry_job(self, job_id: str) -> bool:
        now = self._now_text()
        with self._connect() as connection:
            cursor = connection.execute(
                """
                UPDATE background_jobs SET status = 'queued', attempts = 0, error = NULL,
                    result_json = NULL, not_before = ?, started_at = NULL, finished_at = NULL, updated_at = ?
                WHERE id = ? AND status IN ('failed', 'cancelled')
                """,
                (now, now, job_id),
            )
        return cursor.rowcount > 0

    def circuit_status(self, name: str) -> dict[str, Any]:
        with self._connect() as connection:
            row = connection.execute("SELECT * FROM circuit_breakers WHERE name = ?", (name[:80],)).fetchone()
        if not row:
            return {"name": name, "failure_count": 0, "open_until": None, "last_error": None, "open": False}
        item = dict(row)
        item["open"] = bool(item.get("open_until") and str(item["open_until"]) > self._now_text())
        return item

    def circuit_allow(self, name: str) -> bool:
        return not bool(self.circuit_status(name).get("open"))

    def circuit_success(self, name: str) -> None:
        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO circuit_breakers(name, failure_count, open_until, last_error, updated_at)
                VALUES (?, 0, NULL, NULL, ?)
                ON CONFLICT(name) DO UPDATE SET failure_count = 0, open_until = NULL,
                    last_error = NULL, updated_at = excluded.updated_at
                """,
                (name[:80], self._now_text()),
            )

    def circuit_failure(self, name: str, error: str, *, threshold: int = 4, cooldown_seconds: int = 45) -> dict[str, Any]:
        current = self.circuit_status(name)
        failures = int(current.get("failure_count", 0)) + 1
        open_until = (
            (self._now() + timedelta(seconds=max(10, cooldown_seconds))).isoformat(timespec="seconds")
            if failures >= max(1, threshold)
            else None
        )
        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO circuit_breakers(name, failure_count, open_until, last_error, updated_at)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(name) DO UPDATE SET failure_count = excluded.failure_count,
                    open_until = excluded.open_until, last_error = excluded.last_error, updated_at = excluded.updated_at
                """,
                (name[:80], failures, open_until, error[:1000], self._now_text()),
            )
        return self.circuit_status(name)

    def record_migration(self, name: str) -> None:
        with self._connect() as connection:
            connection.execute(
                "INSERT OR IGNORE INTO schema_migrations(name, applied_at) VALUES (?, ?)",
                (name[:160], self._now_text()),
            )

    def list_migrations(self) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute("SELECT name, applied_at FROM schema_migrations ORDER BY applied_at, name").fetchall()
        return [dict(row) for row in rows]

    def upsert_suggestion(
        self,
        suggestion_key: str,
        *,
        title: str,
        prompt: str,
        reason: str,
        priority: int = 1,
    ) -> dict[str, Any]:
        now = self._now_text()
        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO proactive_suggestions(
                    suggestion_key, title, prompt, reason, priority, status, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, 'active', ?, ?)
                ON CONFLICT(suggestion_key) DO UPDATE SET
                    title = excluded.title,
                    prompt = excluded.prompt,
                    reason = excluded.reason,
                    priority = excluded.priority,
                    updated_at = excluded.updated_at,
                    status = CASE
                        WHEN proactive_suggestions.status = 'accepted' THEN 'accepted'
                        WHEN proactive_suggestions.status = 'dismissed' THEN 'dismissed'
                        ELSE 'active'
                    END
                """,
                (
                    suggestion_key[:160],
                    title[:160],
                    prompt[:500],
                    reason[:300],
                    max(1, min(5, priority)),
                    now,
                    now,
                ),
            )
            row = connection.execute(
                "SELECT * FROM proactive_suggestions WHERE suggestion_key = ?",
                (suggestion_key[:160],),
            ).fetchone()
        return dict(row) if row else {}

    def list_suggestions(self, *, limit: int = 3, min_interval_minutes: int = 30) -> list[dict[str, Any]]:
        now_value = self._now()
        now = now_value.isoformat(timespec="seconds")
        shown_cutoff = (now_value - timedelta(minutes=max(5, min(1440, min_interval_minutes)))).isoformat(
            timespec="seconds"
        )
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT id, suggestion_key, title, prompt, reason, priority, status,
                       created_at, updated_at, shown_at, snoozed_until
                FROM proactive_suggestions
                WHERE status = 'active'
                  AND (snoozed_until IS NULL OR snoozed_until <= ?)
                  AND (shown_at IS NULL OR shown_at <= ?)
                ORDER BY priority DESC, updated_at DESC
                LIMIT ?
                """,
                (now, shown_cutoff, max(1, min(10, limit))),
            ).fetchall()
            ids = [int(row["id"]) for row in rows]
            if ids:
                placeholders = ",".join("?" for _ in ids)
                connection.execute(
                    f"UPDATE proactive_suggestions SET shown_at = ? WHERE id IN ({placeholders})",
                    (now, *ids),
                )
        return [dict(row) for row in rows]

    def update_suggestion(self, suggestion_id: int, action: str, *, snooze_minutes: int = 60) -> bool:
        now = self._now()
        if action == "dismiss":
            status = "dismissed"
            snoozed_until = None
        elif action == "accept":
            status = "accepted"
            snoozed_until = None
        elif action == "snooze":
            status = "active"
            snoozed_until = (now + timedelta(minutes=max(5, min(1440, snooze_minutes)))).isoformat(timespec="seconds")
        else:
            return False
        with self._connect() as connection:
            cursor = connection.execute(
                """
                UPDATE proactive_suggestions
                SET status = ?, snoozed_until = ?, updated_at = ?
                WHERE id = ?
                """,
                (status, snoozed_until, now.isoformat(timespec="seconds"), suggestion_id),
            )
        return cursor.rowcount > 0

    def create_confirmation(
        self,
        token_hash: str,
        *,
        tool_name: str,
        payload_hash: str,
        ttl_seconds: int = 90,
    ) -> None:
        now = self._now()
        expires_at = now + timedelta(seconds=max(30, min(300, ttl_seconds)))
        with self._connect() as connection:
            connection.execute("DELETE FROM confirmations WHERE expires_at <= ? OR used_at IS NOT NULL", (now.isoformat(timespec="seconds"),))
            connection.execute(
                """
                INSERT INTO confirmations(token_hash, tool_name, payload_hash, expires_at, created_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    token_hash,
                    tool_name[:80],
                    payload_hash,
                    expires_at.isoformat(timespec="seconds"),
                    now.isoformat(timespec="seconds"),
                ),
            )

    def consume_confirmation(self, token_hash: str, *, tool_name: str, payload_hash: str) -> bool:
        now = self._now_text()
        with self._connect() as connection:
            cursor = connection.execute(
                """
                UPDATE confirmations SET used_at = ?
                WHERE token_hash = ? AND tool_name = ? AND payload_hash = ?
                  AND used_at IS NULL AND expires_at > ?
                """,
                (now, token_hash, tool_name, payload_hash, now),
            )
        return cursor.rowcount > 0

    def grant_trusted_action(self, tool_name: str, scope_key: str, scope_label: str) -> dict[str, Any]:
        now = self._now_text()
        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO trusted_action_grants(tool_name, scope_key, scope_label, created_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(tool_name, scope_key) DO UPDATE SET
                    scope_label = excluded.scope_label
                """,
                (tool_name[:80], scope_key[:128], scope_label[:180], now),
            )
            row = connection.execute(
                """
                SELECT id, tool_name, scope_label, created_at, last_used_at, use_count
                FROM trusted_action_grants
                WHERE tool_name = ? AND scope_key = ?
                """,
                (tool_name[:80], scope_key[:128]),
            ).fetchone()
        if not row:
            raise RuntimeError("Dauerfreigabe konnte nicht gespeichert werden.")
        return {
            "id": int(row["id"]),
            "tool_name": row["tool_name"],
            "scope_label": row["scope_label"],
            "created_at": row["created_at"],
            "last_used_at": row["last_used_at"],
            "use_count": int(row["use_count"]),
        }

    def trusted_action_granted(self, tool_name: str, scope_key: str, *, touch: bool = False) -> bool:
        with self._connect() as connection:
            row = connection.execute(
                """
                SELECT id FROM trusted_action_grants
                WHERE tool_name = ? AND scope_key = ?
                """,
                (tool_name[:80], scope_key[:128]),
            ).fetchone()
            if row and touch:
                connection.execute(
                    """
                    UPDATE trusted_action_grants
                    SET last_used_at = ?, use_count = use_count + 1
                    WHERE id = ?
                    """,
                    (self._now_text(), int(row["id"])),
                )
        return row is not None

    def list_trusted_actions(self) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT id, tool_name, scope_label, created_at, last_used_at, use_count
                FROM trusted_action_grants
                ORDER BY tool_name, scope_label COLLATE NOCASE
                """
            ).fetchall()
        return [
            {
                "id": int(row["id"]),
                "tool_name": row["tool_name"],
                "scope_label": row["scope_label"],
                "created_at": row["created_at"],
                "last_used_at": row["last_used_at"],
                "use_count": int(row["use_count"]),
            }
            for row in rows
        ]

    def revoke_trusted_action(self, grant_id: int) -> bool:
        with self._connect() as connection:
            cursor = connection.execute("DELETE FROM trusted_action_grants WHERE id = ?", (grant_id,))
        return cursor.rowcount > 0

    def get_action_receipt(self, idempotency_key: str, *, action_name: str, payload_hash: str) -> dict[str, Any] | None:
        now = self._now_text()
        with self._connect() as connection:
            connection.execute("DELETE FROM action_receipts WHERE expires_at <= ?", (now,))
            row = connection.execute(
                """
                SELECT result_json FROM action_receipts
                WHERE idempotency_key = ? AND action_name = ? AND payload_hash = ?
                """,
                (idempotency_key, action_name, payload_hash),
            ).fetchone()
        if not row:
            return None
        try:
            result = json.loads(row["result_json"])
        except json.JSONDecodeError:
            return None
        return result if isinstance(result, dict) else None

    def action_receipt_exists(self, idempotency_key: str) -> bool:
        now = self._now_text()
        with self._connect() as connection:
            connection.execute("DELETE FROM action_receipts WHERE expires_at <= ?", (now,))
            row = connection.execute(
                "SELECT 1 FROM action_receipts WHERE idempotency_key = ?",
                (idempotency_key,),
            ).fetchone()
        return row is not None

    def save_action_receipt(
        self,
        idempotency_key: str,
        *,
        action_name: str,
        payload_hash: str,
        result: dict[str, Any],
        ttl_hours: int = 24,
    ) -> None:
        now = self._now()
        with self._connect() as connection:
            connection.execute(
                """
                INSERT OR REPLACE INTO action_receipts(
                    idempotency_key, action_name, payload_hash, result_json, expires_at, created_at
                ) VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    idempotency_key[:160],
                    action_name[:80],
                    payload_hash,
                    json.dumps(result, ensure_ascii=False, default=str),
                    (now + timedelta(hours=max(1, min(168, ttl_hours)))).isoformat(timespec="seconds"),
                    now.isoformat(timespec="seconds"),
                ),
            )

    @staticmethod
    def _decode_mapping(value: str) -> dict[str, Any]:
        try:
            item = json.loads(value)
        except (TypeError, json.JSONDecodeError):
            return {}
        return item if isinstance(item, dict) else {}

    def _action_run_item(self, row: sqlite3.Row, *, include_payload: bool = False) -> dict[str, Any]:
        item = {
            "id": int(row["id"]),
            "request_id": row["request_id"],
            "parent_id": int(row["parent_id"]) if row["parent_id"] is not None else None,
            "tool_name": row["tool_name"],
            "label": row["label"],
            "status": row["status"],
            "mode": row["mode"],
            "verification": row["verification"],
            "result_summary": row["result_summary"],
            "error": row["error"],
            "attempts": int(row["attempts"]),
            "max_attempts": int(row["max_attempts"]),
            "app_closed": bool(row["app_closed"]),
            "authorization": row["authorization"],
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
            "finished_at": row["finished_at"],
        }
        if include_payload:
            item["payload"] = self._decode_mapping(row["payload_json"])
        return item

    def start_action_run(
        self,
        request_id: str,
        *,
        tool_name: str,
        label: str,
        payload: dict[str, Any],
        max_attempts: int = 3,
        parent_id: int | None = None,
    ) -> dict[str, Any]:
        now = self._now_text()
        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO action_runs(
                    request_id, parent_id, tool_name, label, payload_json, status,
                    attempts, max_attempts, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, 'running', 1, ?, ?, ?)
                ON CONFLICT(request_id) DO NOTHING
                """,
                (
                    request_id[:160],
                    parent_id,
                    tool_name[:80],
                    label[:180],
                    json.dumps(payload, ensure_ascii=False, default=str),
                    max(1, min(5, int(max_attempts))),
                    now,
                    now,
                ),
            )
            row = connection.execute(
                "SELECT * FROM action_runs WHERE request_id = ?",
                (request_id[:160],),
            ).fetchone()
        return self._action_run_item(row, include_payload=True) if row else {}

    def finish_action_run(
        self,
        request_id: str,
        result: dict[str, Any],
        *,
        authorization: str = "",
    ) -> dict[str, Any] | None:
        now = self._now_text()
        summary = str(
            result.get("result_summary")
            or result.get("message")
            or ("Aktion erfolgreich abgeschlossen." if result.get("ok") else "Aktion beendet.")
        )
        with self._connect() as connection:
            connection.execute(
                """
                UPDATE action_runs SET status = 'success', mode = ?, verification = ?,
                    result_summary = ?, error = '', app_closed = ?, authorization = ?,
                    updated_at = ?, finished_at = ?
                WHERE request_id = ?
                """,
                (
                    str(result.get("mode") or "direct")[:80],
                    str(result.get("verification") or "completed")[:120],
                    summary[:500],
                    int(bool(result.get("app_closed"))),
                    authorization[:40],
                    now,
                    now,
                    request_id[:160],
                ),
            )
            row = connection.execute(
                "SELECT * FROM action_runs WHERE request_id = ?",
                (request_id[:160],),
            ).fetchone()
        return self._action_run_item(row) if row else None

    def fail_action_run(self, request_id: str, error: str) -> dict[str, Any] | None:
        now = self._now_text()
        with self._connect() as connection:
            connection.execute(
                """
                UPDATE action_runs SET status = 'failed', error = ?, updated_at = ?, finished_at = ?
                WHERE request_id = ?
                """,
                (str(error)[:2_000], now, now, request_id[:160]),
            )
            row = connection.execute(
                "SELECT * FROM action_runs WHERE request_id = ?",
                (request_id[:160],),
            ).fetchone()
        return self._action_run_item(row) if row else None

    def get_action_run(self, action_id: int, *, include_payload: bool = False) -> dict[str, Any] | None:
        with self._connect() as connection:
            row = connection.execute("SELECT * FROM action_runs WHERE id = ?", (action_id,)).fetchone()
        return self._action_run_item(row, include_payload=include_payload) if row else None

    def list_action_runs(self, limit: int = 30) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT * FROM action_runs ORDER BY id DESC LIMIT ?",
                (max(1, min(100, int(limit))),),
            ).fetchall()
        return [self._action_run_item(row) for row in rows]

    def restart_action_run(self, action_id: int) -> dict[str, Any] | None:
        now = self._now_text()
        with self._connect() as connection:
            connection.execute(
                """
                UPDATE action_runs SET status = 'running', error = '', result_summary = '',
                    attempts = attempts + 1, updated_at = ?, finished_at = NULL
                WHERE id = ? AND status = 'failed' AND attempts < max_attempts
                """,
                (now, action_id),
            )
            row = connection.execute("SELECT * FROM action_runs WHERE id = ?", (action_id,)).fetchone()
        if not row or row["status"] != "running":
            return None
        return self._action_run_item(row, include_payload=True)

    def _routine_item(self, row: sqlite3.Row, *, include_payload: bool = True) -> dict[str, Any]:
        item = {
            "id": int(row["id"]),
            "name": row["name"],
            "tool_name": row["tool_name"],
            "schedule": row["schedule"],
            "time_of_day": row["time_of_day"],
            "weekday": int(row["weekday"]),
            "enabled": bool(row["enabled"]),
            "next_run_at": row["next_run_at"],
            "last_run_at": row["last_run_at"],
            "last_status": row["last_status"],
            "last_error": row["last_error"],
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
        }
        if include_payload:
            item["payload"] = self._decode_mapping(row["payload_json"])
        return item

    def save_routine(
        self,
        *,
        name: str,
        tool_name: str,
        payload: dict[str, Any],
        schedule: str,
        time_of_day: str,
        weekday: int,
        enabled: bool,
        next_run_at: str,
        routine_id: int | None = None,
    ) -> dict[str, Any]:
        now = self._now_text()
        with self._connect() as connection:
            values = (
                name[:120],
                tool_name[:80],
                json.dumps(payload, ensure_ascii=False, default=str),
                schedule[:20],
                time_of_day[:5],
                max(0, min(6, int(weekday))),
                int(bool(enabled)),
                next_run_at,
                now,
            )
            if routine_id is None:
                cursor = connection.execute(
                    """
                    INSERT INTO routines(
                        name, tool_name, payload_json, schedule, time_of_day, weekday,
                        enabled, next_run_at, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (*values, now),
                )
                routine_id = int(cursor.lastrowid)
            else:
                cursor = connection.execute(
                    """
                    UPDATE routines SET name = ?, tool_name = ?, payload_json = ?, schedule = ?,
                        time_of_day = ?, weekday = ?, enabled = ?, next_run_at = ?, updated_at = ?
                    WHERE id = ?
                    """,
                    (*values, routine_id),
                )
                if cursor.rowcount == 0:
                    raise KeyError("Routine wurde nicht gefunden.")
        item = self.get_routine(routine_id)
        if not item:
            raise KeyError("Routine konnte nicht gespeichert werden.")
        return item

    def list_routines(self) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT * FROM routines ORDER BY enabled DESC, next_run_at, name COLLATE NOCASE"
            ).fetchall()
        return [self._routine_item(row) for row in rows]

    def get_routine(self, routine_id: int) -> dict[str, Any] | None:
        with self._connect() as connection:
            row = connection.execute("SELECT * FROM routines WHERE id = ?", (routine_id,)).fetchone()
        return self._routine_item(row) if row else None

    def delete_routine(self, routine_id: int) -> bool:
        with self._connect() as connection:
            cursor = connection.execute("DELETE FROM routines WHERE id = ?", (routine_id,))
        return cursor.rowcount > 0

    def due_routines(self, limit: int = 5) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT * FROM routines
                WHERE enabled = 1 AND next_run_at <= ?
                ORDER BY next_run_at, id LIMIT ?
                """,
                (self._now_text(), max(1, min(20, int(limit)))),
            ).fetchall()
        return [self._routine_item(row) for row in rows]

    def claim_routine(self, routine_id: int, expected_next_run: str, next_run_at: str) -> bool:
        now = self._now_text()
        with self._connect() as connection:
            cursor = connection.execute(
                """
                UPDATE routines SET next_run_at = ?, last_run_at = ?, last_status = 'running',
                    last_error = '', updated_at = ?
                WHERE id = ? AND enabled = 1 AND next_run_at = ?
                """,
                (next_run_at, now, now, routine_id, expected_next_run),
            )
        return cursor.rowcount > 0

    def finish_routine(self, routine_id: int, *, status: str, error: str = "") -> None:
        with self._connect() as connection:
            connection.execute(
                "UPDATE routines SET last_status = ?, last_error = ?, updated_at = ? WHERE id = ?",
                (status[:40], str(error)[:2_000], self._now_text(), routine_id),
            )

    def create_timer(self, label: str, seconds: int) -> dict[str, Any]:
        cleaned = " ".join(label.split()).strip() or "Timer"
        safe_seconds = max(1, min(604_800, int(seconds)))
        created_at = self._now()
        due_at = created_at + timedelta(seconds=safe_seconds)
        with self._connect() as connection:
            cursor = connection.execute(
                "INSERT INTO timers(label, due_at, status, created_at) VALUES (?, ?, 'active', ?)",
                (
                    cleaned[:200],
                    due_at.isoformat(timespec="seconds"),
                    created_at.isoformat(timespec="seconds"),
                ),
            )
        self.add_audit("create_timer", cleaned, "success", {"seconds": safe_seconds})
        return self.get_timer(int(cursor.lastrowid)) or {}

    def _refresh_due_timers(self) -> None:
        now = self._now_text()
        with self._connect() as connection:
            due_rows = connection.execute(
                "SELECT id, label FROM timers WHERE status = 'active' AND due_at <= ?",
                (now,),
            ).fetchall()
            connection.execute(
                "UPDATE timers SET status = 'fired', fired_at = ? WHERE status = 'active' AND due_at <= ?",
                (now, now),
            )
        for row in due_rows:
            self.add_audit("timer", row["label"], "fired", {"timer_id": row["id"]})

    def get_timer(self, timer_id: int) -> dict[str, Any] | None:
        self._refresh_due_timers()
        with self._connect() as connection:
            row = connection.execute(
                "SELECT id, label, due_at, status, created_at, fired_at, acknowledged_at FROM timers WHERE id = ?",
                (timer_id,),
            ).fetchone()
        return dict(row) if row else None

    def list_timers(self, limit: int = 100) -> list[dict[str, Any]]:
        self._refresh_due_timers()
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT id, label, due_at, status, created_at, fired_at, acknowledged_at
                FROM timers
                WHERE status IN ('active', 'fired')
                ORDER BY CASE status WHEN 'fired' THEN 0 ELSE 1 END, due_at
                LIMIT ?
                """,
                (max(1, min(200, limit)),),
            ).fetchall()
        return [dict(row) for row in rows]

    def cancel_timer(self, timer_id: int) -> bool:
        with self._connect() as connection:
            cursor = connection.execute(
                "UPDATE timers SET status = 'cancelled' WHERE id = ? AND status = 'active'",
                (timer_id,),
            )
        if cursor.rowcount:
            self.add_audit("cancel_timer", str(timer_id), "success")
        return cursor.rowcount > 0

    def acknowledge_timer(self, timer_id: int) -> bool:
        with self._connect() as connection:
            cursor = connection.execute(
                "UPDATE timers SET status = 'acknowledged', acknowledged_at = ? WHERE id = ? AND status = 'fired'",
                (self._now_text(), timer_id),
            )
        return cursor.rowcount > 0

    def simulation_enabled(self) -> bool:
        return bool(self.get_setting("simulation_enabled", True))

    def set_simulation_enabled(self, enabled: bool) -> bool:
        self.set_setting("simulation_enabled", bool(enabled))
        self.add_audit("simulation", "mode", "enabled" if enabled else "disabled")
        return bool(enabled)

    def list_simulation_devices(self) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT entity_id, domain, name, state, attributes_json, updated_at FROM simulation_devices ORDER BY domain, name"
            ).fetchall()
        return [
            {
                "entity_id": row["entity_id"],
                "domain": row["domain"],
                "name": row["name"],
                "state": row["state"],
                "attributes": json.loads(row["attributes_json"]),
                "updated_at": row["updated_at"],
            }
            for row in rows
        ]

    def get_simulation_device(self, entity_id: str) -> dict[str, Any] | None:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT entity_id, domain, name, state, attributes_json, updated_at FROM simulation_devices WHERE entity_id = ?",
                (entity_id,),
            ).fetchone()
        if not row:
            return None
        return {
            "entity_id": row["entity_id"],
            "domain": row["domain"],
            "name": row["name"],
            "state": row["state"],
            "attributes": json.loads(row["attributes_json"]),
            "updated_at": row["updated_at"],
        }

    def update_simulation_device(
        self,
        entity_id: str,
        *,
        state: str,
        attributes: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        current = self.get_simulation_device(entity_id)
        if not current:
            return None
        merged_attributes = dict(current["attributes"])
        merged_attributes.update(attributes or {})
        with self._connect() as connection:
            connection.execute(
                "UPDATE simulation_devices SET state = ?, attributes_json = ?, updated_at = ? WHERE entity_id = ?",
                (
                    state[:80],
                    json.dumps(merged_attributes, ensure_ascii=False),
                    self._now_text(),
                    entity_id,
                ),
            )
        result = self.get_simulation_device(entity_id)
        self.add_audit("simulation", entity_id, "updated", {"state": state, "attributes": attributes or {}})
        return result

    def control_simulation_device(
        self,
        entity_id: str,
        domain: str,
        service: str,
        data: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        current = self.get_simulation_device(entity_id)
        if not current or current["domain"] != domain:
            return None
        attributes = dict(data or {})
        state = str(current["state"])
        if service == "turn_on":
            state = "on"
        elif service == "turn_off":
            state = "off"
        elif service == "toggle":
            state = "off" if state == "on" else "on"
        elif service == "open_cover":
            state = "open"
        elif service == "close_cover":
            state = "closed"
        elif service == "stop_cover":
            state = "stopped"
        elif service in {"set_temperature", "set_hvac_mode", "volume_set", "media_play_pause", "media_stop"}:
            state = str(attributes.get("hvac_mode", state))
        return self.update_simulation_device(entity_id, state=state, attributes=attributes)

    def add_simulation_event(
        self,
        event_type: str,
        message: str,
        *,
        entity_id: str | None = None,
        data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        created_at = self._now_text()
        with self._connect() as connection:
            cursor = connection.execute(
                "INSERT INTO simulation_events(event_type, entity_id, message, data_json, created_at) VALUES (?, ?, ?, ?, ?)",
                (
                    event_type[:80],
                    entity_id,
                    message[:500],
                    json.dumps(data or {}, ensure_ascii=False),
                    created_at,
                ),
            )
        self.add_audit("simulation_event", event_type, "success", {"entity_id": entity_id})
        return {
            "id": cursor.lastrowid,
            "event_type": event_type,
            "entity_id": entity_id,
            "message": message,
            "data": data or {},
            "created_at": created_at,
        }

    def list_simulation_events(self, limit: int = 20) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT id, event_type, entity_id, message, data_json, created_at FROM simulation_events ORDER BY id DESC LIMIT ?",
                (max(1, min(200, limit)),),
            ).fetchall()
        return [
            {
                "id": row["id"],
                "event_type": row["event_type"],
                "entity_id": row["entity_id"],
                "message": row["message"],
                "data": json.loads(row["data_json"]),
                "created_at": row["created_at"],
            }
            for row in rows
        ]

    def stats(self) -> dict[str, int]:
        self._refresh_due_timers()
        with self._connect() as connection:
            timers = connection.execute("SELECT COUNT(*) FROM timers WHERE status = 'active'").fetchone()[0]
            errors = connection.execute("SELECT COUNT(*) FROM error_log").fetchone()[0]
            audit = connection.execute("SELECT COUNT(*) FROM audit_log").fetchone()[0]
            contacts = connection.execute("SELECT COUNT(*) FROM contacts").fetchone()[0]
            trusted_actions = connection.execute("SELECT COUNT(*) FROM trusted_action_grants").fetchone()[0]
            active_routines = connection.execute("SELECT COUNT(*) FROM routines WHERE enabled = 1").fetchone()[0]
            pending_actions = connection.execute(
                "SELECT COUNT(*) FROM action_runs WHERE status IN ('running', 'failed')"
            ).fetchone()[0]
            queued_jobs = connection.execute(
                "SELECT COUNT(*) FROM background_jobs WHERE status IN ('queued', 'running')"
            ).fetchone()[0]
        return {
            "active_timers": int(timers),
            "errors": int(errors),
            "audit_entries": int(audit),
            "contacts": int(contacts),
            "trusted_actions": int(trusted_actions),
            "active_routines": int(active_routines),
            "pending_actions": int(pending_actions),
            "active_background_jobs": int(queued_jobs),
        }
