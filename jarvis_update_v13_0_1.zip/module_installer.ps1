[CmdletBinding()]
param(
    [ValidateSet("agents", "memory", "voice", "vision", "experimental", "stable", "all", "check")]
    [string]$Mode = "all",
    [switch]$Automatic
)

$ErrorActionPreference = "Continue"
$ProgressPreference = "SilentlyContinue"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$InstallerDir = Join-Path $Root "data\installer"
$LogFile = Join-Path $InstallerDir "module-install.log"
$SummaryFile = Join-Path $InstallerDir "module-install-summary.json"
$MainVenv = Join-Path $Root ".venv"
$ExtraRoot = Join-Path $Root ".jarvis_envs"
$script:Results = [System.Collections.Generic.List[object]]::new()
$script:CriticalFailure = $false

New-Item -ItemType Directory -Path $InstallerDir -Force | Out-Null
New-Item -ItemType Directory -Path $ExtraRoot -Force | Out-Null
"JARVIS v13.0.1 module installation - $(Get-Date -Format o) - mode=$Mode" |
    Set-Content -Path $LogFile -Encoding UTF8

function Write-Section {
    param([string]$Text)
    Write-Host ""
    Write-Host "=== $Text ===" -ForegroundColor Cyan
    Add-Content -Path $LogFile -Value "`n=== $Text ===" -Encoding UTF8
}

function Add-Result {
    param(
        [string]$Name,
        [bool]$Ok,
        [int]$ExitCode,
        [bool]$Required,
        [string]$Detail = ""
    )
    $script:Results.Add([pscustomobject]@{
        name = $Name
        ok = $Ok
        exit_code = $ExitCode
        required = $Required
        detail = $Detail
        timestamp = (Get-Date -Format o)
    })
    if (-not $Ok -and $Required) {
        $script:CriticalFailure = $true
    }
}

function Invoke-Native {
    param(
        [string]$Name,
        [string]$FilePath,
        [string[]]$Arguments,
        [bool]$Required = $false
    )
    Write-Host "-> $Name" -ForegroundColor Yellow
    Add-Content -Path $LogFile -Value "`n[$Name] $FilePath $($Arguments -join ' ')" -Encoding UTF8
    try {
        & $FilePath @Arguments 2>&1 |
            ForEach-Object {
                $line = $_.ToString()
                Write-Host $line
                Add-Content -Path $LogFile -Value $line -Encoding UTF8
            }
        $code = if ($null -eq $LASTEXITCODE) { 0 } else { [int]$LASTEXITCODE }
    } catch {
        $errorText = $_ | Out-String
        Write-Host $errorText
        Add-Content -Path $LogFile -Value $errorText -Encoding UTF8
        $code = 1
    }
    $ok = $code -eq 0
    Add-Result -Name $Name -Ok $ok -ExitCode $code -Required $Required
    if ($ok) {
        Write-Host "   OK" -ForegroundColor Green
    } else {
        Write-Host "   FEHLER (Code $code)" -ForegroundColor Red
    }
    return $ok
}

function Refresh-Path {
    $machinePath = [Environment]::GetEnvironmentVariable("Path", "Machine")
    $userPath = [Environment]::GetEnvironmentVariable("Path", "User")
    $env:Path = "$machinePath;$userPath"
}

function Test-Python312 {
    param([string]$FilePath, [string[]]$Prefix = @())
    if (-not (Test-Path $FilePath) -and -not (Get-Command $FilePath -ErrorAction SilentlyContinue)) {
        return $false
    }
    & $FilePath @Prefix -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 12) else 1)" *> $null
    return $LASTEXITCODE -eq 0
}

function Find-Python312 {
    $py = Get-Command "py.exe" -ErrorAction SilentlyContinue
    if ($py -and (Test-Python312 -FilePath $py.Source -Prefix @("-3.12"))) {
        return [pscustomobject]@{ file = $py.Source; prefix = @("-3.12") }
    }

    $candidates = @(
        (Join-Path $env:LOCALAPPDATA "Programs\Python\Python312\python.exe"),
        (Join-Path $env:ProgramFiles "Python312\python.exe"),
        (Join-Path $env:ProgramFiles "Python 3.12\python.exe")
    )
    foreach ($candidate in $candidates) {
        if (Test-Python312 -FilePath $candidate) {
            return [pscustomobject]@{ file = $candidate; prefix = @() }
        }
    }

    $python = Get-Command "python.exe" -ErrorAction SilentlyContinue
    if ($python -and (Test-Python312 -FilePath $python.Source)) {
        return [pscustomobject]@{ file = $python.Source; prefix = @() }
    }
    return $null
}

function Install-WingetPackage {
    param([string]$Name, [string]$Id, [bool]$Required = $false)
    $winget = Get-Command "winget.exe" -ErrorAction SilentlyContinue
    if (-not $winget) {
        Add-Result -Name $Name -Ok $false -ExitCode 1 -Required $Required -Detail "winget fehlt"
        Write-Host "winget fehlt: $Name konnte nicht automatisch installiert werden." -ForegroundColor Red
        return $false
    }
    $arguments = @(
        "install", "--id", $Id, "-e", "--silent",
        "--accept-source-agreements", "--accept-package-agreements",
        "--disable-interactivity"
    )
    $ok = Invoke-Native -Name $Name -FilePath $winget.Source -Arguments $arguments -Required $Required
    Refresh-Path
    return $ok
}

function Ensure-Python312 {
    $python = Find-Python312
    if ($python) {
        Add-Result -Name "Python 3.12 gefunden" -Ok $true -ExitCode 0 -Required $true
        return $python
    }
    Write-Section "Python 3.12"
    Install-WingetPackage -Name "Python 3.12 installieren" -Id "Python.Python.3.12" -Required $true | Out-Null
    $python = Find-Python312
    if (-not $python) {
        Add-Result -Name "Python 3.12 nach Installation" -Ok $false -ExitCode 1 -Required $true
        throw "Python 3.12 wurde nicht gefunden. Windows einmal neu starten und INSTALLIEREN.bat erneut ausfuehren."
    }
    return $python
}

function Invoke-BasePython {
    param([object]$Python, [string]$Name, [string[]]$Arguments, [bool]$Required = $false)
    $allArguments = @($Python.prefix) + $Arguments
    return Invoke-Native -Name $Name -FilePath $Python.file -Arguments $allArguments -Required $Required
}

function Ensure-Venv {
    param([object]$Python, [string]$Path, [string]$Name, [bool]$Required = $false)
    $venvPython = Join-Path $Path "Scripts\python.exe"
    if (Test-Path $venvPython) {
        & $venvPython -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 12) else 1)" *> $null
        if ($LASTEXITCODE -ne 0) {
            $backupName = "$(Split-Path $Path -Leaf).incompatible.$(Get-Date -Format yyyyMMddHHmmss)"
            $backupPath = Join-Path (Split-Path $Path -Parent) $backupName
            Move-Item -Path $Path -Destination $backupPath
            Add-Content -Path $LogFile -Value "Alte Umgebung verschoben nach $backupPath" -Encoding UTF8
        }
    }
    if (-not (Test-Path $venvPython)) {
        $ok = Invoke-BasePython -Python $Python -Name "$Name erstellen" -Arguments @("-m", "venv", $Path) -Required $Required
        if (-not $ok) {
            return $null
        }
    }
    return $venvPython
}

function Bootstrap-Uv {
    param([string]$VenvPython, [string]$Name, [bool]$Required = $false)
    $ok = Invoke-Native -Name "${Name}: pip und uv" -FilePath $VenvPython -Arguments @(
        "-m", "pip", "install", "--disable-pip-version-check", "--upgrade",
        "pip", "setuptools", "wheel", "uv"
    ) -Required $Required
    if (-not $ok) {
        return $null
    }
    return Join-Path (Split-Path $VenvPython -Parent) "uv.exe"
}

function Install-Main {
    param([object]$Python, [string[]]$Files)
    Write-Section "Isolierter JARVIS-Kern"
    $venvPython = Ensure-Venv -Python $Python -Path $MainVenv -Name "JARVIS-Umgebung" -Required $true
    if (-not $venvPython) {
        return $false
    }
    $uv = Bootstrap-Uv -VenvPython $venvPython -Name "JARVIS-Umgebung" -Required $true
    if (-not $uv) {
        return $false
    }
    $arguments = @(
        "pip", "install", "--python", $venvPython, "--torch-backend", "cpu",
        "--only-binary", "litellm"
    )
    foreach ($file in $Files) {
        $arguments += @("-r", (Join-Path $Root $file))
    }
    $ok = Invoke-Native -Name "JARVIS-Pakete installieren" -FilePath $uv -Arguments $arguments -Required $true
    if (-not $ok) {
        return $false
    }
    Invoke-Native -Name "Python-Abhaengigkeiten pruefen" -FilePath $venvPython -Arguments @("-m", "pip", "check") -Required $true | Out-Null
    if ($Files -contains "requirements.txt" -or $Files -contains "requirements-v11-agents.txt") {
        Invoke-Native -Name "Playwright Chromium installieren" -FilePath $venvPython -Arguments @(
            "-m", "playwright", "install", "chromium"
        ) -Required $false | Out-Null
    }
    return $true
}

function Install-Isolated {
    param(
        [object]$Python,
        [string]$Key,
        [string]$RequirementFile,
        [string]$DisplayName,
        [bool]$InstallBrowser = $false
    )
    Write-Section $DisplayName
    $path = Join-Path $ExtraRoot $Key
    $installedMarker = Join-Path $path ".jarvis-installed"
    $browserMarker = Join-Path $path ".jarvis-playwright-ready"
    Remove-Item -Path $installedMarker -Force -ErrorAction SilentlyContinue
    if ($InstallBrowser) {
        Remove-Item -Path $browserMarker -Force -ErrorAction SilentlyContinue
    }
    $venvPython = Ensure-Venv -Python $Python -Path $path -Name $DisplayName -Required $false
    if (-not $venvPython) {
        return $false
    }
    $uv = Bootstrap-Uv -VenvPython $venvPython -Name $DisplayName -Required $false
    if (-not $uv) {
        return $false
    }
    $ok = Invoke-Native -Name "$DisplayName installieren" -FilePath $uv -Arguments @(
        "pip", "install", "--python", $venvPython,
        "-r", (Join-Path $Root $RequirementFile)
    ) -Required $false
    if ($ok) {
        Invoke-Native -Name "$DisplayName pruefen" -FilePath $venvPython -Arguments @("-m", "pip", "check") -Required $false | Out-Null
        if ($InstallBrowser) {
            $playwrightReady = Invoke-Native -Name "$DisplayName Playwright pruefen" -FilePath $venvPython -Arguments @(
                "-c", "import playwright"
            ) -Required $false
            if ($playwrightReady) {
                $browserReady = Invoke-Native -Name "$DisplayName Chromium" -FilePath $venvPython -Arguments @(
                    "-m", "playwright", "install", "chromium"
                ) -Required $false
                if ($browserReady) {
                    New-Item -ItemType File -Path $browserMarker -Force | Out-Null
                }
                $ok = $ok -and $browserReady
            } else {
                $ok = $false
            }
        }
        if ($ok) {
            New-Item -ItemType File -Path $installedMarker -Force | Out-Null
        }
    }
    return $ok
}

function Install-ExternalRuntimes {
    Write-Section "Externe Laufzeiten"
    if (-not (Get-Command "node.exe" -ErrorAction SilentlyContinue)) {
        Install-WingetPackage -Name "Node.js LTS installieren" -Id "OpenJS.NodeJS.LTS" | Out-Null
    } else {
        Add-Result -Name "Node.js gefunden" -Ok $true -ExitCode 0 -Required $false
    }
    if (-not (Get-Command "ollama.exe" -ErrorAction SilentlyContinue)) {
        Install-WingetPackage -Name "Ollama installieren" -Id "Ollama.Ollama" | Out-Null
    } else {
        Add-Result -Name "Ollama gefunden" -Ok $true -ExitCode 0 -Required $false
    }
    if (-not (Get-Command "cargo.exe" -ErrorAction SilentlyContinue)) {
        Install-WingetPackage -Name "Rustup fuer Tauri installieren" -Id "Rustlang.Rustup" | Out-Null
    } else {
        Add-Result -Name "Rust/Cargo gefunden" -Ok $true -ExitCode 0 -Required $false
    }
    if (-not (Get-Command "git.exe" -ErrorAction SilentlyContinue)) {
        Install-WingetPackage -Name "Git installieren" -Id "Git.Git" | Out-Null
    } else {
        Add-Result -Name "Git gefunden" -Ok $true -ExitCode 0 -Required $false
    }

    Refresh-Path
    $npm = Get-Command "npm.cmd" -ErrorAction SilentlyContinue
    $serviceDir = Join-Path $Root "services\whatsapp-webjs"
    if ($npm -and (Test-Path (Join-Path $serviceDir "package.json"))) {
        Push-Location $serviceDir
        try {
            Invoke-Native -Name "whatsapp-web.js Abhaengigkeiten" -FilePath $npm.Source -Arguments @(
                "install", "--omit=dev", "--no-audit", "--no-fund"
            ) -Required $false | Out-Null
        } finally {
            Pop-Location
        }
    } else {
        Add-Result -Name "whatsapp-web.js Abhaengigkeiten" -Ok $false -ExitCode 1 -Required $false -Detail "Node/npm fehlt"
    }
}

function Run-ModuleCheck {
    $venvPython = Join-Path $MainVenv "Scripts\python.exe"
    if (Test-Path $venvPython) {
        Invoke-Native -Name "JARVIS-Moduldiagnose" -FilePath $venvPython -Arguments @(
            (Join-Path $Root "module_check.py")
        ) -Required $false | Out-Null
    } else {
        Add-Result -Name "JARVIS-Moduldiagnose" -Ok $false -ExitCode 1 -Required $false -Detail ".venv fehlt"
    }
}

try {
    Set-Location $Root
    if ($Mode -eq "check") {
        Run-ModuleCheck
    } else {
        $python = Ensure-Python312
        $mainFiles = @("requirements.txt")
        switch ($Mode) {
            "agents" { $mainFiles += "requirements-v11-agents.txt" }
            "memory" { $mainFiles += "requirements-v11-memory.txt" }
            "voice" { $mainFiles += "requirements-v11-voice.txt" }
            "vision" { $mainFiles += "requirements-v11-vision-media.txt" }
            "stable" {
                $mainFiles += @(
                    "requirements-v11-agents.txt",
                    "requirements-v11-memory.txt",
                    "requirements-v11-voice.txt",
                    "requirements-v11-vision-media.txt"
                )
            }
            "all" {
                $mainFiles += @(
                    "requirements-v11-agents.txt",
                    "requirements-v11-memory.txt",
                    "requirements-v11-voice.txt",
                    "requirements-v11-vision-media.txt"
                )
            }
        }
        Install-Main -Python $python -Files $mainFiles | Out-Null

        if ($Mode -in @("voice", "stable", "all")) {
            Install-Isolated -Python $python -Key "ovos" -RequirementFile "requirements-v11-ovos.txt" -DisplayName "OpenVoiceOS" | Out-Null
        }
        if ($Mode -in @("experimental", "all")) {
            Install-Isolated -Python $python -Key "open-interpreter" -RequirementFile "requirements-v11-open-interpreter.txt" -DisplayName "Open Interpreter" | Out-Null
            Install-Isolated -Python $python -Key "openadapt" -RequirementFile "requirements-v11-openadapt.txt" -DisplayName "OpenAdapt" -InstallBrowser $true | Out-Null
        }
        if ($Mode -eq "all") {
            Install-ExternalRuntimes
        }
        Run-ModuleCheck
    }
} catch {
    $errorText = $_ | Out-String
    Write-Host $errorText
    Add-Content -Path $LogFile -Value $errorText -Encoding UTF8
    Add-Result -Name "Installer" -Ok $false -ExitCode 1 -Required $true -Detail $_.Exception.Message
}

$summary = [pscustomobject]@{
    version = "13.0.1"
    mode = $Mode
    automatic = [bool]$Automatic
    completed_at = (Get-Date -Format o)
    critical_failure = $script:CriticalFailure
    results = $script:Results
}
$summary | ConvertTo-Json -Depth 8 | Set-Content -Path $SummaryFile -Encoding UTF8

Write-Section "Ergebnis"
if ($script:CriticalFailure) {
    Write-Host "Die Kerninstallation ist fehlgeschlagen." -ForegroundColor Red
    Write-Host "Bericht: $LogFile"
    exit 1
}
Write-Host "Kerninstallation abgeschlossen." -ForegroundColor Green
Write-Host "Bericht: $LogFile"
exit 0
