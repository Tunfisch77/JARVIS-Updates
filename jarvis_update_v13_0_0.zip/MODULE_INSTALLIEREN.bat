@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title JARVIS v13.0.0 Module

if /i "%~1"=="--auto" goto auto

:menu
cls
echo ============================================================
echo JARVIS v13.0.0 - MODUL-INSTALLATION
echo ============================================================
echo.
echo [1] Agenten und Browser-Agent
echo [2] Memory, Vektorsuche und Datenbankverschluesselung
echo [3] Offline-Stimme, Wakeword und OpenVoiceOS
echo [4] Vision, Windows-APIs und Spotify
echo [5] Experimentell: Open Interpreter und OpenAdapt
echo [8] Alle stabilen Gruppen
echo [9] Alles inklusive experimentell und externe Laufzeiten
echo [P] Nur pruefen und Fehlerbericht erstellen
echo [0] Beenden
echo.
set /p choice=Auswahl:

if /i "%choice%"=="1" set "mode=agents"
if /i "%choice%"=="2" set "mode=memory"
if /i "%choice%"=="3" set "mode=voice"
if /i "%choice%"=="4" set "mode=vision"
if /i "%choice%"=="5" set "mode=experimental"
if /i "%choice%"=="8" set "mode=stable"
if /i "%choice%"=="9" set "mode=all"
if /i "%choice%"=="P" set "mode=check"
if /i "%choice%"=="0" exit /b 0

if not defined mode goto menu
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0module_installer.ps1" -Mode "%mode%"
set "result=%errorlevel%"
echo.
if "%result%"=="0" (
  echo Vorgang abgeschlossen. Details: data\installer\module-install.log
) else (
  echo Mindestens ein wichtiger Schritt ist fehlgeschlagen.
  echo Details: data\installer\module-install.log
)
pause
set "mode="
goto menu

:auto
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0module_installer.ps1" -Mode all -Automatic
exit /b %errorlevel%
