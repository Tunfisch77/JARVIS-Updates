@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title JARVIS v13.0.0 Installation
echo JARVIS richtet jetzt Python 3.12, den isolierten Kern und alle Module ein.
echo Das kann beim ersten Mal je nach Internetverbindung laenger dauern.
echo.
call "%~dp0MODULE_INSTALLIEREN.bat" --auto
if errorlevel 1 (
  echo.
  echo Die Kerninstallation ist fehlgeschlagen.
  echo Fehlerbericht: data\installer\module-install.log
  pause
  exit /b 1
)
echo.
echo Installation abgeschlossen.
pause
