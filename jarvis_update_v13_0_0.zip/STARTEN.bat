@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist .env (
  echo FEHLER: Die Datei .env fehlt.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  echo JARVIS wird beim ersten Start automatisch eingerichtet...
  call "%~dp0MODULE_INSTALLIEREN.bat" --auto
  if errorlevel 1 (
    echo Fehlerbericht: data\installer\module-install.log
    pause
    exit /b 1
  )
)
echo Starte JARVIS v13.0.0 auf Port 8017...
start "" cmd /c "timeout /t 2 /nobreak >nul & start http://127.0.0.1:8017/?v=13.0.0"
".venv\Scripts\python.exe" -m uvicorn app:app --host 127.0.0.1 --port 8017
pause
