#!/usr/bin/env bash
set -Eeuo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if [[ ! -x .venv/bin/python ]]; then echo "Zuerst bash INSTALLIEREN.sh starten." >&2; exit 1; fi
exec .venv/bin/python jarvis_linux.py whatsapp-window
