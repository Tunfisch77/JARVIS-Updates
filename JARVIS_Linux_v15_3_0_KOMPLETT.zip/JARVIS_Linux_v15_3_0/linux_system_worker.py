"""System-Python helper: registered apps, AT-SPI, BlueZ and XDG portals."""
from __future__ import annotations
import json
import os
from pathlib import Path
import re
import sys
import time
import unicodedata

def norm(value):
    value = unicodedata.normalize('NFKD', str(value).casefold())
    return ' '.join(re.findall(r'[^\W_]+', ''.join(c for c in value if not unicodedata.combining(c))))

def gio():
    import gi
    gi.require_version('Gio', '2.0')
    from gi.repository import Gio, GLib
    return Gio, GLib

def desktop_class():
    Gio, _ = gio()
    if hasattr(Gio, 'DesktopAppInfo'): return Gio.DesktopAppInfo
    import gi
    gi.require_version('GioUnix', '2.0')
    from gi.repository import GioUnix
    return GioUnix.DesktopAppInfo

def apps():
    Gio, _ = gio()
    result = []
    for info in Gio.AppInfo.get_all():
        if not info.should_show() or not info.get_id(): continue
        desktop = desktop_class().new(info.get_id())
        if not desktop: continue
        exe = Path(info.get_executable() or '').name.casefold()
        terminal = desktop.get_boolean('Terminal') or 'TerminalEmulator' in (desktop.get_categories() or '') or exe in {
            'sh','bash','dash','zsh','fish','python','python3','perl','ruby','node','pwsh','env'}
        result.append(dict(id=info.get_id(), name=info.get_display_name(), executable=exe, terminal=terminal))
    return result

def find_app(target, items):
    wanted = norm(target)
    exact = [i for i in items if wanted in {norm(i['id']), norm(i['name']), norm(i['executable'])}]
    if len(exact) > 1:
        raise RuntimeError('Mehrere Apps heißen so. Die eindeutige App-ID verwenden: '+', '.join(i['id'] for i in exact[:5]))
    if not exact: raise RuntimeError('Keine installierte Desktop-App mit diesem Namen gefunden. Namen aus dem Mint-Startmenü verwenden.')
    return exact[0]

def launch_app(payload):
    item = find_app(payload['target'], apps())
    if item['terminal'] and not payload.get('allow_terminal'):
        raise RuntimeError('Terminal- und Kommandozeilenstarter sind in den Agent-Einstellungen gesperrt.')
    app = desktop_class().new(item['id'])
    Gio, _ = gio()
    context = Gio.AppLaunchContext()
    context.setenv('QT_LINUX_ACCESSIBILITY_ALWAYS_ON','1')
    if not app or not app.launch([], context): raise RuntimeError('Die Anwendung hat den Start nicht angenommen.')
    return dict(ok=True, app=item)

def atspi():
    import gi
    gi.require_version('Atspi', '2.0')
    from gi.repository import Atspi
    Atspi.init(); Atspi.set_timeout(1000, 1000)
    return Atspi

def walk(node, *, limit=8000, seconds=6):
    pending, count, deadline = [node], 0, time.monotonic()+seconds
    while pending:
        if time.monotonic() > deadline or count >= limit:
            raise RuntimeError('Die vollständige UI-Suche hat ihr Zeitlimit erreicht. Genaueres Fenster wählen.')
        current = pending.pop(); count += 1
        if current is None: raise RuntimeError('Die Oberfläche hat sich während der Suche geändert.')
        yield current
        try:
            children = current.get_child_count()
            if children > 2000: raise RuntimeError('Zu viele Bedienelemente für eine eindeutige Suche.')
            pending.extend(current.get_child_at_index(i) for i in range(children))
        except RuntimeError: raise
        except Exception as exc:
            raise RuntimeError('Die Oberfläche hat sich während der Suche geändert. Erneut prüfen.') from exc

def windows(Atspi):
    result = []
    desktop = Atspi.get_desktop(0)
    for i in range(desktop.get_child_count()):
        app = desktop.get_child_at_index(i)
        count = app.get_child_count()
        if count > 500: raise RuntimeError('Zu viele Fenster für eine eindeutige Suche.')
        for j in range(count):
            window = app.get_child_at_index(j)
            if window.get_name() and window.get_state_set().contains(Atspi.StateType.SHOWING):
                result.append((window, app.get_name() or ''))
    return result

def named_control(payload, *, focus=False):
    Atspi = atspi()
    target = norm(payload['window'])
    available = windows(Atspi)
    matches = [(w,a) for w,a in available if norm(w.get_name()) == target]
    matches = matches or [(w,a) for w,a in available if target and target in norm(w.get_name())]
    if len(matches) != 1: raise RuntimeError('Fenster nicht eindeutig in AT-SPI gefunden. Exakten sichtbaren Titel angeben.')
    window = matches[0][0]
    if focus:
        if not window.get_component_iface().grab_focus(): raise RuntimeError('Die Anwendung erlaubt keinen Fensterfokus über AT-SPI.')
        return {'ok':True}
    wanted, candidates = norm(payload['control']), []
    for node in walk(window):
        if norm(node.get_name() or '') != wanted: continue
        state = node.get_state_set()
        if not (state.contains(Atspi.StateType.SHOWING) and state.contains(Atspi.StateType.ENABLED)): continue
        try:
            action = node.get_action_iface()
            actions = [i for i in range(action.get_n_actions()) if str(action.get_action_name(i)).casefold() in {'click','press','activate','toggle'}]
        except Exception: continue
        if len(actions) == 1: candidates.append((action, actions[0]))
    if len(candidates) != 1:
        raise RuntimeError('Bedienelement fehlt, ist nicht eindeutig oder bietet keine Klickaktion über AT-SPI an. Es wurde nichts angeklickt.')
    action, index = candidates[0]
    if not action.do_action(index): raise RuntimeError('Die Anwendung hat die Klickaktion abgelehnt.')
    return dict(ok=True, window=payload['window'], control=payload['control'], method='atspi')

def probe():
    result = dict(ok=True, gio=False, atspi=False, remote_desktop=False, screenshot=False)
    try:
        Gio, GLib = gio(); desktop_class(); result['gio'] = True
        try:
            import gi
            gi.require_version('Atspi','2.0')
            from gi.repository import Atspi
            result['atspi'] = bool(os.getenv('DBUS_SESSION_BUS_ADDRESS'))
        except (ImportError, ValueError): pass
        bus = Gio.bus_get_sync(Gio.BusType.SESSION, None)
        for interface, key in [('RemoteDesktop','remote_desktop'),('Screenshot','screenshot')]:
            try:
                answer = bus.call_sync('org.freedesktop.portal.Desktop','/org/freedesktop/portal/desktop',
                    'org.freedesktop.DBus.Properties','Get',GLib.Variant('(ss)',('org.freedesktop.portal.'+interface,'version')),
                    None,Gio.DBusCallFlags.NONE,600,None)
                result[key] = bool(answer)
            except Exception: pass
    except Exception: pass
    return result

def bluetooth(payload):
    Gio, GLib = gio()
    bus = Gio.bus_get_sync(Gio.BusType.SYSTEM,None)
    objects = bus.call_sync('org.bluez','/','org.freedesktop.DBus.ObjectManager','GetManagedObjects',
        None,None,Gio.DBusCallFlags.NONE,3000,None).unpack()[0]
    devices=[]
    for path, interfaces in objects.items():
        d = interfaces.get('org.bluez.Device1')
        if d and d.get('Paired'):
            devices.append(dict(path=path,address=d.get('Address'),name=d.get('Alias') or d.get('Name'),connected=d.get('Connected',False)))
    if payload.get('action','list') == 'list': return dict(ok=True,devices=devices)
    found = [d for d in devices if str(d['address']).casefold() == str(payload.get('address','')).casefold()]
    if len(found) != 1 or payload['action'] not in {'connect','disconnect'}:
        raise RuntimeError('Ein bereits gekoppeltes Gerät mit exakter Bluetooth-Adresse ist erforderlich.')
    bus.call_sync('org.bluez',found[0]['path'],'org.bluez.Device1','Connect' if payload['action']=='connect' else 'Disconnect',
        None,None,Gio.DBusCallFlags.NONE,20000,None)
    return dict(ok=True,action=payload['action'],address=found[0]['address'])

def enable_accessibility():
    Gio,_=gio(); source=Gio.SettingsSchemaSource.get_default(); changed=[]
    for name in ['org.cinnamon.desktop.interface','org.gnome.desktop.interface']:
        schema=source.lookup(name,True) if source else None
        if schema and schema.has_key('toolkit-accessibility'):
            settings=Gio.Settings.new_full(schema,None,None)
            if settings.get_boolean('toolkit-accessibility') or settings.set_boolean('toolkit-accessibility',True): changed.append(name)
    Gio.Settings.sync()
    return dict(ok=True,enabled_for=changed,hint='Bereits laufende Ziel-Apps neu starten. Bei Bedarf Barrierefreiheit in den Desktop-Einstellungen aktivieren.')

def main():
    operation=sys.argv[1]
    payload=json.loads(sys.stdin.read(2_000_000) or '{}')
    if operation=='probe': return probe()
    if operation=='apps': return dict(ok=True,items=apps())
    if operation=='launch': return launch_app(payload)
    if operation=='click_control': return named_control(payload)
    if operation=='focus': return named_control(payload,focus=True)
    if operation=='windows': return dict(ok=True,items=[dict(title=w.get_name(),application=a) for w,a in windows(atspi())][:100])
    if operation=='bluetooth': return bluetooth(payload)
    if operation=='enable_accessibility': return enable_accessibility()
    if operation=='portal_plan':
        from linux_portal import execute_plan
        return execute_plan(payload)
    if operation=='screenshot':
        from linux_portal import screenshot
        return screenshot()
    raise RuntimeError('Unbekannte Linux-Systemaktion.')

if __name__=='__main__':
    try: print(json.dumps(main(),ensure_ascii=False))
    except Exception as exc:
        print(json.dumps(dict(ok=False,error=str(exc)),ensure_ascii=False)); raise SystemExit(1)
