"""Bounded JSON bridge to Mint's system Python and GI libraries."""
from __future__ import annotations
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
class BridgeError(RuntimeError):
    pass

def call(operation, payload=None, *, timeout=12, check_stop=None):
    try:
        process = subprocess.Popen(['/usr/bin/python3', str(ROOT/'linux_system_worker.py'), operation],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, shell=False)
    except OSError as exc:
        raise BridgeError('Linux-Systemadapter konnte nicht starten. INSTALLIEREN.sh erneut ausführen.') from exc
    deadline, first = time.monotonic()+timeout, True
    try:
        while True:
            if check_stop: check_stop()
            try:
                output, _ = process.communicate(json.dumps(payload or {}) if first else None, timeout=.1)
                break
            except subprocess.TimeoutExpired:
                first = False
                if time.monotonic() >= deadline:
                    raise BridgeError('Linux-Desktop antwortet nicht rechtzeitig. Freigabedialog und DIAGNOSE.sh prüfen.')
        try:
            result = json.loads(output)
            if not isinstance(result, dict): raise ValueError('not an object')
        except (ValueError, TypeError) as exc:
            raise BridgeError('Linux-Systemadapter fehlt oder konnte nicht starten. INSTALLIEREN.sh erneut ausführen.') from exc
        if process.returncode or not result.get('ok'):
            raise BridgeError(str(result.get('error') or 'Linux-Systemaktion fehlgeschlagen.'))
        return result
    finally:
        if process.poll() is None:
            process.terminate()
            try: process.communicate(timeout=2)
            except subprocess.TimeoutExpired:
                process.kill(); process.communicate(timeout=2)

_probe = (0.0, {})
def probe():
    global _probe
    now = time.monotonic()
    if now-_probe[0] < 5: return dict(_probe[1])
    try: result = call('probe', timeout=4)
    except (BridgeError, OSError):
        result = dict(gio=False, atspi=False, remote_desktop=False, screenshot=False)
    _probe = (now, result)
    return dict(result)
