"""Linux desktop adapters. No shell interpretation; X11 input stays explicit."""
from __future__ import annotations

import importlib.util
import base64
import os
import re
import shutil
import subprocess
import time
from pathlib import Path
from typing import Callable
from linux_bridge import BridgeError, call, probe


class LinuxDesktopError(RuntimeError):
    pass


# Only known desktop applications can be started as programs. Arbitrary binaries,
# scripts and .desktop files are not treated as documents.
PROGRAMS = {
    "explorer": ("Dateien", ("nemo", "nautilus", "thunar", "dolphin")),
    "editor": ("Texteditor", ("xed", "gedit", "mousepad", "kate")),
    "rechner": ("Rechner", ("gnome-calculator", "mate-calc", "kcalc")),
    "einstellungen": ("Einstellungen", ("cinnamon-settings", "gnome-control-center")),
    "taskmanager": ("Systemüberwachung", ("gnome-system-monitor", "mate-system-monitor")),
    "fotos": ("Bildbetrachter", ("xviewer", "eog", "ristretto")),
    "firefox": ("Firefox", ("firefox",)),
    "brave": ("Brave", ("brave-browser", "brave-browser-stable", "brave")),
    "chrome": ("Chrome", ("google-chrome", "google-chrome-stable")),
    "chromium": ("Chromium", ("chromium", "chromium-browser")),
    "libreoffice": ("LibreOffice", ("libreoffice",)),
    "thunderbird": ("Thunderbird", ("thunderbird",)),
    "vlc": ("VLC", ("vlc",)),
    "spotify": ("Spotify", ("spotify",)),
    "kamera": ("Kamera", ("cheese", "guvcview")),
    "paint": ("Zeichenprogramm", ("drawing", "pinta", "gimp")),
    "terminal": ("Terminal", ("gnome-terminal", "xfce4-terminal", "konsole", "x-terminal-emulator")),
}
ALIASES = {"dateien": "explorer", "datei explorer": "explorer", "dateiexplorer": "explorer",
           "dateimanager": "explorer", "nemo": "explorer", "notepad": "editor", "xed": "editor",
           "texteditor": "editor", "task manager": "taskmanager", "calculator": "rechner"}
BLOCKED_SUFFIXES = {".sh", ".bash", ".zsh", ".fish", ".desktop", ".appimage", ".run", ".bin",
                    ".deb", ".rpm", ".py", ".pyw", ".pl", ".rb", ".so", ".exe"}


def session_status() -> dict:
    session = os.environ.get("XDG_SESSION_TYPE", "").casefold()
    wayland = session == "wayland" or (not session and bool(os.environ.get("WAYLAND_DISPLAY")))
    display = bool(os.environ.get("DISPLAY"))
    x11 = display and not wayland
    bridges = probe()
    return {
        "system": "linux", "session": "wayland" if wayland else "x11" if display else "headless",
        "desktop_input": (x11 and bool(shutil.which("xdotool"))) or (wayland and bridges["remote_desktop"]),
        "native_screenshot": (x11 and importlib.util.find_spec("mss") is not None) or (wayland and bridges["screenshot"]),
        "window_focus": (x11 and bool(shutil.which("wmctrl"))) or bridges["atspi"],
        "named_controls": bridges["atspi"], "registered_apps": bridges["gio"],
        "portal_permission_required": wayland,
        "coordinate_space": "selected_monitor_logical_pixels" if wayland else "x11_root_pixels",
        "bridges": bridges, "browser_screen_selection": True,
        "hint": ("X11-Eingaben; benannte Bedienelemente benötigen AT-SPI-Unterstützung der Ziel-App." if x11 else
                 "Wayland benötigt ein RemoteDesktop-Portal und deine Freigabe. Koordinaten beziehen sich auf den freigegebenen Monitor; Fensterfokus kann der Desktop ablehnen." if wayland else
                 "Keine grafische Sitzung. Desktop-Aktionen benötigen eine Anmeldung am Linux-Desktop."),
    }

def require_x11() -> None:
    if session_status()["session"] != "x11":
        raise LinuxDesktopError("Diese Desktop-Aktion benötigt Cinnamon mit X11. Unter Wayland bitte die Bildschirmfreigabe im Browser nutzen.")


def session_locked() -> bool:
    """Ask the desktop locker; unknown states keep message previews private."""
    if not os.environ.get("DBUS_SESSION_BUS_ADDRESS") or not shutil.which("gdbus"):
        return True
    for service, path in [("org.cinnamon.ScreenSaver", "/org/cinnamon/ScreenSaver"),
                          ("org.gnome.ScreenSaver", "/org/gnome/ScreenSaver"),
                          ("org.freedesktop.ScreenSaver", "/org/freedesktop/ScreenSaver")]:
        try:
            result = subprocess.run(["gdbus", "call", "--session", "--dest", service,
                                     "--object-path", path, "--method", service + ".GetActive"],
                                    capture_output=True, text=True, timeout=0.6, check=True)
            if result.stdout.strip() in {"(true,)", "(false,)"}:
                return result.stdout.strip() == "(true,)"
        except (OSError, subprocess.SubprocessError):
            continue
    return True


def resolve_program(name: str, *, allow_terminal: bool = False) -> dict | None:
    key = ALIASES.get(name, name)
    spec = PROGRAMS.get(key)
    if key == "terminal" and not allow_terminal:
        raise LinuxDesktopError("Das Terminal ist in den Agent-OS-Sicherheitseinstellungen deaktiviert.")
    if spec:
        label, candidates = spec
        executable = next((path for cmd in candidates if (path := shutil.which(cmd))), None)
        if executable:
            return {"mode": "command", "kind": "program", "value": [executable], "label": label}
    try:
        items = call("apps")["items"]
    except BridgeError:
        items = []
    from linux_system_worker import norm
    matches = [i for i in items if norm(name) in {norm(i["id"]), norm(i["name"]), norm(i["executable"])}]
    if len(matches) > 1:
        raise LinuxDesktopError("Mehrere Programme passen. Bitte die App-ID wählen: " + ", ".join(i["id"] for i in matches[:5]))
    if matches:
        item = matches[0]
        if item["terminal"] and not allow_terminal:
            raise LinuxDesktopError("Terminal- und Kommandozeilenstarter sind in den Agent-Einstellungen gesperrt.")
        return {"mode": "desktop_app", "kind": "program", "value": item["id"], "label": item["name"]}
    if spec:
        raise LinuxDesktopError(f"{spec[0]} wurde nicht gefunden. Bei Flatpak die App-ID aus dem Programmkatalog verwenden.")
    return None


def program_catalog() -> list[dict]:
    aliases = [{"alias": alias, "label": label} for alias, (label, commands) in PROGRAMS.items()
               if any(shutil.which(command) for command in commands)]
    try:
        return aliases + [{"alias": i["id"], "label": i["name"], "terminal": i["terminal"]} for i in call("apps")["items"]]
    except BridgeError:
        return aliases


def launch_registered(target: str, *, allow_terminal: bool = False) -> None:
    try:
        call("launch", {"target": target, "allow_terminal": allow_terminal})
    except BridgeError as exc:
        raise LinuxDesktopError(str(exc)) from exc

def validate_document(path: Path) -> None:
    if path.suffix.casefold() in BLOCKED_SUFFIXES:
        raise LinuxDesktopError("Skripte, Installer und ausführbare Dateien werden nicht als Dokument geöffnet. Programme bitte über ihren Namen wählen.")
    with path.open("rb") as source:
        prefix = source.read(4)
    if prefix.startswith((b"#!", b"\x7fELF", b"MZ")):
        raise LinuxDesktopError("Diese Datei enthält ausführbaren Code und wird nicht als Dokument geöffnet.")


def open_document(path: str) -> None:
    target = Path(path).resolve(strict=True)
    if target.is_file():
        validate_document(target)
    command = shutil.which("xdg-open")
    if not command:
        raise LinuxDesktopError("xdg-open fehlt. Bitte INSTALLIEREN.sh erneut ausführen.")
    try:
        subprocess.run([command, str(target)], check=True, timeout=10, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    except (OSError, subprocess.SubprocessError) as exc:
        raise LinuxDesktopError("Das Ziel konnte mit der zugeordneten Linux-Anwendung nicht geöffnet werden.") from exc


def capture_with_metadata() -> tuple[bytes, dict]:
    if session_status()["session"] == "wayland":
        try:
            result = call("screenshot", timeout=100)
            return base64.b64decode(result["data"], validate=True), {"source": result["source"], "persisted": True, "portal_managed_file": True}
        except BridgeError as exc:
            raise LinuxDesktopError(str(exc)) from exc
    require_x11()
    try:
        import mss
        import mss.tools
        with mss.mss() as capture:
            shot = capture.grab(capture.monitors[0])
            return mss.tools.to_png(shot.rgb, shot.size), {"source": "linux_x11", "persisted": False, "portal_managed_file": False}
    except Exception as exc:
        raise LinuxDesktopError("Keine Bildschirmaufnahme möglich. DIAGNOSE.sh prüfen oder Browser-Bildschirmfreigabe verwenden.") from exc


def capture_screen() -> bytes:
    return capture_with_metadata()[0]

def visible_windows(limit: int = 12) -> list[dict]:
    if session_status()["session"] != "x11" or not shutil.which("wmctrl"):
        try:
            return call("windows")["items"][:max(1, min(100, limit))]
        except BridgeError:
            return []
    try:
        result = subprocess.run(["wmctrl", "-l"], capture_output=True, text=True, timeout=3, check=True)
        items = []
        for line in result.stdout.splitlines():
            fields = line.split(None, 3)
            if len(fields) == 4 and re.fullmatch(r"0x[0-9a-fA-F]+", fields[0]):
                items.append({"id": fields[0], "title": fields[3][:300]})
        return items[:max(1, min(100, limit))]
    except (OSError, subprocess.SubprocessError):
        return []


KEYS = {"ctrl": "ctrl", "control": "ctrl", "alt": "alt", "shift": "shift", "win": "super",
        "super": "super", "enter": "Return", "return": "Return", "esc": "Escape", "escape": "Escape",
        "tab": "Tab", "space": "space", "backspace": "BackSpace", "delete": "Delete", "del": "Delete",
        "up": "Up", "down": "Down", "left": "Left", "right": "Right", "home": "Home", "end": "End",
        "pageup": "Page_Up", "pagedown": "Page_Down", "insert": "Insert"}


def key_name(value: str) -> str:
    value = value.casefold().strip()
    if value in KEYS:
        return KEYS[value]
    if re.fullmatch(r"[a-z0-9]|f(?:[1-9]|1[0-2])", value):
        return value.upper() if value.startswith("f") and len(value) > 1 else value
    raise LinuxDesktopError(f"Nicht unterstützte Taste: {value}")


def validate_actions(actions: list[dict]) -> None:
    state = session_status()
    for action in actions:
        kind = action["action"]
        if kind == "click_control":
            if not state["named_controls"]:
                raise LinuxDesktopError("AT-SPI ist nicht verfügbar. INSTALLIEREN.sh ausführen und grafisch anmelden.")
        elif kind == "focus_window":
            if not state["window_focus"]:
                raise LinuxDesktopError("Fensterfokus ist in dieser Sitzung nicht verfügbar.")
        elif kind in {"set_volume", "set_mute", "bluetooth_connect", "bluetooth_disconnect", "notify"}:
            from linux_services import validate_action
            validate_action(action)
        elif kind not in {"open", "wait"} and not state["desktop_input"]:
            raise LinuxDesktopError("Keine Desktop-Eingabe verfügbar. Unter Wayland fehlt ein RemoteDesktop-Portal; alternativ in Cinnamon (X11) anmelden.")
        if kind == "press":
            for key in action["key"].split("+"): key_name(key)
        if kind == "hotkey":
            for key in action["keys"]: key_name(key)

def run_interruptible(command: list[str], check_stop: Callable[[], None], *, text: str | None = None) -> None:
    check_stop()
    process = subprocess.Popen(command, stdin=subprocess.PIPE if text is not None else subprocess.DEVNULL,
                               stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True, shell=False)
    deadline = time.monotonic() + 20
    first = True
    try:
        while True:
            check_stop()
            try:
                _, error = process.communicate(input=text if first else None, timeout=0.1)
                break
            except subprocess.TimeoutExpired:
                first = False
                if time.monotonic() >= deadline:
                    raise LinuxDesktopError("Desktop-Schritt hat das Zeitlimit überschritten.")
        if process.returncode:
            raise LinuxDesktopError("Der Linux-Desktop hat den Steuerbefehl nicht ausgeführt.")
    finally:
        if process.poll() is None:
            process.terminate()
            try:
                process.communicate(timeout=2)
            except subprocess.TimeoutExpired:
                process.kill()
                process.communicate(timeout=2)


def execute_action(action: dict, check_stop: Callable[[], None]) -> None:
    validate_actions([action])
    kind = action["action"]
    if kind in {"set_volume", "set_mute", "bluetooth_connect", "bluetooth_disconnect", "notify"}:
        from linux_services import execute_action as service_action
        service_action(action, check_stop)
        return
    if kind == "click_control" or (kind == "focus_window" and session_status()["session"] != "x11"):
        try:
            call("click_control" if kind == "click_control" else "focus", action, timeout=15, check_stop=check_stop)
        except BridgeError as exc:
            raise LinuxDesktopError(str(exc)) from exc
        return
    command = ["xdotool"]
    text = None
    if kind == "focus_window":
        needle = action["window"].casefold()
        windows = visible_windows(100)
        matches = [w for w in windows if w["title"].casefold() == needle]
        matches = matches or [w for w in windows if needle in w["title"].casefold()]
        if len(matches) != 1:
            raise LinuxDesktopError("Das Fenster wurde nicht eindeutig gefunden. Bitte einen eindeutigen Fenstertitel angeben.")
        command = ["wmctrl", "-ia", matches[0]["id"]]
    elif kind == "click_point":
        command += ["mousemove", "--sync", str(action["x"]), str(action["y"]), "click", {"left": "1", "middle": "2", "right": "3"}[action["button"]]]
    elif kind == "type_text":
        command += ["type", "--clearmodifiers", "--delay", "1", "--file", "-"]
        text = action["text"]
    elif kind in {"press", "hotkey"}:
        keys = action["key"].split("+") if kind == "press" else action["keys"]
        command += ["key", "--clearmodifiers", "+".join(key_name(k) for k in keys)]
    elif kind == "scroll":
        amount = int(action["amount"])
        if not amount:
            return
        command += ["click", "--repeat", str(abs(amount)), "--delay", "30", "4" if amount > 0 else "5"]
    else:
        raise LinuxDesktopError("Unbekannter Linux-Desktop-Schritt.")
    run_interruptible(command, check_stop, text=text)


def launch_setup_terminal(script: Path) -> bool:
    if not os.environ.get("DISPLAY") and not os.environ.get("WAYLAND_DISPLAY"):
        return False
    terminal = shutil.which("x-terminal-emulator")
    if not terminal:
        return False
    subprocess.Popen([terminal, "-e", "bash", str(script)], cwd=script.parent, start_new_session=True)
    return True


def execute_portal_plan(actions: list[dict], pc_agent, check_stop: Callable[[], None]) -> dict:
    prepared = []
    for action in actions:
        item = dict(action)
        if item["action"] == "open": item["resolved"] = pc_agent.resolve_target(item["target"])
        prepared.append(item)
    try:
        return call("portal_plan", {"actions": prepared, "allow_terminal": pc_agent._terminal_allowed()},
                    timeout=120 + sum(float(a.get("seconds", 0)) for a in actions) + len(actions) * 15,
                    check_stop=check_stop)
    except BridgeError as exc:
        raise LinuxDesktopError(str(exc)) from exc
