"""Dedicated Chromium app windows with separate profiles and active sandbox."""
from __future__ import annotations
import os
from pathlib import Path
import shutil
import subprocess
import time
ROOT=Path(__file__).resolve().parent

def browser_executable():
    for name in ('brave-browser','brave-browser-stable','brave','google-chrome','google-chrome-stable','chromium','chromium-browser'):
        if found:=shutil.which(name):return found
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            path=p.chromium.executable_path
            if Path(path).is_file():return path
    except Exception:pass
    return None

def open_window(kind='jarvis'):
    if kind not in {'jarvis','whatsapp'}:raise ValueError('Unbekanntes Appfenster.')
    if not (os.getenv('DISPLAY') or os.getenv('WAYLAND_DISPLAY')):raise RuntimeError('Kein grafischer Desktop verfügbar.')
    executable=browser_executable()
    if not executable:raise RuntimeError('Kein Chromium-Browser verfügbar. INSTALLIEREN.sh erneut starten oder Brave installieren.')
    profile=ROOT/'data'/('jarvis-window-profile' if kind=='jarvis' else 'whatsapp-window-profile')
    profile.mkdir(parents=True,exist_ok=True,mode=0o700);profile.chmod(0o700)
    url='http://127.0.0.1:8017' if kind=='jarvis' else 'https://web.whatsapp.com/'
    log=ROOT/'data'/(kind+'-window.log')
    if log.exists() and log.stat().st_size>2*1024*1024:log.replace(log.with_suffix('.previous.log'))
    with log.open('ab') as output:
        child=subprocess.Popen([executable,'--app='+url,'--user-data-dir='+str(profile),'--force-renderer-accessibility',
            '--no-first-run','--no-default-browser-check'],stdin=subprocess.DEVNULL,stdout=output,stderr=subprocess.STDOUT,start_new_session=True,shell=False)
    time.sleep(.4)
    if child.poll() not in {None,0}:raise RuntimeError('Appfenster konnte nicht starten. Details: data/'+log.name)
    return dict(ok=True,url=url,mode='chromium_app_window')
