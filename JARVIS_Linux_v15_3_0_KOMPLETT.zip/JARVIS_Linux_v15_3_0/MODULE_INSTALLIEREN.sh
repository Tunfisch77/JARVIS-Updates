#!/usr/bin/env bash
set -Eeuo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
umask 077
if [[ $# -gt 0 && -x .venv/bin/python ]]; then .venv/bin/python jarvis_linux.py stop; fi
exec python3 linux_modules.py "$@"
