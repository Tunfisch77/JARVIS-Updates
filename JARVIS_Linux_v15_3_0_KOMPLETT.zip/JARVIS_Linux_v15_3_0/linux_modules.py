"""Optional modules in staged environments; preserve a working runtime."""
from __future__ import annotations
import argparse
from contextlib import ExitStack
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import uuid
from jarvis_linux import lock_file,LaunchError
ROOT=Path(__file__).resolve().parent
GROUPS={n:n for n in ['agents','memory','voice','vision-media']}
ISOLATED={n:n for n in ['open-interpreter','openadapt','ovos']}

def run(command):subprocess.run([str(x) for x in command],cwd=ROOT,check=True)

def activate(stage,target):
    pointer=target.parent/(target.name+'.next-'+uuid.uuid4().hex)
    pointer.symlink_to(stage,target_is_directory=True)
    backup=None
    try:
        if target.exists() and not target.is_symlink():
            backup=ROOT/'.jarvis_envs'/('previous-'+target.name.lstrip('.')+'-'+uuid.uuid4().hex)
            target.rename(backup)
        try:os.replace(pointer,target)
        except BaseException:
            if backup is not None:backup.rename(target)
            raise
    finally:pointer.unlink(missing_ok=True)

def previous_groups():
    marker=ROOT/'.venv/.jarvis-groups.json'
    if not marker.exists():return []
    selected=json.loads(marker.read_text())
    if not isinstance(selected,list) or any(i not in GROUPS for i in selected):
        raise RuntimeError('Ungültige Modulauswahl in .venv/.jarvis-groups.json. Installation angehalten.')
    return selected

def install_runtime(selected):
    selected=sorted(set(previous_groups())|set(selected))
    stage=ROOT/'.jarvis_envs'/('runtime-'+uuid.uuid4().hex);activated=False
    try:
        run([sys.executable,'-m','venv',stage]);python=stage/'bin/python'
        run([python,'-m','pip','install','-r',ROOT/'requirements-linux-lock.txt'])
        if selected:
            command=[python,'-m','pip','install','-c',ROOT/'requirements-linux-lock.txt']
            for group in selected:command+=['-r',ROOT/('requirements-v11-'+GROUPS[group]+'.txt')]
            run(command)
        run([python,'-m','pip','check'])
        run([python,'-c','import fastapi, uvicorn, httpx, psutil, playwright, mss, google.auth, msal'])
        (stage/'.jarvis-groups.json').write_text(json.dumps(selected))
        (stage/'.jarvis-resolved.txt').write_text(subprocess.check_output([str(python),'-m','pip','freeze'],text=True))
        activate(stage,ROOT/'.venv');activated=True
    finally:
        if not activated and stage.exists():shutil.rmtree(stage)

def install_isolated(name):
    stage=ROOT/'.jarvis_envs'/(name+'-'+uuid.uuid4().hex);activated=False
    try:
        run([sys.executable,'-m','venv',stage]);python=stage/'bin/python'
        run([python,'-m','pip','install','-r',ROOT/('requirements-v11-'+ISOLATED[name]+'.txt')])
        run([python,'-m','pip','check'])
        if name=='openadapt':
            run([python,'-m','playwright','install','chromium']);(stage/'.jarvis-playwright-ready').touch()
        (stage/'.jarvis-installed').touch()
        (stage/'.jarvis-resolved.txt').write_text(subprocess.check_output([str(python),'-m','pip','freeze'],text=True))
        activate(stage,ROOT/'.jarvis_envs'/name);activated=True
    finally:
        if not activated and stage.exists():shutil.rmtree(stage)

def main():
    parser=argparse.ArgumentParser(description='Linux-Zusatzmodule installieren; ohne Argumente verfügbare Gruppen anzeigen.')
    parser.add_argument('groups',nargs='*',help='core, agents, memory, voice, vision-media, open-interpreter, openadapt, ovos oder all')
    args=parser.parse_args();choices={'core','all',*GROUPS,*ISOLATED}
    if not args.groups:
        print('Gruppen: '+', '.join(sorted(choices)))
        print('Beispiel: bash MODULE_INSTALLIEREN.sh voice\nall lädt auch große experimentelle Pakete. Externe Dienste und Modelle separat konfigurieren.')
        return 0
    if any(i not in choices for i in args.groups):parser.error('Unbekannte Modulgruppe.')
    if os.geteuid()==0:raise RuntimeError('Ohne sudo als normaler Linux-Benutzer starten.')
    selected=set(args.groups)
    if 'all' in selected:selected={'core',*GROUPS,*ISOLATED}
    (ROOT/'.jarvis_envs').mkdir(mode=0o700,exist_ok=True);failures=[]
    with ExitStack() as locks:
        locks.enter_context(lock_file(ROOT/'data/linux-launcher.lock'))
        locks.enter_context(lock_file(ROOT/'data/linux-server.lock'))
        if (ROOT/'.update.lock').exists():raise RuntimeError('Ein Update läuft. Dessen Abschluss abwarten.')
        if selected & ({'core'}|set(GROUPS)):
            try:install_runtime(selected&set(GROUPS))
            except (subprocess.CalledProcessError,OSError,RuntimeError) as exc:failures.append('Laufzeit/Module: '+str(exc))
        for group in sorted(selected&set(ISOLATED)):
            try:install_isolated(group)
            except (subprocess.CalledProcessError,OSError) as exc:failures.append(group+': '+str(exc))
    if failures:
        print('Nicht installierte Gruppen; bisherige Umgebung dieser Gruppe bleibt erhalten:',file=sys.stderr)
        for error in failures:print(error,file=sys.stderr)
        return 1
    print('Pakete installiert und Abhängigkeiten geprüft. Konten, Modelle und Dienste bei Bedarf separat einrichten.')
    return 0
if __name__=='__main__':
    os.umask(0o077)
    try:raise SystemExit(main())
    except (OSError,RuntimeError,LaunchError) as exc:
        print('Modulinstallation: '+str(exc),file=sys.stderr);raise SystemExit(1)
