"""Wayland input through the user's XDG permission dialogs; one session per plan."""
from __future__ import annotations
import base64
from pathlib import Path
import secrets
import signal
import time
from urllib.parse import unquote,urlparse
DEST='org.freedesktop.portal.Desktop'
PATH='/org/freedesktop/portal/desktop'
PREFIX='org.freedesktop.portal.'

class Portal:
    def __init__(self):
        from linux_system_worker import gio
        self.Gio,self.GLib=gio()
        self.bus=self.Gio.bus_get_sync(self.Gio.BusType.SESSION,None)
        self.session='';self.pressed=set()
        signal.signal(signal.SIGTERM,lambda *_: (_ for _ in ()).throw(SystemExit(143)))
    def call(self,interface,method,signature,values,*,path=PATH):
        return self.bus.call_sync(DEST,path,PREFIX+interface,method,
            self.GLib.Variant(signature,values) if signature else None,None,self.Gio.DBusCallFlags.NONE,5000,None)
    def request(self,interface,method,signature,leading=(),options=None):
        token='jarvis_'+secrets.token_hex(10)
        sender=self.bus.get_unique_name().lstrip(':').replace('.','_')
        handle='/org/freedesktop/portal/desktop/request/'+sender+'/'+token
        options=dict(options or {}); options['handle_token']=self.GLib.Variant('s',token)
        answer=[]
        def received(_bus,_sender,path,_interface,_signal,parameters,*_):
            if path==handle: answer.append(parameters.unpack())
        subscription=self.bus.signal_subscribe(DEST,PREFIX+'Request','Response',None,None,self.Gio.DBusSignalFlags.NONE,received)
        try:
            handle=self.call(interface,method,signature,(*leading,options)).unpack()[0]
            deadline=time.monotonic()+90; context=self.GLib.MainContext.default()
            while not answer:
                while context.pending(): context.iteration(False)
                if time.monotonic()>deadline: raise RuntimeError('Desktop-Freigabe nicht erteilt; Zeitlimit erreicht.')
                time.sleep(.02)
            code,values=answer[0]
            if code!=0: raise RuntimeError('Desktop-Freigabe wurde abgebrochen oder vom Desktop abgelehnt.')
            return values
        finally:
            self.bus.signal_unsubscribe(subscription)
            if not answer:
                try: self.call('Request','Close',None,(),path=handle)
                except Exception: pass
    def start(self,*,pointer=False):
        V=self.GLib.Variant
        created=self.request('RemoteDesktop','CreateSession','(a{sv})',options={'session_handle_token':V('s','jarvis_'+secrets.token_hex(10))})
        self.session=created['session_handle']
        self.request('RemoteDesktop','SelectDevices','(oa{sv})',(self.session,),{'types':V('u',3),'persist_mode':V('u',0)})
        if pointer:
            self.request('ScreenCast','SelectSources','(oa{sv})',(self.session,),{'types':V('u',1),'multiple':V('b',False)})
        info=self.request('RemoteDesktop','Start','(osa{sv})',(self.session,''))
        if int(info.get('devices',0))&3 !=3: raise RuntimeError('Tastatur und Zeiger wurden nicht vollständig freigegeben.')
        streams=info.get('streams',[])
        if pointer and len(streams)!=1: raise RuntimeError('Für Koordinatensteuerung genau einen Bildschirm freigeben.')
        self.stream=streams[0] if streams else None
    def key(self,keysym,down):
        self.call('RemoteDesktop','NotifyKeyboardKeysym','(oa{sv}iu)',(self.session,{},int(keysym),int(down)))
        if down: self.pressed.add(keysym)
        else: self.pressed.discard(keysym)
    def close(self):
        if not self.session:return
        for key in list(self.pressed):
            try:self.key(key,False)
            except Exception:pass
        try:self.call('Session','Close',None,(),path=self.session)
        except Exception:pass
        self.session=''

KEYSYMS={'ctrl':0xffe3,'control':0xffe3,'shift':0xffe1,'alt':0xffe9,'win':0xffeb,'super':0xffeb,
 'enter':0xff0d,'return':0xff0d,'esc':0xff1b,'escape':0xff1b,'tab':0xff09,'space':32,'backspace':0xff08,
 'delete':0xffff,'del':0xffff,'left':0xff51,'up':0xff52,'right':0xff53,'down':0xff54,'home':0xff50,
 'end':0xff57,'pageup':0xff55,'pagedown':0xff56,'insert':0xff63}
def key_symbol(key):
    key=key.casefold().strip()
    if key in KEYSYMS:return KEYSYMS[key]
    if len(key)==1 and key.isascii() and key.isalnum():return ord(key)
    if key.startswith('f') and key[1:].isdigit() and 1<=int(key[1:])<=12:return 0xffbd+int(key[1:])
    raise RuntimeError('Nicht unterstützte Taste: '+key)

def execute_plan(payload):
    from linux_system_worker import launch_app,named_control
    actions=payload['actions']; portal=Portal(); completed=[]
    try:
        if any(a['action'] in {'click_point','type_text','press','hotkey','scroll'} for a in actions):
            portal.start(pointer=any(a['action']=='click_point' for a in actions))
        for index,action in enumerate(actions):
            kind=action['action']
            if kind=='wait':time.sleep(action['seconds'])
            elif kind=='open':
                resolved=action['resolved']
                if resolved['mode']=='desktop_app':launch_app({'target':resolved['value'],'allow_terminal':payload.get('allow_terminal',False)})
                else:
                    import subprocess
                    command=resolved['value'] if resolved['mode']=='command' else ['xdg-open',str(resolved['value'])]
                    subprocess.Popen(command,shell=False,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            elif kind=='focus_window':named_control(action,focus=True)
            elif kind=='click_control':named_control(action)
            elif kind in {'set_volume','set_mute','bluetooth_connect','bluetooth_disconnect','notify'}:
                from linux_services import execute_action
                execute_action(action,lambda:None)
            elif kind=='type_text':
                for char in action['text']:
                    value={'\n':0xff0d,'\t':0xff09}.get(char,ord(char) if ord(char)<=255 else 0x01000000|ord(char))
                    portal.key(value,True);portal.key(value,False)
            elif kind in {'press','hotkey'}:
                keys=[key_symbol(k) for k in (action['keys'] if kind=='hotkey' else action['key'].split('+'))]
                try:
                    for key in keys:portal.key(key,True)
                finally:
                    for key in reversed(keys):
                        try:portal.key(key,False)
                        except Exception:pass
            elif kind=='scroll':portal.call('RemoteDesktop','NotifyPointerAxisDiscrete','(oa{sv}ui)',(portal.session,{},0,-int(action['amount'])))
            elif kind=='click_point':
                node,props=portal.stream;size=props.get('logical_size') or props.get('size')
                x,y=int(action['x']),int(action['y'])
                if not size or not (0<=x<size[0] and 0<=y<size[1]):raise RuntimeError('Klick liegt außerhalb des freigegebenen Bildschirms oder dessen Größe ist unbekannt.')
                portal.call('RemoteDesktop','NotifyPointerMotionAbsolute','(oa{sv}udd)',(portal.session,{},node,float(x),float(y)))
                button={'left':272,'right':273,'middle':274}[action['button']]
                try:portal.call('RemoteDesktop','NotifyPointerButton','(oa{sv}iu)',(portal.session,{},button,1))
                finally:portal.call('RemoteDesktop','NotifyPointerButton','(oa{sv}iu)',(portal.session,{},button,0))
            else:raise RuntimeError('Nicht unterstützte Portal-Aktion.')
            completed.append(dict(index=index,action=kind,status='success'))
        return dict(ok=True,completed=completed,method='xdg-remote-desktop',coordinate_space='selected_monitor_logical_pixels')
    finally:portal.close()

def screenshot():
    portal=Portal()
    answer=portal.request('Screenshot','Screenshot','(sa{sv})',('',),{'interactive':portal.GLib.Variant('b',True)})
    uri=urlparse(str(answer.get('uri','')))
    if uri.scheme!='file' or uri.netloc not in {'','localhost'}:raise RuntimeError('Das Screenshot-Portal lieferte keine lokale Bilddatei.')
    path=Path(unquote(uri.path))
    if not path.is_file() or path.stat().st_size>8*1024*1024:raise RuntimeError('Portal-Bild fehlt oder ist größer als 8 MB.')
    data=path.read_bytes()
    if not data.startswith(b'\x89PNG\r\n\x1a\n'):raise RuntimeError('Das Portal lieferte kein PNG-Bild.')
    return dict(ok=True,data=base64.b64encode(data).decode(),source='xdg-screenshot',portal_managed_file=True)
