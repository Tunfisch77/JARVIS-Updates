"""Linux audio, paired Bluetooth devices and local desktop notifications."""
from __future__ import annotations
import json
import re
import shutil
import subprocess
from linux_bridge import BridgeError,call
SYSTEM_ACTIONS={'set_volume','set_mute','bluetooth_connect','bluetooth_disconnect','notify'}

def validate_action(action):
    from linux_desktop import LinuxDesktopError
    kind=action['action']
    if kind in {'set_volume','set_mute'}:
        if not shutil.which('pactl'):raise LinuxDesktopError('pactl fehlt. INSTALLIEREN.sh installiert die Audio-Werkzeuge.')
        target=str(action.get('audio_target','@DEFAULT_SINK@'))
        if not re.fullmatch(r'@DEFAULT_SINK@|[A-Za-z0-9_.:-]{1,200}',target) or target.startswith('-'):
            raise LinuxDesktopError('Ungültiges Audiogerät. Kennung aus der Diagnose verwenden.')
        scope=action.get('audio_scope','sink')
        if scope not in {'sink','stream'} or (scope=='stream' and not target.isdigit()):raise LinuxDesktopError('Audiostream benötigt eine numerische Kennung.')
        if kind=='set_volume' and (type(action.get('volume')) is not int or not 0<=action['volume']<=100):raise LinuxDesktopError('Lautstärke muss eine ganze Zahl von 0 bis 100 sein.')
        if kind=='set_mute' and type(action.get('mute')) is not bool:raise LinuxDesktopError('Stummschaltung benötigt true oder false.')
    elif kind.startswith('bluetooth_'):
        if not re.fullmatch(r'(?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}',str(action.get('address',''))):raise LinuxDesktopError('Bluetooth benötigt eine exakte Adresse eines gekoppelten Geräts.')
    elif kind=='notify':
        if not shutil.which('notify-send'):raise LinuxDesktopError('notify-send fehlt. INSTALLIEREN.sh erneut starten.')
        if not action.get('text') or len(action['text'])>2000 or len(action.get('title','JARVIS'))>200:raise LinuxDesktopError('Benachrichtigung benötigt kurzen Titel und bis zu 2000 Zeichen Text.')
    else:raise LinuxDesktopError('Unbekannte Linux-Systemaktion.')

def execute_action(action,check_stop):
    from linux_desktop import LinuxDesktopError,run_interruptible
    validate_action(action);check_stop();kind=action['action']
    if kind in {'set_volume','set_mute'}:
        device='sink-input' if action.get('audio_scope')=='stream' else 'sink'
        operation='volume' if kind=='set_volume' else 'mute'
        value=str(action['volume'])+'%' if kind=='set_volume' else '1' if action['mute'] else '0'
        run_interruptible(['pactl','set-'+device+'-'+operation,action.get('audio_target','@DEFAULT_SINK@'),value],check_stop)
    elif kind=='notify':
        run_interruptible(['notify-send','--app-name=JARVIS','--expire-time=8000','--',action.get('title','JARVIS'),action['text']],check_stop)
    else:
        try:call('bluetooth',{'action':kind.removeprefix('bluetooth_'),'address':action['address']},timeout=25,check_stop=check_stop)
        except BridgeError as exc:raise LinuxDesktopError(str(exc)) from exc

def status():
    result=dict(audio=dict(available=False,sinks=[],streams=[]),bluetooth=dict(available=False,devices=[]),notifications=bool(shutil.which('notify-send')))
    if shutil.which('pactl'):
        try:
            for source,target in [('sinks','sinks'),('sink-inputs','streams')]:
                raw=subprocess.run(['pactl','--format=json','list',source],capture_output=True,text=True,timeout=3,check=True)
                data=json.loads(raw.stdout)
                result['audio'][target]=[dict(id=str(i['index']),name=i.get('name') or i.get('properties',{}).get('application.name',''),
                    description=i.get('description',''),mute=i.get('mute'),volume=i.get('volume',{})) for i in data[:100]]
            result['audio']['available']=True
        except (OSError,subprocess.SubprocessError,ValueError,KeyError):result['audio']['hint']='Kein erreichbarer PulseAudio-/PipeWire-Pulse-Server.'
    try:result['bluetooth']=dict(available=True,devices=call('bluetooth',{'action':'list'},timeout=4)['devices'])
    except BridgeError:result['bluetooth']['hint']='BlueZ oder Bluetooth-Adapter nicht erreichbar; in VMware gegebenenfalls USB-Adapter durchreichen.'
    return result
