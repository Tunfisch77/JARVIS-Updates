from __future__ import annotations

import unittest

from app import extract_web_sources


class WebSearchParsingTests(unittest.TestCase):
    def test_extracts_unique_safe_citations(self) -> None:
        payload = {
            "output": [
                {
                    "type": "message",
                    "content": [
                        {
                            "type": "output_text",
                            "text": "Antwort",
                            "annotations": [
                                {"type": "url_citation", "url": "https://example.com/a", "title": "A"},
                                {"type": "url_citation", "url": "https://example.com/a", "title": "Doppelt"},
                                {"type": "url_citation", "url": "javascript:alert(1)", "title": "Unsicher"},
                            ],
                        }
                    ],
                },
                {
                    "type": "web_search_call",
                    "action": {"sources": [{"url": "https://example.org/b", "title": "B"}]},
                },
            ]
        }
        sources = extract_web_sources(payload, limit=5)
        self.assertEqual(
            sources,
            [
                {"title": "A", "url": "https://example.com/a"},
                {"title": "B", "url": "https://example.org/b"},
            ],
        )


if __name__ == "__main__":
    unittest.main()
