from __future__ import annotations

import asyncio
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from fastapi.testclient import TestClient

import app
from integration_hub import IntegrationConfig, IntegrationHub
from mail_accounts import (
    ACCOUNT_GMAIL,
    ACCOUNT_OUTLOOK,
    ConnectedAccountConfig,
    ConnectedAccounts,
)
from state_store import JarvisStateStore


class AccountRouterTests(unittest.TestCase):
    def test_explicit_contact_domain_and_private_default_routing(self) -> None:
        config = ConnectedAccountConfig(
            base_dir=Path("."),
            default_account=ACCOUNT_GMAIL,
            school_domains=frozenset({"schule.example"}),
        )
        accounts = ConnectedAccounts(config)
        self.assertEqual(accounts.route("outlook_school", recipient="x@gmail.com"), ACCOUNT_OUTLOOK)
        self.assertEqual(accounts.route("auto", recipient="lehrer@schule.example"), ACCOUNT_OUTLOOK)
        self.assertEqual(accounts.route("auto", recipient="freund@example.com"), ACCOUNT_GMAIL)
        self.assertEqual(
            accounts.route("auto", recipient="x@example.com", contact_preference="outlook_school"),
            ACCOUNT_OUTLOOK,
        )

    def test_contact_preference_persists_through_schema_migration(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            store = JarvisStateStore(Path(directory) / "jarvis.db")
            item = store.save_contact(
                name="Lehrer",
                email="lehrer@schule.example",
                preferred_email_account="outlook_school",
            )
            self.assertEqual(item["preferred_email_account"], "outlook_school")


class WhatsAppWebTests(unittest.TestCase):
    def test_web_mode_calls_structured_browser_sender_and_reports_real_send(self) -> None:
        hub = IntegrationHub(
            lambda: [],
            IntegrationConfig(whatsapp_mode="web", whatsapp_web_auto_send=True),
        )
        with patch.object(hub, "_send_whatsapp_web") as sender:
            result = asyncio.run(hub.whatsapp_message("+436601234567", "Testnachricht"))
        sender.assert_called_once_with("436601234567", "Testnachricht")
        self.assertEqual(result["mode"], "web_auto")
        self.assertFalse(result["requires_user_action"])


class AutonomyApiTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary_directory = tempfile.TemporaryDirectory()
        self.store = JarvisStateStore(Path(self.temporary_directory.name) / "jarvis.db")
        self.hub = IntegrationHub(self.store.list_contacts, IntegrationConfig())
        self.state_patch = patch.object(app, "state_store", self.store)
        self.hub_patch = patch.object(app, "integration_hub", self.hub)
        self.state_patch.start()
        self.hub_patch.start()
        self.client = TestClient(app.app)
        self.client.post(
            "/contacts",
            json={
                "name": "Testkontakt",
                "whatsapp_number": "+436601234567",
                "email": "test@example.com",
                "preferred_email_account": "gmail_private",
            },
        )

    def tearDown(self) -> None:
        self.client.close()
        self.hub_patch.stop()
        self.state_patch.stop()
        self.temporary_directory.cleanup()

    def test_autonomy_is_opt_in_per_database_and_can_be_toggled(self) -> None:
        self.assertFalse(self.client.get("/autonomy").json()["item"]["enabled"])
        enabled = self.client.put("/autonomy", json={"enabled": True})
        self.assertEqual(enabled.status_code, 200, enabled.text)
        self.assertTrue(enabled.json()["item"]["enabled"])
        self.assertFalse(enabled.json()["item"]["bulk_messages"])
        self.assertFalse(enabled.json()["item"]["arbitrary_shell"])

    def test_autonomy_executes_clear_single_message_without_confirmation(self) -> None:
        self.client.put("/autonomy", json={"enabled": True})
        response = self.client.post(
            "/integrations/whatsapp/message",
            json={"target": "Testkontakt", "message": "Hallo"},
            headers={"Idempotency-Key": "autonomy-whatsapp-001"},
        )
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json()["authorization"], "autonomy")


class AutonomyUiAndPromptTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        root = Path(__file__).resolve().parents[1]
        cls.html = (root / "static" / "index.html").read_text(encoding="utf-8")
        cls.source = (root / "app.py").read_text(encoding="utf-8")

    def test_ui_exposes_autonomy_and_account_preferences(self) -> None:
        for marker in (
            'id="autonomyEnabled"',
            'id="contactEmailAccount"',
            "outlook_school",
            "gmail_private",
            "function loadAutonomy",
        ):
            self.assertIn(marker, self.html)

    def test_prompt_maps_school_and_private_accounts(self) -> None:
        self.assertIn("setze account='outlook_school'", self.source)
        self.assertIn("setze account='gmail_private'", self.source)
        self.assertIn("Sende niemals Sammelnachrichten", self.source)

    def test_oauth_token_files_are_excluded_from_model_context(self) -> None:
        from code_workspace import CodeWorkspaceManager

        for name in ("gmail_token.json", "google_client_secret.json", "outlook_token_cache.json"):
            self.assertTrue(CodeWorkspaceManager.is_sensitive_path(name))
            self.assertTrue(app._is_secret_path(name))


if __name__ == "__main__":
    unittest.main()
