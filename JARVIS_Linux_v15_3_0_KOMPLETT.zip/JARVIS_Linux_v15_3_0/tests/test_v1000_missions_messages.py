from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, patch

from fastapi.testclient import TestClient

import app
from state_store import JarvisStateStore
from v10_core import V10Store


class V10StoreTests(unittest.TestCase):
    def test_mission_is_claimed_step_by_step_and_completed(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            store = V10Store(Path(directory) / "jarvis.db")
            mission = store.create_mission(
                title="Morgencheck",
                goal="Neue Nachrichten prüfen und einen Timer starten",
                steps=[
                    {"kind": "check_messages", "title": "Inbox prüfen", "payload": {}},
                    {"kind": "create_timer", "title": "Timer starten", "payload": {"label": "Schule", "seconds": 60}},
                ],
            )
            store.start_mission(mission["id"])
            first = store.claim_next_step()
            self.assertEqual(first["kind"], "check_messages")
            store.finish_step(first["id"], {"ok": True})
            second = store.claim_next_step()
            self.assertEqual(second["kind"], "create_timer")
            finished = store.finish_step(second["id"], {"ok": True})
            self.assertEqual(finished["status"], "success")
            self.assertEqual(finished["progress"], 100)

    def test_messages_are_deduplicated_and_can_be_read_and_replied(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            store = V10Store(Path(directory) / "jarvis.db")
            first = store.upsert_message(
                source="whatsapp",
                external_id="wa-1",
                sender_name="Mama",
                conversation="Mama",
                body="Wann kommst du?",
            )
            store.upsert_message(
                source="whatsapp",
                external_id="wa-1",
                sender_name="Mama",
                conversation="Mama",
                body="Wann kommst du heute?",
            )
            self.assertEqual(len(store.list_messages()), 1)
            read = store.get_message(first["id"], mark_read=True)
            self.assertFalse(read["unread"])
            replied = store.mark_replied(first["id"])
            self.assertTrue(replied["replied"])


class V10ApiAndUiTests(unittest.TestCase):
    def setUp(self) -> None:
        self.directory = tempfile.TemporaryDirectory()
        database = Path(self.directory.name) / "jarvis.db"
        self.state = JarvisStateStore(database)
        self.v10 = V10Store(database)
        self.state.set_setting(
            "autonomy",
            {"enabled": True, "structured_actions_only": True, "bulk_messages": False, "arbitrary_shell": False},
        )
        self.state_patch = patch.object(app, "state_store", self.state)
        self.v10_patch = patch.object(app, "v10_store", self.v10)
        self.state_patch.start()
        self.v10_patch.start()
        # These inbox tests model a logged-in, unlocked desktop.
        privacy_patch = patch("v10_core.windows_session_locked", return_value=False)
        privacy_patch.start()
        self.addCleanup(privacy_patch.stop)
        self.client = TestClient(app.app)

    def tearDown(self) -> None:
        self.client.close()
        self.v10_patch.stop()
        self.state_patch.stop()
        self.directory.cleanup()

    def test_refresh_unified_inbox_and_read_message(self) -> None:
        gmail = [{
            "source": "gmail",
            "external_id": "gmail-1",
            "sender_name": "Lehrer",
            "sender_address": "lehrer@example.com",
            "conversation": "thread-1",
            "subject": "Abgabe",
            "body": "Bitte bis Freitag abgeben.",
            "received_at": "2026-07-22T12:00:00+02:00",
        }]
        with patch.object(app.connected_accounts, "list_unread_gmail", return_value=gmail):
            response = self.client.post("/messages/refresh", json={"sources": ["gmail"], "limit": 20})
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json()["summary"]["total"], 1)
        message_id = response.json()["items"][0]["id"]
        read = self.client.get(f"/messages/{message_id}")
        self.assertEqual(read.status_code, 200)
        self.assertEqual(read.json()["item"]["body"], "Bitte bis Freitag abgeben.")

    def test_create_and_start_mission_api(self) -> None:
        created = self.client.post(
            "/missions",
            json={
                "title": "Inbox prüfen",
                "goal": "Neue Nachrichten laden",
                "steps": [{"kind": "check_messages", "title": "Posteingang", "payload": {"sources": ["gmail"]}}],
                "safety_level": "balanced",
                "auto_start": False,
            },
        )
        self.assertEqual(created.status_code, 200, created.text)
        mission_id = created.json()["item"]["id"]
        started = self.client.post(f"/missions/{mission_id}/start")
        self.assertEqual(started.status_code, 200)
        self.assertEqual(started.json()["item"]["status"], "running")

    def test_reply_uses_existing_safe_send_path(self) -> None:
        message = self.v10.upsert_message(
            source="whatsapp",
            external_id="wa-2",
            sender_name="Sista",
            conversation="Sista",
            body="Kommst du?",
        )
        result = {
            "ok": True,
            "mode": "desktop_auto",
            "requires_user_action": False,
            "verification": "desktop_send_command_completed",
            "result_summary": "Gesendet",
            "app_closed": True,
        }
        with patch.object(app.integration_hub, "whatsapp_chat_reply", new=AsyncMock(return_value=result)) as send:
            response = self.client.post(
                f"/messages/{message['id']}/reply",
                headers={"Idempotency-Key": "v10-reply-test"},
                json={"message": "Ja, um acht."},
            )
        self.assertEqual(response.status_code, 200, response.text)
        send.assert_awaited_once_with("Sista", "Ja, um acht.")
        self.assertTrue(self.v10.get_message(message["id"])["replied"])

    def test_v10_ui_contains_command_center_and_settings_search(self) -> None:
        html = (Path(__file__).resolve().parents[1] / "static" / "index.html").read_text(encoding="utf-8")
        self.assertEqual(app.APP_VERSION, "15.3.0")
        for marker in (
            'id="settingsSearch"',
            'id="messageList"',
            'id="missionList"',
            'id="inboxDeckBtn"',
            'id="quickScreenBtn"',
            "getDisplayMedia",
            "applySettingsSearch",
            "MISSION CONTROL",
        ):
            self.assertIn(marker, html)


if __name__ == "__main__":
    unittest.main()
