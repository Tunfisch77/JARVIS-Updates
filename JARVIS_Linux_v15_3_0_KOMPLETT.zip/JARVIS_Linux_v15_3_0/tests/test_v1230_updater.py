from __future__ import annotations

import hashlib
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

import jarvis_updater


class UpdaterTests(unittest.TestCase):
    def _fixture(self, root: Path, files: dict[str, str], *, version: str = "12.3.1") -> Path:
        package = root / "update.zip"
        with zipfile.ZipFile(package, "w") as archive:
            for name, value in files.items():
                archive.writestr(name, value)
        manifest = root / "manifest.json"
        manifest.write_text(
            json.dumps(
                {
                    "format": "jarvis-update-v1",
                    "platform": "linux",
                    "version": version,
                    "package": package.name,
                    "sha256": hashlib.sha256(package.read_bytes()).hexdigest(),
                }
            ),
            encoding="utf-8",
        )
        return manifest

    def test_installs_changed_file_and_keeps_backup(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            app = root / "app"
            app.mkdir()
            (app / "module.py").write_text("old", encoding="utf-8")
            manifest = self._fixture(root, {"module.py": "new"})
            with patch.object(jarvis_updater, "APP_VERSION", "12.3.0"):
                result = jarvis_updater.install_update(app, str(manifest))
            self.assertTrue(result["updated"])
            self.assertEqual((app / "module.py").read_text(encoding="utf-8"), "new")
            self.assertEqual((app / ".update_backups" / "12.3.0" / "module.py").read_text(), "old")

    def test_rejects_protected_data(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            app = root / "app"
            app.mkdir()
            manifest = self._fixture(root, {"data/jarvis.db": "bad"})
            with patch.object(jarvis_updater, "APP_VERSION", "12.3.0"), self.assertRaises(jarvis_updater.UpdateError):
                jarvis_updater.install_update(app, str(manifest))

    def test_rejects_wrong_hash(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            app = root / "app"
            app.mkdir()
            manifest = self._fixture(root, {"module.py": "new"})
            payload = json.loads(manifest.read_text())
            payload["sha256"] = "0" * 64
            manifest.write_text(json.dumps(payload))
            with patch.object(jarvis_updater, "APP_VERSION", "12.3.0"), self.assertRaisesRegex(jarvis_updater.UpdateError, "Prüfsumme"):
                jarvis_updater.install_update(app, str(manifest))

    def test_no_downgrade(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            app = root / "app"
            app.mkdir()
            manifest = self._fixture(root, {"module.py": "old"}, version="12.2.9")
            result = jarvis_updater.install_update(app, str(manifest))
            self.assertFalse(result["updated"])


if __name__ == "__main__":
    unittest.main()
