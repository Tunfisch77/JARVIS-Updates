from __future__ import annotations

import asyncio
from datetime import datetime
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from mail_accounts import ACCOUNT_OUTLOOK, ConnectedAccountConfig, ConnectedAccounts


class OutlookWebConfigurationTests(unittest.TestCase):
    def test_environment_defaults_to_web_profile_without_graph_client(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = ConnectedAccountConfig.from_environment(root, {})
            self.assertEqual(config.outlook_mode, "web")
            self.assertTrue(config.outlook_web_auto_send)
            self.assertEqual(
                config.outlook_profile_dir,
                Path.home() / ".jarvis" / "browser_profiles" / "outlook",
            )

    def test_marker_reports_outlook_web_as_connected(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            profile = Path(directory) / "outlook"
            profile.mkdir()
            (profile / ".jarvis_connected").write_text("ready", encoding="utf-8")
            accounts = ConnectedAccounts(
                ConnectedAccountConfig(base_dir=Path(directory), outlook_profile_dir=profile)
            )
            status = accounts.status()[ACCOUNT_OUTLOOK]
            self.assertEqual(status["status"], "connected")
            self.assertEqual(status["mode"], "web_auto")


class OutlookWebActionTests(unittest.TestCase):
    def _connected_accounts(self, directory: str) -> ConnectedAccounts:
        profile = Path(directory) / "outlook"
        profile.mkdir()
        (profile / ".jarvis_connected").write_text("ready", encoding="utf-8")
        return ConnectedAccounts(
            ConnectedAccountConfig(base_dir=Path(directory), outlook_profile_dir=profile)
        )

    def test_send_uses_web_automation_and_reports_completed_action(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            accounts = self._connected_accounts(directory)
            with patch.object(accounts, "_send_outlook_web") as sender:
                result = asyncio.run(accounts.send_outlook("teacher@example.edu", "Test", "Hallo"))
            sender.assert_called_once_with("teacher@example.edu", "Test", "Hallo")
            self.assertEqual(result["mode"], "outlook_web_auto")
            self.assertFalse(result["requires_user_action"])

    def test_email_deeplink_contains_structured_fields(self) -> None:
        accounts = ConnectedAccounts(ConnectedAccountConfig(base_dir=Path(".")))
        with patch.object(accounts, "_run_outlook_web_action") as runner:
            accounts._send_outlook_web("teacher@example.edu", "Prüfung morgen", "Guten Tag")
        url, buttons = runner.call_args.args
        self.assertIn("outlook.office.com/mail/deeplink/compose", url)
        self.assertIn("teacher%40example.edu", url)
        self.assertIn("Pr%C3%BCfung+morgen", url)
        self.assertEqual(buttons, ("Send", "Senden"))

    def test_calendar_deeplink_saves_event_without_graph(self) -> None:
        accounts = ConnectedAccounts(ConnectedAccountConfig(base_dir=Path(".")))
        start = datetime.fromisoformat("2026-07-21T08:00:00+02:00")
        end = datetime.fromisoformat("2026-07-21T09:00:00+02:00")
        with patch.object(accounts, "_run_outlook_web_action") as runner:
            accounts._create_outlook_web_event(
                "Mathematik",
                start,
                end,
                "Wiederholung",
                "Klasse 2A",
                [],
            )
        url, buttons = runner.call_args.args
        self.assertIn("outlook.office.com/calendar/deeplink/compose", url)
        self.assertIn("subject=Mathematik", url)
        self.assertEqual(buttons[:2], ("Save", "Speichern"))


if __name__ == "__main__":
    unittest.main()
