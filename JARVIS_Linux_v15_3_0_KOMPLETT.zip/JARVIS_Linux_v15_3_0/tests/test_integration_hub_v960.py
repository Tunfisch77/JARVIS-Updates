import asyncio
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from fastapi.testclient import TestClient

import app
import integration_hub as hub_module
from capabilities import build_registry
from integration_hub import IntegrationConfig, IntegrationError, IntegrationHub, normalize_phone
from state_store import JarvisStateStore


class IntegrationHubUnitTests(unittest.TestCase):
    def test_phone_requires_international_format(self) -> None:
        self.assertEqual(normalize_phone("+43 660 123 45 67"), "436601234567")
        with self.assertRaises(IntegrationError):
            normalize_phone("0660 1234567")

    def test_contact_alias_resolves_without_exposing_other_contacts(self) -> None:
        contacts = [
            {
                "name": "Mama",
                "aliases": ["Mutter"],
                "whatsapp_number": "436601234567",
                "email": "mama@example.com",
                "telegram_chat_id": "123456",
            }
        ]
        hub = IntegrationHub(lambda: contacts, IntegrationConfig())
        self.assertEqual(hub.resolve_recipient("Mutter", "whatsapp")["recipient"], "436601234567")
        self.assertEqual(hub.resolve_recipient("Mama", "email")["recipient"], "mama@example.com")

    def test_whatsapp_email_and_calendar_create_safe_drafts(self) -> None:
        contacts = [
            {
                "name": "Mama",
                "aliases": [],
                "whatsapp_number": "436601234567",
                "email": "mama@example.com",
                "telegram_chat_id": "",
            }
        ]
        hub = IntegrationHub(lambda: contacts, IntegrationConfig())
        whatsapp = asyncio.run(hub.whatsapp_message("Mama", "Bin gleich da!"))
        email = asyncio.run(hub.email_message("Mama", "Test", "Hallo"))
        calendar = hub.calendar_event("Training", "2026-07-21T18:00", "2026-07-21T19:30")
        self.assertTrue(whatsapp["action_url"].startswith("https://wa.me/436601234567?"))
        self.assertTrue(whatsapp["requires_user_action"])
        self.assertTrue(email["action_url"].startswith("mailto:mama@example.com?"))
        self.assertIn("calendar.google.com/calendar/render", calendar["action_url"])
        self.assertIn("20260721T160000Z", calendar["action_url"])

    def test_invalid_timezone_falls_back_without_stopping_jarvis(self) -> None:
        hub = IntegrationHub(lambda: [], IntegrationConfig(timezone="Europe/Definitely-Not-Real"))
        status = hub.status()
        self.assertEqual(status["calendar"]["timezone"], "Europe/Vienna")
        self.assertTrue(status["warnings"])

    def test_webhook_and_launcher_allowlists_block_unsafe_targets(self) -> None:
        config = IntegrationConfig(
            webhooks={"local": "https://127.0.0.1/hook", "safe": "https://example.com/hook"},
            launch_targets={"unsafe": "file:///C:/secret.txt", "portal": "https://example.com/portal"},
        )
        hub = IntegrationHub(lambda: [], config)
        self.assertNotIn("local", hub.webhooks)
        self.assertIn("safe", hub.webhooks)
        self.assertNotIn("unsafe", hub.launch_targets)
        self.assertIn("portal", hub.launch_targets)
        with self.assertRaises(IntegrationError):
            hub.launch("unsafe")

    def test_configured_telegram_sends_only_to_resolved_chat_id(self) -> None:
        contacts = [
            {
                "name": "Daniel",
                "aliases": [],
                "whatsapp_number": "",
                "email": "",
                "telegram_chat_id": "987654321",
            }
        ]
        hub = IntegrationHub(lambda: contacts, IntegrationConfig(telegram_bot_token="secret-bot-token"))

        class FakeResponse:
            is_error = False
            status_code = 200
            content = b"{}"

            @staticmethod
            def json() -> dict[str, object]:
                return {"ok": True, "result": {"message_id": 42}}

        class FakeClient:
            url = ""
            payload: dict[str, object] = {}

            def __init__(self, *args: object, **kwargs: object) -> None:
                pass

            async def __aenter__(self) -> "FakeClient":
                return self

            async def __aexit__(self, *args: object) -> None:
                return None

            async def post(self, url: str, **kwargs: object) -> FakeResponse:
                FakeClient.url = url
                FakeClient.payload = kwargs["json"]
                return FakeResponse()

        with patch.object(hub_module.httpx, "AsyncClient", FakeClient):
            result = asyncio.run(hub.telegram_message("Daniel", "Hallo"))
        self.assertEqual(result["message_id"], 42)
        self.assertEqual(FakeClient.payload, {"chat_id": "987654321", "text": "Hallo"})
        self.assertIn("secret-bot-token", FakeClient.url)
        self.assertNotIn("secret-bot-token", str(result))

    def test_registry_exposes_ready_integration_tools(self) -> None:
        tools = build_registry({"telegram": True, "webhooks": True}).enabled_tools()
        for tool in (
            "list_contacts",
            "send_whatsapp_message",
            "send_telegram_message",
            "send_email",
            "create_calendar_event",
            "trigger_webhook",
            "open_app_or_website",
        ):
            self.assertIn(tool, tools)


class IntegrationHubApiTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary_directory = tempfile.TemporaryDirectory()
        self.store = JarvisStateStore(Path(self.temporary_directory.name) / "jarvis.db")
        self.hub = IntegrationHub(self.store.list_contacts, IntegrationConfig())
        self.state_patch = patch.object(app, "state_store", self.store)
        self.hub_patch = patch.object(app, "integration_hub", self.hub)
        self.state_patch.start()
        self.hub_patch.start()
        self.client = TestClient(app.app)

    def tearDown(self) -> None:
        self.client.close()
        self.hub_patch.stop()
        self.state_patch.stop()
        self.temporary_directory.cleanup()

    def create_contact(self, name: str = "Mama", alias: str = "Mutter") -> dict[str, object]:
        response = self.client.post(
            "/contacts",
            json={
                "name": name,
                "aliases": [alias],
                "whatsapp_number": "+436601234567",
                "email": "mama@example.com",
                "telegram_chat_id": "123456789",
                "notes": "Privater Kontakt",
            },
        )
        self.assertEqual(response.status_code, 200, response.text)
        return response.json()["item"]

    def confirmation(self, tool_name: str, payload: dict[str, object]) -> str:
        response = self.client.post("/confirmations", json={"tool_name": tool_name, "payload": payload})
        self.assertEqual(response.status_code, 200, response.text)
        return response.json()["token"]

    def test_contact_book_persists_and_model_list_hides_addresses(self) -> None:
        item = self.create_contact()
        self.assertEqual(self.store.get_contact(item["id"])["aliases"], ["Mutter"])
        response = self.client.get("/contacts")
        self.assertEqual(response.status_code, 200)
        visible = response.json()["items"][0]
        self.assertEqual(visible["name"], "Mama")
        self.assertEqual(visible["channels"], ["whatsapp", "email", "telegram"])
        self.assertNotIn("whatsapp_number", visible)
        self.assertNotIn("email", visible)
        self.assertNotIn("notes", visible)

    def test_alias_collision_is_rejected(self) -> None:
        self.create_contact()
        response = self.client.post(
            "/contacts",
            json={"name": "Andere Person", "aliases": ["Mutter"]},
        )
        self.assertEqual(response.status_code, 409)

    def test_whatsapp_requires_confirmation_and_is_idempotent(self) -> None:
        self.create_contact()
        payload = {"target": "Mutter", "message": "Bin gleich da"}
        blocked = self.client.post("/integrations/whatsapp/message", json=payload)
        self.assertEqual(blocked.status_code, 428)

        token = self.confirmation("send_whatsapp_message", payload)
        headers = {"X-Jarvis-Confirmation": token, "Idempotency-Key": "whatsapp-test-001"}
        first = self.client.post("/integrations/whatsapp/message", json=payload, headers=headers)
        second = self.client.post("/integrations/whatsapp/message", json=payload, headers=headers)
        self.assertEqual(first.status_code, 200, first.text)
        self.assertEqual(second.status_code, 200, second.text)
        self.assertTrue(first.json()["requires_user_action"])
        self.assertTrue(second.json()["idempotent_replay"])
        self.assertEqual(first.json()["request_id"], "whatsapp-test-001")

    def test_contact_delete_always_requires_confirmation(self) -> None:
        item = self.create_contact()
        blocked = self.client.delete(f"/contacts/{item['id']}")
        self.assertEqual(blocked.status_code, 428)
        payload = {"contact_id": item["id"]}
        token = self.confirmation("manage_contacts", payload)
        deleted = self.client.delete(
            f"/contacts/{item['id']}",
            headers={"X-Jarvis-Confirmation": token},
        )
        self.assertEqual(deleted.status_code, 200)


class IntegrationHubUiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        root = Path(__file__).resolve().parents[1]
        cls.html = (root / "static" / "index.html").read_text(encoding="utf-8")
        cls.app_source = (root / "app.py").read_text(encoding="utf-8")

    def test_ui_has_contact_manager_and_safe_action_card(self) -> None:
        for marker in (
            'id="integrationHubSummary"',
            'id="contactName"',
            'id="contactWhatsapp"',
            'id="contactEmail"',
            'id="contactTelegram"',
            "function showExternalAction",
            "JETZT ÖFFNEN",
        ):
            self.assertIn(marker, self.html)

    def test_realtime_client_routes_all_integration_tools(self) -> None:
        for tool in (
            "list_contacts",
            "send_whatsapp_message",
            "send_telegram_message",
            "send_email",
            "create_calendar_event",
            "trigger_webhook",
            "open_app_or_website",
        ):
            self.assertIn(f'call.name === "{tool}"', self.html)
            self.assertIn(f'"name": "{tool}"', self.app_source)

    def test_prompt_forbids_guessing_recipients_and_proactive_sends(self) -> None:
        self.assertIn("Rate niemals einen Kontakt", self.app_source)
        self.assertIn("Sende niemals Sammelnachrichten", self.app_source)
        self.assertIn("proaktiven Vermutung", self.app_source)


if __name__ == "__main__":
    unittest.main()
