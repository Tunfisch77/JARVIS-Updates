from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, patch

from fastapi import HTTPException
from fastapi.testclient import TestClient

import app
from backup_manager import BackupManager
from memory_store import MemoryStore
from stability_manager import SafeModeGuard, resilient_call, run_startup_self_test
from state_store import JarvisStateStore


class StabilityStateTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary_directory = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary_directory.name)
        self.database = self.root / "jarvis.db"
        self.memory = MemoryStore(self.database)
        self.store = JarvisStateStore(self.database)

    def tearDown(self) -> None:
        self.temporary_directory.cleanup()

    def test_usage_events_are_idempotent_and_enforce_budget(self) -> None:
        settings = {
            "daily_token_limit": 100,
            "monthly_token_limit": 1000,
            "warning_percent": 80,
            "hard_stop": True,
        }
        self.store.set_setting("budget", settings)
        self.assertTrue(
            self.store.record_model_usage(
                "realtime",
                {"input_tokens": 50, "output_tokens": 30},
                model="test",
                event_key="realtime:first",
            )
        )
        self.assertFalse(
            self.store.record_model_usage(
                "realtime",
                {"input_tokens": 50, "output_tokens": 30},
                model="test",
                event_key="realtime:first",
            )
        )
        status = self.store.budget_status(settings)
        self.assertEqual(status["daily_tokens"], 80)
        self.assertFalse(status["exceeded"])
        self.assertTrue(status["warning"])
        self.store.record_model_usage("web", {"total_tokens": 20}, event_key="web:second")
        self.assertTrue(self.store.budget_status(settings)["exceeded"])

    def test_background_jobs_survive_recovery_and_keep_payload_and_result(self) -> None:
        created = self.store.enqueue_job("reasoning", {"question": "Prüfe das Projekt"}, max_attempts=3)
        self.assertEqual(created["payload"]["question"], "Prüfe das Projekt")
        claimed = self.store.claim_next_job()
        self.assertIsNotNone(claimed)
        self.assertEqual(claimed["status"], "running")
        self.assertEqual(claimed["attempts"], 1)
        self.assertEqual(self.store.recover_interrupted_jobs(), 1)
        resumed = self.store.claim_next_job()
        self.assertIsNotNone(resumed)
        self.assertEqual(resumed["attempts"], 2)
        self.assertTrue(self.store.complete_job(created["id"], {"answer": "Fertig"}))
        finished = self.store.get_job(created["id"])
        self.assertEqual(finished["status"], "completed")
        self.assertEqual(finished["result"]["answer"], "Fertig")

    def test_circuit_breaker_is_persistent_and_resets_after_success(self) -> None:
        for _ in range(4):
            self.store.circuit_failure("openai_test", "temporär", threshold=4, cooldown_seconds=10)
        self.assertFalse(self.store.circuit_allow("openai_test"))
        recreated = JarvisStateStore(self.database)
        self.assertTrue(recreated.circuit_status("openai_test")["open"])
        recreated.circuit_success("openai_test")
        self.assertTrue(recreated.circuit_allow("openai_test"))

    def test_backup_roundtrip_restores_database_without_secrets(self) -> None:
        self.memory.add_memory("Backup-Merkpunkt", importance=4)
        self.store.set_setting("personality", {"mode": "focus"})
        manager = BackupManager(self.database, self.root / "backups", app_version="9.4.1")
        data = manager.create_bytes(reason="test")
        self.store.set_setting("personality", {"mode": "night"})
        result = manager.restore_bytes(data)
        restored_state = JarvisStateStore(self.database)
        restored_memory = MemoryStore(self.database)
        self.assertTrue(result["ok"])
        self.assertEqual(restored_state.get_setting("personality", {})["mode"], "focus")
        self.assertEqual(restored_memory.search("Backup-Merkpunkt")[0]["text"], "Backup-Merkpunkt")
        self.assertNotIn(b"OPENAI_API_KEY", data)

    def test_startup_self_test_checks_database_directories_and_disk(self) -> None:
        result = run_startup_self_test(
            self.database,
            self.root / "generated",
            self.root / "backups",
            api_key_configured=True,
        )
        self.assertTrue(result["ok"])
        names = {item["name"] for item in result["checks"]}
        self.assertTrue({"database", "generated_directory", "backup_directory", "disk_space"}.issubset(names))
        self.assertIn("v9.4.1-stability-schema", {item["name"] for item in self.store.list_migrations()})

    def test_unclean_shutdown_marker_activates_safe_mode(self) -> None:
        marker = self.root / "jarvis.running"
        marker.write_text("old-process", encoding="ascii")
        guard = SafeModeGuard(marker)
        self.assertTrue(guard.start())
        self.assertIn("nicht sauber beendet", guard.reason)
        guard.stop()
        self.assertFalse(marker.exists())


class ResilientCallTests(unittest.IsolatedAsyncioTestCase):
    async def test_retry_succeeds_and_closes_circuit(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            store = JarvisStateStore(Path(directory) / "jarvis.db")
            operation = AsyncMock(side_effect=[HTTPException(status_code=503, detail="busy"), "ok"])
            result = await resilient_call(
                store,
                "retry-test",
                operation,
                is_retryable=lambda error: isinstance(error, HTTPException) and error.status_code == 503,
                max_attempts=3,
                base_delay_seconds=0,
            )
            self.assertEqual(result, "ok")
            self.assertEqual(operation.await_count, 2)
            self.assertEqual(store.circuit_status("retry-test")["failure_count"], 0)

    async def test_worker_persists_finished_result(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            database = Path(directory) / "jarvis.db"
            MemoryStore(database)
            store = JarvisStateStore(database)
            created = store.enqueue_job("reasoning", {"question": "Löse sie", "difficulty": "terra"})
            claimed = store.claim_next_job()
            result = {"answer": "Erledigt", "model": "test", "usage": {"total_tokens": 12}, "response_id": "resp_test"}
            with (
                patch.object(app, "state_store", store),
                patch.object(app, "_run_reasoning_stable", new=AsyncMock(return_value=result)) as reasoning,
            ):
                await app._execute_background_job(claimed)
            reasoning.assert_awaited_once_with("Löse sie", "terra")
            self.assertEqual(store.get_job(created["id"])["result"]["answer"], "Erledigt")


class StabilityApiAndUiTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary_directory = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary_directory.name)
        self.database = self.root / "jarvis.db"
        MemoryStore(self.database)
        self.store = JarvisStateStore(self.database)
        self.state_patch = patch.object(app, "state_store", self.store)
        self.backup_patch = patch.object(
            app,
            "backup_manager",
            BackupManager(self.database, self.root / "backups", app_version="9.4.1"),
        )
        self.state_patch.start()
        self.backup_patch.start()
        self.client = TestClient(app.app)

    def tearDown(self) -> None:
        self.client.close()
        self.backup_patch.stop()
        self.state_patch.stop()
        self.temporary_directory.cleanup()

    def test_budget_and_background_job_endpoints(self) -> None:
        budget = self.client.put(
            "/settings/budget",
            json={
                "daily_token_limit": 5000,
                "monthly_token_limit": 50000,
                "warning_percent": 75,
                "hard_stop": True,
            },
        )
        self.assertEqual(budget.status_code, 200)
        with patch.object(app, "OPENAI_API_KEY", "test-key"):
            job = self.client.post(
                "/jobs",
                json={"kind": "reasoning", "question": "Analysiere die Stabilität", "difficulty": "terra"},
            )
        self.assertEqual(job.status_code, 200)
        self.assertEqual(job.json()["item"]["payload"]["question"], "Analysiere die Stabilität")
        listed = self.client.get("/jobs").json()["items"]
        self.assertEqual(len(listed), 1)
        self.assertEqual(listed[0]["status"], "queued")

    def test_safe_mode_blocks_optional_model_work(self) -> None:
        guard = app.SafeModeGuard(self.root / "running")
        guard.active = True
        guard.reason = "Testschutz"
        with (
            patch.object(app, "safe_mode_guard", guard),
            patch.object(app, "OPENAI_API_KEY", "test-key"),
        ):
            response = self.client.post("/web/search", json={"query": "Aktuelle Nachrichten"})
        self.assertEqual(response.status_code, 503)
        self.assertIn("Safe Mode", response.json()["detail"])

    def test_background_job_honors_reasoning_confirmation(self) -> None:
        self.store.update_permission("solve_complex_task", enabled=True, requires_confirmation=True)
        payload = {"question": "Bestätigte Analyse", "difficulty": "terra"}
        body = {"kind": "reasoning", **payload}
        with patch.object(app, "OPENAI_API_KEY", "test-key"):
            blocked = self.client.post("/jobs", json=body)
            issued = self.client.post(
                "/confirmations",
                json={"tool_name": "solve_complex_task", "payload": payload},
            ).json()
            allowed = self.client.post(
                "/jobs",
                json=body,
                headers={"X-Jarvis-Confirmation": issued["token"]},
            )
        self.assertEqual(blocked.status_code, 428)
        self.assertEqual(allowed.status_code, 200)

    def test_ui_exposes_stability_jobs_budget_and_realtime_usage(self) -> None:
        html = (Path(__file__).resolve().parents[1] / "static" / "index.html").read_text(encoding="utf-8")
        self.assertIn("STABILITÄT &amp; WIEDERHERSTELLUNG", html)
        self.assertIn("HINTERGRUNDAUFTRÄGE", html)
        self.assertIn("MODELL-BUDGET", html)
        self.assertIn('requestJson("/usage"', html)
        self.assertIn("all v14 and earlier controls remain available in v15", html)


if __name__ == "__main__":
    unittest.main()
