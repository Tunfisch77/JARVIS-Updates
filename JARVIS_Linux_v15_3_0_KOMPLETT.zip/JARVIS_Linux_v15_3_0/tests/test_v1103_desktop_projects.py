from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, patch

from fastapi.testclient import TestClient

import app
from state_store import JarvisStateStore
from v11_core import DesktopControlError, DesktopController, V11CapabilityManager


class DesktopProjectControllerTests(unittest.TestCase):
    def make_controller(self, directory: str) -> DesktopController:
        root = Path(directory)
        store = JarvisStateStore(root / "jarvis.db")
        manager = V11CapabilityManager(store, root)
        return DesktopController(store, manager, root)

    def test_creates_complete_project_atomically(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            controller = self.make_controller(directory)
            destination = Path(directory) / "Eigene Projekte" / "snake"
            files = [
                {"path": "index.html", "content": "<canvas id=\"game\"></canvas>\n"},
                {"path": "css/style.css", "content": "canvas { background: #000; }\n"},
                {"path": "js/game.js", "content": "let score = 0;\n"},
            ]
            result = controller.create_project(str(destination), files, open_after_create=False)
            self.assertEqual(result["file_count"], 3)
            self.assertEqual(result["location"], "explicit_path")
            self.assertEqual(result["path"], str(destination))
            self.assertIn("bytegenau", result["verification"])
            self.assertEqual((destination / "js" / "game.js").read_text(encoding="utf-8"), "let score = 0;\n")
            self.assertFalse(any(item.name.startswith(".snake.jarvis-") for item in destination.parent.iterdir()))

    def test_never_overwrites_existing_project(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            controller = self.make_controller(directory)
            existing = Path(directory) / "projects" / "snake"
            existing.mkdir(parents=True)
            marker = existing / "index.html"
            marker.write_text("original", encoding="utf-8")
            with self.assertRaises(DesktopControlError):
                controller.create_project(
                    str(existing),
                    [{"path": "index.html", "content": "replacement"}],
                    open_after_create=False,
                )
            self.assertEqual(marker.read_text(encoding="utf-8"), "original")

    def test_requires_an_explicit_absolute_target_path(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            controller = self.make_controller(directory)
            for target_path in ("", "snake", "projects/snake"):
                with self.subTest(target_path=target_path), self.assertRaises(DesktopControlError):
                    controller.create_project(
                        target_path,
                        [{"path": "index.html", "content": "ok"}],
                        open_after_create=False,
                    )

    def test_blocks_traversal_secrets_and_executables(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            controller = self.make_controller(directory)
            destination = Path(directory) / "snake"
            for path in ("../escape.js", ".env", "start.bat"):
                with self.subTest(path=path), self.assertRaises(DesktopControlError):
                    controller.create_project(
                        str(destination),
                        [{"path": path, "content": "x"}],
                        open_after_create=False,
                    )

    def test_window_name_is_inferred_from_open_action(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            controller = self.make_controller(directory)
            plan = controller.validate_plan(
                [
                    {"action": "open", "target": "notepad.exe"},
                    {"action": "click_control", "control": "Datei"},
                ]
            )
            self.assertEqual(plan[1]["window"], "notepad")


class DesktopProjectApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.client = TestClient(app.app)

    def test_realtime_exposes_dedicated_project_builder(self) -> None:
        tools = {item.get("name"): item for item in app._all_realtime_tools()}
        self.assertIn("create_desktop_project", tools)
        self.assertIn("Softwareprojekt", str(tools["create_desktop_project"]["description"]))
        schema = tools["create_desktop_project"]["parameters"]
        self.assertIn("target_path", schema["required"])
        self.assertNotIn("location", schema["properties"])
        self.assertNotIn("folder_name", schema["properties"])
        self.assertIn("erfinde niemals Desktop", str(tools["create_desktop_project"]["description"]))

    def test_confirmed_project_request_generates_and_writes_files(self) -> None:
        target_path = str(Path(tempfile.gettempdir()) / "Eigene Projekte" / "snake")
        model_result = {
            "answer": "Snake wurde vollständig erstellt.",
            "changes": [
                {"path": "snake/index.html", "action": "upsert", "content": "<canvas></canvas>"},
                {"path": "game.js", "action": "upsert", "content": "let snake = [];"},
            ],
            "model": "test-model",
            "usage": {},
            "response_id": "resp-desktop-project-test",
        }
        created = {
            "ok": True,
            "folder_name": "snake",
            "location": "explicit_path",
            "path": target_path,
            "file_count": 2,
            "total_bytes": 30,
            "files": [],
            "opened": False,
            "verification": "geprüft",
        }
        payload = {
            "target_path": target_path,
            "instruction": "Baue ein vollständiges Snake-Spiel von null auf.",
            "open_after_create": True,
        }
        with (
            patch.object(app, "OPENAI_API_KEY", "test-key"),
            patch.object(app, "_run_workspace_edit_stable", new=AsyncMock(return_value=model_result)),
            patch.object(app.desktop_controller, "create_project", return_value=created) as writer,
        ):
            response = self.client.post(
                "/v11/desktop/projects",
                json=payload,
                headers={"X-Jarvis-Confirmed": "true"},
            )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["project"]["file_count"], 2)
        self.assertEqual(writer.call_args.args[0], target_path)
        generated_files = writer.call_args.args[1]
        self.assertEqual([item["path"] for item in generated_files], ["index.html", "game.js"])

    def test_api_rejects_missing_target_path_before_generation(self) -> None:
        with patch.object(app, "_run_workspace_edit_stable", new=AsyncMock()) as generator:
            response = self.client.post(
                "/v11/desktop/projects",
                json={"instruction": "Baue ein Spiel.", "open_after_create": False},
                headers={"X-Jarvis-Confirmed": "true"},
            )
        self.assertEqual(response.status_code, 422)
        generator.assert_not_awaited()

    def test_frontend_requests_missing_project_path_without_confirmation(self) -> None:
        html = (Path(__file__).resolve().parents[1] / "static" / "index.html").read_text(encoding="utf-8")
        self.assertIn('missing: "target_path"', html)
        self.assertIn("In welchem vollständigen Pfad soll ich das Projekt erstellen?", html)
        self.assertNotIn('location: "desktop"', html)

    def test_realtime_internal_message_always_has_item_type(self) -> None:
        html = (Path(__file__).resolve().parents[1] / "static" / "index.html").read_text(encoding="utf-8")
        self.assertIn('item: { type: "message", role: "user", content }', html)


if __name__ == "__main__":
    unittest.main()
