import unittest

from capabilities import build_registry


class CapabilityTests(unittest.TestCase):
    def test_ready_tools_are_enabled_by_default(self) -> None:
        registry = build_registry()
        tools = registry.enabled_tools()
        self.assertIn("solve_complex_task", tools)
        self.assertIn("create_timer", tools)
        self.assertIn("search_web", tools)
        self.assertIn("analyze_attachments", tools)

    def test_future_capability_cannot_become_active(self) -> None:
        registry = build_registry()
        items = {item["key"]: item for item in registry.list({"weather": True})}
        self.assertFalse(items["weather"]["enabled"])
        self.assertFalse(items["weather"]["ready"])


if __name__ == "__main__":
    unittest.main()
