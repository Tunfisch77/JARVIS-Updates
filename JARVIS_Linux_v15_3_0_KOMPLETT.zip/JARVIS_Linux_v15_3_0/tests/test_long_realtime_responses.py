import asyncio
from pathlib import Path
import unittest
from unittest.mock import patch

import app


class LongRealtimeResponseTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        root = Path(__file__).resolve().parents[1]
        cls.html = (root / "static" / "index.html").read_text(encoding="utf-8")

    def test_realtime_session_has_no_fixed_output_limit(self) -> None:
        class FakeResponse:
            is_error = False
            status_code = 200
            text = ""

            @staticmethod
            def json() -> dict[str, object]:
                return {"value": "temporary-client-secret"}

        class FakeClient:
            payload: dict[str, object] | None = None

            def __init__(self, *args: object, **kwargs: object) -> None:
                pass

            async def __aenter__(self) -> "FakeClient":
                return self

            async def __aexit__(self, *args: object) -> None:
                return None

            async def post(self, *args: object, **kwargs: object) -> FakeResponse:
                FakeClient.payload = kwargs["json"]
                return FakeResponse()

        async def run_without_retries(_service: str, operation: object) -> object:
            return await operation()

        with (
            patch.object(app, "OPENAI_API_KEY", "test-key"),
            patch.object(app, "_require_budget"),
            patch.object(app, "_with_openai_stability", side_effect=run_without_retries),
            patch.object(app.httpx, "AsyncClient", FakeClient),
        ):
            response = asyncio.run(app.create_realtime_token(voice="marin", noise_profile="strong"))

        self.assertEqual(response.status_code, 200)
        self.assertIsNotNone(FakeClient.payload)
        session = FakeClient.payload["session"]
        self.assertEqual(session["max_output_tokens"], "inf")
        self.assertIn("gewünschte Längen", session["instructions"])
        self.assertIn("beende eine Antwort nicht absichtlich mitten im Satz", session["instructions"])

    def test_only_output_limit_incompleteness_is_continued_automatically(self) -> None:
        reason = self.html.split("function outputLimitReason", 1)[1].split("function startPendingAutomaticContinuation", 1)[0]
        queue = self.html.split("function queueAutomaticContinuation", 1)[1].split("function escapeRegExp", 1)[0]
        self.assertIn('response?.status || "") !== "incomplete"', reason)
        self.assertIn('outputLimitReason(response) !== "max_output_tokens"', queue)
        self.assertIn("MAX_AUTOMATIC_CONTINUATIONS", queue)
        self.assertNotIn('"cancelled"', queue)

    def test_continuation_waits_for_audio_and_keeps_one_transcript_message(self) -> None:
        starter = self.html.split("function startPendingAutomaticContinuation", 1)[1].split("function queueAutomaticContinuation", 1)[0]
        self.assertIn("activeAudioResponses.size > 0", starter)
        self.assertIn("pendingAutomaticContinuation", starter)
        self.assertIn("ohne Wiederholung", starter)

        audio_stop = self.html.split('event.type === "output_audio_buffer.stopped"', 1)[1]
        audio_stop = audio_stop.split('event.type === "response.output_audio_transcript.delta"', 1)[0]
        self.assertIn("startPendingAutomaticContinuation()", audio_stop)

        transcript = self.html.split("function displaySynchronizedTranscript", 1)[1].split("function updateTranscriptPart", 1)[0]
        self.assertIn("automaticContinuationPrefix", transcript)
        self.assertIn("currentJarvisMessage", transcript)

    def test_incomplete_response_is_queued_before_history_persistence(self) -> None:
        response_done = self.html.split('event.type === "response.done"', 1)[1]
        queue = response_done.index("queueAutomaticContinuation(event.response)")
        persistence = response_done.index('persistHistory("jarvis", rawContent)')
        self.assertLess(queue, persistence)


if __name__ == "__main__":
    unittest.main()
