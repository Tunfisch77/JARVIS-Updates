from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from browser_runtime import (
    browser_candidates,
    channel_from_progid,
    launch_persistent_browser,
)
from integration_hub import IntegrationConfig, IntegrationHub
from integrations_setup import _find_ready_snapchat_page


class FakePage:
    def __init__(self, url: str) -> None:
        self.url = url


class FakeChromium:
    def __init__(self, failures: dict[str | None, Exception] | None = None) -> None:
        self.failures = failures or {}
        self.calls: list[dict[str, object]] = []

    def launch_persistent_context(self, profile: str, **kwargs: object) -> object:
        self.calls.append({"profile": profile, **kwargs})
        channel = kwargs.get("channel")
        if channel in self.failures:
            raise self.failures[channel]
        return {"channel": channel}


class FakePlaywright:
    def __init__(self, chromium: FakeChromium) -> None:
        self.chromium = chromium


class BrowserAndSnapchatTests(unittest.TestCase):
    def test_windows_default_browser_mapping(self) -> None:
        self.assertEqual(channel_from_progid("BraveHTML"), "brave")
        self.assertEqual(channel_from_progid("BraveHTML-4UQJ3A"), "brave")
        self.assertEqual(channel_from_progid("ChromeHTML"), "chrome")
        self.assertEqual(channel_from_progid("MSEdgeHTM"), "msedge")
        self.assertIsNone(channel_from_progid("FirefoxURL-308046B0AF4A39CB"))

    def test_auto_uses_brave_when_it_is_the_windows_default(self) -> None:
        self.assertEqual(
            browser_candidates("auto", detected_channel="brave"),
            ("brave", None),
        )

    def test_auto_uses_detected_default_then_bundled_chromium(self) -> None:
        self.assertEqual(
            browser_candidates("auto", detected_channel="chrome"),
            ("chrome", None),
        )

    def test_missing_default_browser_falls_back_without_forcing_edge(self) -> None:
        chromium = FakeChromium(
            {"chrome": RuntimeError("Chromium distribution 'chrome' is not found")}
        )
        result = launch_persistent_browser(
            FakePlaywright(chromium),
            Path("."),
            preference="chrome",
            headless=True,
        )
        self.assertEqual(result, {"channel": None})
        self.assertEqual([call.get("channel") for call in chromium.calls], ["chrome", None])

    def test_brave_uses_its_executable_and_a_separate_profile(self) -> None:
        chromium = FakeChromium()
        executable = Path("C:/Program Files/BraveSoftware/Brave-Browser/Application/brave.exe")
        with patch("browser_runtime.brave_executable_path", return_value=executable):
            result = launch_persistent_browser(
                FakePlaywright(chromium),
                Path("data/snapchat_web_profile"),
                preference="brave",
                headless=False,
            )
        self.assertEqual(result, {"channel": None})
        self.assertEqual(chromium.calls[0].get("executable_path"), str(executable))
        self.assertNotIn("channel", chromium.calls[0])
        self.assertIs(chromium.calls[0].get("chromium_sandbox"), True)

    def test_browser_launch_removes_unsafe_sandbox_flags(self) -> None:
        chromium = FakeChromium()
        launch_persistent_browser(
            FakePlaywright(chromium),
            Path("."),
            preference="chromium",
            headless=False,
            args=["--start-maximized", "--no-sandbox", "--disable-setuid-sandbox"],
            chromium_sandbox=False,
        )
        self.assertIs(chromium.calls[0].get("chromium_sandbox"), True)
        self.assertEqual(chromium.calls[0].get("args"), ["--start-maximized"])

    def test_missing_explicit_brave_never_opens_another_browser(self) -> None:
        chromium = FakeChromium()
        with patch("browser_runtime.brave_executable_path", return_value=None):
            with self.assertRaisesRegex(RuntimeError, "Brave browser executable"):
                launch_persistent_browser(
                    FakePlaywright(chromium),
                    Path("."),
                    preference="brave",
                    headless=True,
                )
        self.assertEqual(chromium.calls, [])

    def test_snapchat_login_can_finish_in_a_new_page(self) -> None:
        ready = FakePage("https://web.snapchat.com/conversations/example")
        pages = [
            FakePage("https://accounts.snapchat.com/accounts/login"),
            ready,
        ]
        self.assertIs(_find_ready_snapchat_page(pages), ready)

    def test_snapchat_status_requires_success_marker(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            profile = Path(directory) / "snapchat"
            profile.mkdir()
            (profile / "Local State").write_text("browser data", encoding="utf-8")
            hub = IntegrationHub(
                lambda: [],
                IntegrationConfig(snapchat_profile_dir=profile)
            )
            self.assertEqual(hub.status()["snapchat"]["status"], "not_configured")
            (profile / ".jarvis_connected").write_text("ready", encoding="utf-8")
            self.assertEqual(hub.status()["snapchat"]["status"], "connected")


if __name__ == "__main__":
    unittest.main()
