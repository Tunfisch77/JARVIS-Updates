from __future__ import annotations

import asyncio
import inspect
import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, Mock, patch

from fastapi.testclient import TestClient

import app
from integration_hub import IntegrationHub
from local_project import LocalProjectError, LocalProjectManager
from mail_accounts import ConnectedAccounts
from state_store import JarvisStateStore


class LocalProjectManagerTests(unittest.TestCase):
    def make_manager(self, directory: str) -> LocalProjectManager:
        root = Path(directory)
        return LocalProjectManager(JarvisStateStore(root / "jarvis.db"), root / "backups")

    def test_remembers_real_project_and_adds_safe_start_batch(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            manager = self.make_manager(directory)
            project = Path(directory) / "snake"
            project.mkdir()
            (project / "index.html").write_text("<canvas></canvas>\n", encoding="utf-8")
            manager.remember_project(str(project))
            collected = manager.collect_ai_files()
            self.assertEqual(collected["path"], str(project))
            result = manager.apply_changes(
                "",
                [
                    {
                        "path": "start.bat",
                        "action": "upsert",
                        "content": '@echo off\ncd /d "%~dp0"\nstart "" "index.html"\n',
                    }
                ],
                instruction="Füge eine start.bat ein.",
            )
            self.assertEqual(result["change_count"], 1)
            self.assertTrue((project / "start.bat").is_file())
            self.assertIn("bytegenau", result["verification"])
            backup = Path(directory) / "backups"
            self.assertTrue(any(path.name == "manifest.json" for path in backup.rglob("manifest.json")))

    def test_blocks_dangerous_batch_commands(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            manager = self.make_manager(directory)
            project = Path(directory) / "demo"
            project.mkdir()
            (project / "main.py").write_text("print('ok')\n", encoding="utf-8")
            with self.assertRaises(LocalProjectError):
                manager.apply_changes(
                    str(project),
                    [
                        {
                            "path": "start.bat",
                            "action": "upsert",
                            "content": "@echo off\npowershell -Command Invoke-WebRequest https://example.com/x\n",
                        }
                    ],
                    instruction="Erstelle eine start.bat.",
                )
            self.assertFalse((project / "start.bat").exists())

    def test_syntax_failure_rolls_back_existing_file(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            manager = self.make_manager(directory)
            project = Path(directory) / "demo"
            project.mkdir()
            source = project / "main.py"
            source.write_text("value = 1\n", encoding="utf-8")
            with self.assertRaises(LocalProjectError):
                manager.apply_changes(
                    str(project),
                    [{"path": "main.py", "action": "upsert", "content": "def broken(:\n"}],
                    instruction="Ändere main.py.",
                )
            self.assertEqual(source.read_text(encoding="utf-8"), "value = 1\n")

    def test_concurrent_user_change_is_never_overwritten(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            manager = self.make_manager(directory)
            project = Path(directory) / "demo"
            project.mkdir()
            source = project / "main.py"
            source.write_text("value = 1\n", encoding="utf-8")
            collected = manager.collect_ai_files(str(project))
            source.write_text("value = 99\n", encoding="utf-8")
            with self.assertRaises(LocalProjectError):
                manager.apply_changes(
                    str(project),
                    [{"path": "main.py", "action": "upsert", "content": "value = 2\n"}],
                    instruction="Ändere den Wert.",
                    expected_hashes=collected["base_hashes"],
                )
            self.assertEqual(source.read_text(encoding="utf-8"), "value = 99\n")


class ProjectEditApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.client = TestClient(app.app)

    def test_realtime_exposes_follow_up_project_editor(self) -> None:
        tools = {item.get("name"): item for item in app._all_realtime_tools()}
        self.assertIn("modify_code_project", tools)
        schema = tools["modify_code_project"]["parameters"]
        self.assertEqual(schema["required"], ["instruction"])
        self.assertIn("Backup", str(tools["modify_code_project"]["description"]))

    def test_confirmed_follow_up_modifies_active_project(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            project = root / "snake"
            project.mkdir()
            (project / "index.html").write_text("<canvas></canvas>\n", encoding="utf-8")
            manager = LocalProjectManager(JarvisStateStore(root / "jarvis.db"), root / "backups")
            manager.remember_project(str(project))
            model_result = {
                "answer": "Startdatei ergänzt.",
                "changes": [
                    {
                        "path": "start.bat",
                        "action": "upsert",
                        "content": '@echo off\ncd /d "%~dp0"\nstart "" "index.html"\n',
                    }
                ],
                "model": "test-model",
                "usage": {},
                "response_id": "resp-project-edit-test",
            }
            with (
                patch.object(app, "OPENAI_API_KEY", "test-key"),
                patch.object(app, "local_project_manager", manager),
                patch.object(app, "_run_workspace_edit_stable", new=AsyncMock(return_value=model_result)),
            ):
                response = self.client.post(
                    "/v11/projects/edit",
                    json={"target_path": "", "instruction": "Füge eine start.bat ein.", "open_after_edit": False},
                    headers={"X-Jarvis-Confirmed": "true"},
                )
            self.assertEqual(response.status_code, 200, response.text)
            self.assertEqual(response.json()["change_count"], 1)
            self.assertTrue((project / "start.bat").is_file())


class BackgroundMessageTests(unittest.IsolatedAsyncioTestCase):
    def test_web_readers_are_headless_but_sending_stays_visible(self) -> None:
        outlook_source = inspect.getsource(ConnectedAccounts.list_unread_outlook)
        whatsapp_source = inspect.getsource(IntegrationHub._list_unread_whatsapp_web)
        outlook_action_source = inspect.getsource(ConnectedAccounts._run_outlook_web_action)
        self.assertIn("headless=True", outlook_source)
        self.assertIn("headless=True", whatsapp_source)
        self.assertNotIn("headless=True", outlook_action_source)

    async def test_refresh_reports_no_visible_browser_windows(self) -> None:
        whatsapp = AsyncMock(return_value=[])
        gmail = Mock(return_value=[])
        outlook = Mock(return_value=[])
        app.message_refresh_lock = asyncio.Lock()
        with (
            patch.object(app.integration_hub, "unread_whatsapp_messages", new=whatsapp),
            patch.object(app.connected_accounts, "list_unread_gmail", new=gmail),
            patch.object(app.connected_accounts, "list_unread_outlook", new=outlook),
        ):
            result = await app._refresh_unified_messages(
                ["whatsapp", "gmail", "outlook"],
                origin="test",
            )
        self.assertTrue(result["ok"])
        self.assertTrue(all(not item["visible_window"] for item in result["sources"].values()))

    def test_frontend_polling_only_reads_local_inbox(self) -> None:
        html = (Path(__file__).resolve().parents[1] / "static" / "index.html").read_text(encoding="utf-8")
        self.assertIn("UNSICHTBAR IM HINTERGRUND PRÜFEN", html)
        self.assertIn("loadMessages({ refresh: false, quiet: true, announce: true })", html)


if __name__ == "__main__":
    unittest.main()
