from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

from memory_store import MemoryStore
import app


class MemoryStoreTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = TemporaryDirectory()
        self.store = MemoryStore(Path(self.temp_dir.name) / "jarvis-test.db")

    def tearDown(self) -> None:
        self.temp_dir.cleanup()

    def test_memory_is_saved_and_found(self) -> None:
        saved = self.store.add_memory("Der Nutzer mag kurze Antworten.", importance=4)
        found = self.store.search("kurze Antworten")
        self.assertEqual(saved["text"], "Der Nutzer mag kurze Antworten.")
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0]["importance"], 4)

    def test_duplicate_memory_is_updated(self) -> None:
        self.store.add_memory("Kamera bleibt standardmäßig aus.", importance=1)
        self.store.add_memory("Kamera bleibt standardmäßig aus.", importance=5)
        self.assertEqual(len(self.store.search()), 1)
        self.assertEqual(self.store.search()[0]["importance"], 5)

    def test_history_roundtrip_and_clear(self) -> None:
        self.store.add_history("user", "Hallo Jarvis")
        self.store.add_history("jarvis", "Hallo Tuncay")
        history = self.store.recent_history()
        self.assertEqual([item["role"] for item in history], ["user", "jarvis"])
        self.assertEqual(self.store.clear_history(), 2)
        self.assertEqual(self.store.recent_history(), [])

    def test_old_history_is_recalled_across_the_full_timeline(self) -> None:
        self.store.add_history("user", "Beim Mango-Projekt wollten wir die Kamera verbessern.")
        for index in range(80):
            self.store.add_history("jarvis", f"Späterer Gesprächseintrag Nummer {index}")
        context = self.store.relevant_context("Was hatten wir beim Mango-Projekt geplant?")
        self.assertTrue(any("Mango-Projekt" in item["content"] for item in context["history"]))

    def test_continuity_context_contains_recent_turns_without_resume_question(self) -> None:
        self.store.add_history("user", "Wir bauen weiter an JARVIS.")
        self.store.add_history("jarvis", "Ich habe den aktuellen Stand gespeichert.")
        context = self.store.continuity_context()
        self.assertIn("FORTLAUFENDE PERSÖNLICHE TIMELINE", context)
        self.assertIn("Wir bauen weiter an JARVIS.", context)

    def test_fresh_version_imports_latest_sibling_conversation_database(self) -> None:
        with TemporaryDirectory() as directory:
            root = Path(directory)
            old_directory = root / "JARVIS_VisionVoice_v9_6_0"
            new_directory = root / "JARVIS_VisionVoice_v9_6_1"
            old_database = old_directory / "data" / "jarvis.db"
            old_store = MemoryStore(old_database)
            old_store.add_history("user", "Diese Unterhaltung soll den Versionswechsel überleben.")

            new_database = new_directory / "data" / "jarvis.db"
            imported = app._import_previous_memory_database(
                new_database,
                search_root=root,
                current_directory=new_directory,
            )

            self.assertEqual(imported, old_database)
            restored = MemoryStore(new_database).recent_history()
            self.assertEqual(restored[0]["content"], "Diese Unterhaltung soll den Versionswechsel überleben.")
            self.assertTrue(old_database.exists())

    def test_migration_closes_sqlite_connections_before_windows_replace(self) -> None:
        class FakeCursor:
            @staticmethod
            def fetchone() -> tuple[str]:
                return ("ok",)

        class FakeConnection:
            def __init__(self) -> None:
                self.closed = False

            def execute(self, _query: str) -> FakeCursor:
                return FakeCursor()

            def backup(self, _destination: object) -> None:
                return None

            def commit(self) -> None:
                return None

            def close(self) -> None:
                self.closed = True

            def __enter__(self) -> "FakeConnection":
                return self

            def __exit__(self, *_args: object) -> None:
                # sqlite3.Connection commits here, but does not close the file handle.
                return None

        with TemporaryDirectory() as directory:
            root = Path(directory)
            old_database = root / "JARVIS_VisionVoice_v9_6_0" / "data" / "jarvis.db"
            old_database.parent.mkdir(parents=True)
            old_database.write_bytes(b"placeholder")
            new_directory = root / "JARVIS_VisionVoice_v9_6_1"
            target = new_directory / "data" / "jarvis.db"
            connections: list[FakeConnection] = []

            def fake_connect(*_args: object, **_kwargs: object) -> FakeConnection:
                connection = FakeConnection()
                connections.append(connection)
                return connection

            def windows_like_replace(_source: Path, _target: Path) -> None:
                self.assertTrue(connections)
                self.assertTrue(all(connection.closed for connection in connections))

            with (
                patch.object(app.sqlite3, "connect", side_effect=fake_connect),
                patch.object(app.os, "replace", side_effect=windows_like_replace),
            ):
                imported = app._import_previous_memory_database(
                    target,
                    search_root=root,
                    current_directory=new_directory,
                )

            self.assertEqual(imported, old_database)


if __name__ == "__main__":
    unittest.main()
