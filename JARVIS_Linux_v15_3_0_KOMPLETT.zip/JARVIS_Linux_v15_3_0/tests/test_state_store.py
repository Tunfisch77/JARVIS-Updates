from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from state_store import JarvisStateStore


class StateStoreTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = TemporaryDirectory()
        self.store = JarvisStateStore(Path(self.temp_dir.name) / "jarvis-state.db")

    def tearDown(self) -> None:
        self.temp_dir.cleanup()

    def test_personality_and_permissions_are_persistent(self) -> None:
        self.store.set_setting("personality", {"mode": "focus", "response_length": "short", "humor": 0})
        self.store.update_permission("control_home_device", enabled=True, requires_confirmation=False)
        self.assertEqual(self.store.get_setting("personality")["mode"], "focus")
        self.assertFalse(self.store.permission("control_home_device")["requires_confirmation"])

    def test_timer_lifecycle(self) -> None:
        timer = self.store.create_timer("Test", 60)
        self.assertEqual(timer["status"], "active")
        self.assertTrue(self.store.cancel_timer(timer["id"]))
        self.assertEqual(self.store.list_timers(), [])

    def test_simulated_device_can_be_controlled(self) -> None:
        self.store.set_simulation_enabled(True)
        item = self.store.control_simulation_device(
            "light.schreibtisch",
            "light",
            "turn_on",
            {"brightness_pct": 42},
        )
        self.assertIsNotNone(item)
        self.assertEqual(item["state"], "on")
        self.assertEqual(item["attributes"]["brightness_pct"], 42)

    def test_simulation_event_is_recorded(self) -> None:
        event = self.store.add_simulation_event(
            "person",
            "Person an der Tür erkannt",
            entity_id="camera.tuer",
        )
        self.assertEqual(event["event_type"], "person")
        self.assertEqual(len(self.store.list_simulation_events()), 1)


if __name__ == "__main__":
    unittest.main()
