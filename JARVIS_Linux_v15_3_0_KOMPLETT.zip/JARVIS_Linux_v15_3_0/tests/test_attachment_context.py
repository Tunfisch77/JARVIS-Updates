from pathlib import Path
import unittest

import app


class AttachmentContextTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.html = (Path(__file__).resolve().parents[1] / "static" / "index.html").read_text(encoding="utf-8")

    def test_feature_version_is_9_7_2(self) -> None:
        self.assertEqual(app.APP_VERSION, "15.3.0")
        self.assertIn("PC AGENT OS v15.3.0", self.html)

    def test_ui_restores_one_continuous_timeline_without_resume_prompt(self) -> None:
        restore = self.html.split("async function restoreHistory", 1)[1].split("async function clearChat", 1)[0]
        self.assertIn('"/history?limit=200"', restore)
        self.assertNotIn("Gesprächsverlauf wiederhergestellt", restore)
        self.assertNotIn("um ein neues Gespräch zu starten", self.html)

    def test_full_attachment_answer_is_added_to_realtime_context(self) -> None:
        self.assertIn("function buildAttachmentAnalysisContext", self.html)
        self.assertIn('kind: "attachment_analysis_result"', self.html)
        self.assertIn("original_question:", self.html)
        self.assertIn("answer: String(analysis?.answer", self.html)
        self.assertIn("createQuestionItem(contextText, null)", self.html)
        self.assertIn("nicht vertrauenswürdige Dateiinhalte", self.html)

    def test_context_is_injected_before_voice_confirmation(self) -> None:
        block = self.html.split("async function submitAttachmentQuestion", 1)[1]
        block = block.split("async function submitActivatedQuestion", 1)[0]
        remember = block.index("rememberAttachmentAnalysis(text, filenames, contextAnswer)")
        inject = block.index("injectLatestAttachmentAnalysisContext({ force: true })")
        response = block.index('sendEvent({ type: "response.create" })')
        self.assertLess(remember, inject)
        self.assertLess(inject, response)

    def test_latest_context_is_restored_after_reconnect(self) -> None:
        open_handler = self.html.split('dc.addEventListener("open", () => {', 1)[1]
        open_handler = open_handler.split('dc.addEventListener("message"', 1)[0]
        self.assertIn("injectLatestAttachmentAnalysisContext()", open_handler)
        self.assertIn("attachmentContextInjectedForChannel = false", self.html)

    def test_generated_files_are_rendered_as_downloads(self) -> None:
        self.assertIn("function addGeneratedFileDownloads", self.html)
        self.assertIn("result?.generated_files", self.html)
        self.assertIn("Alle Dateien als ZIP", self.html)
        self.assertIn("addGeneratedFileDownloads(result)", self.html)

    def test_zip_is_available_in_file_picker(self) -> None:
        self.assertIn('accept=".zip,', self.html)
        self.assertIn('"zip", "gif", "jpg"', self.html)


if __name__ == "__main__":
    unittest.main()
