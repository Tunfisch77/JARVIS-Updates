from __future__ import annotations

import asyncio
import inspect
import unittest
from pathlib import Path
from unittest.mock import patch

import app


ROOT = Path(__file__).resolve().parents[1]


class V1210OneShotBackendTests(unittest.TestCase):
    def test_exact_screenshot_email_request_is_complete_in_one_turn(self) -> None:
        route = app._v12_fallback_communication_route(
            "Kannst du eine E-Mail an guliyev.tuncay2006@gmail.com schreiben? "
            "Frag ihn, wie das Wetter so in Villach ist."
        )

        self.assertIsNotNone(route)
        self.assertEqual(route["kind"], "action")
        self.assertEqual(route["tool"], "send_email")
        self.assertFalse(route["needs_clarification"])
        arguments = route["arguments"]
        self.assertEqual(arguments["target"], "guliyev.tuncay2006@gmail.com")
        self.assertEqual(arguments["subject"], "Wetter in Villach")
        self.assertIn("Wie ist das Wetter in Villach?", arguments["message"])
        self.assertEqual(arguments["account"], "auto")

    def test_missing_email_subject_is_derived_instead_of_asked(self) -> None:
        route = {
            "kind": "clarify",
            "tool": "send_email",
            "arguments": {
                "target": "test@example.com",
                "subject": "",
                "message": "Hallo, danke für die Einladung.",
                "account": "auto",
            },
            "needs_clarification": True,
            "question": "Welchen Betreff soll ich verwenden?",
            "confidence": 0.8,
        }

        with patch.object(app, "_v12_fallback_communication_route", return_value=None):
            normalized = app._normalize_v12_communication_route("Schreib die Mail.", route)

        self.assertEqual(normalized["kind"], "action")
        self.assertFalse(normalized["needs_clarification"])
        self.assertTrue(normalized["arguments"]["subject"])

    def test_fallback_overrides_conversation_route_when_planner_is_unavailable(self) -> None:
        packet = {
            "route": {
                "kind": "conversation",
                "confidence": 0.86,
                "planner_required": False,
                "tool": "",
                "arguments": {},
                "needs_clarification": False,
                "question": "",
            },
            "context": "",
            "entities": [],
            "active_project": None,
            "memory_count": 0,
            "history_count": 0,
        }
        query = (
            "Kannst du eine E-Mail an guliyev.tuncay2006@gmail.com schreiben? "
            "Frag ihn, wie das Wetter so in Villach ist."
        )

        with (
            patch.object(app.v12_context_engine, "resolve", return_value=packet),
            patch.object(app.state_store, "add_audit"),
            patch.object(app, "OPENAI_API_KEY", ""),
        ):
            result = asyncio.run(app._orchestrate_v12_turn(query))

        self.assertEqual(result["route"]["kind"], "action")
        self.assertEqual(result["route"]["tool"], "send_email")
        self.assertFalse(result["route"]["needs_clarification"])

    def test_whatsapp_semantic_instruction_is_already_content(self) -> None:
        route = {
            "kind": "action",
            "tool": "send_whatsapp_message",
            "arguments": {
                "target": "Ella",
                "message": "Ich komme zehn Minuten später.",
                "target_kind": "contact",
            },
            "needs_clarification": False,
            "question": "",
            "confidence": 0.98,
        }

        with patch.object(app, "_v12_fallback_communication_route", return_value=None):
            normalized = app._normalize_v12_communication_route(
                "Schreib Ella auf WhatsApp, dass ich zehn Minuten später komme.",
                route,
            )

        self.assertEqual(normalized["kind"], "action")
        self.assertEqual(normalized["arguments"]["message"], "Ich komme zehn Minuten später.")
        self.assertFalse(normalized["needs_clarification"])

    def test_planner_contract_explicitly_forbids_reasking_known_fields(self) -> None:
        source = inspect.getsource(app._run_v12_planner_once)
        self.assertIn("semantische Formulierungsanweisung", source)
        self.assertIn("du darfst nicht noch einmal nach Empfänger, Betreff, Wortlaut oder Freigabe fragen", source)
        self.assertIn("Ein Betreff ist nie ein Rückfragegrund", source)


class V1210OneShotFrontendTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.html = (ROOT / "static" / "index.html").read_text(encoding="utf-8")

    def test_communication_action_executes_before_realtime_summary(self) -> None:
        submit = self.html.split("async function submitActivatedQuestion", 1)[1].split(
            "async function handleTranscript",
            1,
        )[0]
        self.assertIn("isV12DirectCommunication(orchestration)", submit)
        self.assertIn("executeV12CommunicationAction(orchestration", submit)
        self.assertIn("buildV12CommunicationResultContext", submit)
        self.assertLess(
            submit.index("executeV12CommunicationAction(orchestration"),
            submit.index('sendEvent({ type: "response.create" })'),
        )

    def test_direct_executor_is_idempotent_and_uses_real_endpoints(self) -> None:
        executor = self.html.split("async function executeV12CommunicationAction", 1)[1].split(
            "function buildV12CommunicationResultContext",
            1,
        )[0]
        self.assertIn('endpoint = "/integrations/email/message"', executor)
        self.assertIn('endpoint = "/integrations/whatsapp/message"', executor)
        self.assertIn('"Idempotency-Key": idempotencyKey', executor)
        self.assertIn("ensureToolPermission(toolName, payload, true)", executor)


if __name__ == "__main__":
    unittest.main()
