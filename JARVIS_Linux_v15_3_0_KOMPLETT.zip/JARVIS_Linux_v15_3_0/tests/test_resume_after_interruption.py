from pathlib import Path
import unittest


class ResumeAfterInterruptionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        root = Path(__file__).resolve().parents[1]
        cls.html = (root / "static" / "index.html").read_text(encoding="utf-8")
        cls.app_source = (root / "app.py").read_text(encoding="utf-8")

    def test_pause_stops_audio_and_saves_resume_point(self) -> None:
        interrupt = self.html.split("function interruptJarvis", 1)[1]
        interrupt = interrupt.split("function pauseActiveAnswer", 1)[0]
        self.assertIn("rememberForResume", interrupt)
        self.assertIn("interruptedAnswerAvailable = true", interrupt)
        self.assertIn('type: "output_audio_buffer.clear"', interrupt)

        pause = self.html.split("function pauseActiveAnswer", 1)[1]
        pause = pause.split("function deactivateAssistant", 1)[0]
        self.assertIn("interruptJarvis({ rememberForResume: true })", pause)
        self.assertIn("RESUME POINT SAVED", pause)
        self.assertNotIn('type: "response.create"', pause)

    def test_continue_uses_explicit_resume_request(self) -> None:
        submit = self.html.split("async function submitActivatedQuestion", 1)[1]
        submit = submit.split("async function handleTranscript", 1)[0]
        self.assertIn("isContinuationPhrase(text)", submit)
        self.assertIn("buildContinuationRequest()", submit)
        self.assertIn("interruptedAnswerAvailable = false", submit)
        self.assertIn("RESUMING ANSWER", submit)

    def test_common_german_pause_and_continue_phrases_are_supported(self) -> None:
        self.assertIn("function isPausePhrase", self.html)
        self.assertIn("function isContinuationPhrase", self.html)
        for phrase in ("stopp", "warte kurz", "pause", "weiter", "mach", "erzahl", "fahr"):
            self.assertIn(phrase, self.html)

    def test_realtime_prompt_requires_continuation_without_recap(self) -> None:
        self.assertIn("zuletzt unterbrochene inhaltliche Antwort", self.app_source)
        self.assertIn("Wiederhole keinen bereits gehörten Abschnitt", self.app_source)


if __name__ == "__main__":
    unittest.main()
