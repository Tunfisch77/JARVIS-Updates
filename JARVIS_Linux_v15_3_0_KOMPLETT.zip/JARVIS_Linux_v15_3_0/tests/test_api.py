from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, patch

from fastapi.testclient import TestClient

import app
from state_store import JarvisStateStore


class ApiTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary_directory = tempfile.TemporaryDirectory()
        self.state_store = JarvisStateStore(Path(self.temporary_directory.name) / "jarvis.db")
        self.state_patch = patch.object(app, "state_store", self.state_store)
        self.state_patch.start()
        app.web_search_attempts.clear()
        app.attachment_analysis_attempts.clear()
        self.client = TestClient(app.app)

    def tearDown(self) -> None:
        self.client.close()
        self.state_patch.stop()
        self.temporary_directory.cleanup()

    def test_simulation_and_confirmation_flow(self) -> None:
        response = self.client.put("/simulation/mode", json={"enabled": True})
        self.assertEqual(response.status_code, 200)

        entities = self.client.get("/home-assistant/entities")
        self.assertEqual(entities.status_code, 200)
        self.assertEqual(entities.json()["mode"], "simulation")

        payload = {
            "domain": "light",
            "service": "turn_on",
            "entity_id": "light.schreibtisch",
            "data": {},
        }
        self.assertEqual(self.client.post("/home-assistant/service", json=payload).status_code, 428)
        controlled = self.client.post(
            "/home-assistant/service",
            json=payload,
            headers={"X-Jarvis-Confirmed": "true"},
        )
        self.assertEqual(controlled.status_code, 200)
        state = self.client.get("/home-assistant/state/light.schreibtisch").json()["item"]
        self.assertEqual(state["state"], "on")

    def test_timer_requires_confirmation_before_cancel(self) -> None:
        created = self.client.post("/timers", json={"label": "Test", "seconds": 30})
        self.assertEqual(created.status_code, 200)
        timer_id = created.json()["item"]["id"]
        self.assertEqual(self.client.delete(f"/timers/{timer_id}").status_code, 428)
        self.assertEqual(
            self.client.delete(
                f"/timers/{timer_id}",
                headers={"X-Jarvis-Confirmed": "true"},
            ).status_code,
            200,
        )

    def test_web_search_uses_backend_and_returns_sources(self) -> None:
        result = {
            "answer": "Eine aktuelle Antwort.",
            "sources": [{"title": "Beispiel", "url": "https://example.com/news"}],
            "model": "test-model",
            "usage": {},
        }
        with (
            patch.object(app, "OPENAI_API_KEY", "test-key"),
            patch.object(app, "_run_openai_web_search", new=AsyncMock(return_value=result)) as search,
        ):
            response = self.client.post(
                "/web/search",
                json={"query": "Was ist heute passiert?", "max_sources": 4},
            )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["sources"][0]["title"], "Beispiel")
        search.assert_awaited_once_with("Was ist heute passiert?", 4, model=app.WEB_SEARCH_MODEL_CANDIDATES[0])

    def test_disabled_web_search_is_blocked(self) -> None:
        self.state_store.update_permission("search_web", enabled=False, requires_confirmation=False)
        with patch.object(app, "OPENAI_API_KEY", "test-key"):
            response = self.client.post("/web/search", json={"query": "Aktuelle Nachrichten"})
        self.assertEqual(response.status_code, 403)

    def test_web_search_can_require_confirmation(self) -> None:
        self.state_store.update_permission("search_web", enabled=True, requires_confirmation=True)
        result = {"answer": "Antwort", "sources": [], "model": "test", "usage": {}}
        with (
            patch.object(app, "OPENAI_API_KEY", "test-key"),
            patch.object(app, "_run_openai_web_search", new=AsyncMock(return_value=result)),
        ):
            blocked = self.client.post("/web/search", json={"query": "Aktuelle Nachrichten"})
            allowed = self.client.post(
                "/web/search",
                json={"query": "Aktuelle Nachrichten"},
                headers={"X-Jarvis-Confirmed": "true"},
            )
        self.assertEqual(blocked.status_code, 428)
        self.assertEqual(allowed.status_code, 200)

    def test_web_search_rate_limit(self) -> None:
        result = {"answer": "Antwort", "sources": [], "model": "test", "usage": {}}
        with (
            patch.object(app, "OPENAI_API_KEY", "test-key"),
            patch.object(app, "_run_openai_web_search", new=AsyncMock(return_value=result)),
        ):
            responses = [
                self.client.post("/web/search", json={"query": f"Aktuelle Nachricht {index}"})
                for index in range(app.WEB_SEARCH_RATE_LIMIT + 1)
            ]
        self.assertTrue(all(response.status_code == 200 for response in responses[:-1]))
        self.assertEqual(responses[-1].status_code, 429)

    def test_attachment_analysis_accepts_code_file(self) -> None:
        result = {"answer": "```python\nprint('fixed')\n```", "model": "test", "usage": {}}
        with (
            patch.object(app, "OPENAI_API_KEY", "test-key"),
            patch.object(app, "_run_openai_attachment_analysis", new=AsyncMock(return_value=result)) as analysis,
        ):
            response = self.client.post(
                "/attachments/analyze",
                data={"question": "Verbessere den Code", "image_detail": "low"},
                files={"files": ("main.py", b"print('hello')", "text/x-python")},
            )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["attachments"][0]["name"], "main.py")
        question, content = analysis.await_args.args
        self.assertEqual(question, "Verbessere den Code")
        self.assertEqual(content[0]["type"], "input_file")
        self.assertEqual(content[0]["filename"], "main.py")
        self.assertTrue(str(content[0]["file_data"]).startswith("data:text/x-python;base64,"))

    def test_attachment_analysis_rejects_executables(self) -> None:
        with patch.object(app, "OPENAI_API_KEY", "test-key"):
            response = self.client.post(
                "/attachments/analyze",
                data={"question": "Analysieren"},
                files={"files": ("programm.exe", b"MZfake", "application/octet-stream")},
            )
        self.assertEqual(response.status_code, 415)

    def test_attachment_analysis_rejects_fake_image(self) -> None:
        with patch.object(app, "OPENAI_API_KEY", "test-key"):
            response = self.client.post(
                "/attachments/analyze",
                data={"question": "Was ist darauf?"},
                files={"files": ("foto.png", b"not-a-png", "image/png")},
            )
        self.assertEqual(response.status_code, 400)


if __name__ == "__main__":
    unittest.main()
