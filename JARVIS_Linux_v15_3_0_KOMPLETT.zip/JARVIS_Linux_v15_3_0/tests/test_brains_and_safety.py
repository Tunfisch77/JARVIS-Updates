from __future__ import annotations

import io
import tempfile
import unittest
import warnings
import zipfile
from pathlib import Path
from unittest.mock import patch

from fastapi import HTTPException
from fastapi.testclient import TestClient

import app
from bundle_store import GeneratedBundleStore
from memory_store import MemoryStore
from state_store import JarvisStateStore


class BrainsAndSafetyApiTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary_directory = tempfile.TemporaryDirectory()
        database = Path(self.temporary_directory.name) / "jarvis.db"
        self.memory_store = MemoryStore(database)
        self.state_store = JarvisStateStore(database)
        self.memory_patch = patch.object(app, "memory_store", self.memory_store)
        self.state_patch = patch.object(app, "state_store", self.state_store)
        self.memory_patch.start()
        self.state_patch.start()
        self.client = TestClient(app.app)

    def tearDown(self) -> None:
        self.client.close()
        self.state_patch.stop()
        self.memory_patch.stop()
        self.temporary_directory.cleanup()

    def test_public_health_contains_no_configuration_details(self) -> None:
        self.assertEqual(self.client.get("/health").json(), {"ok": True})

    def test_remote_routes_require_lan_mode_and_bearer_token(self) -> None:
        with (
            patch.object(app, "_is_loopback_host", return_value=False),
            patch.object(app, "JARVIS_ALLOW_LAN", False),
        ):
            self.assertEqual(self.client.get("/diagnostics").status_code, 403)

        with (
            patch.object(app, "_is_loopback_host", return_value=False),
            patch.object(app, "JARVIS_ALLOW_LAN", True),
            patch.object(app, "JARVIS_ACCESS_TOKEN", "secret-test-token"),
        ):
            self.assertEqual(self.client.get("/diagnostics").status_code, 401)
            response = self.client.get(
                "/diagnostics",
                headers={"Authorization": "Bearer secret-test-token"},
            )
            self.assertEqual(response.status_code, 200)

    def test_relevant_memory_and_intent_are_returned_together(self) -> None:
        self.memory_store.add_memory("Mein JARVIS-Projekt verwendet FastAPI.", importance=5)
        self.memory_store.add_history("user", "Wir haben gestern am Upload gearbeitet.")
        response = self.client.get("/context/recall", params={"query": "Wie geht es beim JARVIS Upload weiter?"})
        self.assertEqual(response.status_code, 200)
        body = response.json()
        self.assertGreaterEqual(body["memory_count"], 1)
        self.assertIn("JARVIS-Projekt", body["context"])
        self.assertIn("name", body["intent"])

    def test_ambiguous_modifying_intent_must_clarify(self) -> None:
        intent = app.infer_user_intent("Mach das dort aus", [{"role": "user", "content": "Licht"}])
        self.assertEqual(intent["name"], "ambiguous_action")
        self.assertTrue(intent["must_clarify"])

    def test_old_continue_project_suggestion_is_retired(self) -> None:
        self.state_store.upsert_suggestion(
            "continue-project-42",
            title="Am letzten Projekt weiterarbeiten",
            prompt="Weitermachen?",
            reason="Alt",
        )
        recreated = JarvisStateStore(self.state_store.database_path)
        active = recreated.list_suggestions(limit=10, min_interval_minutes=5)
        self.assertFalse(any(item["suggestion_key"] == "continue-project-42" for item in active))

    def test_confirmation_is_bound_and_single_use_and_action_is_idempotent(self) -> None:
        payload = {
            "domain": "light",
            "service": "turn_on",
            "entity_id": "light.schreibtisch",
            "data": {},
        }
        issued = self.client.post(
            "/confirmations",
            json={"tool_name": "control_home_device", "payload": payload},
        )
        self.assertEqual(issued.status_code, 200)
        token = issued.json()["token"]
        headers = {"X-Jarvis-Confirmation": token, "Idempotency-Key": "light-test-action-1"}
        first = self.client.post("/home-assistant/service", json=payload, headers=headers)
        self.assertEqual(first.status_code, 200)
        replay = self.client.post(
            "/home-assistant/service",
            json=payload,
            headers={"Idempotency-Key": "light-test-action-1"},
        )
        self.assertEqual(replay.status_code, 200)
        self.assertTrue(replay.json()["idempotent_replay"])
        consumed = self.client.post(
            "/home-assistant/service",
            json=payload,
            headers={"X-Jarvis-Confirmation": token, "Idempotency-Key": "light-test-action-2"},
        )
        self.assertEqual(consumed.status_code, 428)

    def test_quiet_time_hides_proactive_suggestions(self) -> None:
        with patch.object(app, "_is_quiet_time", return_value=True):
            response = self.client.get("/suggestions")
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["quiet"])
        self.assertEqual(response.json()["items"], [])


class GeneratedOutputSafetyTests(unittest.TestCase):
    def test_generated_zip_rejects_nested_archives(self) -> None:
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w") as archive:
            archive.writestr("project/nested.zip", b"PK\x03\x04")
        with self.assertRaises(HTTPException):
            app._validate_generated_zip(buffer.getvalue())

    def test_generated_zip_rejects_duplicate_paths(self) -> None:
        buffer = io.BytesIO()
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            with zipfile.ZipFile(buffer, "w") as archive:
                archive.writestr("project/main.py", b"one")
                archive.writestr("PROJECT/Main.py", b"two")
        with self.assertRaises(HTTPException):
            app._validate_generated_zip(buffer.getvalue())

    def test_generated_bundles_survive_store_recreation(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            store = GeneratedBundleStore(root)
            store.save("persistent_bundle_1234", [{"path": "demo.txt", "data": b"hello"}])
            recreated = GeneratedBundleStore(root)
            item, data = recreated.read_file("persistent_bundle_1234", 0)
            self.assertEqual(item["path"], "demo.txt")
            self.assertEqual(data, b"hello")


if __name__ == "__main__":
    unittest.main()
