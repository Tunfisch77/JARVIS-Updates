from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, patch

from fastapi.testclient import TestClient

import app
from state_store import JarvisStateStore
from v10_core import V10Store


class MessageHistorySearchTests(unittest.TestCase):
    def setUp(self) -> None:
        self.directory = tempfile.TemporaryDirectory()
        database = Path(self.directory.name) / "jarvis.db"
        self.state = JarvisStateStore(database)
        self.messages = V10Store(database)
        self.state_patch = patch.object(app, "state_store", self.state)
        self.message_patch = patch.object(app, "v10_store", self.messages)
        self.state_patch.start()
        self.message_patch.start()
        # These inbox tests model a logged-in, unlocked desktop.
        privacy_patch = patch("v10_core.windows_session_locked", return_value=False)
        privacy_patch.start()
        self.addCleanup(privacy_patch.stop)
        self.client = TestClient(app.app)

    def tearDown(self) -> None:
        self.client.close()
        self.message_patch.stop()
        self.state_patch.stop()
        self.directory.cleanup()

    def test_last_gmail_from_saved_contact_uses_email_and_returns_read_message(self) -> None:
        self.state.save_contact(
            name="Asim Cetin",
            aliases=["Asim"],
            email="asim@example.com",
            preferred_email_account="gmail_private",
        )
        gmail = [
            {
                "source": "gmail",
                "external_id": "gmail-asim-1",
                "sender_name": "Asim Cetin",
                "sender_address": "asim@example.com",
                "conversation": "thread-asim",
                "subject": "Treffen",
                "body": "Wir treffen uns um 18 Uhr.",
                "received_at": "2026-07-27T15:00:00+02:00",
                "unread": False,
            }
        ]
        with patch.object(app.connected_accounts, "list_recent_gmail", return_value=gmail) as recent:
            response = self.client.post(
                "/messages/search",
                json={"sources": ["gmail"], "target": "Asim", "limit": 1},
            )
        self.assertEqual(response.status_code, 200, response.text)
        recent.assert_called_once_with(20, "asim@example.com")
        self.assertEqual(response.json()["items"][0]["body"], "Wir treffen uns um 18 Uhr.")
        self.assertFalse(response.json()["items"][0]["unread"])

    def test_family_group_alias_loads_exact_whatsapp_chat_history(self) -> None:
        self.state.save_whatsapp_group(
            name="Familie",
            aliases=["Familiengruppe"],
            chat_name="Familie Privat 👨‍👩‍👧‍👦",
        )
        whatsapp = [
            {
                "source": "whatsapp",
                "external_id": "wa-family-1",
                "sender_name": "Mama",
                "sender_address": "",
                "conversation": "Familie Privat 👨‍👩‍👧‍👦",
                "subject": "",
                "body": "Essen ist fertig.",
                "received_at": "2026-07-28T09:00:00+02:00",
                "unread": False,
                "metadata": {"is_group": True},
            }
        ]
        with patch.object(
            app.integration_hub,
            "recent_whatsapp_messages",
            new=AsyncMock(return_value=whatsapp),
        ) as recent:
            response = self.client.post(
                "/messages/search",
                json={"sources": ["whatsapp"], "target": "Familiengruppe", "limit": 1},
            )
        self.assertEqual(response.status_code, 200, response.text)
        recent.assert_awaited_once_with("Familiengruppe", 20)
        self.assertEqual(response.json()["items"][0]["body"], "Essen ist fertig.")
        self.assertEqual(response.json()["items"][0]["sender_name"], "Mama")

    def test_store_search_orders_by_received_time_and_includes_read_items(self) -> None:
        self.messages.upsert_message(
            source="gmail",
            external_id="old",
            sender_name="Asim Cetin",
            body="Alt",
            received_at="2026-07-20T10:00:00+02:00",
            unread=False,
        )
        self.messages.upsert_message(
            source="gmail",
            external_id="new",
            sender_name="Asim Cetin",
            body="Neu",
            received_at="2026-07-28T10:00:00+02:00",
            unread=False,
        )
        result = self.messages.search_messages(
            terms=["Asim Cetin"],
            sources=["gmail"],
            limit=1,
        )
        self.assertEqual(result[0]["body"], "Neu")


class V1107UiAndPromptTests(unittest.TestCase):
    def test_tools_and_simplified_contact_editor_are_present(self) -> None:
        root = Path(__file__).resolve().parents[1]
        source = (root / "app.py").read_text(encoding="utf-8")
        html = (root / "static" / "index.html").read_text(encoding="utf-8")
        self.assertIn('"name": "search_messages"', source)
        self.assertIn("Familiengruppe", source)
        self.assertIn("KONTAKT HINZUFÜGEN", html)
        self.assertIn("WEITERE ANGABEN – OPTIONAL", html)
        self.assertIn('id="contactWhatsapp"', html)
        self.assertIn('id="contactEmail"', html)
        self.assertIn('id="whatsappGroupList"', html)
        self.assertIn('["whatsapp", "gmail", "outlook"]', html)


if __name__ == "__main__":
    unittest.main()
