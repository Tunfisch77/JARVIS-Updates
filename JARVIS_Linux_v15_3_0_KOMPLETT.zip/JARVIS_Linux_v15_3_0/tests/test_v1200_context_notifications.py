from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from local_project import LocalProjectManager
from memory_store import MemoryStore
from state_store import JarvisStateStore
from v12_core import V12ContextEngine, V12NotificationStore


ROOT = Path(__file__).resolve().parents[1]


class V12ContextEngineTests(unittest.TestCase):
    def setUp(self) -> None:
        self.directory = tempfile.TemporaryDirectory()
        root = Path(self.directory.name)
        database = root / "jarvis.db"
        self.memory = MemoryStore(database)
        self.state = JarvisStateStore(database)
        self.projects = LocalProjectManager(self.state, root / "backups")
        self.engine = V12ContextEngine(self.memory, self.state, self.projects.active_project)

    def tearDown(self) -> None:
        self.directory.cleanup()

    def test_project_follow_up_is_bound_before_voice_model(self) -> None:
        project = Path(self.directory.name) / "snake"
        project.mkdir()
        (project / "index.html").write_text("<canvas></canvas>\n", encoding="utf-8")
        self.projects.remember_project(str(project))

        packet = self.engine.resolve("Mach es flüssiger und füge einen Neustart-Button ein.")

        self.assertEqual(packet["route"]["kind"], "project_edit")
        self.assertEqual(packet["route"]["tool"], "modify_code_project")
        self.assertEqual(packet["route"]["arguments"]["target_path"], str(project.resolve()))
        self.assertFalse(packet["route"]["planner_required"])

    def test_follow_up_context_contains_recent_turn(self) -> None:
        self.memory.add_history("user", "Wir planen den Familienurlaub in Wien.")
        self.memory.add_history("jarvis", "Ich habe drei Tagespläne vorgeschlagen.")

        packet = self.engine.resolve("Mach damit weiter.")

        self.assertEqual(packet["route"]["kind"], "context_follow_up")
        self.assertIn("Familienurlaub", packet["context"])
        self.assertGreaterEqual(packet["history_count"], 2)

    def test_normal_conversation_does_not_trigger_action_planner(self) -> None:
        packet = self.engine.resolve("Wie geht es dir heute?")
        self.assertEqual(packet["route"]["kind"], "conversation")
        self.assertFalse(packet["route"]["planner_required"])


class V12NotificationStoreTests(unittest.TestCase):
    def setUp(self) -> None:
        self.directory = tempfile.TemporaryDirectory()
        self.store = V12NotificationStore(Path(self.directory.name) / "jarvis.db")

    def tearDown(self) -> None:
        self.directory.cleanup()

    def test_only_selected_person_creates_positive_event(self) -> None:
        self.store.save_rule(source="whatsapp", target="Ella", event_types=["message"])
        self.assertEqual(
            self.store.capture_message(
                {
                    "source": "whatsapp",
                    "external_id": "bob-1",
                    "sender_name": "Bob",
                    "body": "Nicht relevant",
                }
            ),
            0,
        )
        message = {
            "source": "whatsapp",
            "external_id": "ella-1",
            "sender_name": "Ella",
            "body": "Privater Inhalt, der nicht angesagt werden darf.",
        }
        self.assertEqual(self.store.capture_message(message), 1)
        self.assertEqual(self.store.capture_message(message), 0)
        pending = self.store.pending_events()
        self.assertEqual(len(pending), 1)
        self.assertEqual(pending[0]["target"], "Ella")
        self.assertNotIn("Privater Inhalt", str(pending[0]["payload"]))

    def test_no_event_exists_for_missing_message(self) -> None:
        self.store.save_rule(source="gmail", target="Ella")
        self.assertEqual(self.store.pending_events(), [])

    def test_saved_group_alias_matches_exact_chat_name(self) -> None:
        self.store.save_rule(
            source="whatsapp",
            target="Familiengruppe",
            target_kind="group",
            match_values=["Familie Privat"],
        )
        created = self.store.capture_message(
            {
                "source": "whatsapp",
                "external_id": "family-1",
                "sender_name": "Mama",
                "conversation": "Familie Privat",
            }
        )
        self.assertEqual(created, 1)
        self.assertEqual(self.store.pending_events()[0]["target"], "Familiengruppe")

    def test_snapchat_first_observation_is_baseline_then_new_transition_emits(self) -> None:
        rule = self.store.save_rule(
            source="snapchat",
            target="Ella",
            event_types=["snap"],
        )
        rule_id = int(rule["id"])
        self.assertFalse(
            self.store.capture_presence(
                rule_id=rule_id,
                unread=True,
                fingerprint="initial",
                event_type="snap",
            )
        )
        self.assertFalse(
            self.store.capture_presence(
                rule_id=rule_id,
                unread=False,
                fingerprint="",
                event_type="snap",
            )
        )
        self.assertTrue(
            self.store.capture_presence(
                rule_id=rule_id,
                unread=True,
                fingerprint="new-snap",
                event_type="snap",
            )
        )
        event = self.store.pending_events()[0]
        self.assertEqual(event["source"], "snapchat")
        self.assertEqual(event["event_type"], "snap")
        self.assertEqual(event["payload"], {})

    def test_announced_events_leave_pending_queue(self) -> None:
        self.store.save_rule(source="outlook", target="Ella")
        self.store.capture_message(
            {
                "source": "outlook",
                "external_id": "mail-1",
                "sender_name": "Ella",
            }
        )
        event_id = int(self.store.pending_events()[0]["id"])
        self.assertEqual(self.store.mark_announced([event_id]), 1)
        self.assertEqual(self.store.pending_events(), [])


class V12FrontendContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.html = (ROOT / "static" / "index.html").read_text(encoding="utf-8")

    def test_app_picker_and_person_rule_controls_exist(self) -> None:
        self.assertIn('id="notificationAppList"', self.html)
        self.assertIn('id="notificationRuleSource"', self.html)
        self.assertIn('id="notificationRuleTarget"', self.html)
        self.assertIn('value="snapchat"', self.html)

    def test_old_unfiltered_announcement_path_is_not_used(self) -> None:
        self.assertNotIn('requestJson("/messages/announced"', self.html)
        self.assertIn('requestJson("/v12/notifications/pending', self.html)
        self.assertIn('requestJson("/v12/notifications/announced"', self.html)

    def test_notification_waits_for_response_audio_and_user(self) -> None:
        ready = self.html.split("function notificationDispatchReady()", 1)[1].split(
            "async function maybeDispatchPendingNotifications", 1
        )[0]
        self.assertIn("!responseInProgress", ready)
        self.assertIn("activeAudioResponses.size === 0", ready)
        self.assertIn("!delegateInProgress", ready)
        self.assertIn("!userSpeechActive", ready)
        self.assertIn("!pendingAutomaticContinuation", ready)

    def test_project_follow_up_executes_verified_endpoint_directly(self) -> None:
        submit = self.html.split("async function submitActivatedQuestion", 1)[1].split(
            "async function handleTranscript", 1
        )[0]
        self.assertIn('orchestration?.route?.kind === "project_edit"', submit)
        self.assertIn("executeV12ProjectEdit", submit)
        self.assertIn('requestJson("/v11/projects/edit"', self.html)


if __name__ == "__main__":
    unittest.main()
