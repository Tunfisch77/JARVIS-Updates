from __future__ import annotations

import os
from pathlib import Path
import unittest
from unittest.mock import call, patch

from integration_hub import IntegrationConfig, IntegrationHub


class WhatsAppNativeDesktopTests(unittest.TestCase):
    def setUp(self) -> None:
        self.hub = IntegrationHub(
            lambda: [],
            IntegrationConfig(whatsapp_mode="desktop", whatsapp_desktop_auto_send=True),
        )

    def test_contact_uses_whatsapp_uri_and_native_enter(self) -> None:
        with (
            patch.object(os, "name", "nt"),
            patch.object(os, "startfile", create=True) as startfile,
            patch.object(self.hub, "_windows_focus_whatsapp") as focus,
            patch.object(self.hub, "_windows_key_combo") as key_combo,
            patch("integration_hub.time.sleep"),
        ):
            self.hub._send_whatsapp_desktop(
                "contact",
                "436761234567",
                "Sista",
                "Test 123",
            )

        startfile.assert_called_once_with("whatsapp://send?phone=436761234567&text=Test%20123")
        focus.assert_called_once_with(25.0)
        key_combo.assert_called_once_with(0x0D)

    def test_group_search_uses_native_clipboard_and_restores_it(self) -> None:
        with (
            patch.object(os, "name", "nt"),
            patch.object(os, "startfile", create=True) as startfile,
            patch.object(self.hub, "_windows_focus_whatsapp"),
            patch.object(self.hub, "_windows_clipboard_text", return_value="vorher"),
            patch.object(self.hub, "_windows_set_clipboard_text") as set_clipboard,
            patch.object(self.hub, "_windows_key_combo") as key_combo,
            patch("integration_hub.time.sleep"),
        ):
            self.hub._send_whatsapp_desktop(
                "group",
                "Familie",
                "Familie",
                "Bin später da",
            )

        startfile.assert_called_once_with("whatsapp:")
        self.assertEqual(
            key_combo.call_args_list,
            [call(0x11, 0x4E), call(0x11, 0x56), call(0x0D), call(0x11, 0x56), call(0x0D)],
        )
        self.assertEqual(
            set_clipboard.call_args_list,
            [call("Familie"), call("Bin später da"), call("vorher")],
        )

    def test_desktop_control_has_no_optional_python_dependency(self) -> None:
        root = Path(__file__).resolve().parents[1]
        requirements = (root / "requirements.txt").read_text(encoding="utf-8").casefold()
        source = (root / "integration_hub.py").read_text(encoding="utf-8").casefold()
        self.assertNotIn("pywinauto", requirements)
        self.assertNotIn("pyperclip", requirements)
        self.assertNotIn("from pywinauto", source)
        self.assertNotIn("import pyperclip", source)


if __name__ == "__main__":
    unittest.main()
