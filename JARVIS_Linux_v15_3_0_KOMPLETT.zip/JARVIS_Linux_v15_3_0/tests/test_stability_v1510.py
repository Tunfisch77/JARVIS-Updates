import asyncio, hashlib, json, tempfile, unittest, zipfile
from pathlib import Path
from unittest.mock import patch
import jarvis_updater as u
import app
from stability_manager import SafeModeGuard
from starlette.requests import Request

class UpdateTests(unittest.TestCase):
    def fixture(self, root):
        dest=root/'app'; dest.mkdir()
        (dest/'module.py').write_text('old'); (dest/'.env').write_text('private')
        z=root/'update.zip'
        with zipfile.ZipFile(z,'w') as a:
            a.writestr('module.py','new'); a.writestr('new.py','new')
        m=root/'manifest.json'
        m.write_text(json.dumps(dict(format='jarvis-update-v1',platform='linux',version='99.0.0',package=z.name,sha256=hashlib.sha256(z.read_bytes()).hexdigest())))
        return dest,m
    def test_marker_failure_rolls_back(self):
        with tempfile.TemporaryDirectory() as tmp:
            d,m=self.fixture(Path(tmp)); original=u.os.replace
            def replace(src,dst):
                if Path(dst).name=='.installed_version': raise PermissionError('locked')
                return original(src,dst)
            with patch.object(u.os,'replace',side_effect=replace):
                with self.assertRaises(u.UpdateError): u.install_update(d,str(m))
            self.assertEqual((d/'module.py').read_text(),'old')
            self.assertEqual((d/'.env').read_text(),'private')
            self.assertFalse((d/'new.py').exists())
            self.assertFalse((d/'.installed_version').exists())
            self.assertFalse(list(d.rglob('*.update-new')))
            self.assertFalse((d/'.update.lock').exists())
    def test_concurrent_update_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            d,m=self.fixture(Path(tmp)); (d/'.update.lock').write_text('busy')
            with self.assertRaisesRegex(u.UpdateError,'bereits'): u.install_update(d,str(m))
            self.assertEqual((d/'module.py').read_text(),'old')
            self.assertTrue((d/'.update.lock').exists())
    def test_windows_paths(self):
        for names in [['..\\escape.py'],['C:/escape.py'],['module.py:payload'],['DATA/secret'],['NUL.txt'],['a./x'],['A.py','a.py']]:
            with self.subTest(names=names), tempfile.TemporaryDirectory() as tmp:
                z=Path(tmp)/'x.zip'
                with zipfile.ZipFile(z,'w') as a:
                    for n in names: a.writestr(n,'bad')
                with zipfile.ZipFile(z) as a:
                    with self.assertRaises(u.UpdateError): u._safe_members(a)
    def test_empty_config_fallback(self):
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp); (d/'update_config.json').write_text('{"manifest_url":""}')
            with patch.dict(u.os.environ,{'JARVIS_UPDATE_MANIFEST_URL':''}):
                self.assertEqual(u.configured_manifest(d),u.DEFAULT_MANIFEST_URL)
    def test_success_and_repeat(self):
        with tempfile.TemporaryDirectory() as tmp:
            d,m=self.fixture(Path(tmp))
            self.assertTrue(u.install_update(d,str(m))['updated'])
            self.assertFalse(u.install_update(d,str(m))['updated'])
            self.assertEqual((d/'.env').read_text(),'private')

class RecoveryTests(unittest.IsolatedAsyncioTestCase):
    async def test_workers_restart_once(self):
        with tempfile.TemporaryDirectory() as tmp:
            guard=SafeModeGuard(Path(tmp)/'marker'); guard.active=True
            async def worker(): await asyncio.Event().wait()
            with patch.object(app,'safe_mode_guard',guard), patch.object(app,'job_worker_task',None), patch.object(app,'message_worker_task',None), patch.object(app,'message_refresh_lock',None), patch.object(app,'_request_confirmation_valid',return_value=True), patch.object(app,'_require_tool_permission'), patch.object(app.state_store,'add_audit'), patch.object(app,'_background_job_worker',side_effect=worker), patch.object(app,'_background_message_worker',side_effect=worker):
                r=await app.clear_safe_mode(Request({'type':'http','headers':[]}))
                tasks=(app.job_worker_task,app.message_worker_task)
                try:
                    self.assertTrue(r['reconnect_required'])
                    self.assertTrue(all(t and not t.done() for t in tasks))
                    await app.clear_safe_mode(Request({'type':'http','headers':[]}))
                    self.assertEqual(tasks,(app.job_worker_task,app.message_worker_task))
                finally:
                    for t in tasks: t.cancel()
                    await asyncio.gather(*tasks,return_exceptions=True)
    async def test_actions_serialized(self):
        active=0; peak=0
        async def operation(**kwargs):
            nonlocal active,peak
            active+=1; peak=max(peak,active)
            await asyncio.sleep(.01); active-=1
            return {'ok':True}
        with patch.object(app,'integration_action_lock',asyncio.Lock()), patch.object(app,'_confirmed_integration_action_serialized',side_effect=operation):
            await asyncio.gather(*(app._confirmed_integration_action() for _ in range(4)))
        self.assertEqual(peak,1)

class DesktopShutdownTests(unittest.TestCase):
    def test_windows_shutdown_uses_graceful_signal(self):
        import desktop_shell as shell
        from unittest.mock import Mock
        process=Mock(); process.poll.return_value=None
        with patch.object(shell.os,'name','nt'), patch.object(shell.signal,'CTRL_BREAK_EVENT',21,create=True):
            shell.stop_server(process)
        process.send_signal.assert_called_once_with(21)
        process.terminate.assert_not_called()
        process.kill.assert_not_called()
        process.wait.assert_called_once_with(timeout=12)
    def test_hung_server_gets_reaped(self):
        import desktop_shell as shell
        from unittest.mock import Mock
        process=Mock(); process.poll.return_value=None
        process.wait.side_effect=[shell.subprocess.TimeoutExpired('server',12),0]
        with patch.object(shell.os,'name','posix'): shell.stop_server(process)
        process.kill.assert_called_once()
        self.assertEqual(process.wait.call_count,2)
