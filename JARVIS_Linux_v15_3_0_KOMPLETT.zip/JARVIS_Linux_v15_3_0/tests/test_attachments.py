from __future__ import annotations

import base64
import unittest

from app import build_attachment_input


class AttachmentTests(unittest.TestCase):
    def test_builds_image_input_without_persisting_file(self) -> None:
        png = b"\x89PNG\r\n\x1a\n" + b"test-image"
        part, metadata = build_attachment_input(
            filename="foto.png",
            data=png,
            image_detail="high",
        )
        self.assertEqual(part["type"], "input_image")
        self.assertEqual(part["detail"], "high")
        encoded = str(part["image_url"]).split(",", 1)[1]
        self.assertEqual(base64.b64decode(encoded), png)
        self.assertEqual(metadata["kind"], "image")

    def test_builds_pdf_file_input(self) -> None:
        pdf = b"%PDF-1.7\nexample"
        part, metadata = build_attachment_input(
            filename="aufgabe.pdf",
            data=pdf,
            image_detail="low",
        )
        self.assertEqual(part["type"], "input_file")
        self.assertEqual(part["filename"], "aufgabe.pdf")
        self.assertEqual(part["detail"], "low")
        self.assertEqual(metadata["mime_type"], "application/pdf")


if __name__ == "__main__":
    unittest.main()
