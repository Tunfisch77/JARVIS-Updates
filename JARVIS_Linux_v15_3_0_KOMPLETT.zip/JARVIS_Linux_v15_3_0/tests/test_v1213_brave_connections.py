from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import browser_runtime
import integrations_setup


BASE_DIR = Path(__file__).resolve().parents[1]
CONNECTION_BATCH_FILES = (
    "GMAIL_VERBINDEN.bat",
    "OUTLOOK_VERBINDEN.bat",
    "SNAPCHAT_VERBINDEN.bat",
    "WHATSAPP_VERBINDEN.bat",
)


class BraveConnectionTests(unittest.TestCase):
    def test_every_connection_batch_explicitly_forces_brave(self) -> None:
        for filename in CONNECTION_BATCH_FILES:
            script = (BASE_DIR / filename).read_text(encoding="utf-8")
            self.assertIn('set "JARVIS_BROWSER_CHANNEL=brave"', script, filename)
            self.assertIn("--browser brave", script, filename)
            self.assertNotIn("--browser msedge", script.casefold(), filename)

    def test_every_connection_batch_repairs_missing_core_modules(self) -> None:
        for filename in CONNECTION_BATCH_FILES:
            script = (BASE_DIR / filename).read_text(encoding="utf-8")
            self.assertIn("import dotenv, playwright, google_auth_oauthlib, msal", script, filename)
            self.assertIn("-m pip install -r requirements.txt", script, filename)

    def test_brave_is_registered_for_oauth_browser_opening(self) -> None:
        executable = Path("C:/Program Files/BraveSoftware/Brave-Browser/Application/brave.exe")
        controller = object()
        with (
            patch("browser_runtime.brave_executable_path", return_value=executable),
            patch("browser_runtime.webbrowser.BackgroundBrowser", return_value=controller),
            patch("browser_runtime.webbrowser.register") as register,
        ):
            browser_runtime.prefer_external_browser("brave")
        register.assert_called_once_with("jarvis-brave", None, controller, preferred=True)

    def test_explicit_brave_never_silently_uses_edge_when_missing(self) -> None:
        with patch("browser_runtime.brave_executable_path", return_value=None):
            with self.assertRaisesRegex(RuntimeError, "Brave wurde nicht gefunden"):
                browser_runtime.prefer_external_browser("brave")

    def test_cli_browser_argument_overrides_existing_edge_environment(self) -> None:
        class FakeAccounts:
            @staticmethod
            def redacted_configuration() -> str:
                return "ok"

        with (
            patch.dict(os.environ, {"JARVIS_BROWSER_CHANNEL": "msedge"}, clear=False),
            patch("integrations_setup._accounts", return_value=FakeAccounts()),
            patch("integrations_setup.load_dotenv"),
            patch("integrations_setup.print"),
            patch("integrations_setup.argparse.ArgumentParser.parse_args") as parse_args,
        ):
            parse_args.return_value = type(
                "Arguments",
                (),
                {"service": "status", "browser": "brave"},
            )()
            integrations_setup.main()
            self.assertEqual(os.environ["JARVIS_BROWSER_CHANNEL"], "brave")

    def test_linux_release_environment_defaults_to_bundled_chromium(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            env_copy = Path(directory) / ".env"
            env_copy.write_text((BASE_DIR / ".env.example").read_text(encoding="utf-8"), encoding="utf-8")
            browser_lines = [
                line
                for line in env_copy.read_text(encoding="utf-8").splitlines()
                if line.startswith("JARVIS_BROWSER_CHANNEL=")
            ]
        self.assertEqual(browser_lines, ["JARVIS_BROWSER_CHANNEL=chromium"])


if __name__ == "__main__":
    unittest.main()
