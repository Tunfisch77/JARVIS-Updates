import base64
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock,patch
import subprocess
import pytest
import linux_bridge as bridge
import linux_desktop as desktop
import linux_system_worker as worker
import linux_portal as portal
import linux_services as services
import linux_modules as modules
import linux_app_window as window
from v11_core import DesktopController,V11CapabilityManager
from v15_core import PcAgentController
from state_store import JarvisStateStore

def manager(root):
    value=V11CapabilityManager(JarvisStateStore(root/'test.db'),root)
    value.update_settings({'desktop_control_enabled':True});return value

def test_registered_program_uses_exact_id(tmp_path):
    item=dict(id='org.example.Design.desktop',name='Design Tool',executable='design',terminal=False)
    with patch.object(desktop,'call',side_effect=[{'items':[item]},{'ok':True}]) as call:
        result=PcAgentController(manager(tmp_path),tmp_path).open_target('Design Tool')
    assert result['mode']=='desktop_app'
    assert call.call_args.args==('launch',{'target':item['id'],'allow_terminal':False})

def test_ambiguous_registered_program_never_launches():
    items=[dict(id=str(i),name='Design',executable='design',terminal=False) for i in range(2)]
    with patch.object(desktop,'call',return_value={'items':items}) as call:
        with pytest.raises(desktop.LinuxDesktopError,match='Mehrere'):desktop.resolve_program('Design')
    assert call.call_count==1

def test_registered_terminal_alias_blocked():
    with patch.object(desktop,'call',return_value={'items':[dict(id='run.desktop',name='Commands',executable='bash',terminal=True)]}):
        with pytest.raises(desktop.LinuxDesktopError,match='Terminal'):desktop.resolve_program('Commands')

def test_worker_requires_unique_application():
    items=[dict(id='one',name='Edit',executable='editor'),dict(id='two',name='Edit',executable='editor2')]
    with pytest.raises(RuntimeError,match='Mehrere'):worker.find_app('Edit',items)
    assert worker.find_app('two',items)['id']=='two'

class Control:
    def __init__(self,name,children=(),enabled=True):self.name,self.children,self.enabled,self.clicks=name,children,enabled,0
    def get_name(self):return self.name
    def get_child_count(self):return len(self.children)
    def get_child_at_index(self,i):return self.children[i]
    def get_state_set(self):return self
    def contains(self,state):return self.enabled
    def get_action_iface(self):return self
    def get_n_actions(self):return 1
    def get_action_name(self,i):return 'click'
    def do_action(self,i):self.clicks+=1;return True

def test_atspi_exact_control_and_duplicate_rejection():
    save,cancel=Control('Speichern'),Control('Abbrechen');root=Control('Dokument',[save,cancel])
    api=SimpleNamespace(StateType=SimpleNamespace(SHOWING=1,ENABLED=2))
    with patch.object(worker,'atspi',return_value=api),patch.object(worker,'windows',return_value=[(root,'Editor')]):
        worker.named_control(dict(window='Dokument',control='Speichern'))
        assert save.clicks==1 and cancel.clicks==0
        other=Control('Speichern');root.children.append(other)
        with pytest.raises(RuntimeError,match='nicht eindeutig'):worker.named_control(dict(window='Dokument',control='Speichern'))
        assert save.clicks==1 and other.clicks==0

def test_atspi_incomplete_search_fails_closed():
    with pytest.raises(RuntimeError,match='Zu viele'):list(worker.walk(Control('huge',[Control(str(i)) for i in range(2001)])))

class FakePortal:
    instances=[]
    def __init__(self):
        self.calls,self.keys,self.closed=[],[],False
        self.stream=(12,{'size':(100,80)});self.session='session';self.instances.append(self)
    def start(self,**kwargs):self.calls.append(('start',kwargs))
    def key(self,key,down):self.keys.append((key,down))
    def call(self,*args):self.calls.append(args)
    def close(self):self.closed=True

def test_wayland_denial_prevents_preceding_open():
    class Deny(FakePortal):
        def start(self,**kwargs):raise RuntimeError('abgebrochen')
    with patch.object(portal,'Portal',Deny),patch.object(worker,'launch_app') as launch:
        with pytest.raises(RuntimeError,match='abgebrochen'):
            portal.execute_plan({'actions':[dict(action='open',resolved=dict(mode='desktop_app',value='x.desktop')),dict(action='type_text',text='Hi')]})
        launch.assert_not_called()
    assert Deny.instances[-1].closed

def test_wayland_bad_coordinates_close_session_without_click():
    with patch.object(portal,'Portal',FakePortal):
        with pytest.raises(RuntimeError,match='außerhalb'):portal.execute_plan({'actions':[dict(action='click_point',x=100,y=0,button='left')]})
    instance=FakePortal.instances[-1];assert instance.closed and len(instance.calls)==1

def test_wayland_unicode_and_hotkey_release():
    with patch.object(portal,'Portal',FakePortal):
        result=portal.execute_plan({'actions':[dict(action='hotkey',keys=['ctrl','s']),dict(action='type_text',text='ə')]})
    instance=FakePortal.instances[-1]
    assert instance.keys==[(0xffe3,True),(ord('s'),True),(ord('s'),False),(0xffe3,False),(0x1000000|ord('ə'),True),(0x1000000|ord('ə'),False)]
    assert instance.closed and len(result['completed'])==2

def test_wayland_error_releases_modifiers():
    class Fails(FakePortal):
        def key(self,key,down):
            super().key(key,down)
            if key==ord('s') and down:raise RuntimeError('disconnected')
    with patch.object(portal,'Portal',Fails):
        with pytest.raises(RuntimeError):portal.execute_plan({'actions':[dict(action='hotkey',keys=['ctrl','s'])]})
    assert Fails.instances[-1].closed and (0xffe3,False) in Fails.instances[-1].keys

def test_controller_uses_one_portal_session(tmp_path):
    c=DesktopController(None,manager(tmp_path),tmp_path)
    with patch.object(desktop,'validate_actions'),patch.object(desktop,'session_status',return_value={'session':'wayland'}),patch.object(desktop,'execute_portal_plan',return_value={'ok':True,'completed':[]}) as execute,patch.object(c,'_execute_action') as individual:
        assert c.execute([dict(action='type_text',text='Hello')],run_id='r')['ok']
    execute.assert_called_once();individual.assert_not_called();assert not c.status()['running']

def test_portal_screenshot_metadata_is_honest(tmp_path):
    png=b'\x89PNG\r\n\x1a\n'+b'\x00'*8+(1).to_bytes(4,'big')*2
    with patch.object(desktop,'session_status',return_value={'session':'wayland'}),patch.object(desktop,'call',return_value={'data':base64.b64encode(png).decode(),'source':'xdg-screenshot'}):
        data,meta=PcAgentController(manager(tmp_path),tmp_path).capture_native_screen()
    assert data==png and meta['persisted'] and meta['portal_managed_file']

def test_stop_terminates_system_bridge():
    child=Mock();child.poll.return_value=None;child.communicate.return_value=('','')
    with patch.object(bridge.subprocess,'Popen',return_value=child):
        with pytest.raises(RuntimeError,match='stop'):bridge.call('portal_plan',check_stop=Mock(side_effect=RuntimeError('stop')))
    child.terminate.assert_called_once()

@pytest.mark.parametrize('raw',[
 dict(action='set_volume',volume=101),dict(action='set_volume',volume=True),dict(action='set_mute',mute='false'),
 dict(action='set_volume',volume=30,audio_target='--help'),dict(action='set_volume',volume=30,audio_scope='stream',audio_target='guess'),
 dict(action='bluetooth_connect',address='My headphones')])
def test_invalid_system_mutations_rejected(raw):
    with patch.object(services.shutil,'which',return_value='/usr/bin/pactl'):
        with pytest.raises(desktop.LinuxDesktopError):services.validate_action(raw)

def test_audio_stream_uses_structured_command_and_confirmation(tmp_path):
    with patch.object(services.shutil,'which',return_value='/usr/bin/pactl'),patch.object(desktop,'run_interruptible') as run:
        action=dict(action='set_volume',audio_scope='stream',audio_target='14',volume=40)
        cleaned=DesktopController(None,manager(tmp_path),tmp_path).validate_plan([action])
        assert DesktopController.plan_requires_confirmation(cleaned)
        services.execute_action(cleaned[0],lambda:None)
    assert run.call_args.args[0]==['pactl','set-sink-input-volume','14','40%']

def test_failed_optional_install_preserves_runtime(tmp_path):
    old=tmp_path/'.venv';old.mkdir();(old/'keep').write_text('existing');(tmp_path/'.jarvis_envs').mkdir()
    def fails(command):
        if command[1:3]==['-m','venv']:Path(command[3]).mkdir();return
        raise subprocess.CalledProcessError(1,command)
    with patch.object(modules,'ROOT',tmp_path),patch.object(modules,'run',side_effect=fails):
        with pytest.raises(subprocess.CalledProcessError):modules.install_runtime(['voice'])
    assert (old/'keep').read_text()=='existing' and not list((tmp_path/'.jarvis_envs').iterdir())

def test_failed_environment_switch_restores_original(tmp_path):
    old,stage=tmp_path/'.venv',tmp_path/'.jarvis_envs/new';old.mkdir();stage.mkdir(parents=True);(old/'keep').write_text('old')
    with patch.object(modules,'ROOT',tmp_path),patch.object(modules.os,'replace',side_effect=OSError('cannot switch')):
        with pytest.raises(OSError):modules.activate(stage,old)
    assert (old/'keep').read_text()=='old' and not old.is_symlink()

def test_app_windows_separate_profiles_keep_sandbox(tmp_path):
    child=Mock();child.poll.return_value=None
    with patch.object(window,'ROOT',tmp_path),patch.dict(window.os.environ,{'DISPLAY':':1'}),patch.object(window,'browser_executable',return_value='/usr/bin/chromium'),patch.object(window.subprocess,'Popen',return_value=child) as launch,patch.object(window.time,'sleep'):
        window.open_window('jarvis');window.open_window('whatsapp')
    commands=[c.args[0] for c in launch.call_args_list]
    assert commands[0][2]!=commands[1][2] and '--app=http://127.0.0.1:8017' in commands[0]
    assert all('--no-sandbox' not in c for c in commands)

def test_reused_pid_is_rejected_even_with_matching_command(tmp_path):
    import json,psutil,jarvis_linux as launcher
    (tmp_path/'linux-server.json').write_text(json.dumps(dict(pid=321,created=1000.0)))
    process=Mock();process.create_time.return_value=2000.0
    process.cmdline.return_value=['python',str(launcher.ROOT/'jarvis_linux.py'),'serve']
    with patch.object(launcher,'DATA',tmp_path),patch.object(psutil,'Process',return_value=process):
        assert launcher.owned_process() is None
    process.terminate.assert_not_called()
