from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from fastapi.testclient import TestClient

import app
from state_store import JarvisStateStore
from v11_core import COMPONENTS, V11CapabilityManager


ROOT = Path(__file__).resolve().parents[1]


class DeterministicMessageRoutingTests(unittest.TestCase):
    def setUp(self) -> None:
        self.directory = tempfile.TemporaryDirectory()
        self.state = JarvisStateStore(Path(self.directory.name) / "jarvis.db")
        self.state_patch = patch.object(app, "state_store", self.state)
        self.state_patch.start()
        self.client = TestClient(app.app)

    def tearDown(self) -> None:
        self.client.close()
        self.state_patch.stop()
        self.directory.cleanup()

    def route(self, text: str) -> dict[str, object]:
        response = self.client.post("/messages/route", json={"text": text})
        self.assertEqual(response.status_code, 200, response.text)
        return response.json()

    def test_general_personal_message_question_always_checks_all_sources(self) -> None:
        result = self.route("Habe ich irgendwelche Nachrichten?")
        self.assertTrue(result["handled"])
        self.assertEqual(result["tool"], "check_new_messages")
        self.assertEqual(result["arguments"]["sources"], ["whatsapp", "gmail", "outlook"])

    def test_explicit_source_limits_general_check(self) -> None:
        result = self.route("Habe ich neue Nachrichten bei Gmail?")
        self.assertEqual(result["tool"], "check_new_messages")
        self.assertEqual(result["arguments"]["sources"], ["gmail"])

    def test_last_gmail_message_extracts_sender_and_limit(self) -> None:
        result = self.route("Was habe ich das letzte Mal von Asim Cetin bei Gmail erhalten?")
        self.assertEqual(result["tool"], "search_messages")
        self.assertEqual(result["arguments"]["sources"], ["gmail"])
        self.assertEqual(result["arguments"]["target"], "asim cetin")
        self.assertEqual(result["arguments"]["limit"], 1)

    def test_latest_gmail_without_sender_routes_to_gmail_history(self) -> None:
        result = self.route("Was habe ich als Letztes auf Gmail erhalten?")
        self.assertEqual(result["tool"], "search_messages")
        self.assertEqual(result["arguments"]["sources"], ["gmail"])
        self.assertEqual(result["arguments"]["target"], "")
        self.assertEqual(result["arguments"]["limit"], 1)

    def test_saved_group_alias_routes_directly_to_whatsapp_history(self) -> None:
        self.state.save_whatsapp_group(
            name="Familie",
            aliases=["Familiengruppe"],
            chat_name="Familie Privat",
        )
        result = self.route("Was war die letzte Nachricht aus der Familiengruppe?")
        self.assertEqual(result["tool"], "search_messages")
        self.assertEqual(result["arguments"]["sources"], ["whatsapp"])
        self.assertEqual(result["arguments"]["target"], "Familiengruppe")

    def test_news_and_sending_requests_are_not_inbox_routed(self) -> None:
        self.assertFalse(self.route("Zeig mir aktuelle Nachrichten aus Österreich.")["handled"])
        self.assertFalse(self.route("Schreib Asim eine Nachricht bei WhatsApp.")["handled"])

    def test_frontend_executes_route_before_realtime_answer(self) -> None:
        html = (ROOT / "static" / "index.html").read_text(encoding="utf-8")
        self.assertIn('requestJson("/messages/route"', html)
        self.assertIn("buildRoutedMessageContext", html)
        self.assertIn("Behaupte deshalb nicht, dass du keinen Zugriff", html)


class OpenAdaptPlaywrightRepairTests(unittest.TestCase):
    def test_openadapt_environment_explicitly_installs_playwright(self) -> None:
        requirements = (ROOT / "requirements-v11-openadapt.txt").read_text(encoding="utf-8")
        installer = (ROOT / "module_installer.ps1").read_text(encoding="utf-8")
        self.assertIn("playwright>=1.50,<2.0", requirements)
        self.assertIn('"import playwright"', installer)
        self.assertIn(".jarvis-playwright-ready", installer)
        self.assertIn("$ok = $ok -and $browserReady", installer)

    def test_openadapt_is_not_ready_without_browser_marker(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            state = JarvisStateStore(base / "jarvis.db")
            manager = V11CapabilityManager(state, base)
            environment = base / ".jarvis_envs" / "openadapt"
            scripts = environment / "bin"
            scripts.mkdir(parents=True)
            (environment / ".jarvis-installed").touch()
            (scripts / "python").touch()
            component = next(item for item in COMPONENTS if item.key == "openadapt")
            self.assertFalse(manager._installed(component))
            (environment / ".jarvis-playwright-ready").touch()
            self.assertTrue(manager._installed(component))


if __name__ == "__main__":
    unittest.main()
