from __future__ import annotations

import asyncio
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import AsyncMock, patch

from fastapi.testclient import TestClient

import app
from integration_hub import IntegrationConfig, IntegrationHub
from state_store import JarvisStateStore


class V980StateTests(unittest.TestCase):
    def test_action_run_can_fail_retry_and_finish(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            store = JarvisStateStore(Path(directory) / "jarvis.db")
            run = store.start_action_run(
                "request-12345678",
                tool_name="send_whatsapp_message",
                label="WhatsApp an Mama",
                payload={"target": "Mama", "message": "Hallo"},
                max_attempts=3,
            )
            self.assertEqual(run["status"], "running")
            store.fail_action_run("request-12345678", "Testfehler")
            restarted = store.restart_action_run(run["id"])
            self.assertEqual(restarted["attempts"], 2)
            finished = store.finish_action_run(
                "request-12345678",
                {
                    "ok": True,
                    "mode": "desktop_auto",
                    "verification": "desktop_send_command_completed",
                    "app_closed": True,
                },
                authorization="manual_retry",
            )
            self.assertEqual(finished["status"], "success")
            self.assertTrue(finished["app_closed"])

    def test_routine_store_claims_each_due_run_once(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            store = JarvisStateStore(Path(directory) / "jarvis.db")
            routine = store.save_routine(
                name="Morgenmeldung",
                tool_name="send_whatsapp_message",
                payload={"target": "Familie", "message": "Guten Morgen", "target_kind": "group"},
                schedule="weekdays",
                time_of_day="07:00",
                weekday=0,
                enabled=True,
                next_run_at="2000-01-01T00:00:00+00:00",
            )
            self.assertEqual(len(store.due_routines()), 1)
            self.assertTrue(
                store.claim_routine(
                    routine["id"],
                    "2000-01-01T00:00:00+00:00",
                    "2099-01-01T00:00:00+00:00",
                )
            )
            self.assertFalse(
                store.claim_routine(
                    routine["id"],
                    "2000-01-01T00:00:00+00:00",
                    "2099-01-02T00:00:00+00:00",
                )
            )


class V980WhatsAppCloseTests(unittest.TestCase):
    def test_jarvis_closes_only_a_whatsapp_window_it_opened(self) -> None:
        hub = IntegrationHub(
            lambda: [],
            IntegrationConfig(
                whatsapp_mode="desktop",
                whatsapp_desktop_auto_send=True,
                close_launched_apps=True,
            ),
        )
        with (
            patch.object(os, "name", "nt"),
            patch.object(os, "startfile", create=True),
            patch.object(hub, "_windows_existing_whatsapp_window", return_value=0),
            patch.object(hub, "_windows_focus_whatsapp", return_value=123),
            patch.object(hub, "_windows_close_window", return_value=True) as close_window,
            patch.object(hub, "_windows_key_combo"),
            patch("integration_hub.time.sleep"),
        ):
            result = hub._send_whatsapp_desktop("contact", "436601234567", "Mama", "Hallo")
        close_window.assert_called_once_with(123)
        self.assertTrue(result["app_closed"])

        with (
            patch.object(os, "name", "nt"),
            patch.object(os, "startfile", create=True),
            patch.object(hub, "_windows_existing_whatsapp_window", return_value=88),
            patch.object(hub, "_windows_focus_whatsapp", return_value=88),
            patch.object(hub, "_windows_close_window") as close_existing,
            patch.object(hub, "_windows_key_combo"),
            patch("integration_hub.time.sleep"),
        ):
            result = hub._send_whatsapp_desktop("contact", "436601234567", "Mama", "Hallo")
        close_existing.assert_not_called()
        self.assertFalse(result["app_closed"])


class V980ApiAndUiTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary_directory = tempfile.TemporaryDirectory()
        self.store = JarvisStateStore(Path(self.temporary_directory.name) / "jarvis.db")
        self.store.set_setting(
            "autonomy",
            {"enabled": True, "structured_actions_only": True, "bulk_messages": False, "arbitrary_shell": False},
        )
        self.store.save_contact(name="Mama", whatsapp_number="436601234567", email="mama@example.com")
        self.hub = IntegrationHub(
            self.store.list_contacts,
            IntegrationConfig(whatsapp_mode="desktop", whatsapp_desktop_auto_send=True),
            group_supplier=self.store.list_whatsapp_groups,
            usage_recorder=self.store.touch_communication_target,
        )
        self.state_patch = patch.object(app, "state_store", self.store)
        self.hub_patch = patch.object(app, "integration_hub", self.hub)
        self.state_patch.start()
        self.hub_patch.start()
        self.client = TestClient(app.app)

    def tearDown(self) -> None:
        self.client.close()
        self.hub_patch.stop()
        self.state_patch.stop()
        self.temporary_directory.cleanup()

    def test_successful_integration_action_appears_in_action_center(self) -> None:
        result = {
            "ok": True,
            "mode": "desktop_auto",
            "requires_user_action": False,
            "verification": "desktop_send_command_completed",
            "result_summary": "WhatsApp hat den Sendebefehl ausgeführt.",
            "app_closed": True,
        }
        with patch.object(self.hub, "whatsapp_message", new=AsyncMock(return_value=result)):
            response = self.client.post(
                "/integrations/whatsapp/message",
                headers={"Idempotency-Key": "v980-action-test"},
                json={"target": "Mama", "message": "Hallo", "target_kind": "contact"},
            )
        self.assertEqual(response.status_code, 200, response.text)
        actions = self.client.get("/actions").json()["items"]
        self.assertEqual(actions[0]["status"], "success")
        self.assertTrue(actions[0]["app_closed"])

    def test_automation_preferences_and_routine_api(self) -> None:
        preferences = self.client.put(
            "/automation-preferences",
            json={"close_launched_apps": False, "action_retry_limit": 4},
        )
        self.assertEqual(preferences.status_code, 200, preferences.text)
        self.assertFalse(self.hub.config.close_launched_apps)
        routine = self.client.post(
            "/routines",
            json={
                "name": "Guten Morgen",
                "channel": "whatsapp",
                "target": "Mama",
                "message": "Guten Morgen",
                "schedule": "weekdays",
                "time_of_day": "07:00",
                "weekday": 0,
                "enabled": True,
            },
        )
        self.assertEqual(routine.status_code, 200, routine.text)
        self.assertEqual(self.client.get("/routines").json()["count"], 1)

    def test_ui_contains_v980_controls(self) -> None:
        html = (Path(__file__).resolve().parents[1] / "static" / "index.html").read_text(encoding="utf-8")
        self.assertEqual(app.APP_VERSION, "15.3.0")
        for marker in (
            "PC AGENT OS v15.3.0",
            'id="closeLaunchedApps"',
            'id="routineList"',
            'id="quickWhatsappBtn"',
            'id="serviceOutlook"',
            "loadActionCenter",
        ):
            self.assertIn(marker, html)


if __name__ == "__main__":
    unittest.main()
