import tempfile
import unittest
from pathlib import Path

from integration_hub import IntegrationConfig
from mail_accounts import ConnectedAccountConfig
from persistent_storage import jarvis_local_root, migrate_legacy_path


class PersistentStorageTests(unittest.TestCase):
    def test_windows_local_app_data_is_version_independent(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = jarvis_local_root(
                {
                    "LOCALAPPDATA": directory,
                    "JARVIS_LOCAL_DATA_DIR": r"%LOCALAPPDATA%\JARVIS",
                }
            )
            self.assertEqual(root, Path(directory) / "JARVIS")

    def test_browser_and_account_paths_use_one_central_root(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory) / "version"
            local = Path(directory) / "local"
            base.mkdir()
            env = {"LOCALAPPDATA": str(local)}
            integrations = IntegrationConfig.from_environment(env, base_dir=base)
            accounts = ConnectedAccountConfig.from_environment(base, env)
            expected = local / "JARVIS"
            self.assertEqual(
                integrations.whatsapp_profile_dir,
                expected / "browser_profiles" / "whatsapp",
            )
            self.assertEqual(
                integrations.snapchat_profile_dir,
                expected / "browser_profiles" / "snapchat",
            )
            self.assertEqual(
                accounts.outlook_profile_dir,
                expected / "browser_profiles" / "outlook",
            )
            self.assertEqual(accounts.gmail_token, expected / "accounts" / "gmail_token.json")

    def test_existing_profile_is_migrated_only_once(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            legacy = root / "old"
            destination = root / "central"
            legacy.mkdir()
            (legacy / "cookie").write_text("logged-in", encoding="utf-8")
            migrate_legacy_path(legacy, destination)
            self.assertEqual((destination / "cookie").read_text(encoding="utf-8"), "logged-in")
            (legacy / "cookie").write_text("changed", encoding="utf-8")
            migrate_legacy_path(legacy, destination)
            self.assertEqual((destination / "cookie").read_text(encoding="utf-8"), "logged-in")


if __name__ == "__main__":
    unittest.main()
