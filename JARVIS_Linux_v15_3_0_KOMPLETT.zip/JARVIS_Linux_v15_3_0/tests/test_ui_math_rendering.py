from pathlib import Path
import re
import unittest


class UiMathRenderingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.root = Path(__file__).resolve().parents[1]
        cls.html = (cls.root / "static" / "index.html").read_text(encoding="utf-8")

    def test_katex_is_local_and_enabled_for_jarvis_messages(self) -> None:
        self.assertIn('/static/vendor/katex/katex.min.css', self.html)
        self.assertIn('/static/vendor/katex/katex.min.js', self.html)
        self.assertIn('/static/vendor/katex/auto-render.min.js', self.html)
        self.assertIn('renderMathInElement(message', self.html)
        self.assertIn('{ left: "\\\\[", right: "\\\\]", display: true }', self.html)

    def test_all_primary_math_fonts_are_bundled(self) -> None:
        css_path = self.root / "static" / "vendor" / "katex" / "katex.min.css"
        css = css_path.read_text(encoding="utf-8")
        font_names = set(re.findall(r"url\(fonts/([^)]*?\.woff2)\)", css))
        self.assertGreaterEqual(len(font_names), 20)
        for name in font_names:
            self.assertTrue((css_path.parent / "fonts" / name).is_file(), name)


if __name__ == "__main__":
    unittest.main()
