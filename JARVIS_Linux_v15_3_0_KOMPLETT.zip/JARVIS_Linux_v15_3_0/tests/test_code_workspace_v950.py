from __future__ import annotations

import io
import stat
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import AsyncMock, patch

from fastapi.testclient import TestClient

import app
from code_workspace import CodeWorkspaceManager, WorkspaceError
from memory_store import MemoryStore
from state_store import JarvisStateStore


def project_zip(files: dict[str, bytes]) -> bytes:
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path, data in files.items():
            archive.writestr(path, data)
    return buffer.getvalue()


class CodeWorkspaceManagerTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary_directory = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary_directory.name)
        self.manager = CodeWorkspaceManager(self.root / "workspaces")

    def tearDown(self) -> None:
        self.temporary_directory.cleanup()

    def test_import_keeps_project_structure_but_excludes_secrets_from_ai(self) -> None:
        data = project_zip(
            {
                "project/src/main.py": b"print('hello')\n",
                "project/.env": b"SECRET=private\n",
                "project/.env.example": b"SECRET=template\n",
                "project/node_modules/ignored.js": b"ignored",
                "project/assets/logo.bin": b"\x00\x01\x02",
            }
        )
        workspace = self.manager.import_zip(data, name="Testprojekt")
        files = {item["path"]: item for item in self.manager.list_files(workspace["id"])}
        self.assertIn("project/src/main.py", files)
        self.assertIn("project/.env", files)
        self.assertTrue(files["project/.env"]["sensitive"])
        self.assertNotIn("project/node_modules/ignored.js", files)
        ai_paths = {item["path"] for item in self.manager.collect_ai_files(workspace["id"])["files"]}
        self.assertIn("project/src/main.py", ai_paths)
        self.assertIn("project/.env.example", ai_paths)
        self.assertNotIn("project/.env", ai_paths)
        with self.assertRaises(WorkspaceError):
            self.manager.read_text(workspace["id"], "project/.env")
        exported = self.manager.export_zip(workspace["id"])
        with zipfile.ZipFile(io.BytesIO(exported)) as archive:
            self.assertEqual(archive.read("project/.env"), b"SECRET=private\n")

    def test_zip_slip_and_symlinks_are_rejected(self) -> None:
        with self.assertRaises(WorkspaceError):
            self.manager.import_zip(project_zip({"../escape.py": b"pass"}), name="bad")

        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w") as archive:
            info = zipfile.ZipInfo("link.py")
            info.create_system = 3
            info.external_attr = (stat.S_IFLNK | 0o777) << 16
            archive.writestr(info, "target.py")
        with self.assertRaises(WorkspaceError):
            self.manager.import_zip(buffer.getvalue(), name="link")

    def test_edit_diff_snapshot_restore_and_export(self) -> None:
        workspace = self.manager.import_zip(project_zip({"main.py": b"value = 1\n"}), name="Demo")
        workspace_id = workspace["id"]
        self.manager.write_text(workspace_id, "main.py", "value = 2\n")
        self.manager.write_text(workspace_id, "new.json", '{"ok": true}\n')
        diff = self.manager.diff_from_snapshot(workspace_id)
        self.assertEqual(diff["count"], 2)
        self.assertIn("-value = 1", next(item["diff"] for item in diff["changes"] if item["path"] == "main.py"))
        snapshot = self.manager.create_snapshot(workspace_id, label="Version zwei")
        self.manager.write_text(workspace_id, "main.py", "value = 3\n")
        restored = self.manager.restore_snapshot(workspace_id, snapshot["id"])
        self.assertTrue(restored["ok"])
        self.assertEqual(self.manager.read_text(workspace_id, "main.py")["content"], "value = 2\n")

    def test_safe_checks_parse_but_never_execute_project_code(self) -> None:
        marker = self.root / "executed.txt"
        code = f"from pathlib import Path\nPath({str(marker)!r}).write_text('bad')\n"
        workspace = self.manager.import_zip(
            project_zip({"safe.py": code.encode(), "broken.py": b"def broken(:\n", "bad.json": b"{ nope"}),
            name="Checks",
        )
        result = self.manager.run_safe_checks(workspace["id"])
        self.assertFalse(result["ok"])
        self.assertEqual(result["execution_policy"], "static-only")
        self.assertFalse(marker.exists())
        failed_paths = {item["path"] for item in result["results"] if not item["ok"]}
        self.assertEqual(failed_paths, {"bad.json", "broken.py"})

    def test_proposal_requires_unchanged_base_and_creates_safety_snapshot(self) -> None:
        workspace = self.manager.import_zip(project_zip({"main.py": b"value = 1\n"}), name="Proposal")
        workspace_id = workspace["id"]
        proposal = self.manager.create_proposal(
            workspace_id,
            instruction="Ändere den Wert",
            summary="Wert geändert",
            changes=[{"path": "main.py", "action": "upsert", "content": "value = 2\n"}],
            model="test-model",
        )
        self.manager.write_text(workspace_id, "main.py", "value = 9\n")
        with self.assertRaises(WorkspaceError):
            self.manager.apply_proposal(workspace_id, proposal["id"])

        proposal = self.manager.create_proposal(
            workspace_id,
            instruction="Ändere den Wert",
            summary="Wert geändert",
            changes=[{"path": "main.py", "action": "upsert", "content": "value = 10\n"}],
            model="test-model",
        )
        applied = self.manager.apply_proposal(workspace_id, proposal["id"])
        self.assertEqual(applied["status"], "applied")
        self.assertTrue(applied["safety_snapshot_id"])
        self.assertEqual(self.manager.read_text(workspace_id, "main.py")["content"], "value = 10\n")


class CodeWorkspaceApiTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary_directory = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary_directory.name)
        database = self.root / "jarvis.db"
        MemoryStore(database)
        self.store = JarvisStateStore(database)
        self.manager = CodeWorkspaceManager(self.root / "workspaces")
        self.state_patch = patch.object(app, "state_store", self.store)
        self.manager_patch = patch.object(app, "code_workspace_manager", self.manager)
        self.state_patch.start()
        self.manager_patch.start()
        self.client = TestClient(app.app)

    def tearDown(self) -> None:
        self.client.close()
        self.manager_patch.stop()
        self.state_patch.stop()
        self.temporary_directory.cleanup()

    def import_workspace(self) -> str:
        response = self.client.post(
            "/workspaces/import",
            data={"name": "API Projekt"},
            files={"file": ("projekt.zip", project_zip({"main.py": b"value = 1\n", ".env": b"SECRET=x\n"}), "application/zip")},
        )
        self.assertEqual(response.status_code, 200)
        return response.json()["item"]["id"]

    def test_import_edit_check_export_and_protected_delete(self) -> None:
        workspace_id = self.import_workspace()
        saved = self.client.put(
            f"/workspaces/{workspace_id}/file",
            json={"path": "main.py", "content": "value = 2\n"},
        )
        self.assertEqual(saved.status_code, 200)
        checked = self.client.post(f"/workspaces/{workspace_id}/check")
        self.assertTrue(checked.json()["ok"])
        exported = self.client.get(f"/workspaces/{workspace_id}/export.zip")
        self.assertEqual(exported.status_code, 200)
        with zipfile.ZipFile(io.BytesIO(exported.content)) as archive:
            self.assertEqual(archive.read("main.py"), b"value = 2\n")
            self.assertEqual(archive.read(".env"), b"SECRET=x\n")
        self.assertEqual(self.client.delete(f"/workspaces/{workspace_id}").status_code, 428)
        deleted = self.client.delete(f"/workspaces/{workspace_id}", headers={"X-Jarvis-Confirmed": "true"})
        self.assertEqual(deleted.status_code, 200)

    def test_ai_edit_is_a_reviewable_proposal_before_application(self) -> None:
        workspace_id = self.import_workspace()
        model_result = {
            "answer": "Ich ändere den Wert.",
            "changes": [{"path": "main.py", "action": "upsert", "content": "value = 7\n"}],
            "model": "strongest-test-model",
            "usage": {"total_tokens": 42},
            "response_id": "resp_workspace_test",
        }
        with (
            patch.object(app, "OPENAI_API_KEY", "test-key"),
            patch.object(app, "_run_workspace_edit_stable", new=AsyncMock(return_value=model_result)) as model,
        ):
            proposed = self.client.post(
                f"/workspaces/{workspace_id}/ai-edit",
                json={"instruction": "Setze value auf 7"},
            )
        self.assertEqual(proposed.status_code, 200)
        proposal = proposed.json()["proposal"]
        self.assertEqual(proposal["status"], "pending")
        self.assertIn("-value = 1", proposal["changes"][0]["diff"])
        self.assertEqual(self.manager.read_text(workspace_id, "main.py")["content"], "value = 1\n")
        model.assert_awaited_once()

        route = f"/workspaces/{workspace_id}/proposals/{proposal['id']}/apply"
        self.assertEqual(self.client.post(route).status_code, 428)
        applied = self.client.post(route, headers={"X-Jarvis-Confirmed": "true"})
        self.assertEqual(applied.status_code, 200)
        self.assertEqual(self.manager.read_text(workspace_id, "main.py")["content"], "value = 7\n")

    def test_sensitive_file_cannot_be_read_through_editor_api(self) -> None:
        workspace_id = self.import_workspace()
        response = self.client.get(f"/workspaces/{workspace_id}/file", params={"path": ".env"})
        self.assertEqual(response.status_code, 400)
        self.assertIn("Sensible", response.json()["detail"])

    def test_ui_contains_real_code_workspace_controls(self) -> None:
        html = (Path(__file__).resolve().parents[1] / "static" / "index.html").read_text(encoding="utf-8")
        self.assertIn("CODE-WORKSPACE", html)
        self.assertIn('id="workspaceEditor"', html)
        self.assertIn("requestWorkspaceAiProposal", html)
        self.assertIn("applyWorkspaceProposal", html)
        self.assertIn("SICHER PRÜFEN", html)
        self.assertIn("all v14 and earlier controls remain available in v15", html)


if __name__ == "__main__":
    unittest.main()
