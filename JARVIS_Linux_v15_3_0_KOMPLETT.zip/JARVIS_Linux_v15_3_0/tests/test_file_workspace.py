from __future__ import annotations

import io
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import AsyncMock, patch

from fastapi import HTTPException
from fastapi.testclient import TestClient

import app
from state_store import JarvisStateStore


def make_zip(files: dict[str, bytes]) -> bytes:
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path, data in files.items():
            archive.writestr(path, data)
    return buffer.getvalue()


class ZipWorkspaceTests(unittest.TestCase):
    def test_zip_expands_supported_project_files_and_skips_secrets(self) -> None:
        archive = make_zip(
            {
                "src/main.py": b"print('hello')\n",
                "README.md": b"# Demo\n",
                ".env": b"OPENAI_API_KEY=secret\n",
                "node_modules/package/index.js": b"ignored",
                "assets/raw.bin": b"ignored",
                "nested.zip": b"PKignored",
            }
        )
        content, metadata, expanded = app.build_zip_attachment_inputs(
            filename="projekt.zip",
            data=archive,
            image_detail="low",
        )
        self.assertEqual(metadata["kind"], "archive")
        self.assertEqual(metadata["files_included"], 2)
        self.assertEqual(metadata["files_skipped"], 4)
        self.assertEqual(expanded, len(b"print('hello')\n") + len(b"# Demo\n"))
        paths = [item["path"] for item in metadata["workspace_files"]]
        self.assertEqual(paths, ["projekt/src/main.py", "projekt/README.md"])
        self.assertEqual(content[0]["type"], "input_text")
        self.assertIn("projekt/src/main.py", content[0]["text"])
        self.assertEqual(content[2]["type"], "input_file")

    def test_zip_accepts_safe_env_template_but_keeps_real_env_secret(self) -> None:
        archive = make_zip(
            {
                "config/.env.example": b"OPENAI_API_KEY=replace-me\n",
                "config/.env": b"OPENAI_API_KEY=real-secret\n",
            }
        )
        content, metadata, expanded = app.build_zip_attachment_inputs(
            filename="projekt.zip",
            data=archive,
            image_detail="low",
        )
        self.assertEqual(metadata["files_included"], 1)
        self.assertEqual(metadata["files_skipped"], 1)
        self.assertEqual(expanded, len(b"OPENAI_API_KEY=replace-me\n"))
        self.assertEqual(metadata["workspace_files"][0]["path"], "projekt/config/.env.example")
        self.assertTrue(str(content[2]["filename"]).endswith(".txt"))

    def test_zip_rejects_path_traversal(self) -> None:
        archive = make_zip({"../evil.py": b"print('no')"})
        with self.assertRaises(HTTPException) as caught:
            app.build_zip_attachment_inputs(filename="bad.zip", data=archive, image_detail="low")
        self.assertEqual(caught.exception.status_code, 400)

    def test_zip_rejects_symlinks(self) -> None:
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w") as archive:
            info = zipfile.ZipInfo("link.py")
            info.create_system = 3
            info.external_attr = 0o120777 << 16
            archive.writestr(info, "target.py")
        with self.assertRaises(HTTPException) as caught:
            app.build_zip_attachment_inputs(filename="links.zip", data=buffer.getvalue(), image_detail="low")
        self.assertEqual(caught.exception.status_code, 400)

    def test_zip_rejects_extreme_compression_ratio(self) -> None:
        archive = make_zip({"large.txt": b"A" * (2 * 1024 * 1024)})
        with self.assertRaises(HTTPException) as caught:
            app.build_zip_attachment_inputs(filename="bomb.zip", data=archive, image_detail="low")
        self.assertEqual(caught.exception.status_code, 413)


class GeneratedFileTests(unittest.TestCase):
    def setUp(self) -> None:
        app.generated_file_bundles.clear()
        self.client = TestClient(app.app)

    def tearDown(self) -> None:
        self.client.close()
        app.generated_file_bundles.clear()

    def test_generated_files_download_individually_and_as_zip(self) -> None:
        files = app.validate_generated_files(
            [
                {"path": "projekt/src/main.py", "content": "print('fixed')\n"},
                {"path": "projekt/README.md", "content": "# Fixed\n"},
            ]
        )
        result = app.create_generated_bundle(files)
        individual = self.client.get(result["generated_files"][0]["download_url"])
        self.assertEqual(individual.status_code, 200)
        self.assertEqual(individual.content, b"print('fixed')\n")
        combined = self.client.get(result["download_all_url"])
        self.assertEqual(combined.status_code, 200)
        with zipfile.ZipFile(io.BytesIO(combined.content)) as archive:
            self.assertEqual(archive.read("projekt/README.md"), b"# Fixed\n")

    def test_generated_files_reject_secret_and_executable_paths(self) -> None:
        for path in ("projekt/.env", "projekt/tool.exe", "../escape.py"):
            with self.subTest(path=path), self.assertRaises(HTTPException):
                app.validate_generated_files([{"path": path, "content": "blocked"}])

    def test_extracts_unique_container_file_citations(self) -> None:
        citation = {
            "type": "container_file_citation",
            "container_id": "cntr_test123",
            "file_id": "cfile_test456",
            "filename": "result.pdf",
        }
        data = {
            "output": [
                {
                    "type": "message",
                    "content": [{"type": "output_text", "text": "done", "annotations": [citation, citation]}],
                }
            ]
        }
        self.assertEqual(
            app.extract_container_file_citations(data),
            [{"container_id": "cntr_test123", "file_id": "cfile_test456", "filename": "result.pdf"}],
        )


class FileWorkspaceModelTests(unittest.IsolatedAsyncioTestCase):
    async def test_requests_structured_output_and_sandboxed_file_tool(self) -> None:
        response_data = {
            "output": [
                {
                    "type": "message",
                    "content": [
                        {
                            "type": "output_text",
                            "text": json.dumps({"answer": "Fertig", "files": []}),
                            "annotations": [],
                        }
                    ],
                }
            ],
            "usage": {},
        }

        class FakeResponse:
            is_error = False
            status_code = 200
            text = ""

            def json(self) -> dict[str, object]:
                return response_data

        class FakeClient:
            payload: dict[str, object] | None = None

            def __init__(self, *args: object, **kwargs: object) -> None:
                pass

            async def __aenter__(self) -> "FakeClient":
                return self

            async def __aexit__(self, *args: object) -> None:
                return None

            async def post(self, *args: object, **kwargs: object) -> FakeResponse:
                FakeClient.payload = kwargs["json"]
                return FakeResponse()

        with patch.object(app.httpx, "AsyncClient", FakeClient):
            result = await app._run_openai_attachment_analysis(
                "Erkläre die Datei",
                [{"type": "input_file", "filename": "demo.txt", "file_data": "data:text/plain;base64,SGFsbG8="}],
            )
        self.assertEqual(result["answer"], "Fertig")
        self.assertEqual(FakeClient.payload["model"], app.FILE_WORKSPACE_MODEL)
        self.assertEqual(FakeClient.payload["tools"][0]["type"], "code_interpreter")
        self.assertEqual(FakeClient.payload["text"]["format"]["type"], "json_schema")


class FileWorkspaceApiTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary_directory = tempfile.TemporaryDirectory()
        self.state_store = JarvisStateStore(Path(self.temporary_directory.name) / "jarvis.db")
        self.state_patch = patch.object(app, "state_store", self.state_store)
        self.state_patch.start()
        app.attachment_analysis_attempts.clear()
        app.generated_file_bundles.clear()
        self.client = TestClient(app.app)

    def tearDown(self) -> None:
        self.client.close()
        self.state_patch.stop()
        self.temporary_directory.cleanup()

    def test_zip_upload_returns_real_downloadable_file(self) -> None:
        model_result = {
            "answer": "Ich habe den Code korrigiert.",
            "files": [{"path": "projekt/src/main.py", "data": b"print('fixed')\n"}],
            "model": "highest-test-model",
            "usage": {},
        }
        archive = make_zip({"src/main.py": b"print('broken')\n"})
        with (
            patch.object(app, "OPENAI_API_KEY", "test-key"),
            patch.object(app, "_run_openai_attachment_analysis", new=AsyncMock(return_value=model_result)) as analysis,
        ):
            response = self.client.post(
                "/attachments/analyze",
                data={"question": "Repariere main.py", "image_detail": "low"},
                files={"files": ("projekt.zip", archive, "application/zip")},
            )
        self.assertEqual(response.status_code, 200)
        body = response.json()
        self.assertEqual(body["attachments"][0]["kind"], "archive")
        self.assertEqual(body["generated_files"][0]["path"], "projekt/src/main.py")
        question, content = analysis.await_args.args
        self.assertEqual(question, "Repariere main.py")
        self.assertIn("projekt/src/main.py", content[0]["text"])
        download = self.client.get(body["generated_files"][0]["download_url"])
        self.assertEqual(download.content, b"print('fixed')\n")

    def test_file_workspace_uses_strongest_configured_model(self) -> None:
        self.assertEqual(app.FILE_WORKSPACE_MODEL, app.TERRA_MODEL)


if __name__ == "__main__":
    unittest.main()
