from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from fastapi.testclient import TestClient

import app
from state_store import JarvisStateStore
from v11_core import COMPONENTS, DesktopControlError, DesktopController, V11CapabilityManager
from v11_store import V11Store


class V11CatalogTests(unittest.TestCase):
    def test_catalog_contains_all_45_numbered_components(self) -> None:
        self.assertEqual(len(COMPONENTS), 45)
        self.assertEqual([item.number for item in COMPONENTS], list(range(1, 46)))
        self.assertEqual(len({item.key for item in COMPONENTS}), 45)
        self.assertIn("pywinauto", {item.key for item in COMPONENTS})
        self.assertIn("whatsapp_web_js", {item.key for item in COMPONENTS})

    def test_v11_defaults_keep_dangerous_actions_off(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            store = JarvisStateStore(Path(directory) / "jarvis.db")
            manager = V11CapabilityManager(store, Path(directory))
            settings = manager.settings()
            self.assertFalse(settings["desktop_control_enabled"])
            self.assertFalse(settings["allow_terminal"])
            self.assertFalse(settings["allow_installs"])
            self.assertFalse(settings["allow_deletes"])
            self.assertTrue(settings["require_confirmation_for_input"])

    def test_critical_component_requires_developer_profile(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            store = JarvisStateStore(Path(directory) / "jarvis.db")
            manager = V11CapabilityManager(store, Path(directory))
            with self.assertRaises(PermissionError):
                manager.set_component_enabled("ui_tars", True)
            manager.update_settings({"safety_profile": "developer"})
            self.assertTrue(manager.set_component_enabled("ui_tars", True)["enabled"])


class V11DesktopTests(unittest.TestCase):
    def test_desktop_plan_is_structured_and_rejects_shell(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            store = JarvisStateStore(Path(directory) / "jarvis.db")
            manager = V11CapabilityManager(store, Path(directory))
            controller = DesktopController(store, manager, Path(directory))
            plan = controller.validate_plan(
                [
                    {"action": "open", "target": "notepad.exe"},
                    {"action": "wait", "seconds": 0.1},
                    {"action": "type_text", "text": "Hallo"},
                ]
            )
            self.assertEqual(len(plan), 3)
            self.assertTrue(controller.plan_requires_confirmation(plan))
            with self.assertRaises(DesktopControlError):
                controller.validate_plan([{"action": "shell", "command": "whoami"}])

    def test_desktop_stop_is_persistent(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            store = JarvisStateStore(Path(directory) / "jarvis.db")
            manager = V11CapabilityManager(store, Path(directory))
            controller = DesktopController(store, manager, Path(directory))
            controller.request_stop()
            self.assertTrue(controller.stop_file.exists())
            controller.clear_stop()
            self.assertFalse(controller.stop_file.exists())

    def test_v11_store_tracks_runs_and_workflows(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            store = V11Store(Path(directory) / "jarvis.db")
            run = store.create_desktop_run("Test", [{"action": "wait", "seconds": 0.1}])
            self.assertEqual(run["status"], "pending")
            store.mark_desktop_running(run["id"])
            finished = store.finish_desktop_run(run["id"], {"ok": True})
            self.assertEqual(finished["status"], "success")
            workflow = store.save_workflow("Testablauf", run["actions"])
            self.assertEqual(workflow["name"], "Testablauf")
            self.assertEqual(len(store.list_workflows()), 1)


class V11ApiAndUiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.client = TestClient(app.app)

    def test_overview_and_component_api(self) -> None:
        overview = self.client.get("/v11/overview")
        self.assertEqual(overview.status_code, 200)
        self.assertEqual(overview.json()["version"], "15.3.0")
        components = self.client.get("/v11/components")
        self.assertEqual(components.status_code, 200)
        self.assertEqual(components.json()["count"], 45)

    def test_realtime_exposes_safe_desktop_planning(self) -> None:
        names = {item.get("name") for item in app._all_realtime_tools()}
        self.assertIn("create_desktop_plan", names)
        permission = app.state_store.permission("desktop_control")
        self.assertTrue(permission["requires_confirmation"])

    def test_ui_contains_agent_os_search_matrix_and_stop(self) -> None:
        html = (Path(__file__).resolve().parents[1] / "static" / "index.html").read_text(
            encoding="utf-8"
        )
        self.assertIn("PC AGENT OS v15.3.0", html)
        self.assertIn('id="v11ModuleSearch"', html)
        self.assertIn('id="v11ModuleList"', html)
        self.assertIn('id="v11EmergencyStopBtn"', html)
        self.assertIn("loadV11Overview", html)
        self.assertIn("create_desktop_plan", html)


if __name__ == "__main__":
    unittest.main()
