from __future__ import annotations

from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from fastapi.testclient import TestClient

import app
import integration_hub as hub_module
from integration_hub import IntegrationConfig, IntegrationHub
from state_store import JarvisStateStore


class TrustedActionStateTests(unittest.TestCase):
    def test_grants_are_persistent_counted_and_revocable(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            store = JarvisStateStore(Path(directory) / "jarvis.db")
            grant = store.grant_trusted_action("send_whatsapp_message", "scope-hash", "WhatsApp an Mama")
            self.assertTrue(store.trusted_action_granted("send_whatsapp_message", "scope-hash", touch=True))
            self.assertEqual(store.list_trusted_actions()[0]["use_count"], 1)
            self.assertTrue(store.revoke_trusted_action(grant["id"]))
            self.assertFalse(store.trusted_action_granted("send_whatsapp_message", "scope-hash"))


class TrustedActionIntegrationTests(unittest.TestCase):
    def test_windows_action_urls_use_startfile_without_command_shell(self) -> None:
        hub = IntegrationHub(lambda: [], IntegrationConfig())
        with (
            patch.object(hub_module.os, "name", "nt"),
            patch.object(hub_module.os, "startfile", create=True) as startfile,
        ):
            self.assertTrue(hub.open_action_url("https://example.com/path?value=1%202"))
        startfile.assert_called_once_with("https://example.com/path?value=1%202")


class TrustedActionApiTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary_directory = tempfile.TemporaryDirectory()
        self.store = JarvisStateStore(Path(self.temporary_directory.name) / "jarvis.db")
        self.hub = IntegrationHub(self.store.list_contacts, IntegrationConfig())
        self.state_patch = patch.object(app, "state_store", self.store)
        self.hub_patch = patch.object(app, "integration_hub", self.hub)
        self.state_patch.start()
        self.hub_patch.start()
        self.client = TestClient(app.app)
        self.client.post(
            "/contacts",
            json={
                "name": "Mama",
                "aliases": ["Mutter"],
                "whatsapp_number": "+436601234567",
                "email": "mama@example.com",
                "telegram_chat_id": "123456789",
            },
        )

    def tearDown(self) -> None:
        self.client.close()
        self.hub_patch.stop()
        self.state_patch.stop()
        self.temporary_directory.cleanup()

    def remember(self, tool_name: str, payload: dict[str, object]) -> dict[str, object]:
        response = self.client.post(
            "/confirmations",
            json={"tool_name": tool_name, "payload": payload, "remember": True},
        )
        self.assertEqual(response.status_code, 200, response.text)
        return response.json()

    def test_alias_scope_can_be_remembered_and_reused_without_prompt(self) -> None:
        first_payload = {"target": "Mutter", "message": "Bin gleich da"}
        check = self.client.post(
            "/trusted-actions/check",
            json={"tool_name": "send_whatsapp_message", "payload": first_payload},
        )
        self.assertFalse(check.json()["granted"])
        self.assertEqual(check.json()["scope_label"], "WhatsApp an Mama")

        remembered = self.remember("send_whatsapp_message", first_payload)
        self.assertTrue(remembered["remembered"])
        with patch.object(self.hub, "open_action_url", return_value=True) as opener:
            first = self.client.post(
                "/integrations/whatsapp/message",
                json=first_payload,
                headers={
                    "X-Jarvis-Confirmation": remembered["token"],
                    "X-Jarvis-Auto-Open": "true",
                    "Idempotency-Key": "remembered-whatsapp-001",
                },
            )
        self.assertEqual(first.status_code, 200, first.text)
        self.assertEqual(first.json()["authorization"], "always")
        self.assertTrue(first.json()["auto_opened"])
        opener.assert_called_once()

        later = self.client.post(
            "/integrations/whatsapp/message",
            json={"target": "Mama", "message": "Ich bin jetzt da"},
            headers={"Idempotency-Key": "remembered-whatsapp-002"},
        )
        self.assertEqual(later.status_code, 200, later.text)
        self.assertEqual(later.json()["authorization"], "always")

    def test_grant_is_limited_to_one_resolved_recipient(self) -> None:
        payload = {"target": "Mama", "message": "Hallo"}
        self.remember("send_whatsapp_message", payload)
        other = self.client.post(
            "/integrations/whatsapp/message",
            json={"target": "+436609999999", "message": "Hallo"},
        )
        self.assertEqual(other.status_code, 428)

    def test_grant_can_be_listed_and_revoked(self) -> None:
        payload = {"target": "Mama", "message": "Hallo"}
        self.remember("send_whatsapp_message", payload)
        listed = self.client.get("/trusted-actions")
        self.assertEqual(listed.status_code, 200)
        grant = listed.json()["items"][0]
        self.assertNotIn("scope_key", grant)
        revoked = self.client.delete(f"/trusted-actions/{grant['id']}")
        self.assertEqual(revoked.status_code, 200)
        check = self.client.post(
            "/trusted-actions/check",
            json={"tool_name": "send_whatsapp_message", "payload": payload},
        )
        self.assertFalse(check.json()["granted"])

    def test_non_integration_tools_cannot_receive_persistent_grants(self) -> None:
        response = self.client.post(
            "/confirmations",
            json={"tool_name": "restore_backup", "payload": {}, "remember": True},
        )
        self.assertEqual(response.status_code, 400)


class TrustedActionUiTests(unittest.TestCase):
    def test_ui_contains_three_choices_auto_open_and_revoke_manager(self) -> None:
        root = Path(__file__).resolve().parents[1]
        html = (root / "static" / "index.html").read_text(encoding="utf-8")
        for marker in (
            "NUR DIESESMAL",
            "FÜR DIESES ZIEL IMMER",
            'id="trustedActionList"',
            "function loadTrustedActions",
            '"X-Jarvis-Auto-Open": "true"',
            "WIDERRUFEN",
            "all v14 and earlier controls remain available in v15",
        ):
            self.assertIn(marker, html)


if __name__ == "__main__":
    unittest.main()
