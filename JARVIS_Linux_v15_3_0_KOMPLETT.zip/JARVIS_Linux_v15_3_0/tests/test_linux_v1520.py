import fcntl
import json
import os
from pathlib import Path
import subprocess
import tempfile
from unittest.mock import Mock, patch

import pytest
import linux_desktop as desktop
import jarvis_linux as launcher
import jarvis_updater as updater
from integration_hub import IntegrationConfig, IntegrationHub
from v15_core import PcAgentController, PcAgentError
from v11_core import DesktopController, DesktopControlError, V11CapabilityManager
from state_store import JarvisStateStore


@pytest.fixture
def manager(tmp_path):
    return V11CapabilityManager(JarvisStateStore(tmp_path / "test.db"), tmp_path)


def test_program_uses_mint_executable(manager, tmp_path):
    controller = PcAgentController(manager, tmp_path)
    with patch.object(desktop.shutil, "which", side_effect=lambda cmd: "/usr/bin/xed" if cmd == "xed" else None), patch("v15_core.subprocess.Popen") as launch:
        result = controller.open_target("editor")
    assert result["kind"] == "program"
    launch.assert_called_once_with(["/usr/bin/xed"], shell=False, close_fds=True)


def test_terminal_remains_disabled(manager, tmp_path):
    with pytest.raises(PcAgentError, match="Terminal"):
        PcAgentController(manager, tmp_path).open_target("terminal")


@pytest.mark.parametrize("name,content", [("go.desktop", b"[Desktop Entry]"), ("go.sh", b"echo hi"),
                                         ("go.txt", b"#!/bin/sh\necho hi"), ("go", b"\x7fELF0"), ("go.AppImage", b"x")])
def test_executable_documents_rejected(manager, tmp_path, name, content):
    path = tmp_path / name
    path.write_bytes(content)
    with pytest.raises(PcAgentError):
        PcAgentController(manager, tmp_path).resolve_target(str(path))


def test_file_path_is_not_shell_code(manager, tmp_path):
    path = tmp_path / "$(touch OWNED).txt"
    path.write_text("harmless")
    with patch.object(desktop.shutil, "which", return_value="/usr/bin/xdg-open"), patch.object(desktop.subprocess, "run") as run:
        result = PcAgentController(manager, tmp_path).open_target(str(path))
    assert result["kind"] == "file"
    assert run.call_args.args[0] == ["/usr/bin/xdg-open", str(path)]
    assert not (tmp_path / "OWNED").exists()


def test_wayland_rejected_before_any_plan_step(manager, tmp_path):
    manager.update_settings({"desktop_control_enabled": True})
    controller = DesktopController(None, manager, tmp_path)
    with patch.dict(os.environ, {"XDG_SESSION_TYPE": "wayland", "DISPLAY": ":4"}), patch.object(controller, "_execute_action") as action:
        with pytest.raises(DesktopControlError, match="X11"):
            controller.execute([{"action": "open", "target": "editor"}, {"action": "type_text", "text": "hey"}])
        action.assert_not_called()


def test_named_control_rejected_before_open(manager, tmp_path):
    manager.update_settings({"desktop_control_enabled": True})
    controller = DesktopController(None, manager, tmp_path)
    with patch.object(controller, "_execute_action") as action:
        with pytest.raises(DesktopControlError, match="AT-SPI"):
            controller.execute([{"action": "open", "target": "editor"}, {"action": "click_control", "window": "editor", "control": "Save"}])
        action.assert_not_called()


def test_linux_input_keeps_text_out_of_command_arguments():
    with patch.object(desktop, "validate_actions"), patch.object(desktop, "run_interruptible") as run:
        desktop.execute_action({"action": "type_text", "text": "Private Grüße $(echo nope)"}, lambda: None)
    assert run.call_args.kwargs["text"] == "Private Grüße $(echo nope)"
    assert run.call_args.args[0][-2:] == ["--file", "-"]


def test_stop_terminates_pending_input():
    child = Mock()
    child.poll.return_value = None
    child.communicate.return_value = (None, "")
    check_stop = Mock(side_effect=[None, RuntimeError("stopped")])
    with patch.object(desktop.subprocess, "Popen", return_value=child):
        with pytest.raises(RuntimeError, match="stopped"):
            desktop.run_interruptible(["xdotool", "type"], check_stop, text="hello")
    child.terminate.assert_called_once()


def test_linux_whatsapp_default(tmp_path):
    with patch.dict(os.environ, {}, clear=True):
        config = IntegrationConfig.from_environment(base_dir=tmp_path)
    assert config.whatsapp_mode == "web"


def test_windows_modules_cannot_claim_ready(manager):
    items = {item["key"]: item for item in manager.list_components()}
    for key in ["ufo2", "pywinauto", "pywinrt", "pycaw", "pywebview"]:
        assert not items[key]["ready"]
        with pytest.raises(PermissionError):
            manager.set_component_enabled(key, True)


def test_update_rejects_windows_even_if_version_matches(tmp_path):
    manifest = tmp_path / "manifest.json"
    manifest.write_text(json.dumps({"format": "jarvis-update-v1", "version": updater.APP_VERSION, "platform": "windows"}))
    with pytest.raises(updater.UpdateError, match="Linux-Updatekanal"):
        updater.install_update(tmp_path, str(manifest))
    assert not (tmp_path / ".installed_version").exists()


def test_running_server_blocks_update(tmp_path):
    data = tmp_path / "data"
    data.mkdir()
    with (data / "linux-server.lock").open("a+") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        with pytest.raises(updater.UpdateError, match="läuft noch"):
            updater.install_update(tmp_path, "unused")
    assert not (tmp_path / ".update.lock").exists()


def test_port_owned_by_other_installation_is_not_reused(tmp_path):
    with patch.object(launcher, "DATA", tmp_path), patch.object(launcher, "read_server", return_value={"version": launcher.VERSION, "edition": "linux", "installation_id": "other"}), patch.object(launcher.subprocess, "Popen") as spawn:
        with pytest.raises(launcher.LaunchError, match="anderen Installation"):
            launcher.start(browser=False)
        spawn.assert_not_called()


def test_foreign_pid_is_never_killed(tmp_path):
    import psutil
    process = Mock(pid=321)
    process.create_time.return_value = 1000.0
    process.cmdline.return_value = ["python", "unrelated_app.py"]
    (tmp_path / "linux-server.json").write_text(json.dumps({"pid": process.pid, "created": process.create_time()}))
    with patch.object(launcher, "DATA", tmp_path), patch.object(psutil, "Process", return_value=process):
        assert launcher.owned_process() is None
    process.terminate.assert_not_called()


def test_configuration_keeps_existing_values(tmp_path):
    config = tmp_path / ".env"
    config.write_text("OPENAI_API_KEY=old-test-key\nJARVIS_WHATSAPP_MODE=web\n")
    with patch.object(launcher, "ROOT", tmp_path), patch.object(launcher.sys.stdin, "isatty", return_value=True), patch.object(launcher.getpass, "getpass", return_value=""):
        launcher.configure()
    assert config.read_text() == "OPENAI_API_KEY=old-test-key\nJARVIS_WHATSAPP_MODE=web\n"
    assert config.stat().st_mode & 0o777 == 0o600


def test_backend_exposes_linux_identity():
    from fastapi.testclient import TestClient
    import app
    with TestClient(app.app) as client:
        result = client.get("/version").json()
        assert result["edition"] == "linux"
        assert result["installation_id"] == launcher.IDENTITY
        status = client.get("/v15/pc/status").json()
        assert status["linux"]["system"] == "linux"
        assert status["linux"]["named_controls"] is False


@pytest.mark.parametrize("reply,locked", [("(true,)\n", True), ("(false,)\n", False)])
def test_cinnamon_privacy_lock(reply, locked):
    with patch.dict(os.environ, {"DBUS_SESSION_BUS_ADDRESS": "unix:mock"}), patch.object(desktop.shutil, "which", return_value="/usr/bin/gdbus"), patch.object(desktop.subprocess, "run", return_value=Mock(stdout=reply)):
        assert desktop.session_locked() is locked


def test_unknown_linux_lock_state_hides_messages():
    with patch.dict(os.environ, {}, clear=True):
        assert desktop.session_locked() is True
