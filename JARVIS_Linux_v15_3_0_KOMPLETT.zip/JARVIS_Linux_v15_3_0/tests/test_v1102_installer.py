from __future__ import annotations

import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class V1102InstallerTests(unittest.TestCase):
    def test_litellm_uses_verified_universal_wheel(self) -> None:
        requirements = (ROOT / "requirements-v11-agents.txt").read_text(encoding="utf-8")
        self.assertIn("litellm==1.91.4", requirements)
        self.assertNotIn("litellm>=1.70\n", requirements)

    def test_installer_rejects_litellm_source_build(self) -> None:
        script = (ROOT / "module_installer.ps1").read_text(encoding="utf-8")
        self.assertIn('"--only-binary", "litellm"', script)
        self.assertNotIn("Tee-Object -FilePath $LogFile", script)


if __name__ == "__main__":
    unittest.main()
