from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from state_store import JarvisStateStore
from v11_core import COMPONENTS, V11CapabilityManager


ROOT = Path(__file__).resolve().parents[1]


class V1101InstallerTests(unittest.TestCase):
    def test_installer_uses_python_312_and_isolated_environments(self) -> None:
        script = (ROOT / "module_installer.ps1").read_text(encoding="utf-8")
        self.assertIn("Python.Python.3.12", script)
        self.assertIn('Join-Path $Root ".venv"', script)
        self.assertIn('Join-Path $Root ".jarvis_envs"', script)
        self.assertIn('"open-interpreter"', script)
        self.assertIn('"openadapt"', script)
        self.assertIn('"ovos"', script)
        self.assertIn('"playwright", "install", "chromium"', script)
        self.assertIn('"pip", "check"', script)

    def test_conflicting_packages_are_separated(self) -> None:
        voice = (ROOT / "requirements-v11-voice.txt").read_text(encoding="utf-8")
        memory = (ROOT / "requirements-v11-memory.txt").read_text(encoding="utf-8")
        experimental = (ROOT / "requirements-v11-experimental.txt").read_text(encoding="utf-8")
        self.assertNotIn("ovos-core", voice)
        self.assertIn("ovos-core", (ROOT / "requirements-v11-ovos.txt").read_text(encoding="utf-8"))
        self.assertIn("sqlcipher3-wheels", memory)
        self.assertNotIn("sqlcipher3-binary", memory)
        self.assertNotIn("open-interpreter>=", experimental)
        self.assertNotIn("openadapt>=", experimental)

    def test_windows_launchers_use_project_venv(self) -> None:
        for name in (
            "STARTEN.bat",
            "JARVIS_APP_STARTEN.bat",
            "GMAIL_VERBINDEN.bat",
            "OUTLOOK_VERBINDEN.bat",
            "WHATSAPP_VERBINDEN.bat",
            "SECRETS_SCHUETZEN.bat",
        ):
            content = (ROOT / name).read_text(encoding="utf-8")
            self.assertIn('.venv\\Scripts\\python.exe', content, name)
            self.assertNotIn("\npy ", content, name)

    def test_isolated_component_is_reported_installed(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            store = JarvisStateStore(base / "jarvis.db")
            manager = V11CapabilityManager(store, base)
            environment = base / ".jarvis_envs" / "openadapt"
            scripts = environment / "bin"
            scripts.mkdir(parents=True)
            (environment / ".jarvis-installed").touch()
            (environment / ".jarvis-playwright-ready").touch()
            (scripts / "python").touch()
            component = next(item for item in COMPONENTS if item.key == "openadapt")
            self.assertTrue(manager._installed(component))


if __name__ == "__main__":
    unittest.main()
