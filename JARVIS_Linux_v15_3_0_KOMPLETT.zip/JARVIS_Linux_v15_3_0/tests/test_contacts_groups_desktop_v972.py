from __future__ import annotations

import asyncio
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from fastapi.testclient import TestClient

import app
from integration_hub import IntegrationConfig, IntegrationError, IntegrationHub, normalize_identity
from state_store import JarvisStateStore


class ContactAndGroupStoreTests(unittest.TestCase):
    def test_existing_contacts_migrate_and_new_fields_persist(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            store = JarvisStateStore(Path(directory) / "jarvis.db")
            contact = store.save_contact(
                name="Frau Müller",
                aliases=["Mathelehrerin"],
                whatsapp_chat_name="Müller Schule",
                email="mueller@example.edu",
                relationship="Lehrerin",
                organization="HTL Villach",
                preferred_channel="email",
            )
            self.assertEqual(contact["relationship"], "Lehrerin")
            self.assertEqual(contact["preferred_channel"], "email")
            self.assertEqual(contact["use_count"], 0)
            store.touch_communication_target("contact", contact["id"])
            self.assertEqual(store.get_contact(contact["id"])["use_count"], 1)

    def test_whatsapp_groups_persist_aliases_and_usage(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            store = JarvisStateStore(Path(directory) / "jarvis.db")
            group = store.save_whatsapp_group(
                name="Familie",
                aliases=["Familiengruppe"],
                chat_name="Familie 👨‍👩‍👧‍👦",
            )
            self.assertEqual(store.get_whatsapp_group(group["id"])["aliases"], ["Familiengruppe"])
            store.touch_communication_target("group", group["id"])
            self.assertEqual(store.get_whatsapp_group(group["id"])["use_count"], 1)


class WhatsAppDesktopRoutingTests(unittest.TestCase):
    def test_identity_matching_ignores_accents_case_and_punctuation(self) -> None:
        self.assertEqual(normalize_identity("FRAU-MÜLLER!"), "frau muller")

    def test_contact_and_group_are_sent_through_desktop_with_exact_target_type(self) -> None:
        contacts = [
            {
                "id": 1,
                "name": "Frau Müller",
                "aliases": ["Mathelehrerin"],
                "whatsapp_number": "436601234567",
                "whatsapp_chat_name": "Müller Schule",
            }
        ]
        groups = [
            {
                "id": 2,
                "name": "Familie",
                "aliases": ["Familiengruppe"],
                "chat_name": "Familie 👨‍👩‍👧‍👦",
            }
        ]
        used: list[tuple[str, int]] = []
        hub = IntegrationHub(
            lambda: contacts,
            IntegrationConfig(whatsapp_mode="desktop", whatsapp_desktop_auto_send=True),
            group_supplier=lambda: groups,
            usage_recorder=lambda kind, target_id: used.append((kind, target_id)),
        )
        with patch.object(hub, "_send_whatsapp_desktop") as sender:
            contact_result = asyncio.run(hub.whatsapp_message("frau muller", "Hallo", "contact"))
            group_result = asyncio.run(hub.whatsapp_message("Familiengruppe", "Bin später da", "group"))
        self.assertEqual(
            sender.call_args_list[0].args,
            ("contact", "436601234567", "Müller Schule", "Hallo"),
        )
        self.assertEqual(
            sender.call_args_list[1].args,
            ("group", "Familie 👨‍👩‍👧‍👦", "Familie 👨‍👩‍👧‍👦", "Bin später da"),
        )
        self.assertEqual(contact_result["mode"], "desktop_auto")
        self.assertEqual(group_result["target_kind"], "group")
        self.assertEqual(used, [("contact", 1), ("group", 2)])

    def test_unknown_group_is_never_guessed(self) -> None:
        hub = IntegrationHub(
            lambda: [],
            IntegrationConfig(whatsapp_mode="desktop", whatsapp_desktop_auto_send=True),
            group_supplier=lambda: [],
        )
        with self.assertRaises(IntegrationError):
            asyncio.run(hub.whatsapp_message("Ähnliche Familie", "Hallo", "group"))


class ContactAndGroupApiTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary_directory = tempfile.TemporaryDirectory()
        self.store = JarvisStateStore(Path(self.temporary_directory.name) / "jarvis.db")
        self.hub = IntegrationHub(
            self.store.list_contacts,
            IntegrationConfig(),
            group_supplier=self.store.list_whatsapp_groups,
            usage_recorder=self.store.touch_communication_target,
        )
        self.state_patch = patch.object(app, "state_store", self.store)
        self.hub_patch = patch.object(app, "integration_hub", self.hub)
        self.state_patch.start()
        self.hub_patch.start()
        self.client = TestClient(app.app)

    def tearDown(self) -> None:
        self.client.close()
        self.hub_patch.stop()
        self.state_patch.stop()
        self.temporary_directory.cleanup()

    def test_group_crud_and_private_chat_name_is_hidden_from_model_list(self) -> None:
        response = self.client.post(
            "/whatsapp-groups",
            json={
                "name": "Familie",
                "aliases": ["Familiengruppe"],
                "chat_name": "Familie Privat 👨‍👩‍👧‍👦",
                "notes": "Privat",
            },
        )
        self.assertEqual(response.status_code, 200, response.text)
        group_id = response.json()["item"]["id"]
        visible = self.client.get("/contacts").json()["items"][0]
        self.assertEqual(visible["kind"], "whatsapp_group")
        self.assertNotIn("chat_name", visible)
        self.assertNotIn("notes", visible)
        payload = {"group_id": group_id}
        token = self.client.post(
            "/confirmations",
            json={"tool_name": "manage_contacts", "payload": payload},
        ).json()["token"]
        deleted = self.client.delete(
            f"/whatsapp-groups/{group_id}",
            headers={"X-Jarvis-Confirmation": token},
        )
        self.assertEqual(deleted.status_code, 200, deleted.text)

    def test_contact_group_identity_collision_is_rejected_accent_insensitively(self) -> None:
        contact = self.client.post("/contacts", json={"name": "Müller"})
        self.assertEqual(contact.status_code, 200, contact.text)
        group = self.client.post(
            "/whatsapp-groups",
            json={"name": "Muller", "chat_name": "Muller"},
        )
        self.assertEqual(group.status_code, 409, group.text)


class V972UiAndPromptTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        root = Path(__file__).resolve().parents[1]
        cls.html = (root / "static" / "index.html").read_text(encoding="utf-8")
        cls.source = (root / "app.py").read_text(encoding="utf-8")

    def test_ui_exposes_v972_contacts_groups_and_desktop(self) -> None:
        for marker in (
            "all v14 and earlier controls remain available in v15",
            'id="contactRelationship"',
            'id="contactPreferredChannel"',
            'id="whatsappGroupChatName"',
            'id="whatsappGroupList"',
            "WhatsApp wird über die installierte Desktop-App geöffnet",
        ):
            self.assertIn(marker, self.html)

    def test_prompt_asks_for_missing_message_and_routes_groups(self) -> None:
        self.assertIn("Was soll ich schreiben?", self.source)
        self.assertIn("target_kind='group'", self.source)
        self.assertIn('"group_count"', self.source)


if __name__ == "__main__":
    unittest.main()
