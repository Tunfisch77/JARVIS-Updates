from pathlib import Path
import unittest


class UiAudioLifecycleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.html = (Path(__file__).resolve().parents[1] / "static" / "index.html").read_text(encoding="utf-8")

    def test_sleep_timer_waits_for_audio_buffer(self) -> None:
        self.assertIn('event.type === "output_audio_buffer.started"', self.html)
        self.assertIn('event.type === "output_audio_buffer.stopped"', self.html)
        self.assertIn("activeAudioResponses.size > 0", self.html)
        self.assertIn("Der Ruhemodus wartet, bis die Sprachausgabe vollständig beendet ist.", self.html)

    def test_final_audio_transcript_repairs_missing_live_deltas(self) -> None:
        self.assertIn('event.type === "response.output_audio_transcript.done"', self.html)
        self.assertIn("updateTranscriptPart(event, event.transcript)", self.html)
        self.assertIn('event.type === "response.content_part.done"', self.html)
        self.assertIn("finalTranscriptFromResponse(event.response)", self.html)

        response_done = self.html.split('event.type === "response.done"', 1)[1]
        final_sync = response_done.index("synchronizeFinalTranscript")
        persistence = response_done.index('persistHistory("jarvis", rawContent)')
        self.assertLess(final_sync, persistence)


if __name__ == "__main__":
    unittest.main()
