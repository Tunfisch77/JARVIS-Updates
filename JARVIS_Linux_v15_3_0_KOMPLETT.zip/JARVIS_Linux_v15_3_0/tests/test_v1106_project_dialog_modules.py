from __future__ import annotations

import os

import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import app
from fastapi.testclient import TestClient
from local_project import LocalProjectManager
from v11_core import V11CapabilityManager


class MemorySettings:
    def __init__(self) -> None:
        self.values: dict[str, object] = {}

    def get_setting(self, key: str, default: object = None) -> object:
        return self.values.get(key, default)

    def set_setting(self, key: str, value: object) -> None:
        self.values[key] = value


class ActiveProjectContextTests(unittest.TestCase):
    def test_active_project_is_injected_into_realtime_instructions(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            project = root / "snake"
            project.mkdir()
            (project / "index.html").write_text("<canvas></canvas>\n", encoding="utf-8")
            manager = LocalProjectManager(MemorySettings(), root / "backups")
            manager.remember_project(str(project))
            with patch.object(app, "local_project_manager", manager):
                instructions = app._active_project_instruction()
            self.assertIn(str(project.resolve()), instructions)
            self.assertIn("modify_code_project", instructions)
            self.assertIn("verlange niemals einen erneuten ZIP-Upload", instructions)

    def test_missing_active_project_asks_for_path_not_zip(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            manager = LocalProjectManager(MemorySettings(), root / "backups")
            with patch.object(app, "local_project_manager", manager):
                instructions = app._active_project_instruction()
            self.assertIn("vollständigem absoluten Ordnerpfad", instructions)
            self.assertIn("Verlange keine ZIP-Datei", instructions)

    def test_active_project_is_adopted_from_previous_sibling_version(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            current = root / "JARVIS_VisionVoice_v11_0_7"
            current.mkdir()
            previous_data = root / "JARVIS_VisionVoice_v11_0_5" / "data"
            previous_data.mkdir(parents=True)
            project = root / "mein-spiel"
            project.mkdir()
            database = previous_data / "jarvis.db"
            with sqlite3.connect(database) as connection:
                connection.execute(
                    "CREATE TABLE settings (key TEXT PRIMARY KEY, value_json TEXT NOT NULL)"
                )
                connection.execute(
                    "INSERT INTO settings(key, value_json) VALUES (?, ?)",
                    (
                        LocalProjectManager.ACTIVE_SETTING,
                        json.dumps({"path": str(project), "name": project.name}),
                    ),
                )
            manager = LocalProjectManager(MemorySettings(), root / "backups")
            imported = app._import_previous_active_project(
                manager,
                search_root=root,
                current_directory=current,
            )
            self.assertEqual(imported, database)
            self.assertEqual(manager.active_project()["path"], str(project.resolve()))


class ActivateAllModulesTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.client = TestClient(app.app)

    def test_balanced_profile_enables_every_ready_noncritical_module(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            store = MemorySettings()
            manager = V11CapabilityManager(store, Path(directory))
            with (
                patch.object(manager, "_installed", return_value=True),
                patch.object(manager, "_configured", return_value=True),
            ):
                result = manager.enable_all_ready()
            self.assertEqual(result["active_ready_count"], 43 if os.name == "nt" else 38)
            self.assertEqual(set(result["blocked"]), {"ui_tars", "open_interpreter"})
            self.assertFalse(result["restart_required"])
            self.assertTrue(result["reconnect_recommended"])

    def test_developer_profile_can_enable_all_45_ready_modules(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            store = MemorySettings()
            manager = V11CapabilityManager(store, Path(directory))
            store.set_setting("v11_settings", {**manager.settings(), "safety_profile": "developer"})
            with (
                patch.object(manager, "_installed", return_value=True),
                patch.object(manager, "_configured", return_value=True),
            ):
                result = manager.enable_all_ready()
            self.assertEqual(result["active_ready_count"], 45 if os.name == "nt" else 40)
            self.assertEqual(result["blocked"], [])

    def test_activate_all_api_requires_and_accepts_visible_confirmation(self) -> None:
        result = {
            "enabled": ["playwright"],
            "already_enabled": [],
            "not_ready": [],
            "blocked": [],
            "enabled_count": 1,
            "active_ready_count": 1,
            "restart_required": False,
            "reconnect_recommended": True,
        }
        with patch.object(app.v11_capabilities, "enable_all_ready", return_value=result):
            missing = self.client.post("/v11/components/activate-all")
            confirmed = self.client.post(
                "/v11/components/activate-all",
                headers={"X-Jarvis-Confirmed": "true"},
            )
        self.assertEqual(missing.status_code, 428)
        self.assertEqual(confirmed.status_code, 200, confirmed.text)
        self.assertEqual(confirmed.json()["active_ready_count"], 1)


class JarvisDialogUiTests(unittest.TestCase):
    def test_native_confirm_dialogs_are_replaced(self) -> None:
        html = (Path(__file__).resolve().parents[1] / "static" / "index.html").read_text(encoding="utf-8")
        self.assertNotIn("window.confirm(", html)
        self.assertIn("function jarvisConfirm(", html)
        self.assertIn('id="v11ActivateAllBtn"', html)
        self.assertIn('id="activateAllV11ModulesBtn"', html)
        self.assertIn("/v11/components/activate-all", html)

    def test_release_version_is_1200(self) -> None:
        self.assertEqual(app.APP_VERSION, "15.3.0")


if __name__ == "__main__":
    unittest.main()
