from __future__ import annotations

import unittest

from integration_hub import IntegrationError
from integrations_setup import (
    _confirm_web_profile_ready,
    _snapchat_page_has_chat_ui,
    _snapchat_session_is_ready,
)


class FakePage:
    def __init__(self, url: str) -> None:
        self.url = url
        self.locator_calls: list[str] = []

    def locator(self, selector: str) -> object:
        self.locator_calls.append(selector)
        raise AssertionError("Snapchat readiness must not depend on a visible body.")


class SnapchatIntegrationSetupTests(unittest.TestCase):
    def test_logged_in_snapchat_web_url_is_ready(self) -> None:
        self.assertTrue(_snapchat_session_is_ready("https://web.snapchat.com/"))
        self.assertTrue(
            _snapchat_session_is_ready("https://web.snapchat.com/conversations/example")
        )
        self.assertTrue(_snapchat_session_is_ready("https://www.snapchat.com/web"))
        self.assertTrue(_snapchat_session_is_ready("https://snapchat.com/web/chat"))

    def test_snapchat_account_login_url_is_not_ready(self) -> None:
        self.assertFalse(
            _snapchat_session_is_ready("https://accounts.snapchat.com/accounts/login")
        )

    def test_similar_external_domain_is_not_accepted(self) -> None:
        self.assertFalse(_snapchat_session_is_ready("https://web.snapchat.com.example.org/"))
        self.assertFalse(_snapchat_session_is_ready("http://web.snapchat.com/"))
        self.assertFalse(_snapchat_session_is_ready("https://www.snapchat.com/"))

    def test_visible_chat_ui_is_accepted_when_snapchat_changes_url(self) -> None:
        class Locator:
            def count(self) -> int:
                return 1

        class ChatPage(FakePage):
            def locator(self, selector: str) -> object:
                self.locator_calls.append(selector)
                if selector == "[data-testid*='conversation']":
                    return Locator()
                raise RuntimeError("not found")

        page = ChatPage("https://accounts.snapchat.com/")
        self.assertTrue(_snapchat_page_has_chat_ui(page))
        _confirm_web_profile_ready(page, name="Snapchat Web", ready_selector=None)

    def test_snapchat_does_not_wait_for_hidden_body(self) -> None:
        page = FakePage("https://web.snapchat.com/")
        _confirm_web_profile_ready(page, name="Snapchat Web", ready_selector="body")
        self.assertEqual(page.locator_calls, [])

    def test_logged_out_snapchat_gets_clean_integration_error(self) -> None:
        page = FakePage("https://accounts.snapchat.com/accounts/login")
        with self.assertRaisesRegex(IntegrationError, "noch nicht angemeldet"):
            _confirm_web_profile_ready(page, name="Snapchat Web", ready_selector=None)


if __name__ == "__main__":
    unittest.main()
