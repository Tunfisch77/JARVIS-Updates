from pathlib import Path
import unittest

import app


class VoiceIsolationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.html = (Path(__file__).resolve().parents[1] / "static" / "index.html").read_text(encoding="utf-8")

    def test_noise_profiles_raise_threshold_in_noisy_rooms(self) -> None:
        self.assertEqual(app.APP_VERSION, "15.3.0")
        strong = app.voice_activity_settings("strong")
        balanced = app.voice_activity_settings("balanced")
        sensitive = app.voice_activity_settings("sensitive")
        self.assertGreater(strong["threshold"], balanced["threshold"])
        self.assertGreater(balanced["threshold"], sensitive["threshold"])
        for profile in (strong, balanced, sensitive):
            self.assertFalse(profile["interrupt_response"])
            self.assertFalse(profile["create_response"])
            self.assertEqual(profile["type"], "server_vad")

    def test_background_sound_does_not_interrupt_immediately(self) -> None:
        speech_start = self.html.split('event.type === "input_audio_buffer.speech_started"', 1)[1]
        speech_start = speech_start.split('event.type === "input_audio_buffer.speech_stopped"', 1)[0]
        self.assertNotIn("interruptJarvis()", speech_start)
        self.assertIn("pendingBargeInItems.add", speech_start)
        self.assertIn("VOICE ISOLATION ACTIVE", speech_start)
        self.assertIn('id="noiseProfile"', self.html)
        self.assertIn("echoCancellation: true", self.html)
        self.assertIn("noiseSuppression: true", self.html)


if __name__ == "__main__":
    unittest.main()
