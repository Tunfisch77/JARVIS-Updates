@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo JARVIS wird beim ersten Start automatisch eingerichtet...
  call "%~dp0MODULE_INSTALLIEREN.bat" --auto
  if errorlevel 1 (
    echo Die Installation konnte nicht abgeschlossen werden.
    echo Fehlerbericht: data\installer\module-install.log
    pause
    exit /b 1
  )
)
echo Starte JARVIS v15.0.0 als Windows-App...
".venv\Scripts\python.exe" desktop_shell.py
if errorlevel 1 pause
