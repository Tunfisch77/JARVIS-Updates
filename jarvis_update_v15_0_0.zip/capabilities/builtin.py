from __future__ import annotations

from .registry import Capability, CapabilityRegistry


def build_registry(readiness: dict[str, bool] | None = None) -> CapabilityRegistry:
    readiness = readiness or {}
    ready = lambda key, default=True: bool(readiness.get(key, default))
    registry = CapabilityRegistry()
    for capability in (
        Capability("reasoning", "Advanced Reasoning", "AI", "Delegiert schwierige Aufgaben an Luna oder Terra.", "solve_complex_task"),
        Capability("memory_write", "Memory Write", "Memory", "Speichert ausdrücklich gewünschte Nutzerinformationen.", "remember_user_fact"),
        Capability("memory_read", "Memory Recall", "Memory", "Sucht in lokalen Erinnerungen.", "recall_user_memory"),
        Capability("home_state", "Smart-Home Status", "Smart Home", "Liest reale oder simulierte Gerätezustände.", "get_home_state"),
        Capability("home_control", "Smart-Home Control", "Smart Home", "Steuert freigegebene reale oder simulierte Geräte.", "control_home_device"),
        Capability("camera_events", "Camera Events", "Vision", "Liest Frigate- oder simulierte Kameraereignisse.", "get_recent_camera_events"),
        Capability("timers", "Timers", "Productivity", "Erstellt lokale Timer und Erinnerungen.", "create_timer"),
        Capability("timer_cancel", "Cancel Timers", "Productivity", "Beendet einen aktiven Timer.", "cancel_timer"),
        Capability("diagnostics", "Diagnostics", "System", "Liest lokale System- und Fehlerdiagnosen.", "get_system_diagnostics"),
        Capability("web_search", "Web Search", "Online", "Sucht aktuelle Informationen im Internet und liefert Quellen.", "search_web"),
        Capability("file_analysis", "File & Photo Analysis", "AI", "Analysiert temporär übergebene Fotos, Dokumente und Codedateien.", "analyze_attachments"),
        Capability("contacts", "Contacts", "Integration Hub", "Löst eindeutige Namen und Aliase aus dem lokalen Kontaktbuch auf.", "list_contacts"),
        Capability("whatsapp", "WhatsApp", "Communication", "Bereitet persönliche Nachrichten sicher vor oder sendet über eine konfigurierte Business Cloud API.", "send_whatsapp_message"),
        Capability("telegram", "Telegram", "Communication", "Sendet bestätigte Nachrichten über einen konfigurierten Telegram-Bot.", "send_telegram_message", ready=ready("telegram", False), requires=("TELEGRAM_BOT_TOKEN",)),
        Capability("email", "E-Mail", "Communication", "Bereitet E-Mails vor oder sendet sie über ausdrücklich konfiguriertes SMTP.", "send_email"),
        Capability("calendar", "Calendar", "Productivity", "Bereitet Termine mit Zeit, Ort, Beschreibung und Teilnehmern vor.", "create_calendar_event"),
        Capability("webhooks", "Automation Webhooks", "Automation", "Löst ausschließlich in der .env freigegebene Automations-Webhooks aus.", "trigger_webhook", ready=ready("webhooks", False), requires=("JARVIS_WEBHOOKS_JSON",)),
        Capability("pc_control", "PC Launcher", "System", "Öffnet freigegebene Webseiten, Windows-Programme und Systemeinstellungen.", "open_app_or_website"),
        Capability("pc_target", "PC Target Opener", "PC Agent", "Öffnet nach Bestätigung ein eindeutig genanntes Programm, eine Datei oder einen Ordner.", "open_pc_target"),
        Capability("pc_screen", "One-shot Screen Analysis", "PC Agent", "Analysiert nach Bestätigung genau ein aktuelles Bildschirmbild und speichert es nicht.", "desktop_observe"),
        Capability("pc_action_list", "PC Action Status", "PC Agent", "Liest Status und Fortschritt der letzten Desktop-Aktionen.", "list_pc_actions"),
        Capability("pc_action_repeat", "Repeat PC Action", "PC Agent", "Wiederholt nach Bestätigung einen sichtbaren Desktop-Plan als neuen Lauf.", "repeat_pc_action"),
        Capability("pc_action_stop", "Stop PC Action", "PC Agent", "Stoppt eine laufende Desktop-Aktion sofort.", "stop_pc_action"),
        Capability("desktop_project", "Project Builder", "Agent OS", "Erstellt nach Bestätigung vollständige neue Codeprojekte genau am ausdrücklich gewählten Zielpfad.", "create_desktop_project"),
        Capability("project_editor", "Project Editor", "Agent OS", "Bearbeitet das aktive lokale Codeprojekt nach Backup und sichtbarer Bestätigung direkt in seinem echten Ordner.", "modify_code_project"),
        Capability("desktop_plan", "Desktop Agent Plan", "Agent OS", "Erstellt einen sichtbaren, bestätigungspflichtigen Maus-/Tastaturplan für Windows.", "create_desktop_plan"),
        Capability("weather", "Weather", "Online", "Wetterdaten über einen späteren Provider.", ready=False, default_enabled=False, requires=("weather_provider",)),
        Capability("face_recognition", "Face Recognition", "Vision", "Türkamera und CompreFace anbinden.", ready=False, default_enabled=False, requires=("compreface", "camera")),
    ):
        registry.register(capability)
    return registry
