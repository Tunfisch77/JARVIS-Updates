@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title JARVIS Update
echo.
echo JARVIS wird auf Updates geprueft...
echo Bitte JARVIS und alle JARVIS-Browserfenster vorher schliessen.
echo.
if not exist ".venv\Scripts\python.exe" (
  echo Die JARVIS-Python-Umgebung fehlt. Starte zuerst JARVIS_APP_STARTEN.bat.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" jarvis_updater.py
if errorlevel 1 (
  echo.
  echo Es wurde nichts an deiner Installation geaendert.
  pause
  exit /b 1
)
echo.
echo Update abgeschlossen. JARVIS wird gestartet...
start "" "%~dp0JARVIS_APP_STARTEN.bat"
exit /b 0
