from __future__ import annotations

import json
import secrets
import sqlite3
from datetime import UTC, datetime
from pathlib import Path
from typing import Any


class V11Store:
    """Small persistence layer for desktop runs and learned workflows."""

    def __init__(self, database_path: Path) -> None:
        self.database_path = database_path
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.database_path, timeout=5)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA foreign_keys=ON")
        return connection

    @staticmethod
    def _now() -> str:
        return datetime.now(UTC).isoformat(timespec="seconds")

    @staticmethod
    def _encode(value: object) -> str:
        return json.dumps(value, ensure_ascii=False, default=str)

    @staticmethod
    def _decode(value: str | None, fallback: object) -> Any:
        try:
            return json.loads(value or "")
        except (TypeError, json.JSONDecodeError):
            return fallback

    def _initialize(self) -> None:
        with self._connect() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS desktop_runs (
                    id TEXT PRIMARY KEY,
                    title TEXT NOT NULL,
                    actions_json TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'pending',
                    result_json TEXT,
                    error TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    started_at TEXT,
                    finished_at TEXT
                );

                CREATE TABLE IF NOT EXISTS learned_workflows (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL COLLATE NOCASE UNIQUE,
                    description TEXT NOT NULL DEFAULT '',
                    actions_json TEXT NOT NULL,
                    enabled INTEGER NOT NULL DEFAULT 1,
                    use_count INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    last_used_at TEXT
                );

                CREATE TABLE IF NOT EXISTS knowledge_edges (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    subject TEXT NOT NULL,
                    relation TEXT NOT NULL,
                    object TEXT NOT NULL,
                    valid_from TEXT,
                    valid_until TEXT,
                    source TEXT NOT NULL DEFAULT 'jarvis',
                    confidence REAL NOT NULL DEFAULT 1.0,
                    created_at TEXT NOT NULL,
                    UNIQUE(subject, relation, object, valid_from)
                );

                CREATE INDEX IF NOT EXISTS idx_desktop_runs_created ON desktop_runs(created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_knowledge_subject ON knowledge_edges(subject, relation);
                """
            )

    def create_desktop_run(self, title: str, actions: list[dict[str, Any]]) -> dict[str, Any]:
        run_id = f"desktop-{secrets.token_hex(8)}"
        now = self._now()
        with self._connect() as connection:
            connection.execute(
                "INSERT INTO desktop_runs(id, title, actions_json, created_at) VALUES (?, ?, ?, ?)",
                (run_id, title.strip()[:180] or "Desktop-Aufgabe", self._encode(actions), now),
            )
        return self.get_desktop_run(run_id) or {}

    def get_desktop_run(self, run_id: str) -> dict[str, Any] | None:
        with self._connect() as connection:
            row = connection.execute("SELECT * FROM desktop_runs WHERE id = ?", (run_id,)).fetchone()
        return self._run_item(row) if row else None

    def _run_item(self, row: sqlite3.Row) -> dict[str, Any]:
        return {
            "id": row["id"],
            "title": row["title"],
            "actions": self._decode(row["actions_json"], []),
            "status": row["status"],
            "result": self._decode(row["result_json"], None),
            "error": row["error"],
            "created_at": row["created_at"],
            "started_at": row["started_at"],
            "finished_at": row["finished_at"],
        }

    def list_desktop_runs(self, limit: int = 30) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT * FROM desktop_runs ORDER BY created_at DESC LIMIT ?",
                (max(1, min(100, int(limit))),),
            ).fetchall()
        return [self._run_item(row) for row in rows]

    def mark_desktop_running(self, run_id: str) -> None:
        with self._connect() as connection:
            connection.execute(
                "UPDATE desktop_runs SET status = 'running', started_at = ?, error = '' WHERE id = ?",
                (self._now(), run_id),
            )

    def finish_desktop_run(self, run_id: str, result: dict[str, Any]) -> dict[str, Any] | None:
        with self._connect() as connection:
            connection.execute(
                "UPDATE desktop_runs SET status = 'success', result_json = ?, finished_at = ?, error = '' WHERE id = ?",
                (self._encode(result), self._now(), run_id),
            )
        return self.get_desktop_run(run_id)

    def fail_desktop_run(self, run_id: str, error: str) -> dict[str, Any] | None:
        with self._connect() as connection:
            connection.execute(
                "UPDATE desktop_runs SET status = 'failed', error = ?, finished_at = ? WHERE id = ?",
                (str(error)[:2_000], self._now(), run_id),
            )
        return self.get_desktop_run(run_id)

    def stop_desktop_run(self, run_id: str, message: str = "Vom Nutzer gestoppt.") -> dict[str, Any] | None:
        with self._connect() as connection:
            connection.execute(
                "UPDATE desktop_runs SET status = 'stopped', error = ?, finished_at = ? WHERE id = ?",
                (str(message)[:2_000], self._now(), run_id),
            )
        return self.get_desktop_run(run_id)

    def clone_desktop_run(self, run_id: str) -> dict[str, Any] | None:
        source = self.get_desktop_run(run_id)
        if not source:
            return None
        title = str(source["title"])
        if not title.endswith("(Wiederholung)"):
            title = f"{title} (Wiederholung)"
        return self.create_desktop_run(title[:180], list(source["actions"]))

    def save_workflow(
        self,
        name: str,
        actions: list[dict[str, Any]],
        description: str = "",
    ) -> dict[str, Any]:
        clean_name = " ".join(name.split())[:160]
        if not clean_name:
            raise ValueError("Der Workflow benötigt einen Namen.")
        now = self._now()
        workflow_id = f"workflow-{secrets.token_hex(8)}"
        with self._connect() as connection:
            existing = connection.execute(
                "SELECT id FROM learned_workflows WHERE name = ? COLLATE NOCASE",
                (clean_name,),
            ).fetchone()
            if existing:
                workflow_id = existing["id"]
                connection.execute(
                    """
                    UPDATE learned_workflows
                    SET description = ?, actions_json = ?, updated_at = ?
                    WHERE id = ?
                    """,
                    (description.strip()[:1_000], self._encode(actions), now, workflow_id),
                )
            else:
                connection.execute(
                    """
                    INSERT INTO learned_workflows(
                        id, name, description, actions_json, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        workflow_id,
                        clean_name,
                        description.strip()[:1_000],
                        self._encode(actions),
                        now,
                        now,
                    ),
                )
        return self.get_workflow(workflow_id) or {}

    def get_workflow(self, workflow_id: str) -> dict[str, Any] | None:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT * FROM learned_workflows WHERE id = ?",
                (workflow_id,),
            ).fetchone()
        if not row:
            return None
        return {
            "id": row["id"],
            "name": row["name"],
            "description": row["description"],
            "actions": self._decode(row["actions_json"], []),
            "enabled": bool(row["enabled"]),
            "use_count": int(row["use_count"]),
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
            "last_used_at": row["last_used_at"],
        }

    def list_workflows(self) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT id FROM learned_workflows ORDER BY updated_at DESC"
            ).fetchall()
        return [item for row in rows if (item := self.get_workflow(row["id"]))]
