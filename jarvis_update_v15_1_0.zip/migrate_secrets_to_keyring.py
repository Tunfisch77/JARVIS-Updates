from __future__ import annotations

import re
from pathlib import Path

from secure_config import KEYRING_SERVICE, SECRET_ENVIRONMENT_KEYS


BASE_DIR = Path(__file__).resolve().parent
ENV_FILE = BASE_DIR / ".env"


def main() -> None:
    try:
        import keyring
    except ImportError as exc:
        raise SystemExit("keyring fehlt. Fuehre zuerst INSTALLIEREN.bat aus.") from exc
    if not ENV_FILE.exists():
        raise SystemExit(".env wurde nicht gefunden.")
    answer = input(
        "Secrets werden in den Windows Credential Manager verschoben und danach aus .env entfernt. EXAKT VERSCHIEBEN eingeben: "
    )
    if answer != "VERSCHIEBEN":
        raise SystemExit("Abgebrochen.")
    text = ENV_FILE.read_text(encoding="utf-8")
    lines = text.splitlines()
    migrated: list[str] = []
    output: list[str] = []
    for line in lines:
        match = re.match(r"^([A-Za-z_][A-Za-z0-9_]*)=(.*)$", line)
        if not match or match.group(1) not in SECRET_ENVIRONMENT_KEYS:
            output.append(line)
            continue
        key, raw_value = match.groups()
        value = raw_value.strip().strip("\"'")
        if not value:
            output.append(line)
            continue
        keyring.set_password(KEYRING_SERVICE, key, value)
        output.append(f"{key}=")
        migrated.append(key)
    ENV_FILE.write_text("\n".join(output) + "\n", encoding="utf-8")
    if not migrated:
        print("Keine passenden Secrets in .env gefunden.")
        return
    print(f"{len(migrated)} Secrets verschoben: {', '.join(migrated)}")
    print("JARVIS liest sie beim Start nur in den laufenden Prozess ein.")


if __name__ == "__main__":
    main()
