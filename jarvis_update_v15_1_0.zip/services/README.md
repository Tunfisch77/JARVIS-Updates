# JARVIS v11 – externe Dienste

Diese Adapter sind absichtlich nicht automatisch gestartet. Sie laufen lokal und werden erst aktiv, wenn die zugehörige URL in `.env` gesetzt und das Modul in der v11-Modul-Matrix eingeschaltet wurde.

## OmniParser

1. Microsoft OmniParser separat nach der offiziellen Repository-Anleitung installieren.
2. Den Dienst nur auf `127.0.0.1` bereitstellen.
3. `OMNIPARSER_URL=http://127.0.0.1:...` in `.env` setzen.
4. Den visuellen Fallback im Agent OS aktivieren.

## UI-TARS Desktop

1. UI-TARS separat installieren und lokal starten.
2. `UI_TARS_URL=http://127.0.0.1:...` setzen.
3. Das Entwicklerprofil auswählen und das kritische Modul ausdrücklich aktivieren.

## Ollama

1. Ollama installieren und ein passendes lokales Modell laden.
2. `OLLAMA_HOST=http://127.0.0.1:11434` setzen.
3. Das Modell in der Modul-Matrix aktivieren.

## whatsapp-web.js

Der enthaltene Dienst ist ein optionaler, inoffizieller Adapter. Er ist standardmäßig deaktiviert und ersetzt nicht die stabile WhatsApp-Desktop-Steuerung.

1. Bei der vollständigen Installation werden Node.js und `npm install` automatisch ausgeführt.
2. Eine lange zufällige Variable `JARVIS_WWEBJS_TOKEN` setzen.
3. `npm start` ausführen und den QR-Code einmal scannen.
4. In JARVIS `JARVIS_WWEBJS_URL=http://127.0.0.1:3211` und denselben Token setzen.

Nutzung auf eigenes Risiko: WhatsApp kann den inoffiziellen Zugriff jederzeit ändern oder einschränken.
