"use strict";

const express = require("express");
const qrcode = require("qrcode-terminal");
const { Client, LocalAuth } = require("whatsapp-web.js");

const host = "127.0.0.1";
const port = Number(process.env.JARVIS_WWEBJS_PORT || 3211);
const token = String(process.env.JARVIS_WWEBJS_TOKEN || "");

if (token.length < 24) {
  throw new Error("JARVIS_WWEBJS_TOKEN muss mindestens 24 Zeichen lang sein.");
}

const app = express();
app.use(express.json({ limit: "256kb" }));

let ready = false;
const unread = new Map();
const client = new Client({
  authStrategy: new LocalAuth({ clientId: "jarvis-v11", dataPath: "./profile" }),
  puppeteer: { headless: true },
});

client.on("qr", (value) => qrcode.generate(value, { small: true }));
client.on("ready", () => { ready = true; });
client.on("disconnected", () => { ready = false; });
client.on("message", async (message) => {
  const chat = await message.getChat();
  const contact = await message.getContact();
  unread.set(message.id._serialized, {
    external_id: message.id._serialized,
    sender_name: contact.pushname || contact.name || message.from,
    sender_address: message.from,
    conversation: chat.name || "",
    body: message.body || "",
    received_at: new Date(Number(message.timestamp) * 1000).toISOString(),
    metadata: { is_group: Boolean(chat.isGroup), has_media: Boolean(message.hasMedia) },
  });
  while (unread.size > 200) unread.delete(unread.keys().next().value);
});

function authorize(request, response, next) {
  const supplied = String(request.headers.authorization || "").replace(/^Bearer\s+/i, "");
  if (supplied !== token) return response.status(401).json({ error: "unauthorized" });
  next();
}

app.get("/health", authorize, (_request, response) => response.json({ ok: true, ready }));

app.get("/unread", authorize, (request, response) => {
  const limit = Math.max(1, Math.min(100, Number(request.query.limit || 20)));
  response.json({ items: [...unread.values()].slice(-limit).reverse() });
});

app.post("/send", authorize, async (request, response) => {
  if (!ready) return response.status(503).json({ error: "WhatsApp client is not ready" });
  const target = String(request.body.target || "").trim();
  const message = String(request.body.message || "").trim();
  if (!target || !message || message.length > 4000) {
    return response.status(400).json({ error: "invalid target or message" });
  }
  const chatId = target.includes("@") ? target : `${target.replace(/\D/g, "")}@c.us`;
  const result = await client.sendMessage(chatId, message);
  response.json({ ok: true, message_id: result.id._serialized });
});

app.use((_error, _request, response, _next) => response.status(500).json({ error: "adapter error" }));

client.initialize();
app.listen(port, host, () => {
  process.stdout.write(`JARVIS whatsapp-web.js adapter: http://${host}:${port}\n`);
});
