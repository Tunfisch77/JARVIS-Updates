# Lokale JARVIS-Erweiterungen

v11 reserviert diesen Ordner für bewusst installierte, lokale Pluggy-/MCP-Erweiterungen. Erweiterungen werden nicht automatisch aus beliebigen Downloads geladen. Sie müssen in der Modul-Matrix freigegeben werden und dürfen keine Zugangsdaten im Quellcode enthalten.
