from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import os
import re
import threading
from dataclasses import dataclass
from datetime import datetime
from email.message import EmailMessage
from pathlib import Path
from typing import Any, Final
from urllib.parse import urlencode, urlparse

import httpx

from browser_runtime import browser_label, launch_persistent_browser, prefer_external_browser
from persistent_storage import migrate_legacy_path, persistent_path


ACCOUNT_AUTO: Final = "auto"
ACCOUNT_OUTLOOK: Final = "outlook_school"
ACCOUNT_GMAIL: Final = "gmail_private"
ALLOWED_ACCOUNTS: Final = {ACCOUNT_AUTO, ACCOUNT_OUTLOOK, ACCOUNT_GMAIL}


class AccountIntegrationError(ValueError):
    pass


def _configured_path(base_dir: Path, value: str, fallback: str) -> Path:
    cleaned = str(value or "").strip()
    path = Path(cleaned).expanduser() if cleaned else base_dir / fallback
    return path if path.is_absolute() else base_dir / path


def _persistent_account_path(
    base_dir: Path,
    env: dict[str, str],
    variable: str,
    *,
    legacy_relative: str,
    central_relative: str,
) -> Path:
    configured = str(env.get(variable, "") or "").strip()
    if configured:
        return _configured_path(base_dir, configured, legacy_relative)
    return migrate_legacy_path(
        base_dir / legacy_relative,
        persistent_path(central_relative, env),
    )


@dataclass(slots=True)
class ConnectedAccountConfig:
    base_dir: Path
    default_account: str = ACCOUNT_GMAIL
    school_domains: frozenset[str] = frozenset()
    gmail_client_secret: Path | None = None
    gmail_token: Path | None = None
    outlook_client_id: str = ""
    outlook_tenant: str = "organizations"
    outlook_timezone: str = "W. Europe Standard Time"
    outlook_cache: Path | None = None
    outlook_mode: str = "web"
    outlook_web_auto_send: bool = True
    outlook_profile_dir: Path | None = None
    browser_channel: str = "auto"

    @classmethod
    def from_environment(
        cls,
        base_dir: Path,
        environment: dict[str, str] | None = None,
    ) -> "ConnectedAccountConfig":
        env = environment if environment is not None else os.environ
        default_account = env.get("JARVIS_EMAIL_DEFAULT_ACCOUNT", ACCOUNT_GMAIL).strip().casefold()
        if default_account not in {ACCOUNT_GMAIL, ACCOUNT_OUTLOOK}:
            default_account = ACCOUNT_GMAIL
        domains = frozenset(
            item.strip().casefold().lstrip("@")
            for item in env.get("JARVIS_SCHOOL_EMAIL_DOMAINS", "").split(",")
            if item.strip()
        )
        outlook_mode = env.get("JARVIS_OUTLOOK_MODE", "web").strip().casefold()
        if outlook_mode not in {"web", "graph"}:
            outlook_mode = "web"
        outlook_auto_send = env.get("JARVIS_OUTLOOK_WEB_AUTO_SEND", "true").strip().casefold()
        return cls(
            base_dir=base_dir,
            default_account=default_account,
            school_domains=domains,
            gmail_client_secret=_configured_path(
                base_dir,
                env.get("JARVIS_GMAIL_CLIENT_SECRET", ""),
                "data/google_client_secret.json",
            ),
            gmail_token=_persistent_account_path(
                base_dir,
                env,
                "JARVIS_GMAIL_TOKEN",
                legacy_relative="data/gmail_token.json",
                central_relative="accounts/gmail_token.json",
            ),
            outlook_client_id=env.get("JARVIS_OUTLOOK_CLIENT_ID", "").strip(),
            outlook_tenant=env.get("JARVIS_OUTLOOK_TENANT", "organizations").strip() or "organizations",
            outlook_timezone=env.get("JARVIS_OUTLOOK_TIMEZONE", "W. Europe Standard Time").strip()
            or "W. Europe Standard Time",
            outlook_cache=_persistent_account_path(
                base_dir,
                env,
                "JARVIS_OUTLOOK_TOKEN_CACHE",
                legacy_relative="data/outlook_token_cache.json",
                central_relative="accounts/outlook_token_cache.json",
            ),
            outlook_mode=outlook_mode,
            outlook_web_auto_send=outlook_auto_send in {"1", "true", "yes", "on"},
            outlook_profile_dir=_persistent_account_path(
                base_dir,
                env,
                "JARVIS_OUTLOOK_WEB_PROFILE_DIR",
                legacy_relative="data/outlook_web_profile",
                central_relative="browser_profiles/outlook",
            ),
            browser_channel=env.get("JARVIS_BROWSER_CHANNEL", "auto").strip() or "auto",
        )


class ConnectedAccounts:
    """Local OAuth account router. Tokens stay on disk and never enter model context."""

    GMAIL_SEND_SCOPES: Final = (
        "https://www.googleapis.com/auth/gmail.send",
        "https://www.googleapis.com/auth/calendar.events",
    )
    GMAIL_SCOPES: Final = (
        *GMAIL_SEND_SCOPES,
        "https://www.googleapis.com/auth/gmail.readonly",
    )
    OUTLOOK_SCOPES: Final = ("User.Read", "Mail.Send", "Calendars.ReadWrite")

    def __init__(self, config: ConnectedAccountConfig) -> None:
        self.config = config
        self._outlook_web_lock = threading.Lock()

    def _outlook_web_marker(self) -> Path | None:
        return self.config.outlook_profile_dir / ".jarvis_connected" if self.config.outlook_profile_dir else None

    def _outlook_web_ready(self) -> bool:
        marker = self._outlook_web_marker()
        return bool(marker and marker.is_file() and self.config.outlook_web_auto_send)

    def route(
        self,
        requested: str,
        *,
        recipient: str = "",
        contact_preference: str = ACCOUNT_AUTO,
    ) -> str:
        selected = str(requested or ACCOUNT_AUTO).strip().casefold()
        if selected not in ALLOWED_ACCOUNTS:
            raise AccountIntegrationError("Unbekanntes E-Mail- oder Kalenderkonto.")
        if selected != ACCOUNT_AUTO:
            return selected
        preferred = str(contact_preference or ACCOUNT_AUTO).strip().casefold()
        if preferred in {ACCOUNT_GMAIL, ACCOUNT_OUTLOOK}:
            return preferred
        domain = recipient.rsplit("@", 1)[-1].casefold() if "@" in recipient else ""
        if domain and domain in self.config.school_domains:
            return ACCOUNT_OUTLOOK
        return self.config.default_account

    def status(self) -> dict[str, Any]:
        gmail_secret = bool(self.config.gmail_client_secret and self.config.gmail_client_secret.is_file())
        gmail_token = bool(self.config.gmail_token and self.config.gmail_token.is_file())
        outlook_cache = bool(self.config.outlook_cache and self.config.outlook_cache.is_file())
        outlook_web = self.config.outlook_mode == "web"
        outlook_connected = self._outlook_web_ready() if outlook_web else bool(
            self.config.outlook_client_id and outlook_cache
        )
        return {
            "default": self.config.default_account,
            "gmail_private": {
                "status": "connected" if gmail_secret and gmail_token else "not_configured",
                "client_secret": gmail_secret,
                "token": gmail_token,
            },
            "outlook_school": {
                "status": "connected" if outlook_connected else "not_configured",
                "mode": "web_auto" if outlook_web else "graph",
                "client_id": bool(self.config.outlook_client_id),
                "token": outlook_cache,
                "web_profile": self._outlook_web_ready(),
            },
            "school_domains": sorted(self.config.school_domains),
        }

    def _gmail_credentials(self, scopes: tuple[str, ...] | None = None) -> Any:
        if not self.config.gmail_client_secret or not self.config.gmail_client_secret.is_file():
            raise AccountIntegrationError(
                "Gmail ist noch nicht eingerichtet. Lege den Google-OAuth-Desktopschlüssel ab und starte GMAIL_VERBINDEN.bat."
            )
        if not self.config.gmail_token or not self.config.gmail_token.is_file():
            raise AccountIntegrationError("Gmail ist noch nicht angemeldet. Starte einmal GMAIL_VERBINDEN.bat.")
        try:
            from google.auth.transport.requests import Request
            from google.oauth2.credentials import Credentials
        except ImportError as exc:
            raise AccountIntegrationError("Google-Bibliotheken fehlen. Starte zuerst INSTALLIEREN.bat.") from exc
        try:
            requested_scopes = scopes or self.GMAIL_SEND_SCOPES
            credentials = Credentials.from_authorized_user_file(
                str(self.config.gmail_token),
                list(requested_scopes),
            )
            if scopes and not credentials.has_scopes(list(scopes)):
                raise AccountIntegrationError(
                    "Gmail darf bisher nur senden. Starte einmal GMAIL_VERBINDEN.bat, um auch das Vorlesen neuer Nachrichten freizugeben."
                )
            if credentials.expired and credentials.refresh_token:
                credentials.refresh(Request())
                self.config.gmail_token.parent.mkdir(parents=True, exist_ok=True)
                self.config.gmail_token.write_text(credentials.to_json(), encoding="utf-8")
        except AccountIntegrationError:
            raise
        except Exception as exc:
            raise AccountIntegrationError("Die Gmail-Anmeldung ist ungültig. Starte GMAIL_VERBINDEN.bat erneut.") from exc
        if not credentials.valid:
            raise AccountIntegrationError("Die Gmail-Anmeldung ist abgelaufen. Starte GMAIL_VERBINDEN.bat erneut.")
        return credentials

    def send_gmail(self, recipient: str, subject: str, body: str) -> dict[str, Any]:
        try:
            from googleapiclient.discovery import build
        except ImportError as exc:
            raise AccountIntegrationError("Google-Bibliotheken fehlen. Starte zuerst INSTALLIEREN.bat.") from exc
        message = EmailMessage()
        message["To"] = recipient
        message["Subject"] = subject
        message.set_content(body)
        raw = base64.urlsafe_b64encode(message.as_bytes()).decode("ascii")
        try:
            service = build("gmail", "v1", credentials=self._gmail_credentials(), cache_discovery=False)
            result = service.users().messages().send(userId="me", body={"raw": raw}).execute()
        except AccountIntegrationError:
            raise
        except Exception as exc:
            raise AccountIntegrationError("Gmail konnte die E-Mail nicht senden.") from exc
        return {
            "ok": True,
            "mode": "gmail_api",
            "account": ACCOUNT_GMAIL,
            "message_id": str(result.get("id", "")) if isinstance(result, dict) else "",
            "requires_user_action": False,
            "verification": "provider_message_id" if isinstance(result, dict) and result.get("id") else "provider_completed",
            "result_summary": "Gmail hat die E-Mail versendet.",
            "app_closed": False,
        }

    @staticmethod
    def _gmail_header(headers: object, name: str) -> str:
        if not isinstance(headers, list):
            return ""
        for item in headers:
            if isinstance(item, dict) and str(item.get("name") or "").casefold() == name.casefold():
                return str(item.get("value") or "").strip()
        return ""

    @classmethod
    def _gmail_text(cls, payload: object) -> str:
        if not isinstance(payload, dict):
            return ""
        mime_type = str(payload.get("mimeType") or "").casefold()
        body = payload.get("body") if isinstance(payload.get("body"), dict) else {}
        encoded = str(body.get("data") or "")
        if encoded and mime_type in {"text/plain", "text/html"}:
            try:
                text = base64.urlsafe_b64decode(encoded + "=" * (-len(encoded) % 4)).decode("utf-8", errors="replace")
            except (ValueError, UnicodeError):
                text = ""
            if mime_type == "text/html":
                text = re.sub(r"<[^>]+>", " ", text)
                text = re.sub(r"\s+", " ", text)
            return text.strip()
        parts = payload.get("parts") if isinstance(payload.get("parts"), list) else []
        plain = ""
        html = ""
        for part in parts:
            text = cls._gmail_text(part)
            if not text:
                continue
            if isinstance(part, dict) and str(part.get("mimeType") or "").casefold() == "text/plain":
                plain = text
                break
            html = html or text
        return plain or html

    def _list_gmail(self, *, limit: int, search_query: str) -> list[dict[str, Any]]:
        try:
            from googleapiclient.discovery import build
            from googleapiclient.errors import HttpError
        except ImportError as exc:
            raise AccountIntegrationError("Google-Bibliotheken fehlen. Starte zuerst INSTALLIEREN.bat.") from exc
        try:
            service = build("gmail", "v1", credentials=self._gmail_credentials(self.GMAIL_SCOPES), cache_discovery=False)
            listing = service.users().messages().list(
                userId="me",
                q=search_query,
                maxResults=max(1, min(50, int(limit))),
            ).execute()
            messages = listing.get("messages", []) if isinstance(listing, dict) else []
            result: list[dict[str, Any]] = []
            for reference in messages:
                message_id = str(reference.get("id") or "") if isinstance(reference, dict) else ""
                if not message_id:
                    continue
                raw = service.users().messages().get(userId="me", id=message_id, format="full").execute()
                payload = raw.get("payload", {}) if isinstance(raw, dict) else {}
                headers = payload.get("headers", []) if isinstance(payload, dict) else []
                sender = self._gmail_header(headers, "From")
                sender_match = re.match(r"\s*(.*?)\s*<([^>]+)>\s*$", sender)
                sender_name = (sender_match.group(1).strip(' "') if sender_match else sender.split("@", 1)[0]).strip()
                sender_address = sender_match.group(2).strip() if sender_match else sender.strip()
                body = self._gmail_text(payload) or str(raw.get("snippet") or "")
                internal = str(raw.get("internalDate") or "")
                received_at = datetime.fromtimestamp(int(internal) / 1000).astimezone().isoformat() if internal.isdigit() else ""
                result.append(
                    {
                        "source": "gmail",
                        "external_id": message_id,
                        "sender_name": sender_name or sender_address or "Unbekannt",
                        "sender_address": sender_address,
                        "conversation": str(raw.get("threadId") or ""),
                        "subject": self._gmail_header(headers, "Subject"),
                        "body": body,
                        "received_at": received_at,
                        "unread": "UNREAD" in {
                            str(item).upper()
                            for item in (raw.get("labelIds", []) if isinstance(raw, dict) else [])
                        },
                    }
                )
            return result
        except AccountIntegrationError:
            raise
        except HttpError as exc:
            if getattr(exc, "status_code", 0) == 403 or "insufficient" in str(exc).casefold():
                raise AccountIntegrationError(
                    "Gmail darf bisher nur senden. Starte einmal GMAIL_VERBINDEN.bat, um auch das Vorlesen neuer Nachrichten freizugeben."
                ) from exc
            raise AccountIntegrationError("Gmail konnte Nachrichten nicht lesen.") from exc
        except Exception as exc:
            raise AccountIntegrationError("Gmail konnte Nachrichten nicht lesen.") from exc

    def list_unread_gmail(self, limit: int = 20) -> list[dict[str, Any]]:
        """Read unread Gmail messages. Older send-only tokens fail with a precise setup hint."""
        return self._list_gmail(
            limit=limit,
            search_query="is:unread -in:spam -in:trash",
        )

    def list_recent_gmail(self, limit: int = 50, sender_query: str = "") -> list[dict[str, Any]]:
        """Read recent received mail, optionally narrowed with Gmail's sender search."""
        sender = re.sub(r"[\r\n\"]+", " ", str(sender_query or "")).strip()
        search = (
            f'from:"{sender}" -in:spam -in:trash'
            if sender
            else "in:inbox -in:spam -in:trash"
        )
        return self._list_gmail(limit=limit, search_query=search)

    def create_google_event(
        self,
        *,
        title: str,
        start: datetime,
        end: datetime,
        description: str,
        location: str,
        attendees: list[str],
        timezone: str,
    ) -> dict[str, Any]:
        try:
            from googleapiclient.discovery import build
        except ImportError as exc:
            raise AccountIntegrationError("Google-Bibliotheken fehlen. Starte zuerst INSTALLIEREN.bat.") from exc
        event: dict[str, Any] = {
            "summary": title,
            "description": description,
            "location": location,
            "start": {"dateTime": start.isoformat(), "timeZone": timezone},
            "end": {"dateTime": end.isoformat(), "timeZone": timezone},
        }
        if attendees:
            event["attendees"] = [{"email": item} for item in attendees]
        try:
            service = build("calendar", "v3", credentials=self._gmail_credentials(), cache_discovery=False)
            result = service.events().insert(calendarId="primary", body=event, sendUpdates="all").execute()
        except AccountIntegrationError:
            raise
        except Exception as exc:
            raise AccountIntegrationError("Google Kalender konnte den Termin nicht erstellen.") from exc
        return {
            "ok": True,
            "mode": "google_calendar_api",
            "account": ACCOUNT_GMAIL,
            "event_id": str(result.get("id", "")) if isinstance(result, dict) else "",
            "event_url": str(result.get("htmlLink", "")) if isinstance(result, dict) else "",
            "requires_user_action": False,
            "verification": "provider_event_id" if isinstance(result, dict) and result.get("id") else "provider_completed",
            "result_summary": "Google Kalender hat den Termin erstellt.",
            "app_closed": False,
        }

    def _outlook_app(self) -> tuple[Any, Any]:
        if not self.config.outlook_client_id:
            raise AccountIntegrationError("JARVIS_OUTLOOK_CLIENT_ID fehlt. Richte Outlook zuerst nach README ein.")
        try:
            import msal
        except ImportError as exc:
            raise AccountIntegrationError("MSAL fehlt. Starte zuerst INSTALLIEREN.bat.") from exc
        cache = msal.SerializableTokenCache()
        if self.config.outlook_cache and self.config.outlook_cache.is_file():
            try:
                cache.deserialize(self.config.outlook_cache.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                pass
        app = msal.PublicClientApplication(
            self.config.outlook_client_id,
            authority=f"https://login.microsoftonline.com/{self.config.outlook_tenant}",
            token_cache=cache,
        )
        return app, cache

    def _save_outlook_cache(self, cache: Any) -> None:
        if cache.has_state_changed and self.config.outlook_cache:
            self.config.outlook_cache.parent.mkdir(parents=True, exist_ok=True)
            self.config.outlook_cache.write_text(cache.serialize(), encoding="utf-8")

    def _outlook_token(self) -> str:
        app, cache = self._outlook_app()
        accounts = app.get_accounts()
        result = app.acquire_token_silent(list(self.OUTLOOK_SCOPES), account=accounts[0]) if accounts else None
        self._save_outlook_cache(cache)
        token = result.get("access_token", "") if isinstance(result, dict) else ""
        if not token:
            raise AccountIntegrationError("Outlook ist noch nicht angemeldet. Starte einmal OUTLOOK_VERBINDEN.bat.")
        return str(token)

    async def _graph_post(self, path: str, payload: dict[str, Any]) -> httpx.Response:
        token = self._outlook_token()
        try:
            async with httpx.AsyncClient(timeout=30.0, follow_redirects=False) as client:
                response = await client.post(
                    f"https://graph.microsoft.com/v1.0{path}",
                    headers={"Authorization": f"Bearer {token}"},
                    json=payload,
                )
        except httpx.HTTPError as exc:
            raise AccountIntegrationError("Microsoft Graph ist derzeit nicht erreichbar.") from exc
        if response.is_error:
            raise AccountIntegrationError(f"Microsoft Graph hat die Aktion abgelehnt (HTTP {response.status_code}).")
        return response

    async def send_outlook(self, recipient: str, subject: str, body: str) -> dict[str, Any]:
        if self.config.outlook_mode == "web":
            if not self._outlook_web_ready():
                raise AccountIntegrationError(
                    "Outlook Web ist noch nicht angemeldet. Starte einmal OUTLOOK_VERBINDEN.bat."
                )
            await asyncio.to_thread(self._send_outlook_web, recipient, subject, body)
            return {
                "ok": True,
                "mode": "outlook_web_auto",
                "account": ACCOUNT_OUTLOOK,
                "requires_user_action": False,
                "verification": "outlook_action_button_completed",
                "result_summary": "Outlook Web hat die E-Mail versendet.",
                "app_closed": True,
            }
        await self._graph_post(
            "/me/sendMail",
            {
                "message": {
                    "subject": subject,
                    "body": {"contentType": "Text", "content": body},
                    "toRecipients": [{"emailAddress": {"address": recipient}}],
                },
                "saveToSentItems": True,
            },
        )
        return {
            "ok": True,
            "mode": "outlook_graph",
            "account": ACCOUNT_OUTLOOK,
            "requires_user_action": False,
            "verification": "provider_completed",
            "result_summary": "Microsoft Graph hat die E-Mail versendet.",
            "app_closed": False,
        }

    async def create_outlook_event(
        self,
        *,
        title: str,
        start: datetime,
        end: datetime,
        description: str,
        location: str,
        attendees: list[str],
        timezone: str,
    ) -> dict[str, Any]:
        if self.config.outlook_mode == "web":
            if not self._outlook_web_ready():
                raise AccountIntegrationError(
                    "Outlook Web ist noch nicht angemeldet. Starte einmal OUTLOOK_VERBINDEN.bat."
                )
            await asyncio.to_thread(
                self._create_outlook_web_event,
                title,
                start,
                end,
                description,
                location,
                attendees,
            )
            return {
                "ok": True,
                "mode": "outlook_calendar_web_auto",
                "account": ACCOUNT_OUTLOOK,
                "event_id": "",
                "event_url": "",
                "requires_user_action": False,
                "verification": "outlook_action_button_completed",
                "result_summary": "Outlook Web hat den Termin gespeichert.",
                "app_closed": True,
            }
        response = await self._graph_post(
            "/me/events",
            {
                "subject": title,
                "body": {"contentType": "Text", "content": description},
                "start": {"dateTime": start.replace(tzinfo=None).isoformat(), "timeZone": timezone},
                "end": {"dateTime": end.replace(tzinfo=None).isoformat(), "timeZone": timezone},
                "location": {"displayName": location},
                "attendees": [
                    {"emailAddress": {"address": item}, "type": "required"} for item in attendees
                ],
            },
        )
        result = response.json() if response.content else {}
        return {
            "ok": True,
            "mode": "outlook_calendar_graph",
            "account": ACCOUNT_OUTLOOK,
            "event_id": str(result.get("id", "")) if isinstance(result, dict) else "",
            "event_url": str(result.get("webLink", "")) if isinstance(result, dict) else "",
            "requires_user_action": False,
            "verification": "provider_event_id" if isinstance(result, dict) and result.get("id") else "provider_completed",
            "result_summary": "Microsoft Graph hat den Termin erstellt.",
            "app_closed": False,
        }

    def _outlook_web_context(self, playwright: Any, *, headless: bool = False) -> Any:
        if not self.config.outlook_profile_dir:
            raise AccountIntegrationError("Kein Outlook-Webprofil konfiguriert.")
        profile = self.config.outlook_profile_dir.resolve()
        profile.mkdir(parents=True, exist_ok=True)
        return launch_persistent_browser(
            playwright,
            profile,
            preference=self.config.browser_channel,
            headless=headless,
        )

    @staticmethod
    def _outlook_login_page(url: str) -> bool:
        hostname = (urlparse(str(url or "")).hostname or "").casefold()
        return hostname.endswith("login.microsoftonline.com") or hostname.endswith("login.live.com")

    @staticmethod
    def _click_outlook_action(page: Any, names: tuple[str, ...]) -> None:
        for name in names:
            pattern = re.compile(rf"^{re.escape(name)}(?: and close)?$", re.IGNORECASE)
            button = page.get_by_role("button", name=pattern).last
            try:
                button.wait_for(state="visible", timeout=6_000)
            except Exception:
                continue
            button.click()
            try:
                button.wait_for(state="hidden", timeout=10_000)
            except Exception as exc:
                raise AccountIntegrationError(
                    "Outlook Web hat die Aktion nach dem Klick nicht abgeschlossen. "
                    "Prüfe im geöffneten Fenster, ob Microsoft noch eine Eingabe verlangt."
                ) from exc
            return
        selectors = ", ".join(
            f"button[aria-label*='{name}'], button[title*='{name}']" for name in names
        )
        fallback = page.locator(selectors).last
        try:
            fallback.wait_for(state="visible", timeout=5_000)
        except Exception as exc:
            raise AccountIntegrationError(
                "Outlook Web konnte die Schaltfläche zum Senden oder Speichern nicht finden. "
                "Microsoft hat möglicherweise die Oberfläche geändert."
            ) from exc
        fallback.click()
        try:
            fallback.wait_for(state="hidden", timeout=10_000)
        except Exception as exc:
            raise AccountIntegrationError(
                "Outlook Web hat die Aktion nach dem Klick nicht abgeschlossen. "
                "Prüfe im geöffneten Fenster, ob Microsoft noch eine Eingabe verlangt."
            ) from exc

    def _run_outlook_web_action(self, url: str, action_names: tuple[str, ...]) -> None:
        try:
            from playwright.sync_api import Error as PlaywrightError
            from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
            from playwright.sync_api import sync_playwright
        except ImportError as exc:
            raise AccountIntegrationError("Playwright fehlt. Starte zuerst INSTALLIEREN.bat.") from exc
        with self._outlook_web_lock:
            try:
                with sync_playwright() as playwright:
                    context = self._outlook_web_context(playwright)
                    try:
                        page = context.pages[0] if context.pages else context.new_page()
                        page.goto(url, wait_until="domcontentloaded", timeout=45_000)
                        if self._outlook_login_page(page.url):
                            raise AccountIntegrationError(
                                "Die Outlook-Webanmeldung ist abgelaufen. Starte OUTLOOK_VERBINDEN.bat erneut."
                            )
                        self._click_outlook_action(page, action_names)
                    finally:
                        context.close()
            except AccountIntegrationError:
                raise
            except (PlaywrightTimeoutError, PlaywrightError) as exc:
                raise AccountIntegrationError(
                    "Outlook Web ist nicht angemeldet, bereits in einem anderen JARVIS-Fenster geöffnet "
                    "oder die Seite hat sich geändert. Starte OUTLOOK_VERBINDEN.bat erneut."
                ) from exc

    def _list_outlook(self, *, limit: int, unread_only: bool) -> list[dict[str, Any]]:
        if not self._outlook_web_ready():
            raise AccountIntegrationError("Outlook Web ist noch nicht angemeldet. Starte einmal OUTLOOK_VERBINDEN.bat.")
        try:
            from playwright.sync_api import Error as PlaywrightError
            from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
            from playwright.sync_api import sync_playwright
        except ImportError as exc:
            raise AccountIntegrationError("Playwright fehlt. Starte zuerst INSTALLIEREN.bat.") from exc
        with self._outlook_web_lock:
            try:
                with sync_playwright() as playwright:
                    context = self._outlook_web_context(playwright, headless=True)
                    try:
                        page = context.pages[0] if context.pages else context.new_page()
                        page.goto("https://outlook.office.com/mail/", wait_until="domcontentloaded", timeout=45_000)
                        if self._outlook_login_page(page.url):
                            raise AccountIntegrationError(
                                "Die Outlook-Webanmeldung ist abgelaufen. Starte OUTLOOK_VERBINDEN.bat erneut."
                            )
                        page.wait_for_timeout(2_000)
                        selector = (
                            "[role='option'][aria-label*='Unread'], [role='option'][aria-label*='Ungelesen'], "
                            "[role='listbox'] [aria-selected][aria-label*='Unread'], "
                            "[role='listbox'] [aria-selected][aria-label*='Ungelesen']"
                            if unread_only
                            else "[role='listbox'] [role='option'], [role='listbox'] [aria-selected]"
                        )
                        rows = page.locator(selector)
                        messages: list[dict[str, Any]] = []
                        for index in range(min(rows.count(), max(1, min(50, int(limit))))):
                            row = rows.nth(index)
                            label = str(row.get_attribute("aria-label") or row.inner_text() or "").strip()
                            lines = [re.sub(r"\s+", " ", item).strip() for item in label.splitlines() if item.strip()]
                            if not lines:
                                continue
                            sender = lines[0].removeprefix("Unread ").removeprefix("Ungelesen ").strip()
                            is_unread = label.casefold().startswith(("unread ", "ungelesen ")) or any(
                                marker in label.casefold()
                                for marker in (" unread", " ungelesen")
                            )
                            subject = lines[1] if len(lines) > 1 else ""
                            body = " ".join(lines[2:]) or subject or label
                            external_id = str(
                                row.get_attribute("data-convid")
                                or row.get_attribute("data-itemid")
                                or hashlib.sha256(label.encode("utf-8")).hexdigest()
                            )
                            messages.append(
                                {
                                    "source": "outlook",
                                    "external_id": external_id,
                                    "sender_name": sender or "Unbekannt",
                                    "sender_address": "",
                                    "conversation": subject,
                                    "subject": subject,
                                    "body": body,
                                    "received_at": datetime.now().astimezone().isoformat(timespec="seconds"),
                                    "unread": is_unread,
                                }
                            )
                        return messages
                    finally:
                        context.close()
            except AccountIntegrationError:
                raise
            except (PlaywrightTimeoutError, PlaywrightError) as exc:
                raise AccountIntegrationError(
                    "Outlook Web konnte Schulmails nicht lesen. Prüfe die Anmeldung oder starte OUTLOOK_VERBINDEN.bat erneut."
                ) from exc

    def list_unread_outlook(self, limit: int = 20) -> list[dict[str, Any]]:
        # The shared reader always launches its persistent browser with headless=True.
        return self._list_outlook(limit=limit, unread_only=True)

    def list_recent_outlook(self, limit: int = 50) -> list[dict[str, Any]]:
        return self._list_outlook(limit=limit, unread_only=False)

    def _send_outlook_web(self, recipient: str, subject: str, body: str) -> None:
        query = urlencode({"to": recipient, "subject": subject, "body": body})
        self._run_outlook_web_action(
            f"https://outlook.office.com/mail/deeplink/compose?{query}",
            ("Send", "Senden"),
        )

    def _create_outlook_web_event(
        self,
        title: str,
        start: datetime,
        end: datetime,
        description: str,
        location: str,
        attendees: list[str],
    ) -> None:
        query: dict[str, str] = {
            "path": "/calendar/action/compose",
            "rru": "addevent",
            "subject": title,
            "startdt": start.isoformat(),
            "enddt": end.isoformat(),
            "body": description,
            "location": location,
        }
        if attendees:
            query["to"] = ";".join(attendees)
        action_names = ("Send", "Senden", "Save", "Speichern") if attendees else (
            "Save",
            "Speichern",
            "Send",
            "Senden",
        )
        self._run_outlook_web_action(
            f"https://outlook.office.com/calendar/deeplink/compose?{urlencode(query)}",
            action_names,
        )

    def setup_outlook_web(self) -> Path:
        try:
            from playwright.sync_api import Error as PlaywrightError
            from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
            from playwright.sync_api import sync_playwright
        except ImportError as exc:
            raise AccountIntegrationError("Playwright fehlt. Starte zuerst INSTALLIEREN.bat.") from exc
        if not self.config.outlook_profile_dir:
            raise AccountIntegrationError("Kein Outlook-Webprofil konfiguriert.")
        with self._outlook_web_lock:
            try:
                with sync_playwright() as playwright:
                    context = self._outlook_web_context(playwright)
                    try:
                        page = context.pages[0] if context.pages else context.new_page()
                        page.goto("https://outlook.office.com/mail/", wait_until="domcontentloaded", timeout=45_000)
                        print(
                            "Melde dich im geöffneten "
                            f"{browser_label(self.config.browser_channel)}-Fenster "
                            "mit deinem Outlook-Schulkonto an."
                        )
                        print("Wenn dein Posteingang sichtbar ist, kehre hierher zurück und drücke Enter.")
                        input("Outlook-Posteingang sichtbar? Dann Enter drücken: ")
                        if self._outlook_login_page(page.url):
                            raise AccountIntegrationError("Die Outlook-Anmeldung wurde noch nicht abgeschlossen.")
                    finally:
                        context.close()
            except AccountIntegrationError:
                raise
            except (PlaywrightTimeoutError, PlaywrightError) as exc:
                raise AccountIntegrationError(
                    "Outlook Web konnte nicht geöffnet werden. Schließe andere JARVIS-Outlook-Fenster und versuche es erneut."
                ) from exc
        marker = self._outlook_web_marker()
        if not marker:
            raise AccountIntegrationError("Kein Outlook-Webprofil konfiguriert.")
        marker.write_text(datetime.now().isoformat(), encoding="utf-8")
        return self.config.outlook_profile_dir

    def setup_gmail(self) -> Path:
        if not self.config.gmail_client_secret or not self.config.gmail_client_secret.is_file():
            raise AccountIntegrationError(
                "Google OAuth Desktop-JSON fehlt unter data/google_client_secret.json (oder JARVIS_GMAIL_CLIENT_SECRET)."
            )
        try:
            from google_auth_oauthlib.flow import InstalledAppFlow
        except ImportError as exc:
            raise AccountIntegrationError("Google-Bibliotheken fehlen. Starte zuerst INSTALLIEREN.bat.") from exc
        flow = InstalledAppFlow.from_client_secrets_file(
            str(self.config.gmail_client_secret),
            list(self.GMAIL_SCOPES),
        )
        try:
            prefer_external_browser(self.config.browser_channel)
        except RuntimeError as exc:
            raise AccountIntegrationError(str(exc)) from exc
        credentials = flow.run_local_server(port=0, open_browser=True)
        if not self.config.gmail_token:
            raise AccountIntegrationError("Kein Gmail-Tokenpfad konfiguriert.")
        self.config.gmail_token.parent.mkdir(parents=True, exist_ok=True)
        self.config.gmail_token.write_text(credentials.to_json(), encoding="utf-8")
        return self.config.gmail_token

    def setup_outlook(self) -> Path:
        app, cache = self._outlook_app()
        flow = app.initiate_device_flow(scopes=list(self.OUTLOOK_SCOPES))
        if not isinstance(flow, dict) or "user_code" not in flow:
            raise AccountIntegrationError("Microsoft konnte keine Geräteanmeldung starten.")
        print(flow.get("message") or f"Öffne {flow.get('verification_uri')} und gib {flow.get('user_code')} ein.")
        result = app.acquire_token_by_device_flow(flow)
        if not isinstance(result, dict) or "access_token" not in result:
            description = result.get("error_description", "Unbekannter Fehler") if isinstance(result, dict) else "Unbekannter Fehler"
            raise AccountIntegrationError(f"Outlook-Anmeldung fehlgeschlagen: {description}")
        self._save_outlook_cache(cache)
        if not self.config.outlook_cache:
            raise AccountIntegrationError("Kein Outlook-Tokenpfad konfiguriert.")
        return self.config.outlook_cache

    def redacted_configuration(self) -> str:
        return json.dumps(self.status(), ensure_ascii=False, indent=2)
