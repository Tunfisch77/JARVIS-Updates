from __future__ import annotations

import importlib.util
import json
import os
import shutil
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR / "data" / "installer"
OUTPUT_FILE = OUTPUT_DIR / "module-status.json"

IMPORTS = {
    "agents": "agents",
    "apscheduler": "apscheduler",
    "browser_use": "browser_use",
    "dateparser": "dateparser",
    "faster_whisper": "faster_whisper",
    "graphiti": "graphiti_core",
    "keyring": "keyring",
    "langfuse": "langfuse",
    "langgraph": "langgraph",
    "litellm": "litellm",
    "markitdown": "markitdown",
    "mediapipe": "mediapipe",
    "mem0": "mem0",
    "mcp": "mcp",
    "openwakeword": "openwakeword",
    "phonenumbers": "phonenumbers",
    "playwright": "playwright",
    "pluggy": "pluggy",
    "pycaw": "pycaw",
    "pyrnnoise": "pyrnnoise",
    "pywebview": "webview",
    "pywinauto": "pywinauto",
    "rapidfuzz": "rapidfuzz",
    "sherpa_onnx": "sherpa_onnx",
    "silero_vad": "silero_vad",
    "spotipy": "spotipy",
    "sqlcipher": "sqlcipher3",
    "sqlite_vec": "sqlite_vec",
    "tenacity": "tenacity",
    "watchdog": "watchdog",
}


def module_exists(name: str) -> bool:
    try:
        return importlib.util.find_spec(name) is not None
    except (ImportError, ModuleNotFoundError, ValueError):
        return False


def command_version(command: str) -> dict[str, str | bool]:
    location = shutil.which(command)
    if not location:
        return {"installed": False, "path": "", "version": ""}
    try:
        result = subprocess.run(
            [location, "--version"],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
        version = (result.stdout or result.stderr).strip().splitlines()[0][:200]
    except (OSError, subprocess.SubprocessError, IndexError):
        version = ""
    return {"installed": True, "path": location, "version": version}


def isolated_status(key: str) -> dict[str, str | bool]:
    root = BASE_DIR / ".jarvis_envs" / key
    path = root / ("Scripts" if os.name == "nt" else "bin") / (
        "python.exe" if os.name == "nt" else "python"
    )
    marker = root / ".jarvis-installed"
    browser_ready = key != "openadapt" or (root / ".jarvis-playwright-ready").exists()
    return {
        "installed": marker.exists() and path.exists() and browser_ready,
        "path": str(path) if path.exists() else "",
        "browser_ready": browser_ready,
    }


def main() -> None:
    imports = {key: module_exists(value) for key, value in IMPORTS.items()}
    node_modules = BASE_DIR / "services" / "whatsapp-webjs" / "node_modules"
    report = {
        "version": "15.1.0",
        "checked_at": datetime.now(UTC).isoformat(timespec="seconds"),
        "python": {
            "version": sys.version.split()[0],
            "executable": sys.executable,
            "supported": sys.version_info[:2] == (3, 12),
        },
        "imports": imports,
        "isolated": {
            "open_interpreter": isolated_status("open-interpreter"),
            "openadapt": isolated_status("openadapt"),
            "openvoiceos": isolated_status("ovos"),
        },
        "executables": {
            "node": command_version("node"),
            "npm": command_version("npm"),
            "ollama": command_version("ollama"),
            "cargo": command_version("cargo"),
            "git": command_version("git"),
        },
        "services": {
            "whatsapp_web_js_dependencies": node_modules.exists(),
        },
        "summary": {
            "main_modules_ready": sum(imports.values()),
            "main_modules_total": len(imports),
        },
    }
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_FILE.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Modulstatus: {OUTPUT_FILE}")
    print(
        f"Python-Module bereit: {report['summary']['main_modules_ready']}/"
        f"{report['summary']['main_modules_total']}"
    )


if __name__ == "__main__":
    main()
