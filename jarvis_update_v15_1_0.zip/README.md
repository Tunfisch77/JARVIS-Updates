# JARVIS Vision + Voice v15.1.0

## Neu in v15.1.0 – PC Agent

- Programme lassen sich nach sichtbarer Bestätigung über eindeutige Namen öffnen.
- Dateien und Ordner werden nur über einen ausdrücklich genannten vollständigen Pfad geöffnet.
- Skripte, Installer, Verknüpfungen und Kommandozeilenargumente bleiben im direkten
  PC-Öffner blockiert.
- Der neue PC-Agent-Bereich zeigt Desktop-Steuerung, Live-Fortschritt und die letzten
  Desktop-Aktionen übersichtlich an.
- Laufende Desktop-Aktionen können sofort gestoppt werden.
- Abgeschlossene, gestoppte oder fehlgeschlagene Desktop-Pläne lassen sich nach
  erneuter Bestätigung als neuer Lauf wiederholen.
- Die Bildschirmanalyse verarbeitet genau ein aktuelles Standbild. Das Bild wird
  nicht dauerhaft gespeichert und nach der Analyse verworfen.
- Sprachbefehle zur Bildschirmansicht verwenden ebenfalls nur ein einzelnes Bild;
  eine Freigabe wird nach dem Bild automatisch beendet.
- Der PC-Agent verwendet weiterhin keine allgemeinen Shell-Befehle. Installationen,
  Löschaktionen, Banking und Passworteingaben bleiben außerhalb sicherer Desktop-Pläne.

## Neu in v14.0.0 – Communication Hub

- WhatsApp, Gmail, Outlook und Snapchat erscheinen in einer gemeinsamen Kommunikationszentrale.
- Nachrichten werden lokal nach Dringlichkeit sortiert. JARVIS zeigt nachvollziehbare Gründe wie
  Frist, Termin, direkte Frage, wichtiger Kontakt oder Aktualität.
- Suche, Quellenfilter, Prioritätsfilter und „nur ungelesen“ arbeiten über alle verbundenen Konten.
- Ein kompakter Tagesüberblick nennt offene und wichtige Nachrichten, ohne ungefragt Inhalte vorzulesen.
- Antwortentwürfe werden als editierbare Vorschläge erzeugt und niemals automatisch gesendet.
- Der Verbindungsstatus unterscheidet jetzt zwischen echtem Posteingangszugriff und reinem Senden.
- WhatsApp speichert nach erfolgreicher QR-Anmeldung einen eindeutigen lokalen Verbindungsmarker.
- Snapchat bleibt absichtlich auf Snap-/Nachrichtenstatus beschränkt; Chat-Inhalte werden nicht ausgelesen.
- Der Privacy Lock blendet Betreff und Vorschau im Communication Hub aus, solange Windows gesperrt ist.

## Neu in v13.0.1 – echter v13-Assistent

- Kombinierte Aufträge werden als vollständige Mehrschritt-Mission geplant, validiert und in
  der richtigen Reihenfolge an Mission Control übergeben.
- JARVIS führt bei einem Mehrschritt-Auftrag nicht mehr versehentlich nur die erste Aktion aus.
- Rückfragen entstehen nur noch bei einem wirklich blockierenden Wert wie Empfänger, Zeitpunkt
  oder Ziel; sicher ableitbare Formulierungen lösen keine Rückfrage aus.
- Ausdrückliche dauerhafte Korrekturen am Verhalten werden lokal gespeichert, bei späteren
  Antworten berücksichtigt und durch eine neue Korrektur derselben Kategorie ersetzt.
- Die Oberfläche zeigt die vom Backend bestätigte Versionsnummer. Dadurch ist sofort sichtbar,
  ob wirklich der neue Code läuft und nicht nur eine alte Browseransicht.
- Der Updater meldet Downloadgröße, Prüfsumme, Zahl der ersetzten Dateien, Backup und installierte
  Version. Künftige Manifeste können notwendige Dateien und Versionsmarker erzwingen.

## Neu in v12.3.0 – sichere Updates und Stabilität

- `UPDATE_JARVIS.bat` lädt künftig nur geänderte Programmdateien.
- Jedes Paket wird vor der Installation per SHA-256 geprüft.
- Ein fehlerhaftes Update wird abgebrochen oder automatisch zurückgerollt.
- `.env`, `.venv`, `data` und `%LOCALAPPDATA%\JARVIS` bleiben geschützt.
- `JARVIS_DIAGNOSE_REPARATUR.bat` prüft Datenbank, Module, Speicher und Updater
  und kann fehlende Python-Abhängigkeiten reparieren.
- Die feste Manifest-Adresse wird einmalig in `update_config.json` hinterlegt.

## Neu in v12.2.0 – dauerhafte lokale Anmeldungen

WhatsApp, Snapchat und Outlook verwenden jetzt versionsunabhängige Browserprofile
unter `%LOCALAPPDATA%\JARVIS\browser_profiles`. Gmail- und Outlook-Tokens liegen
unter `%LOCALAPPDATA%\JARVIS\accounts`. Beim ersten Start übernimmt JARVIS
vorhandene Anmeldedaten aus dem bisherigen `data`-Ordner automatisch, sofern
noch keine zentralen Daten existieren. Neue Versionen greifen anschließend auf
denselben lokalen Ordner zu und überschreiben ihn beim Entpacken nicht.

## Fix in v12.2.0 – Snapchat-Login wird zuverlässig erkannt

- Erkennt neben `web.snapchat.com` auch Snapchats alternative Web-App-Adresse.
- Prüft zusätzlich die sichtbare Chat-Oberfläche, statt ausschließlich der URL zu vertrauen.
- Berücksichtigt den Tab, in dem die Web-App nach dem Login tatsächlich geöffnet wurde.
- Löscht den gespeicherten Verbindungsmarker nicht mehr bei einer einzelnen kurzfristigen Weiterleitung.
- Brave, die aktive Browser-Sandbox und die getrennten JARVIS-Profile bleiben erhalten.

## Fix in v12.1.4 – Brave startet ohne `--no-sandbox`

- Aktiviert für alle Playwright-Browserstarts ausdrücklich die Chromium-Sandbox.
- Entfernt unsichere Sandbox-Abschaltflags auch dann, wenn sie später versehentlich als Startargument übergeben werden.
- Brave zeigt beim Verbinden nicht mehr die Warnung „unsupported command-line flag: --no-sandbox“.
- Die getrennten JARVIS-Profile, Brave-Erzwingung und gespeicherten Anmeldungen bleiben erhalten.

## Fix in v12.1.3 – Verbindungs-BATs erzwingen Brave

- Alle vier `*_VERBINDEN.bat` starten die Anmeldung ausdrücklich mit Brave.
- Eine alte Windows- oder Benutzer-Umgebungsvariable mit `msedge` kann die BATs nicht mehr überschreiben.
- Gmail registriert Brave vor dem OAuth-Login ausdrücklich, statt die fehlerhafte Windows-Standardbrowser-Zuordnung zu verwenden.
- Fehlende Grundmodule wie `python-dotenv` werden vor dem Verbindungsstart automatisch erkannt und nachinstalliert.
- Wenn Brave nicht gefunden wird, erscheint ein klarer Fehler; JARVIS wechselt nicht unbemerkt zu Edge.

## Fix in v12.1.2 – Brave als Standardbrowser

- Erkennt `BraveHTML` als Windows-Standardbrowser.
- Startet die installierte `brave.exe` mit dem getrennten JARVIS-Profil.
- Sucht Brave in den üblichen Benutzer- und Programmordnern.
- Fällt nur dann auf den JARVIS-Browser zurück, wenn Brave nicht installiert gefunden wird.
- Optional kann `JARVIS_BRAVE_EXECUTABLE` auf eine abweichende `brave.exe` zeigen.

## Fix in v12.1.1 – Standardbrowser und zuverlässiger Snapchat-Login

- Web-Verbindungen sind nicht mehr fest auf Microsoft Edge eingestellt. Unter Windows verwendet JARVIS automatisch Google Chrome oder Edge, wenn dieser Browser als Standard für HTTPS festgelegt ist; andernfalls wird das mitgelieferte Chromium verwendet.
- Das getrennte JARVIS-Profil bleibt erhalten, damit WhatsApp, Outlook und Snapchat ihre Anmeldung später auch im Hintergrund wiederverwenden können.
- Ein erfolgreicher Snapchat-Login erzeugt jetzt einen eindeutigen lokalen Verbindungsmarker. Vorhandene Browserdateien allein gelten nicht mehr fälschlich als Anmeldung.
- Falls Snapchat den Login in einem neuen Tab beendet, erkennt JARVIS diesen Tab ebenfalls.
- Die Hintergrundprüfung wartet nicht mehr auf einen sichtbaren `body`-Container.
- Nach dem Start einer Verbindungs-BAT aktualisiert die App den Status automatisch, sobald die Anmeldung abgeschlossen ist.

## Neu in v12.1.0 – One-Shot-Aktionen statt Rückfragen-Ketten

- Eindeutige E-Mail- und WhatsApp-Aufträge laufen jetzt über einen direkten, geprüften Pfad: verstehen, validieren, einmal ausführen, Ergebnis melden.
- Semantische Anweisungen wie „frag ihn, wie das Wetter ist“ oder „sag ihr, dass ich später komme“ gelten als vollständiger Inhalt. JARVIS formuliert daraus selbst einen kurzen natürlichen Text.
- E-Mail-Betreffzeilen werden automatisch aus dem Zweck gebildet und sind kein eigener Rückfrageschritt mehr.
- Nur Empfänger oder Mitteilungszweck dürfen noch eine Rückfrage auslösen; bereits bekannte Angaben werden nicht erneut abgefragt.
- Direkte Kommunikationsaktionen verwenden einen Idempotency-Key und können bei einem technischen Wiederholungsversuch nicht doppelt gesendet werden.
- Der Orchestrator verwendet standardmäßig `gpt-5.6-sol`; seine Aktionsausgabe wird durch ein striktes Schema geprüft.

## Fix in v12.0.1 – stabiler Snapchat-Web-Login

- Snapchat Web wird nach der manuellen Anmeldung über die sichere Webadresse statt über einen sichtbaren `body`-Container erkannt.
- Versteckte Snapchat-Seitencontainer lösen keinen falschen 15-Sekunden-Timeout mehr aus.
- Playwright-Ladefehler werden als kurze verständliche Meldung ausgegeben, nicht als langer Python-Traceback.
- WhatsApp verwendet weiterhin seine eigene Chatlisten-Prüfung; der Snapchat-Fix verändert die anderen Integrationen nicht.

## Neu in v12.0.0 – gebundener Kontext und störungsfreie Benachrichtigungen

- Ein lokaler Kontext-Orchestrator bindet aktive Projekte, passende Erinnerungen, erkannte Kontakte und die letzten Gesprächszüge vor jeder Realtime-Antwort.
- Eindeutige Folgeänderungen an einem aktiven Projekt werden direkt über den sicheren Projekt-Editor ausgeführt; das Sprachmodell kann nicht mehr auf eine falsche ZIP-Antwort ausweichen.
- Verändernde, aber mehrdeutige Aufträge erhalten einen strukturierten Plan mit freigegebenem Werkzeug oder genau einer Rückfrage.
- Apps und ausgewählte Personen beziehungsweise Gruppen lassen sich getrennt als Benachrichtigungsregeln verwalten.
- Automatische Ansagen entstehen ausschließlich bei einem echten neuen Treffer einer aktiven Regel. Ausbleibende Nachrichten erzeugen niemals eine Ansage.
- Die positive Benachrichtigungswarteschlange wartet auf das Ende von Antwort, Audio, Tool-Ausführung und Spracheingabe.
- WhatsApp, Gmail und Outlook nennen bei automatischen Treffern nur App und Absender; Inhalte werden erst auf ausdrückliche Nachfrage gelesen.
- Snapchat Web arbeitet als bestmögliche Metadaten-Prüfung für ausgewählte Chats. JARVIS öffnet keinen Chat und speichert keinen Nachrichteninhalt.
- v12 startet mit einem leeren Gesprächsverlauf. Kontakte, Logins, App-Profile, Einstellungen und dauerhafte Erinnerungen bleiben erhalten.

## Fix in v11.0.8 – verbindliche Nachrichtenroute und OpenAdapt-Browser

- Persönliche Nachrichtenfragen werden vor der Realtime-Antwort lokal und regelbasiert erkannt.
- „Habe ich irgendwelche Nachrichten?“ führt die gemeinsame WhatsApp-, Gmail- und Outlook-Prüfung jetzt verbindlich aus.
- Fragen nach der letzten Nachricht werden direkt an die Verlaufssuche weitergeleitet; das Sprachmodell kann nicht mehr mit einer allgemeinen Zugriffsverweigerung ausweichen.
- Fehlgeschlagene oder nicht verbundene Quellen werden einzeln genannt, während erfolgreiche Quellen weiterhin ausgewertet werden.
- OpenAdapt installiert Playwright nun ausdrücklich in seiner eigenen isolierten Umgebung.
- OpenAdapt gilt erst als bereit, wenn der Playwright-Import und die Chromium-Installation beide erfolgreich waren.

## Neu in v11.0.7 – quellenübergreifende Nachrichtensuche

- „Habe ich irgendwo Nachrichten?“ prüft immer alle verfügbaren Quellen: WhatsApp, Gmail und Outlook.
- Die Suche läuft weiter, wenn eine einzelne Quelle nicht verbunden oder vorübergehend nicht erreichbar ist.
- `search_messages` findet auch bereits gelesene Nachrichten nach Kontakt, E-Mail-Adresse, Alias oder WhatsApp-Gruppe.
- „Letzte Nachricht aus der Familiengruppe“ löst den Gruppenalias auf und liest den gewünschten Chat unsichtbar im Hintergrund.
- „Letzte Gmail von Asim Cetin“ verwendet bei einem gespeicherten Kontakt direkt dessen E-Mail-Adresse.
- Das Kontaktformular zeigt zuerst nur Name, Standardkanal, WhatsApp und E-Mail; selten benötigte Angaben sind einklappbar.
- WhatsApp-Gruppen haben einen eigenen kompakten Bereich mit kurzem Namen, exaktem Chatnamen und Aliasen.

## Neu in v11.0.6 – sichere Folgeänderungen und JARVIS-Dialoge

- Der gespeicherte aktive Projektpfad wird bei jeder neuen Sprachverbindung direkt an JARVIS übergeben.
- Beim Versionswechsel übernimmt JARVIS den zuletzt gültigen aktiven Projektpfad automatisch aus dem vorherigen Nachbarordner.
- Folgeaufträge wie „mach es flüssiger“, „ändere das“, „repariere es“ oder „baue weiter“ verwenden verbindlich den lokalen Projekt-Editor.
- JARVIS verlangt bei einem gespeicherten aktiven Projekt keinen erneuten ZIP-Upload.
- Browser-Bestätigungsfenster wurden durch einheitliche JARVIS-Systemdialoge ersetzt.
- „Alles aktivieren“ schaltet alle installierten und fertig eingerichteten Module gemeinsam ein.
- Nicht eingerichtete Module werden übersprungen; kritische Module bleiben außerhalb des Entwicklerprofils gesperrt.
- Für bereits bereite Module ist kein kompletter Neustart nötig. Eine neue Sprachverbindung übernimmt geänderte KI-Werkzeuge.

## Neu in v11.0.5 – bestehende Projekte und unsichtbarer Posteingang

- Das zuletzt erstellte oder ausdrücklich gewählte Projekt bleibt als aktives Projekt gespeichert.
- Folgeaufträge ändern den echten Projektordner direkt, statt nur Code zum Kopieren auszugeben.
- Vor jeder KI-Änderung entsteht ein lokales Wiederherstellungs-Backup.
- Änderungen werden atomar geschrieben, bytegenau geprüft und statisch validiert.
- Eine sichere `start.bat` ist bei ausdrücklichem Nutzerwunsch erlaubt.
- Outlook und WhatsApp Web werden beim Lesen im Headless-Modus geprüft – ohne sichtbare Browserfenster.
- Die Nachrichtenprüfung läuft serverseitig weiter, solange JARVIS läuft; die Oberfläche muss dafür nicht offen bleiben.

## Fix in v11.0.4 – Projekte am ausdrücklich gewählten Pfad

- JARVIS nimmt für neue Projekte nicht mehr automatisch den Desktop.
- Nennt der Nutzer einen vollständigen Zielpfad inklusive Projektordner, wird genau dort erstellt.
- Fehlt der Zielpfad, fragt JARVIS zuerst: „In welchem vollständigen Pfad soll ich das Projekt erstellen?“
- Relative Pfade werden abgelehnt; bestehende Zielordner werden weiterhin niemals überschrieben.
- Auch ein noch nicht vorhandener übergeordneter Ordner wird innerhalb des ausdrücklich gewählten Pfads sicher angelegt.

## Fix in v11.0.4 – Desktop-Projekte werden wirklich erstellt

- Neue bestätigungspflichtige Aktion `create_desktop_project` für komplette Websites, Spiele und Codeprojekte.
- JARVIS fragt bei einem eindeutig genannten Desktop-Projekt nicht mehr nach Explorer, Editor oder Fensternamen.
- Das starke Dateimodell erzeugt alle benötigten Dateien; JARVIS schreibt sie atomar in einen neuen Desktop-Ordner und prüft sie bytegenau.
- Bestehende Ordner werden niemals überschrieben. Pfad-Traversal, Secrets und ausführbare Dateien bleiben gesperrt.
- Allgemeine Desktop-Pläne werden nach einer sichtbaren Bestätigung direkt ausgeführt, statt nur unbemerkt als Plan liegenzubleiben.
- Fehlende Fensternamen werden nach einem eindeutigen `open`- oder `focus_window`-Schritt sicher übernommen.
- Der Realtime-Fehler `Missing required parameter: item.type` bei internen Nachrichtenhinweisen ist behoben.

## Fix in v11.0.2 – Windows-Installation ohne C++-Build-Tools

- **LiteLLM-Windows-Fix:** Der Installer verwendet die geprüfte universelle Version `1.91.4`, statt die Rust-basierte Version `1.93.0` lokal kompilieren zu wollen.
- **Kein Visual Studio nötig:** Für LiteLLM sind Quellcode-Builds ausdrücklich deaktiviert. `link.exe` und die großen Visual Studio Build Tools werden nicht benötigt.
- **Vorhandene Umgebung reparierbar:** Eine bei v11.0.1 angelegte Python-3.12-Umgebung kann direkt weiterverwendet und beim nächsten Start vervollständigt werden.
- **Lesbarer Fehlerbericht:** `data/installer/module-install.log` wird vollständig als UTF-8 geschrieben.

## Fix in v11.0.1 – automatische, isolierte Modulinstallation

- **Python 3.12 statt zufälliger Standardversion:** Der Installer findet Python 3.12 oder richtet es über Windows Package Manager ein. Python 3.14 wird für die v11-Module bewusst nicht verwendet.
- **Eigene JARVIS-Umgebung:** Kern, Agenten, Memory, Offline-Stimme und Vision werden unter `.venv` installiert. Globale Python-Pakete werden nicht mehr verändert.
- **Konfliktfreie Experimentalpakete:** Open Interpreter, OpenAdapt und OpenVoiceOS erhalten getrennte Umgebungen unter `.jarvis_envs`.
- **Automatische Zusatzschritte:** Playwright Chromium sowie bei „Alles“ Node.js, whatsapp-web.js, Ollama, Git und Rust/Cargo werden mit eingerichtet.
- **Fehlerbericht:** `data/installer/module-install.log` und `module-status.json` zeigen genau, was installiert wurde und was fehlgeschlagen ist.
- **Automatischer Erststart:** Fehlt die Umgebung, richten `JARVIS_APP_STARTEN.bat` und `STARTEN.bat` sie selbst ein.
- **Behobener SQLCipher-Fehler:** Unter Windows wird ein vorhandenes Python-3.12-Wheel verwendet.

## Neu in v11.0.0 – Agent OS

- **Alle 45 ausgewählten GitHub-Bausteine:** Die neue Modul-Matrix zeigt für jeden Baustein `aktiv`, `bereit` oder `Setup nötig`, Kategorie, Risiko und Installationsgruppe.
- **Echter Desktop-Control-Modus:** JARVIS kann sichtbare Windows-Abläufe als strukturierte Schritte planen, Fenster fokussieren, UI-Controls anklicken, Maus/Tastatur bedienen, scrollen und Ziele öffnen.
- **Sicherer Ausführungsweg:** Direkte API vor Windows UI Automation, Playwright und erst danach optionaler Vision-Fallback. Maus- und Tastaturpläne werden sichtbar gespeichert und separat bestätigt.
- **Desktop Not-Aus:** Jede laufende Desktop-Automation kann sofort gestoppt werden. Terminal, Installationen, Löschaktionen, Käufe und kritische Agenten sind standardmäßig gesperrt.
- **Gelernte Workflows:** Vorgeführte, geprüfte Abläufe können als lokale Workflows gespeichert und später erneut gestartet werden.
- **Agenten und Missionen:** OpenAI Agents SDK, Realtime-Agent-Architektur, LangGraph, Tenacity, LiteLLM, MCP und Pluggy sind über die gemeinsame Agent-Schicht vorbereitet.
- **Memory v11:** Mem0, sqlite-vec und Graphiti sind optional angebunden. RapidFuzz verbessert Kontaktauflösung, `phonenumbers` prüft Nummern und `dateparser` versteht natürliche deutsche Zeiten.
- **Offline Voice Stack:** openWakeWord, Silero VAD, RNNoise, faster-whisper, Piper, sherpa-onnx und OpenVoiceOS sind als getrennte Installationsgruppe vorhanden.
- **Datei-Agent:** MarkItDown und Watchdog stehen für lokale Dokumentumwandlung und überwachte Ordner bereit.
- **Sicherheit:** API-Schlüssel lassen sich über `SECRETS_SCHUETZEN.bat` in den Windows Credential Manager verschieben. SQLCipher bleibt als bewusste optionale Datenbankmigration getrennt.
- **Windows-App:** `JARVIS_APP_STARTEN.bat` startet die UI über pywebview ohne normale Browserleiste.
- **Externe Dienste:** OmniParser, Ollama, UI-TARS und der optionale whatsapp-web.js-Adapter haben getrennte lokale Konfigurationen. Sie werden niemals automatisch gestartet.
- **Neue UI:** Agent OS ist als dritter Hauptbereich neben Unified Inbox und Mission Control eingebaut; die globale Einstellungssuche findet auch alle 45 Module.
- **Kompatibel:** WhatsApp Desktop, Gmail, Outlook, Kontakte, Gruppen, Routinen, Nachrichten, Missionen, Memory, Kamera, Bildschirm und alle v10-Funktionen bleiben erhalten.

### Installation

1. ZIP entpacken.
2. `JARVIS_APP_STARTEN.bat` starten. Beim ersten Start werden Kern und alle installierbaren Module automatisch eingerichtet.
3. Alternativ kann `INSTALLIEREN.bat` zuerst separat ausgeführt werden.

Konten, API-Schlüssel, Spotify, Home Assistant sowie große externe Modelle wie OmniParser und UI-TARS benötigen weiterhin ihre jeweilige Verbindung oder Konfiguration. Die Installation aktiviert kritische Module nicht automatisch; dafür gelten weiterhin Sicherheitsprofil und Bestätigung.

## Neu in v10.0.0 – Autonomous Intelligence System

- **Mission Control:** Mehrstufige Aufträge werden als 1 bis 20 sichtbare Schritte gespeichert. Jeder Schritt zeigt `bereit`, `läuft`, `erfolgreich` oder `fehlgeschlagen`; Missionen lassen sich starten, pausieren, erneut starten und abbrechen.
- **Sicherer Missions-Agent:** JARVIS verwendet ausschließlich freigegebene strukturierte Aktionen. Strikte Missionen benötigen für externe Schritte eine vorhandene Dauerfreigabe; im ausgewogenen Modus gelten Autonomie und bestehende Berechtigungen.
- **Unified Inbox:** Neue WhatsApp-, Gmail- und Outlook-Nachrichten erscheinen gemeinsam im Command Center. Doppelte Nachrichten werden anhand ihrer Dienst-ID automatisch zusammengeführt.
- **Vorlesen und Antworten wie Siri:** JARVIS nennt zuerst Absender und Quelle, fragt auf Wunsch vor dem Vorlesen und sendet nur eine klar diktierte Antwort. WhatsApp-Antworten verwenden exakt den Chat, aus dem die neue Nachricht stammt.
- **Privatsphäre:** Bei gesperrtem Windows-PC werden keine Nachrichteninhalte vorgelesen. Automatische Prüfung läuft nur, solange JARVIS aktiv ist, und kann vollständig ausgeschaltet werden.
- **V10 Command Center:** Unified Inbox und Mission Control sind direkt am Reaktor erreichbar. Ungelesene Nachrichten und aktive Missionen sind dauerhaft sichtbar.
- **Bildschirmverständnis auf Wunsch:** Über `SCREEN` oder einen eindeutigen Sprachbefehl kann ein Fenster/Bildschirm freigegeben werden. JARVIS verarbeitet pro Frage nur ein aktuelles Standbild; beim Stoppen wird die Freigabe sicher beendet.
- **Neue Systemzustände:** `LISTEN`, `THINK`, `EXECUTE`, `ASK` und `SPEAK` zeigen sofort, was JARVIS gerade macht.
- **Globale Einstellungssuche:** Durchsucht alle Einstellungsbereiche sowie geladene Kontakte, WhatsApp-Gruppen, Routinen, Berechtigungen und Missionen.
- **Bestehende Funktionen bleiben erhalten:** WhatsApp Desktop, Outlook Web, Gmail, Kalender, Kontakte, Gruppen, Routinen, Auto-Close, Memory, Kamera, Dateien, Websuche, Backups und Code-Workspaces wurden übernommen.
- Funktionsnummer im Dateinamen: `v10_0_0`.

Hinweis für Gmail: Die bestehende Gmail-Verbindung kann weiterhin senden. Für das erstmalige Lesen neuer Gmail-Nachrichten muss einmal `GMAIL_VERBINDEN.bat` gestartet werden, damit Google zusätzlich den Nur-Lesen-Zugriff freigibt. WhatsApp und Outlook verwenden die übernommenen Profile weiter.

## Neu in v9.8.0 – Aktionszentrum, Routinen und Auto-Close

- **Apps automatisch schließen:** WhatsApp Desktop wird nach einer erfolgreichen Aktion automatisch geschlossen, wenn JARVIS das Fenster selbst geöffnet hat. Ein bereits vorher geöffnetes WhatsApp-Fenster bleibt unangetastet. Outlook-Webaktionen schließen ihr eigenes Automationsfenster wie bisher direkt nach Abschluss.
- **Aktionszentrum:** Externe Aktionen zeigen jetzt `wird ausgeführt`, `erfolgreich` oder `fehlgeschlagen`, den verwendeten Dienst, die technische Bestätigung und ob das gestartete Fenster geschlossen wurde.
- **Wiederholen:** Fehlgeschlagene Aktionen können im Aktionszentrum gezielt erneut ausgeführt werden. Die maximale Zahl manueller Versuche ist einstellbar.
- **Routinen:** Wiederkehrende WhatsApp- und E-Mail-Nachrichten lassen sich täglich, montags bis freitags oder an einem bestimmten Wochentag planen. Sie laufen lokal, solange JARVIS gestartet und Autonomie aktiviert ist.
- **Schnellaktionen:** WhatsApp, Outlook-Schulmail, Kalendertermin und Timer sind direkt unter dem Reaktor erreichbar.
- **Verbindungsstatus:** WhatsApp, Gmail, Outlook, Mikrofon und Kamera sind im Hauptbildschirm sofort sichtbar.
- **Aufgeräumtes Kontrollzentrum:** Allgemein, Dienste, Automation und System sind jetzt als Tabs getrennt.
- **Kontaktlernen:** Nach einer erfolgreichen Kommunikation wird die Nutzung gezählt; bei Kontakten mit Kanalwahl `Automatisch` merkt sich JARVIS den erfolgreich verwendeten Kanal.
- **Kompakterer Reaktor:** Der Reaktor ist etwas kleiner, damit Status und Schnellaktionen ohne Überladung Platz haben.
- Funktionsnummer im Dateinamen: `v9_8_0`.

## Fix in v9.7.3 – WhatsApp Desktop ohne Zusatzmodul

- Die Desktop-Steuerung verwendet jetzt direkt die eingebauten Windows-APIs.
- `pywinauto` und `pyperclip` werden nicht mehr benötigt.
- Kontakte werden weiterhin über ihre Nummer geöffnet; Gruppen weiterhin über den exakt gespeicherten Chatnamen gesucht.
- Bei einem Fehler nennt JARVIS den konkreten Schritt, an dem die Windows-Steuerung gescheitert ist.
- Bestehende Kontakte, Gruppen, Logins, Konten und Memory-Daten werden unverändert übernommen.

Diese Version erweitert den bisherigen Integration Hub um WhatsApp Desktop, gespeicherte Gruppen und ein deutlich robusteres Kontaktbuch. Alle bisherigen Sprach-, Datei-, Gedächtnis-, Outlook-, Gmail-, Stabilitäts- und Sicherheitsfunktionen bleiben enthalten.

## Neu in v9.7.2 – WhatsApp Desktop, Gruppen und bessere Kontakte

- **WhatsApp Desktop statt Edge:** JARVIS öffnet die installierte WhatsApp-App über das registrierte Windows-Protokoll und sendet eindeutige einzelne Textnachrichten automatisch.
- **Gespeicherte Gruppen:** Gruppen haben einen JARVIS-Namen, einen exakten WhatsApp-Chatnamen und mehrere Aliase. „Schreib in die Gruppe Familie …“ wird dadurch eindeutig aufgelöst.
- **Bessere Kontakte:** Zusätzlich zu Namen und Aliasen werden WhatsApp-Chatname, Beziehung, Organisation, bevorzugter Kanal und Nutzungshäufigkeit gespeichert.
- **Sprachrobuste Suche:** Groß-/Kleinschreibung, Satzzeichen und Akzente führen nicht mehr unnötig zu verschiedenen Kontakten. Kollisionen zwischen Kontakten und Gruppen werden beim Speichern verhindert.
- **Kein erfundener Inhalt:** Fehlt der Nachrichtentext, fragt JARVIS kurz nach, anstatt einen Zugriff zu verneinen oder etwas zu erfinden.
- **Sichere Migration:** Bestehende Kontakte, Memory, Einstellungen, Gmail-/Outlook-Verbindungen, `.env` und bisherige Browserprofile bleiben erhalten. Die vorhandene Datenbank wird nur erweitert.
- Funktionsnummer im Dateinamen: `v9_7_2`.

## Neu in v9.7.1 – Outlook Web ohne Graph-Adminfreigabe

- **Einmal anmelden:** `OUTLOOK_VERBINDEN.bat` öffnet ein eigenes lokales Edge-Profil. Nach der Anmeldung am Schulpostfach bleibt die Sitzung ausschließlich unter `data/outlook_web_profile` gespeichert.
- **Schulmails automatisch senden:** Eindeutig beauftragte einzelne Outlook-Mails werden als vorausgefüllte Nachricht in Outlook Web geöffnet und automatisch über **Send/Senden** abgeschickt.
- **Schultermine automatisch speichern:** Outlook-Kalendertermine werden vorausgefüllt und automatisch über **Save/Speichern** beziehungsweise bei Teilnehmern über **Send/Senden** abgeschlossen.
- **Kein Entra-Zwang:** Im Standardmodus `JARVIS_OUTLOOK_MODE=web` werden keine Client-ID, kein Microsoft-Graph-Token und keine Administratorzustimmung benötigt.
- **Graph bleibt optional:** Wer später eine offizielle Freigabe erhält, kann `JARVIS_OUTLOOK_MODE=graph` setzen und die bisherige Microsoft-Graph-Anbindung weiterverwenden.
- **Experimenteller Webmodus:** Microsoft kann Oberfläche, Selektoren, Loginregeln oder Schulrichtlinien jederzeit ändern. Dann stoppt JARVIS mit einer klaren Fehlermeldung, statt eine unvollständige Aktion als erfolgreich zu melden.
- Funktionsnummer im Dateinamen: `v9_7_1`.

## Neu in v9.7.0 – Autonomie und verbundene Konten

- **Autonomie ohne ständige Rückfragen:** Im Kontrollzentrum ist Autonomie standardmäßig aktiv. Eindeutig beauftragte einzelne Nachrichten, Kalendertermine, freigegebene Webhooks und Startziele werden ohne erneute Bestätigungsfrage ausgeführt.
- **Bewusst begrenzt:** Autonomie gilt nicht für Sammelnachrichten, unklare Empfänger, Käufe, Banking, Passwortänderungen, irreversible Löschaktionen oder beliebige Terminal-/Administratorbefehle.
- **WhatsApp-Testnummer:** JARVIS nutzt dafür die installierte WhatsApp-Desktop-App; der frühere Webmodus bleibt nur als technischer Rückfall erhalten.
- **Outlook = Schule:** Nennt der Nutzer Outlook, Schule oder Schulmail, wählt JARVIS immer `outlook_school`.
- **Gmail = privat:** Nennt der Nutzer Gmail oder privat, wählt JARVIS immer `gmail_private`.
- **Automatische Route:** Wird kein Konto genannt, gelten zuerst die Kontaktpräferenz und erkannte Schuldomain, danach Gmail privat als Standard.
- **Direkte Kalender:** Mit den gleichen Konten erstellt JARVIS Schultermine über Microsoft Graph und private Termine über Google Calendar. Ohne eingerichtetes Konto bleibt der sichere Kalenderentwurf erhalten.
- **Tokens bleiben lokal:** Google- und Microsoft-OAuth-Tokens werden nur unter `data/` gespeichert, nicht an das Modell gesendet und nicht in Ergebnis-ZIPs übernommen.
- Funktionsnummer im Dateinamen: `v9_7_0`.

## Neu in v9.6.1 – einmal fragen, danach automatisch

- **Drei klare Entscheidungen:** Beim ersten Kommunikations-, Kalender-, Webhook- oder Startbefehl zeigt JARVIS **Abbrechen**, **Nur dieses Mal** und **Für dieses Ziel immer**.
- **Eng begrenzte Dauerfreigaben:** Eine Freigabe gilt nur für den aufgelösten Kontakt und Kanal, das konkrete PC-Ziel, den konkreten Webhook oder neue Kalendertermine – niemals automatisch für unbekannte Empfänger.
- **Automatisches Öffnen:** WhatsApp-, E-Mail- und Kalenderentwürfe sowie freigegebene Webseiten werden unter Windows nach der Freigabe automatisch über das registrierte Standardprogramm geöffnet. Falls Windows oder der Browser das verhindert, bleibt die sichere Öffnen-Schaltfläche sichtbar.
- **Direkte Integrationen:** Telegram, SMTP, WhatsApp Business Cloud und Webhooks werden nach einer gespeicherten Freigabe ohne erneute Nachfrage ausgeführt.
- **Widerruf:** Jede Dauerfreigabe ist im Kontrollzentrum einzeln sichtbar, zählt automatische Nutzungen und kann sofort widerrufen werden.
- **Persönliches WhatsApp:** Der passende Chat und Nachrichtentext öffnen automatisch; bei einem normalen persönlichen Konto bleibt der abschließende WhatsApp-Klick auf **Senden** erforderlich.
- Funktionsnummer im Dateinamen: `v9_6_1`.

## Neu in v9.6.0 – Integration Hub

- **Lokales Kontaktbuch:** Namen, eindeutige Aliase, WhatsApp-Nummer, E-Mail und Telegram-Chat-ID werden in SQLite gespeichert und im Kontrollzentrum verwaltet. Das Modell sieht beim Auflisten nur Namen, Aliase und verfügbare Kanäle – keine Adressen oder privaten Notizen.
- **WhatsApp für persönliche Konten:** JARVIS öffnet einen fertigen `wa.me`-Entwurf mit Kontakt und Nachricht. Wegen der WhatsApp-Schnittstellenregeln drückt der Nutzer im persönlichen Modus selbst auf **Senden**.
- **WhatsApp Business Cloud API:** Für passende geschäftliche Anwendungsfälle kann nach eigener Meta-Einrichtung auf `JARVIS_WHATSAPP_MODE=cloud` umgestellt werden. Access Token und Phone Number ID bleiben ausschließlich in der privaten `.env`.
- **Telegram:** Bestätigte Nachrichten können über einen eigenen Telegram-Bot und gespeicherte numerische Chat-IDs wirklich gesendet werden.
- **E-Mail:** Standardmäßig wird ein fertiger Entwurf im lokalen Mailprogramm geöffnet. Optional sendet JARVIS über ausdrücklich konfiguriertes SMTP.
- **Google-Kalender:** Titel, Beginn, Ende, Beschreibung, Ort und Teilnehmer werden als fertiger Kalenderentwurf vorbereitet. Relative Zeitangaben verwenden die konfigurierte Zeitzone, standardmäßig `Europe/Vienna`.
- **Automations-Webhooks:** Nur namentlich in `JARVIS_WEBHOOKS_JSON` erlaubte HTTPS-Endpunkte können ausgelöst werden. Beliebige Modell-URLs, Zugangsdaten in URLs und lokale Ziele sind standardmäßig blockiert.
- **PC-Launcher:** Google, YouTube, Gmail, Kalender, Maps, Spotify sowie unter Windows Rechner, Editor, Explorer und Einstellungen sind als feste Startziele vorhanden. Zusätzliche sichere Webseiten lassen sich per `.env` ergänzen; beliebige Programme oder Dateipfade nicht.
- **Sicherheitsvorschau:** Nachrichten, Termine, Webhooks und PC-Aktionen benötigen eine Einmal- oder gezielte Dauerfreigabe. Empfänger dürfen nicht geraten werden und Sammelnachrichten sind im JARVIS-Prompt verboten.
- **Doppelschutz:** Idempotency-Keys verhindern, dass Browser- oder Netzwerk-Wiederholungen dieselbe bestätigte Aktion doppelt ausführen.
- **Safe Mode:** Nach einem unsauberen Ende bleiben alle externen Integration-Hub-Aktionen gesperrt, bis der Safe Mode bewusst verlassen wurde.
- Funktionsnummer im Dateinamen: `v9_6_0`.

## Neu in v9.5.4 – lange Antworten ohne festen Abbruch

- Das bisherige feste Realtime-Limit von 900 gemeinsamen Text-/Audio-Tokens wurde durch die von der API unterstützte unbegrenzte Einstellung `inf` ersetzt.
- Konkrete Vorgaben wie „300 Wörter“, vollständige Geschichten, Listen und ausführliche Erklärungen haben Vorrang vor der standardmäßig kurzen Antwortlänge.
- Meldet die API trotzdem eine unvollständige Antwort mit dem Grund `max_output_tokens`, setzt JARVIS sie automatisch ohne Wiederholung oder neue Einleitung fort.
- Die automatische Fortsetzung wartet auf das Ende des bereits gepufferten Tons, damit sich keine zwei Sprachausgaben überlagern.
- Fortsetzungen werden in derselben JARVIS-Nachricht weitergeschrieben und erst als vollständige Antwort im lokalen Verlauf gespeichert.
- Zum Schutz vor einer Fehlerschleife stoppt die Automatik nach drei Fortsetzungen; danach kann weiterhin manuell „Weiter“ gesagt werden.
- Patch-Nummer im Dateinamen: `v9_5_4`.

## Neu in v9.5.3 – vollständiges Live-Transkript

- Einzelne Transkript-Deltas werden weiterhin sofort live in den Chat geschrieben.
- Das offizielle finale Ereignis `response.output_audio_transcript.done` ersetzt einen möglicherweise unvollständigen Live-Text durch das vollständige Audiotranskript.
- `response.content_part.done` und das fertige `response.done` dienen als zusätzliche Rückfallebenen, falls ein Browser ein einzelnes Delta- oder Done-Ereignis nicht verarbeitet.
- Erst nach der finalen Synchronisierung wird die vollständige JARVIS-Antwort im lokalen Gesprächsverlauf gespeichert.
- Mehrere Audio-Inhaltsteile werden in ihrer ursprünglichen Reihenfolge zusammengesetzt.
- Patch-Nummer im Dateinamen: `v9_5_3`.

## Neu in v9.5.2 – Windows-Migrationsfix

- SQLite-Quell- und Zieldatenbank werden vor dem finalen Umbenennen der importierten Datenbank ausdrücklich geschlossen.
- Dadurch blockiert Windows `jarvis.db.importing` nicht mehr mit `WinError 32`.
- Eine übrig gebliebene `.importing`-Datei nach einem abgebrochenen Start wird beim nächsten Versuch sicher entfernt; scheitert die Bereinigung erneut, startet JARVIS ohne einen zweiten Absturzversuch weiter.
- Patch-Nummer im Dateinamen: `v9_5_2`.

## Neu in v9.5.1 – eine fortlaufende JARVIS-Timeline

- **Eine Unterhaltung statt Sitzungen:** Ruhemodus, Seitenneuladen und Realtime-Neuverbindungen beginnen für JARVIS kein neues Gespräch mehr.
- **Keine Fortsetzungsfrage:** Der automatische Vorschlag „Am letzten Projekt weiterarbeiten“ wird nicht mehr erzeugt; bereits gespeicherte Exemplare werden beim Start still deaktiviert.
- **Nahtloser Neustart:** Die letzten Gesprächszüge und dauerhaften Erinnerungen werden direkt in jede neue technische Realtime-Verbindung übernommen, ohne Wiederherstellungsansage im Chat.
- **Nahtloses Versionsupdate:** Fehlt beim ersten Start die neue Datenbank, übernimmt v9.5.1 automatisch die neueste intakte `data/jarvis.db` aus einem danebenliegenden älteren `JARVIS_VisionVoice_v...`-Ordner. Bei einem ausdrücklich gesetzten `JARVIS_MEMORY_DB` findet keine automatische Migration statt.
- **Rückgriff auf ältere Gespräche:** Bei einer Anspielung auf Vergangenes durchsucht JARVIS nicht mehr nur die letzten 50 Einträge, sondern die gesamte lokal gespeicherte Timeline nach passenden Begriffen. Nur relevante Ausschnitte werden in das Modellfenster geladen.
- **Vollständiger lokaler Verlauf:** Nutzer- und JARVIS-Nachrichten bleiben in SQLite erhalten, bis du sie über „Chat löschen“ oder die Datenschutz-Bereinigung ausdrücklich entfernst.
- **ZIP-Template-Fix:** Sichere Vorlagendateien wie `.env.example` in einem ZIP werden korrekt analysiert. Echte `.env`- und Secret-Dateien bleiben weiterhin ausgeschlossen.
- Patch-Nummer im Dateinamen: `v9_5_1`.

## Neu in v9.5.0 – richtiger Code-Workspace

- **Persistente ZIP-Projekte:** Ein Projekt-ZIP lässt sich im Kontrollzentrum importieren und bleibt unter `data/workspaces` erhalten, bis du den Workspace ausdrücklich löschst.
- **Projektstruktur statt Einmal-Upload:** Relative Pfade, Textdateien, Assets und sensible Dateien bleiben im lokalen Projekt erhalten. Abhängigkeits- und Build-Ordner wie `node_modules`, `.git`, `.venv`, `vendor`, `build` und `dist` werden beim Import ausgelassen.
- **Lokaler Code-Editor:** Unterstützte UTF-8-Code- und Konfigurationsdateien bis 2 MB können geöffnet, erstellt, gespeichert, umbenannt und gelöscht werden.
- **Secret-Isolierung:** Echte `.env`-, Schlüssel- und Secret-Dateien bleiben im lokalen Projekt und im späteren Projekt-Export erhalten, werden aber weder im Editor angezeigt noch an die KI gesendet oder von ihr geändert.
- **KI-Änderungsvorschläge:** Der Code-Workspace verwendet das stärkste konfigurierte Dateimodell. Änderungen werden als vollständige neue Dateien vorgeschlagen und zunächst nur als Diff gespeichert.
- **Bestätigung vor Anwendung:** Ein KI-Vorschlag verändert das Projekt erst nach ausdrücklicher Bestätigung. Ist eine Datei seit Erstellung des Vorschlags manuell verändert worden, wird die Anwendung zum Schutz vor Überschreiben blockiert.
- **Snapshots und Rücksprung:** Beim Import entsteht eine Basisversion. Manuelle Snapshots und automatische Sicherheits-Snapshots vor KI-Änderungen oder Wiederherstellungen erlauben einen lokalen Rücksprung; höchstens zehn Snapshots pro Workspace bleiben erhalten.
- **Sichere Projektprüfung:** Python, JSON, TOML, XML/SVG, HTML und CSS werden statisch auf grundlegende Syntaxfehler geprüft. Hochgeladener Projektcode wird dabei niemals lokal ausgeführt.
- **Gesamt-Diff:** Änderungen gegenüber der Import-Basis sind jederzeit sichtbar; Inhalte sensibler und binärer Dateien bleiben dabei verborgen.
- **Echter Projektexport:** Das aktuell bearbeitete Projekt kommt als neues ZIP zurück – einschließlich lokal aufbewahrter sensibler Dateien, aber ohne die internen JARVIS-Snapshots und Vorschlagsdaten.
- **Importgrenzen:** maximal 25 MB ZIP, 500 Einträge, 10 MB pro Datei und 80 MB entpackt; Zip-Slip, doppelte Pfade, Symlinks, verschlüsselte Einträge und extreme Kompression werden blockiert.
- Funktionsnummer im Dateinamen: `v9_5_0`.

## Neu in v9.4.1 – Stability & Recovery

- **Persistente Hintergrundaufträge:** Komplexe Aufgaben und Websuchen können im Kontrollzentrum als Auftrag gestartet werden. Status, Versuche, Frage und Ergebnis liegen in SQLite und überstehen einen Neustart.
- **Automatische Wiederholung:** Vorübergehende Fehler wie HTTP 429/5xx werden mit kurzem exponentiellem Abstand erneut versucht. Nach mehreren Fehlern pausiert ein persistenter Circuit Breaker den betroffenen externen Dienst vorübergehend.
- **Modell-Fallbacks:** Realtime, Luna, Terra, Websuche und Datei-Arbeitsmodus können jeweils eine geordnete Ersatzmodell-Liste verwenden, falls ein Modell nicht verfügbar oder nicht unterstützt ist.
- **Automatische lokale Backups:** Beim Start wird höchstens einmal täglich ein begrenztes SQLite-Backup angelegt; die letzten sieben bleiben erhalten. Manuelle Exporte und streng validierte Wiederherstellung sind im Kontrollzentrum verfügbar.
- **Rollback vor Wiederherstellung:** Vor dem Einlesen eines Backups erzeugt JARVIS automatisch ein lokales Rücksprung-Backup. `.env` und API-Schlüssel sind niemals Bestandteil eines Laufzeit-Backups.
- **Safe Mode nach unsauberem Ende:** Erkennt JARVIS einen abgebrochenen Serverlauf, bleiben externe Modellarbeit, reale Smart-Home-/Kamera-Integrationen und Hintergrundaufträge zunächst geschützt aus. Lokale Diagnose, Speicher und Einstellungen bleiben erreichbar.
- **Start-Selbsttest:** Datenbankintegrität, Schreibrechte der Ausgabe- und Backup-Verzeichnisse, freier Speicher und OpenAI-Konfiguration werden geprüft und im Kontrollzentrum angezeigt.
- **Token-Budget:** Tages- und Monatsgrenzen, Warnschwelle sowie optionaler harter Stopp lassen sich einstellen. Realtime-, Web-, Reasoning- und Datei-Nutzung wird ereignisgenau und doppelsicher erfasst.
- **Stabilitätsoberfläche:** Safe Mode, Selbsttest, letztes Backup, Auftragsstatus und Budget sind ohne Konsole sichtbar und steuerbar.
- Patch-Nummer im Dateinamen: `v9_4_1`.

## Neu in v9.4.0 – Brains & Safety

- **Kontextbewusstes lokales Gedächtnis:** Vor jeder normalen Frage werden passende Erinnerungen und letzte Gesprächsausschnitte lokal bewertet und still an JARVIS übergeben. Erinnerungen lassen sich jetzt auch bearbeiten.
- **Vorsichtige Absichtserkennung:** Fortsetzungen und Folgefragen werden erkannt. Bei mehrdeutigen ändernden Aktionen muss JARVIS nach Ziel oder Wert fragen, statt etwas zu erraten.
- **Proaktive, nicht aufdringliche Hinweise:** JARVIS kann passende Vorschlagskarten im Chat zeigen. Sie machen keinen Ton, erscheinen nicht während eines aktiven Gesprächs, respektieren Ruhezeiten und führen niemals automatisch eine Aktion aus.
- **Datenschutz-Steuerung:** Proaktivität, Ruhezeiten sowie Löschfristen für Verlauf, Audit und Fehler lassen sich im Kontrollzentrum verwalten.
- **Local-first Netzwerksschutz:** `STARTEN.bat` bindet weiterhin nur an `127.0.0.1`. Fernzugriff ist standardmäßig gesperrt; LAN-Betrieb benötigt ausdrücklich `JARVIS_ALLOW_LAN=true` und einen Bearer-Token.
- **Einmalige Aktionsbestätigungen:** Bestätigungen sind 90 Sekunden gültig, nur einmal verwendbar und an Werkzeug plus konkrete Nutzdaten gebunden. Der alte reine Browser-Header ist keine Fernzugriffs-Sicherheitsgrenze mehr.
- **Smart-Home-Risikostufen:** Entity-Allowlist, niedrige/mittlere/hohe Aktionsrisiken, Request-IDs, Audit-Metadaten und Idempotency-Keys verhindern unklare Ziele und doppelte Netzwerkaktionen.
- **Robuster lokaler Zustand:** Rate Limits und Aktionsbelege liegen in SQLite. Erzeugte Download-Bundles liegen kurzlebig auf der lokalen Platte, funktionieren nach einem Serverneustart weiter und werden per TTL/Gesamtlimit bereinigt.
- **Strengere Ergebnis-ZIPs:** Doppelte Pfade, verschachtelte Archive, zu große Einträge, extreme Kompression, Secret-Dateien, ausführbare und nicht erlaubte Dateitypen werden blockiert.
- **Getrennte Diagnose-Endpunkte:** `/health` meldet öffentlich nur noch `{ "ok": true }`; Details bleiben hinter der lokalen bzw. authentifizierten Oberfläche.
- Funktionsnummer im Dateinamen: `v9_4_0`.

## Neu in v9.3.0

- ZIP-Projekte lassen sich über die Büroklammer, Drag-and-drop oder die Zwischenablage hochladen.
- JARVIS liest unterstützte Dateien innerhalb eines ZIPs im Arbeitsspeicher, behält deren relative Projektpfade und kann mehrere Dateien gemeinsam bearbeiten.
- Bei Datei-Aufgaben wird immer das stärkste konfigurierte Modell verwendet: standardmäßig `TERRA_MODEL`, optional ausdrücklich über `FILE_WORKSPACE_MODEL` überschreibbar.
- Erstellte oder bearbeitete Dateien erscheinen als echte Downloads im Chat – einzeln und gemeinsam als `jarvis-ergebnis.zip`.
- Für PDF-, Office-, Tabellen-, Bild- und ZIP-Ergebnisse kann das stärkste Modell den abgeschotteten OpenAI-Code-Interpreter verwenden. Hochgeladene Programme oder Projekte dürfen darin nicht ausgeführt werden.
- Die Downloadlinks bleiben etwa 15 Minuten verfügbar; Uploads werden nicht dauerhaft gespeichert, Ergebnis-Bundles liegen bis zum Ablauf kurzzeitig unter `data/generated`.
- Schutz vor Pfad-Traversal, symbolischen Links, verschlüsselten Archiven, ZIP-Bombs, doppelten Pfaden und verschachtelten ZIPs.
- Echte `.env`-, Schlüssel- und typische Secret-Dateien sowie Abhängigkeitsordner wie `node_modules`, `.git`, `.venv`, `vendor`, `build` und `dist` werden aus der KI-Analyse ausgeschlossen.
- Archive werden niemals ausgeführt. Ausführbare Dateien, Schlüsseldateien und echte `.env`-Dateien werden weder erzeugt noch als KI-Ergebnis angenommen.
- Funktionsnummer im Dateinamen: `v9_3_0`.

## Enthalten aus v9.2.3

- „Stopp“, „Warte“, „Pause“ oder „Moment“ pausiert eine laufende Antwort lokal, ohne eine unnötige neue KI-Antwort zu erzeugen.
- „Weiter“, „Mach weiter“, „Erzähl weiter“ oder „Fahr fort“ setzt die unterbrochene Antwort ohne Zusammenfassung und möglichst ohne Wiederholung fort.
- Beim Audiostopp wird der ungehörte Teil aus dem Realtime-Gespräch entfernt, damit JARVIS die richtige Fortsetzungsstelle kennt.
- Die Fortsetzung bleibt auch nach dem normalen Ruhemodus verfügbar; seit v9.5.1 wird ein technischer Neustart zusätzlich wieder an die lokale fortlaufende Timeline angebunden.
- Die vom Nutzer bereitgestellte `.env` wird ab dieser Version in das ZIP aufgenommen.
- Patch-Nummer im Dateinamen: `v9_2_3`.

> **Wichtig:** Die beigefügte `.env` kann deinen privaten OpenAI-API-Schlüssel enthalten. Teile das ZIP nicht öffentlich und lade es nicht in ein öffentliches GitHub-Repository hoch. `.gitignore` schützt die `.env` weiterhin vor einem normalen Git-Commit.

## Enthalten aus v9.2.2

- Das vollständige Ergebnis einer Foto- oder Dateianalyse wird still in den laufenden Realtime-Gesprächskontext übernommen.
- JARVIS kann danach Folgefragen wie „Erkläre Schritt 2“ oder „Welche Zeile muss ich ändern?“ beantworten.
- Die kurze Sprachbestätigung liest weiterhin keine langen Rechnungen, Dokumente oder Codeblöcke vor.
- Der Analysekontext bleibt im Ruhemodus erhalten und wird bei einer automatischen Realtime-Wiederverbindung erneut synchronisiert, solange die Seite geöffnet bleibt.
- Analyseinhalte bleiben als nicht vertrauenswürdige Daten gekennzeichnet und können keine Systemanweisungen ersetzen.
- Neues Versionsschema: Hauptversion `9`, Funktionsversion `2`, zweite kleine Verbesserung `2` – im Dateinamen `v9_2_2`.

## Enthalten aus v9.2.1

- Einstellbare Stimmenisolierung: **Stark**, **Ausgewogen** oder **Empfindlich**.
- Browser-Rauschunterdrückung, Echounterdrückung und OpenAI-Far-Field-Filter arbeiten gemeinsam.
- Hintergrundgeräusche unterbrechen JARVIS nicht mehr sofort.
- Eine laufende Antwort wird erst unterbrochen, nachdem echte Sprache transkribiert und geprüft wurde.
- Sehr kurze Geräuschtranskripte, typische Fülllaute und erkannte Lautsprecher-Echos werden ignoriert.

## Enthalten aus v9.2

- Fotos und Dateien über die Büroklammer auswählen, in den Chat ziehen oder aus der Zwischenablage einfügen.
- Bilder, PDFs, Word-, PowerPoint-, Excel-, Text- und viele gängige Codedateien gemeinsam mit einer Frage analysieren.
- Aus hochgeladenem Code Fehler erklären, Änderungen vorschlagen oder vollständigen neuen Code erstellen lassen.
- Codeblöcke werden sicher formatiert und besitzen einen Kopieren-Button.
- Bis zu 5 Dateien pro Anfrage, maximal 10 MB je Datei und 25 MB insgesamt.
- Programme und Skripte werden nicht ausgeführt. ZIP-Unterstützung kam erst mit v9.3.0; Dateiinhalte gelten weiterhin als nicht vertrauenswürdige Daten.
- Die App speichert Uploads nicht lokal, sondern hält sie nur für die laufende Anfrage im Arbeitsspeicher und sendet sie zur Analyse an die OpenAI API.
- Eigene Berechtigung **Fotos und Dateien analysieren**, optional mit Bestätigung vor jeder Ausführung.
- Der automatische Ruhemodus wartet jetzt auf das tatsächliche Ende der Sprachausgabe und schneidet lange Antworten nicht mehr ab.
- Mathematische Formeln werden mit der lokal enthaltenen KaTeX-Mathematikschrift dargestellt; Brüche, Wurzeln, Potenzen und Gleichungen erscheinen nicht mehr als roher LaTeX-Text.

## Enthalten aus v9.1

- Automatische Websuche bei aktuellen Informationen, Nachrichten, Wetter, Preisen, Terminen und Öffnungszeiten.
- Manuelle Testsuche direkt im Kontrollzentrum.
- Klickbare Quellen im Chat und in der Testsuche.
- Eigenes Web-Search-Modul und eigene Berechtigung.
- Optional einstellbare Bestätigung vor jeder Websuche.
- Maximal 10 Suchen pro Minute und höchstens 8 angezeigte Quellen.
- Nur lesender Zugriff: keine Logins, Käufe, Downloads oder Webseitenaktionen.
- Fehler und erfolgreiche Suchen werden lokal protokolliert.

## Außerdem enthalten

- Kontrollzentrum direkt in den Einstellungen.
- Persönlichkeitsmodi: Normal, Schule, Fokus und Nacht.
- Einstellbare Antwortlänge und Humor-Stufe.
- Speicherverwaltung zum Anzeigen, Hinzufügen und Löschen lokaler Erinnerungen.
- Vollständiger Simulationsmodus mit virtuellen Lampen, Schaltern, Tür, Bewegungssensor, Kamera und Klima.
- Testereignisse für Person, Bewegung und Türklingel.
- Lokale Timer und Erinnerungen mit Browser-Hinweis und Signalton.
- Berechtigungssystem: Funktionen sperren oder vor jeder Ausführung bestätigen lassen.
- Modulares Fähigkeitssystem mit vorbereiteten späteren Integrationen.
- Systemdiagnose, Fehlerprotokoll und exportierbarer Diagnosebericht.
- Automatische Realtime-Wiederverbindung mit drei abgestuften Versuchen.
- Audit-Protokoll für wichtige lokale Aktionen.

Die bisherigen Funktionen bleiben erhalten: Realtime-Sprachdialog, Kamera auf ausdrückliche Aktivierung, Modell-Routing, lokaler Gesprächsverlauf, Home Assistant und Frigate.

## Start unter Windows

1. Falls nötig: `.env.example` kopieren und die Kopie in `.env` umbenennen.
2. `OPENAI_API_KEY` in `.env` eintragen.
3. Einmal `INSTALLIEREN.bat` ausführen.
4. Danach `STARTEN.bat` ausführen.
5. Die App öffnet sich unter `http://127.0.0.1:8017/?v=10.0.0`.

Oben muss **AUTONOMOUS SYSTEM v10** stehen. Über das Zahnrad öffnest du das Kontrollzentrum; ganz oben befindet sich die globale Suche.

## Integration Hub einrichten

Kontakte und WhatsApp-Gruppen kannst du direkt im Kontrollzentrum anlegen. Trage WhatsApp-Nummern international ein, zum Beispiel `+436601234567`. Bei Gruppen muss der **exakte WhatsApp-Chatname** mit der Desktop-App übereinstimmen. Nach einer `.env`-Änderung JARVIS neu starten und die Realtime-Verbindung neu aufbauen.

### WhatsApp-Testnummer automatisch senden

1. Starte zuerst `INSTALLIEREN.bat`.
2. Installiere die offizielle WhatsApp-Desktop-App für Windows und melde deine Testnummer dort einmal an.
3. Starte bei Bedarf `WHATSAPP_VERBINDEN.bat`; es öffnet direkt die Desktop-App zur Kontrolle.
4. Lass `JARVIS_WHATSAPP_MODE=desktop` und `JARVIS_WHATSAPP_DESKTOP_AUTO_SEND=true` gesetzt.

Einzelkontakte werden über ihre internationale Nummer geöffnet. Gruppen werden über ihren exakt gespeicherten Chatnamen gesucht. JARVIS sendet nur eine ausdrücklich beauftragte einzelne Textnachricht; Sammelnachrichten bleiben gesperrt. WhatsApp untersagt nicht autorisierte automatische Nachrichten beziehungsweise automatisierten Zugriff in seinen Nutzungsbedingungen; verwende deshalb wirklich nur das Testkonto und rechne damit, dass sich die App-Steuerung später ändern kann: https://www.whatsapp.com/legal/terms-of-service

### Privates Gmail und Google Kalender verbinden

1. Erstelle in der Google Cloud Console einen OAuth-Client vom Typ **Desktop-App** und aktiviere Gmail API sowie Google Calendar API.
2. Speichere die heruntergeladene JSON-Datei als `data/google_client_secret.json`.
3. Starte einmal `GMAIL_VERBINDEN.bat`, melde dich mit dem privaten Konto an und erlaube Gmail-Senden sowie Kalendertermine.

JARVIS nutzt für E-Mails den offiziellen Gmail-`users.messages.send`-Ablauf und für Termine `events.insert`: https://developers.google.com/workspace/gmail/api/guides/sending und https://developers.google.com/workspace/calendar/api/guides/create-events

### Outlook-Schulkonto verbinden

1. Lass in `.env` `JARVIS_OUTLOOK_MODE=web` und `JARVIS_OUTLOOK_WEB_AUTO_SEND=true` gesetzt.
2. Starte zuerst `INSTALLIEREN.bat` und danach einmal `OUTLOOK_VERBINDEN.bat`.
3. Melde dich im geöffneten JARVIS-Browserfenster mit deinem Schulkonto an.
4. Warte, bis der Outlook-Posteingang sichtbar ist. Kehre dann zur Konsole zurück und drücke Enter.

JARVIS verwendet danach ein eigenes persistentes Browserprofil unter `data/outlook_web_profile`. Beim automatischen Senden öffnet sich kurz Outlook Web. Schließe dieses Fenster nicht während der Aktion und öffne nicht gleichzeitig ein zweites JARVIS-Outlook-Fenster mit demselben Profil.

Der Webmodus umgeht keine Anmeldung oder Sicherheitsrichtlinie: Er bedient nur deine bereits angemeldete Outlook-Weboberfläche. Falls die Schule Outlook Web oder Browserautomatisierung blockiert, kann nur die Schul-IT diese Richtlinie ändern. Für den optionalen offiziellen Graph-Modus setze `JARVIS_OUTLOOK_MODE=graph` und konfiguriere weiterhin `JARVIS_OUTLOOK_CLIENT_ID`, Tenant und die delegierten Berechtigungen.

Die persönliche `.env` ist absichtlich im ausgelieferten ZIP enthalten. Teile dieses ZIP deshalb niemals öffentlich und lade es nicht in ein öffentliches Repository hoch.

## Code-Workspace verwenden

1. Öffne das Zahnrad und den Bereich **Code-Workspace**.
2. Klicke **ZIP importieren** und wähle dein Projekt. Der Import ist dauerhaft lokal und nicht derselbe kurzlebige Ablauf wie eine normale Chat-Anlage.
3. Öffne editierbare Dateien über **Öffnen** oder erstelle über den Dateipfad und den Editor eine neue Datei.
4. Mit **Sicher prüfen** werden unterstützte Dateitypen statisch kontrolliert, ohne Projektcode auszuführen.
5. Beschreibe unter **KI-Änderungsauftrag**, was geändert werden soll. Prüfe anschließend den angezeigten Diff.
6. Erst **Vorschlag übernehmen** schreibt die vorgeschlagenen Dateien. JARVIS erstellt davor automatisch einen Sicherheits-Snapshot.
7. Mit **Projekt-ZIP** erhältst du den aktuellen vollständigen Projektstand zurück.

Für eine KI-Anfrage werden höchstens 60 sichere UTF-8-Dateien und insgesamt 2 MB Projekttext übertragen. Sensible, binäre, zu große oder darüber hinausgehende Dateien erscheinen als übersprungen und bleiben ausschließlich lokal. Die automatischen SQLite-Systembackups aus v9.4.1 enthalten keine Code-Workspaces; exportiere wichtige Projekte zusätzlich als Projekt-ZIP.

## Stabilität, Backups und Hintergrundaufträge

Unter **Stabilität & Wiederherstellung** kannst du den Selbsttest erneut ausführen, ein lokales Backup exportieren oder ein zuvor von JARVIS erzeugtes Backup wiederherstellen. Laufzeit-Backups enthalten die lokale SQLite-Datenbank, aber niemals `.env`, API-Schlüssel oder hochgeladene Dateien. Bewahre dennoch auch Backups privat auf, weil darin Erinnerungen und Verlauf stecken können.

Unter **Hintergrundaufträge** kannst du eine komplexe Luna-/Terra-Aufgabe oder Websuche starten. Fehlgeschlagene oder abgebrochene Aufträge lassen sich erneut starten; fertige Antworten können direkt in den Chat übernommen werden. Im Safe Mode werden neue Hintergrundaufträge absichtlich blockiert.

Unter **Modell-Budget** bedeutet der Wert `0` unbegrenzt. Bei aktiviertem harten Stopp werden neue externe Modellaufrufe blockiert, sobald Tages- oder Monatsgrenze erreicht ist. Lokale Einstellungen, Speicher, Backups und Diagnose funktionieren weiter.

Optionale Ersatzmodelle werden als kommagetrennte Listen in `.env` eingetragen. Die Reihenfolge bestimmt die Priorität:

```env
REALTIME_FALLBACK_MODELS=
LUNA_FALLBACK_MODELS=
TERRA_FALLBACK_MODELS=
WEB_SEARCH_FALLBACK_MODELS=
FILE_WORKSPACE_FALLBACK_MODELS=
JARVIS_SAFE_MODE=false
```

`JARVIS_SAFE_MODE=true` erzwingt den Schutzmodus bis zur nächsten Konfigurationsänderung und einem Neustart.

## Gedächtnis und Vorschläge

Passender Kontext wird pro Frage aus deiner lokalen SQLite-Datenbank gewählt. Das ist bewusst leichtgewichtig und benötigt keine zusätzliche Vektordatenbank. Im Kontrollzentrum kannst du Erinnerungen ansehen, hinzufügen, bearbeiten oder löschen. Unter **Proaktive Vorschläge** stellst du Ruhezeiten und Mindestabstand ein. **Übernehmen** füllt nur das Eingabefeld – erst du entscheidest, ob die Nachricht gesendet wird.

## Optionaler Zugriff im LAN

Der mitgelieferte Windows-Start bleibt absichtlich lokal. Falls du JARVIS später von einem zweiten Gerät aus verwenden möchtest:

```env
JARVIS_ALLOW_LAN=true
JARVIS_ACCESS_TOKEN=EIN_LANGES_ZUFAELLIGES_TOKEN
```

Starte den Dienst dann bewusst auf einer LAN-Adresse und setze für echten Betrieb einen TLS-Reverse-Proxy davor. Gib den Token beim ersten Öffnen im Browser ein; er wird nur im Sitzungs-Speicher des Tabs gehalten. Veröffentliche Port 8017 nicht direkt im Internet. Für reine lokale Nutzung lässt du beide Einstellungen unverändert.

## Stimmenisolierung einstellen

Unter **System Configuration → Stimmenisolierung** ist **Stark** voreingestellt. Falls JARVIS deine leise Stimme nicht zuverlässig erkennt, wähle **Ausgewogen**. **Empfindlich** ist nur für sehr ruhige Räume gedacht. Eine Änderung wird beim nächsten Verbindungsstart aktiv.

## Fotos und Dateien verwenden

1. Klicke links neben dem Texteingabefeld auf die Büroklammer. Alternativ kannst du Dateien in den Chat ziehen oder ein Bild einfügen.
2. Wähle bis zu fünf Fotos, Dokumente, Codedateien oder ZIP-Projekte aus.
3. Schreibe deine Aufgabe, zum Beispiel: `Finde den Fehler, bearbeite die Dateien und gib sie mir zurück.`
4. Sende die Nachricht. Erklärungen erscheinen im Chat; erstellte oder bearbeitete Dateien werden darunter als Downloads angeboten.

Unterstützt werden ZIP, JPG, PNG, WebP, PDF, DOCX, PPTX, XLS/XLSX, CSV/TSV, TXT, Markdown, JSON, XML, YAML, HTML/CSS sowie viele gängige Code- und Konfigurationsdateien. Innerhalb eines ZIPs werden höchstens 300 Einträge geprüft, davon maximal 60 unterstützte Dateien und höchstens 25 MB analysierbarer Inhalt. Ein einzelner Upload darf weiterhin höchstens 10 MB groß sein; alle Uploads zusammen höchstens 25 MB.

JARVIS kann unterstützte Dokumente, Bilder, Tabellen und Text-/Codedateien lesen. Einfache Text- und Codedateien entstehen direkt; PDF-, Office-, Tabellen-, Bild- und ZIP-Ergebnisse werden bei Bedarf in einem abgeschotteten OpenAI-Container gebaut und danach sofort in den lokalen Arbeitsspeicher heruntergeladen. Programme, Makros, Schlüssel und echte `.env`-Dateien bleiben blockiert. Das Dateimodell lässt sich über `FILE_WORKSPACE_MODEL` in `.env` ändern und verwendet standardmäßig `TERRA_MODEL`.

Der gehostete Code-Interpreter ist ein zusätzlich abgerechnetes OpenAI-Werkzeug und wird nur verwendet, wenn die Aufgabe tatsächlich eine komplexe oder binäre Ergebnisdatei benötigt.

## Webzugriff testen

1. Stelle sicher, dass `OPENAI_API_KEY` in `.env` eingetragen ist.
2. Starte JARVIS neu.
3. Öffne das Zahnrad und suche unter **Webzugriff** zum Beispiel nach `Aktuelle Nachrichten aus Österreich`.
4. Alternativ kannst du JARVIS per Sprache nach aktuellen Informationen fragen.

Das verwendete Modell lässt sich optional über `WEB_SEARCH_MODEL` in `.env` ändern. Die Websuche verursacht zusätzlich zu den Modell-Tokens Kosten für Suchaufrufe.

## Ohne Komponenten testen

Der Simulationsmodus ist beim ersten Start bereits aktiv. Unter **System Configuration → Simulationsmodus** kannst du die virtuellen Geräte verändern. JARVIS kann deren Zustände lesen und – nach deiner Bestätigung – steuern. Die drei Ereignisbuttons erzeugen Testmeldungen für die spätere Kamera- und Sensorlogik.

## Spätere reale Integrationen

```env
HOME_ASSISTANT_URL=http://DEINE-IP:8123
HOME_ASSISTANT_TOKEN=DEIN_LONG_LIVED_ACCESS_TOKEN
FRIGATE_URL=http://DEINE-IP:5000
```

Wenn der Simulationsmodus ausgeschaltet ist, verwendet JARVIS diese realen Integrationen. Ohne Konfiguration bleibt die restliche App funktionsfähig.

## Datenschutz und Sicherheit

- Erinnerungen, Einstellungen, Timer, Audit- und Fehlerprotokolle liegen lokal in `data/jarvis.db`.
- Der OpenAI-Key bleibt im Backend.
- Online-Updates enthalten niemals `.env`, Tokens, Browserprofile oder persönliche Daten.
- Hochgeladene Dateien werden nicht in der lokalen Datenbank oder im Projektordner gespeichert. Für die Analyse werden unterstützte Inhalte an die OpenAI API übertragen.
- Echte Secrets innerhalb hochgeladener ZIPs werden nicht an das Modell weitergegeben. `.env.example`, `.env.sample` und `.env.template` sind als Vorlagen erlaubt.
- Erzeugte Dateien werden aus dem kurzlebigen OpenAI-Container sofort in einen begrenzten lokalen Download-Speicher übernommen und verfallen dort nach etwa 15 Minuten.
- Alte Verlaufs-, Audit- und Fehlerdaten lassen sich anhand eigener Aufbewahrungsfristen bereinigen.
- Proaktive Vorschläge bleiben stumm, respektieren Ruhezeiten und dürfen keine Aktion selbst ausführen.
- Kritische Steueraktionen verlangen standardmäßig eine Bestätigung.
- Berechtigungen und Module lassen sich im Kontrollzentrum deaktivieren.
- Die Kamera startet nicht automatisch und sendet nur bei visuellen Fragen ein Standbild.

## Tests

```powershell
.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Die ausgewerteten GitHub-Bausteine und die spätere Hardware-Roadmap stehen in `GITHUB_BAUSTEINE.md`.
