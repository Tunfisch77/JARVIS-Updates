from __future__ import annotations

import os
import shutil
from pathlib import Path


def jarvis_local_root(environment: dict[str, str] | None = None) -> Path:
    """Return the version-independent local JARVIS data directory."""
    env = environment if environment is not None else os.environ
    configured = str(env.get("JARVIS_LOCAL_DATA_DIR", "") or "").strip()
    if configured:
        for key, value in env.items():
            configured = configured.replace(f"%{key}%", str(value))
        if os.name != "nt":
            configured = configured.replace("\\", os.sep)
        return Path(os.path.expandvars(configured)).expanduser().resolve()
    local_app_data = str(env.get("LOCALAPPDATA", "") or "").strip()
    if local_app_data:
        return (Path(local_app_data) / "JARVIS").resolve()
    return (Path.home() / ".jarvis").resolve()


def persistent_path(relative: str, environment: dict[str, str] | None = None) -> Path:
    return jarvis_local_root(environment) / Path(relative)


def migrate_legacy_path(legacy: Path, destination: Path) -> Path:
    """Copy a previous version-local login/token into central storage once."""
    if destination.exists() or not legacy.exists():
        return destination
    destination.parent.mkdir(parents=True, exist_ok=True)
    if legacy.is_dir():
        shutil.copytree(legacy, destination)
    else:
        shutil.copy2(legacy, destination)
    return destination
