from __future__ import annotations

import io
import json
import sqlite3
import tempfile
import threading
import time
import zipfile
from datetime import UTC, datetime
from pathlib import Path
from typing import Any


class BackupError(ValueError):
    pass


class BackupManager:
    """Create and restore bounded JARVIS backups without including secrets or .env files."""

    MAX_BACKUP_BYTES = 60 * 1024 * 1024
    REQUIRED_TABLES = {"memories", "history", "settings", "permissions"}

    def __init__(self, database_path: Path, backup_directory: Path, *, app_version: str) -> None:
        self.database_path = database_path
        self.backup_directory = backup_directory
        self.app_version = app_version
        self._lock = threading.RLock()
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self.backup_directory.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _timestamp() -> str:
        return datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")

    def _snapshot_database(self, destination: Path) -> None:
        with sqlite3.connect(self.database_path, timeout=10) as source:
            with sqlite3.connect(destination, timeout=10) as target:
                source.backup(target)

    def create_bytes(self, *, reason: str = "manual") -> bytes:
        with self._lock, tempfile.TemporaryDirectory(prefix="jarvis-backup-") as directory:
            snapshot = Path(directory) / "jarvis.db"
            self._snapshot_database(snapshot)
            manifest = {
                "format": "jarvis-backup-v1",
                "app_version": self.app_version,
                "created_at": datetime.now(UTC).isoformat(timespec="seconds"),
                "reason": reason[:80],
            }
            buffer = io.BytesIO()
            with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as archive:
                archive.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
                archive.write(snapshot, "jarvis.db")
            data = buffer.getvalue()
            if len(data) > self.MAX_BACKUP_BYTES:
                raise BackupError("Das Backup ist größer als 60 MB.")
            return data

    def create_automatic(self, *, reason: str, keep: int = 7) -> Path:
        data = self.create_bytes(reason=reason)
        target = self.backup_directory / f"jarvis-backup-{self._timestamp()}.zip"
        temporary = target.with_suffix(".zip.tmp")
        temporary.write_bytes(data)
        temporary.replace(target)
        backups = sorted(self.backup_directory.glob("jarvis-backup-*.zip"), key=lambda path: path.stat().st_mtime)
        while len(backups) > max(1, keep):
            backups.pop(0).unlink(missing_ok=True)
        return target

    def _validate_snapshot(self, database: Path) -> dict[str, Any]:
        try:
            with sqlite3.connect(database, timeout=10) as connection:
                integrity = connection.execute("PRAGMA integrity_check").fetchone()[0]
                if integrity != "ok":
                    raise BackupError("Die Datenbank im Backup ist beschädigt.")
                tables = {
                    row[0]
                    for row in connection.execute("SELECT name FROM sqlite_master WHERE type = 'table'").fetchall()
                }
        except sqlite3.Error as exc:
            raise BackupError("Die Datenbank im Backup ist ungültig.") from exc
        missing = sorted(self.REQUIRED_TABLES - tables)
        if missing:
            raise BackupError(f"Im Backup fehlen notwendige Tabellen: {', '.join(missing)}")
        return {"integrity": integrity, "tables": len(tables)}

    def restore_bytes(self, data: bytes) -> dict[str, Any]:
        if not data or len(data) > self.MAX_BACKUP_BYTES:
            raise BackupError("Das Backup ist leer oder größer als 60 MB.")
        with self._lock, tempfile.TemporaryDirectory(prefix="jarvis-restore-") as directory:
            try:
                archive = zipfile.ZipFile(io.BytesIO(data))
            except zipfile.BadZipFile as exc:
                raise BackupError("Die Backup-Datei ist kein gültiges ZIP.") from exc
            with archive:
                names = archive.namelist()
                if set(names) != {"manifest.json", "jarvis.db"} or len(names) != 2:
                    raise BackupError("Das Backup enthält unerwartete Dateien.")
                manifest_info = archive.getinfo("manifest.json")
                database_info = archive.getinfo("jarvis.db")
                if manifest_info.file_size > 64 * 1024:
                    raise BackupError("Das Backup-Manifest ist zu groß.")
                if database_info.file_size > self.MAX_BACKUP_BYTES:
                    raise BackupError("Die Backup-Datenbank ist zu groß.")
                for info in (manifest_info, database_info):
                    ratio = info.file_size / max(1, info.compress_size)
                    if info.flag_bits & 0x1 or ratio > 250:
                        raise BackupError("Das Backup ist verschlüsselt oder ungewöhnlich stark komprimiert.")
                try:
                    manifest = json.loads(archive.read("manifest.json"))
                except (json.JSONDecodeError, UnicodeDecodeError) as exc:
                    raise BackupError("Das Backup-Manifest ist ungültig.") from exc
                if not isinstance(manifest, dict) or manifest.get("format") != "jarvis-backup-v1":
                    raise BackupError("Dieses Backup-Format wird nicht unterstützt.")
                snapshot = Path(directory) / "jarvis.db"
                snapshot.write_bytes(archive.read("jarvis.db"))

            validation = self._validate_snapshot(snapshot)
            rollback = self.create_automatic(reason="before-restore", keep=7)
            try:
                with sqlite3.connect(snapshot, timeout=10) as source:
                    with sqlite3.connect(self.database_path, timeout=10) as target:
                        source.backup(target)
            except sqlite3.Error as exc:
                raise BackupError("Das Backup konnte nicht wiederhergestellt werden.") from exc
            return {
                "ok": True,
                "backup_version": manifest.get("app_version"),
                "created_at": manifest.get("created_at"),
                "rollback_backup": rollback.name,
                **validation,
            }

    def latest_automatic(self) -> dict[str, Any] | None:
        backups = sorted(self.backup_directory.glob("jarvis-backup-*.zip"), key=lambda path: path.stat().st_mtime)
        if not backups:
            return None
        latest = backups[-1]
        return {"name": latest.name, "size": latest.stat().st_size, "modified_at": latest.stat().st_mtime}

    def automatic_backup_due(self, interval_hours: int = 24) -> bool:
        latest = self.latest_automatic()
        return not latest or time.time() - float(latest["modified_at"]) >= max(1, interval_hours) * 3600
