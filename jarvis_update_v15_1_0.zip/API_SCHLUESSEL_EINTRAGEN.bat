@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist ".env" copy /y ".env.example" ".env" >nul
echo Trage deinen API-Schluessel hinter OPENAI_API_KEY= ein.
echo Danach speichern und den Editor schliessen.
echo Falls JARVIS bereits laeuft, anschliessend neu starten.
start "" /wait notepad.exe "%~dp0.env"
exit /b 0
