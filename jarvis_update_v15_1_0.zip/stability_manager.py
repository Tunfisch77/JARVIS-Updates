from __future__ import annotations

import asyncio
import os
import sqlite3
import tempfile
from pathlib import Path
from typing import Any, Awaitable, Callable, TypeVar

import psutil

from state_store import JarvisStateStore


T = TypeVar("T")


class CircuitOpenError(RuntimeError):
    pass


class SafeModeGuard:
    """Detect an unclean previous shutdown and keep risky optional modules disabled."""

    def __init__(self, marker_path: Path, *, forced: bool = False) -> None:
        self.marker_path = marker_path
        self.forced = forced
        self.active = forced
        self.reason = "Per Konfiguration aktiviert." if forced else ""

    def start(self) -> bool:
        self.marker_path.parent.mkdir(parents=True, exist_ok=True)
        previous_unclean_shutdown = self.marker_path.exists()
        if previous_unclean_shutdown and not self.forced:
            self.active = True
            self.reason = "Der vorherige Serverlauf wurde nicht sauber beendet."
        self.marker_path.write_text(str(os.getpid()), encoding="ascii")
        return self.active

    def stop(self) -> None:
        self.marker_path.unlink(missing_ok=True)

    def clear(self) -> None:
        if not self.forced:
            self.active = False
            self.reason = ""


async def resilient_call(
    store: JarvisStateStore,
    dependency: str,
    operation: Callable[[], Awaitable[T]],
    *,
    is_retryable: Callable[[Exception], bool],
    max_attempts: int = 3,
    base_delay_seconds: float = 0.45,
) -> T:
    if not store.circuit_allow(dependency):
        status = store.circuit_status(dependency)
        raise CircuitOpenError(f"{dependency} ist vorübergehend pausiert bis {status.get('open_until')}.")
    last_error: Exception | None = None
    for attempt in range(1, max(1, max_attempts) + 1):
        try:
            result = await operation()
            store.circuit_success(dependency)
            return result
        except Exception as exc:
            last_error = exc
            retryable = is_retryable(exc)
            if not retryable:
                raise
            circuit = store.circuit_failure(dependency, str(exc))
            if circuit.get("open"):
                raise CircuitOpenError(f"{dependency} ist nach mehreren Fehlern vorübergehend pausiert.") from exc
            if attempt >= max_attempts:
                raise
            await asyncio.sleep(base_delay_seconds * (2 ** (attempt - 1)))
    if last_error:
        raise last_error
    raise RuntimeError("Stabilitätsaufruf ohne Ergebnis beendet.")


def run_startup_self_test(
    database_path: Path,
    generated_directory: Path,
    backup_directory: Path,
    *,
    api_key_configured: bool,
    workspace_directory: Path | None = None,
) -> dict[str, Any]:
    checks: list[dict[str, Any]] = []

    try:
        with sqlite3.connect(database_path, timeout=5) as connection:
            result = connection.execute("PRAGMA quick_check").fetchone()[0]
        checks.append({"name": "database", "ok": result == "ok", "detail": result})
    except sqlite3.Error as exc:
        checks.append({"name": "database", "ok": False, "detail": str(exc)})

    directories = [("generated_directory", generated_directory), ("backup_directory", backup_directory)]
    if workspace_directory is not None:
        directories.append(("workspace_directory", workspace_directory))
    for name, directory in directories:
        try:
            directory.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile(prefix="jarvis-check-", dir=directory, delete=True) as handle:
                handle.write(b"ok")
                handle.flush()
            checks.append({"name": name, "ok": True, "detail": str(directory)})
        except OSError as exc:
            checks.append({"name": name, "ok": False, "detail": str(exc)})

    try:
        free_bytes = psutil.disk_usage(str(database_path.parent)).free
        checks.append(
            {
                "name": "disk_space",
                "ok": free_bytes >= 200 * 1024 * 1024,
                "detail": {"free_bytes": free_bytes, "minimum_bytes": 200 * 1024 * 1024},
            }
        )
    except OSError as exc:
        checks.append({"name": "disk_space", "ok": False, "detail": str(exc)})

    checks.append(
        {
            "name": "openai_configuration",
            "ok": api_key_configured,
            "detail": "configured" if api_key_configured else "OPENAI_API_KEY fehlt",
            "required_for_core": False,
        }
    )
    required_failures = [item for item in checks if not item["ok"] and item.get("required_for_core", True)]
    return {
        "ok": not required_failures,
        "status": "ok" if not required_failures else "degraded",
        "checks": checks,
    }
