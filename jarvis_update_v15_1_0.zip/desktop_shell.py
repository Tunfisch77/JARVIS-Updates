from __future__ import annotations

import socket
import os
import signal
import json
import urllib.request
import subprocess
import sys
import time
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent
HOST = "127.0.0.1"
PORT = 8017
APP_VERSION = "15.1.0"


def server_ready() -> bool:
    try:
        with urllib.request.urlopen(f"http://{HOST}:{PORT}/version", timeout=0.5) as response:
            return json.load(response).get("version") == APP_VERSION
    except (OSError, ValueError):
        return False


def stop_server(process) -> None:
    if process is None or process.poll() is not None:
        return
    try:
        if os.name == "nt":
            # terminate() uses TerminateProcess on Windows and skips app shutdown.
            process.send_signal(signal.CTRL_BREAK_EVENT)
        else:
            process.terminate()
        process.wait(timeout=12)
    except (OSError, subprocess.TimeoutExpired):
        if process.poll() is None:
            process.kill()
        process.wait(timeout=5)


def main() -> None:
    try:
        import webview
    except ImportError as exc:
        raise SystemExit("pywebview fehlt. Fuehre zuerst INSTALLIEREN.bat aus.") from exc

    process: subprocess.Popen[bytes] | None = None
    if not server_ready():
        try:
            with socket.create_connection((HOST, PORT), timeout=0.3):
                raise SystemExit("Auf Port 8017 läuft bereits ein anderer oder älterer Server. Bitte die bisherige JARVIS-App schließen.")
        except OSError:
            pass
        process = subprocess.Popen(
            [
                sys.executable,
                "-m",
                "uvicorn",
                "app:app",
                "--host",
                HOST,
                "--port",
                str(PORT),
            ],
            cwd=BASE_DIR,
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0,
        )
        deadline = time.monotonic() + 20
        while time.monotonic() < deadline and not server_ready():
            if process.poll() is not None:
                raise SystemExit("JARVIS-Server konnte nicht gestartet werden.")
            time.sleep(0.2)
        if not server_ready():
            stop_server(process)
            raise SystemExit("JARVIS-Server antwortet nicht.")

    try:
        webview.create_window(
            "J.A.R.V.I.S v15.1.0 PC Agent OS",
            f"http://{HOST}:{PORT}/?v=15.1.0",
            width=1480,
            height=920,
            min_size=(1050, 720),
        )
        webview.start(private_mode=False)
    finally:
        stop_server(process)


if __name__ == "__main__":
    main()
