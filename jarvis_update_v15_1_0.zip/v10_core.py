from __future__ import annotations

import ctypes
import json
import re
import secrets
import sqlite3
import sys
import unicodedata
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Final


MISSION_STEP_KINDS: Final = {
    "check_messages",
    "search_web",
    "send_whatsapp_message",
    "send_email",
    "create_calendar_event",
    "create_timer",
    "open_app_or_website",
    "remember_user_fact",
    "desktop_plan",
}

READ_ONLY_MISSION_STEPS: Final = {"check_messages", "search_web", "desktop_plan"}

MESSAGE_SOURCES: Final = {"whatsapp", "gmail", "outlook", "snapchat"}


def normalize_message_identity(value: object) -> str:
    decomposed = unicodedata.normalize("NFKD", str(value or "").casefold())
    without_marks = "".join(character for character in decomposed if not unicodedata.combining(character))
    return " ".join(re.findall(r"[^\W_]+", without_marks, flags=re.UNICODE))


def windows_session_locked() -> bool:
    """Best-effort privacy check without adding a Windows-only dependency."""
    if sys.platform != "win32":
        return False
    user32 = ctypes.windll.user32
    desktop = user32.OpenInputDesktop(0, False, 0x0100)
    if not desktop:
        return True
    user32.CloseDesktop(desktop)
    return False


class V10Store:
    """Persistent Mission Control and unified message inbox for JARVIS v10."""

    def __init__(self, database_path: Path) -> None:
        self.database_path = database_path
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.database_path, timeout=5)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA foreign_keys=ON")
        return connection

    @staticmethod
    def _now_text() -> str:
        return datetime.now(UTC).isoformat(timespec="seconds")

    @staticmethod
    def _json(value: object) -> str:
        return json.dumps(value, ensure_ascii=False, default=str)

    @staticmethod
    def _parse_json(value: str | None, fallback: object) -> Any:
        try:
            return json.loads(value or "")
        except (TypeError, json.JSONDecodeError):
            return fallback

    def _initialize(self) -> None:
        with self._connect() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS missions (
                    id TEXT PRIMARY KEY,
                    title TEXT NOT NULL,
                    goal TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'pending',
                    safety_level TEXT NOT NULL DEFAULT 'balanced',
                    current_step INTEGER NOT NULL DEFAULT 0,
                    error TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    started_at TEXT,
                    finished_at TEXT
                );

                CREATE TABLE IF NOT EXISTS mission_steps (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    mission_id TEXT NOT NULL,
                    step_index INTEGER NOT NULL,
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'pending',
                    result_json TEXT,
                    error TEXT NOT NULL DEFAULT '',
                    requires_confirmation INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL,
                    started_at TEXT,
                    finished_at TEXT,
                    FOREIGN KEY(mission_id) REFERENCES missions(id) ON DELETE CASCADE,
                    UNIQUE(mission_id, step_index)
                );

                CREATE TABLE IF NOT EXISTS unified_messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source TEXT NOT NULL,
                    external_id TEXT NOT NULL,
                    sender_name TEXT NOT NULL,
                    sender_address TEXT NOT NULL DEFAULT '',
                    conversation TEXT NOT NULL DEFAULT '',
                    subject TEXT NOT NULL DEFAULT '',
                    body TEXT NOT NULL,
                    received_at TEXT NOT NULL,
                    unread INTEGER NOT NULL DEFAULT 1,
                    announced INTEGER NOT NULL DEFAULT 0,
                    read_at TEXT,
                    replied_at TEXT,
                    metadata_json TEXT NOT NULL DEFAULT '{}',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    UNIQUE(source, external_id)
                );

                CREATE INDEX IF NOT EXISTS idx_missions_status ON missions(status, updated_at DESC);
                CREATE INDEX IF NOT EXISTS idx_mission_steps_status ON mission_steps(mission_id, status, step_index);
                CREATE INDEX IF NOT EXISTS idx_unified_messages_unread ON unified_messages(unread, received_at DESC);
                CREATE INDEX IF NOT EXISTS idx_unified_messages_source ON unified_messages(source, received_at DESC);
                """
            )

    def _mission_item(self, row: sqlite3.Row, *, include_steps: bool = True) -> dict[str, Any]:
        item = {
            "id": row["id"],
            "title": row["title"],
            "goal": row["goal"],
            "status": row["status"],
            "safety_level": row["safety_level"],
            "current_step": int(row["current_step"]),
            "error": row["error"],
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
            "started_at": row["started_at"],
            "finished_at": row["finished_at"],
        }
        if include_steps:
            with self._connect() as connection:
                steps = connection.execute(
                    "SELECT * FROM mission_steps WHERE mission_id = ? ORDER BY step_index",
                    (row["id"],),
                ).fetchall()
            item["steps"] = [self._step_item(step) for step in steps]
            done = sum(step["status"] in {"success", "skipped"} for step in item["steps"])
            item["progress"] = round((done / len(item["steps"])) * 100) if item["steps"] else 0
        return item

    def _step_item(self, row: sqlite3.Row) -> dict[str, Any]:
        return {
            "id": int(row["id"]),
            "mission_id": row["mission_id"],
            "index": int(row["step_index"]),
            "kind": row["kind"],
            "title": row["title"],
            "payload": self._parse_json(row["payload_json"], {}),
            "status": row["status"],
            "result": self._parse_json(row["result_json"], None),
            "error": row["error"],
            "requires_confirmation": bool(row["requires_confirmation"]),
            "created_at": row["created_at"],
            "started_at": row["started_at"],
            "finished_at": row["finished_at"],
        }

    def create_mission(
        self,
        *,
        title: str,
        goal: str,
        steps: list[dict[str, Any]],
        safety_level: str = "balanced",
    ) -> dict[str, Any]:
        clean_title = re.sub(r"\s+", " ", str(title or "").strip())[:160]
        clean_goal = re.sub(r"\s+", " ", str(goal or "").strip())[:2_000]
        if not clean_title or not clean_goal:
            raise ValueError("Mission benötigt einen Namen und ein klares Ziel.")
        if not 1 <= len(steps) <= 20:
            raise ValueError("Eine Mission benötigt 1 bis 20 überprüfbare Schritte.")
        level = str(safety_level or "balanced").casefold()
        if level not in {"strict", "balanced", "trusted"}:
            raise ValueError("Unbekannte Sicherheitsstufe.")
        normalized: list[dict[str, Any]] = []
        for index, step in enumerate(steps):
            kind = str(step.get("kind") or "").strip().casefold()
            if kind not in MISSION_STEP_KINDS:
                raise ValueError(f"Missionsschritt {index + 1} verwendet eine nicht freigegebene Aktion.")
            payload = step.get("payload") if isinstance(step.get("payload"), dict) else {}
            encoded = self._json(payload)
            if len(encoded.encode("utf-8")) > 100_000:
                raise ValueError(f"Missionsschritt {index + 1} ist zu groß.")
            step_title = re.sub(r"\s+", " ", str(step.get("title") or kind.replace("_", " ")).strip())[:180]
            normalized.append(
                {
                    "kind": kind,
                    "title": step_title,
                    "payload": payload,
                    "requires_confirmation": bool(
                        step.get("requires_confirmation", kind not in READ_ONLY_MISSION_STEPS)
                    ),
                }
            )
        mission_id = f"mission-{secrets.token_hex(8)}"
        now = self._now_text()
        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO missions(id, title, goal, status, safety_level, created_at, updated_at)
                VALUES (?, ?, ?, 'pending', ?, ?, ?)
                """,
                (mission_id, clean_title, clean_goal, level, now, now),
            )
            for index, step in enumerate(normalized):
                connection.execute(
                    """
                    INSERT INTO mission_steps(
                        mission_id, step_index, kind, title, payload_json,
                        requires_confirmation, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        mission_id,
                        index,
                        step["kind"],
                        step["title"],
                        self._json(step["payload"]),
                        int(step["requires_confirmation"]),
                        now,
                    ),
                )
        mission = self.get_mission(mission_id)
        if not mission:
            raise RuntimeError("Mission konnte nicht gespeichert werden.")
        return mission

    def get_mission(self, mission_id: str) -> dict[str, Any] | None:
        with self._connect() as connection:
            row = connection.execute("SELECT * FROM missions WHERE id = ?", (mission_id,)).fetchone()
        return self._mission_item(row) if row else None

    def list_missions(self, limit: int = 30) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT * FROM missions ORDER BY created_at DESC LIMIT ?",
                (max(1, min(100, int(limit))),),
            ).fetchall()
        return [self._mission_item(row) for row in rows]

    def start_mission(self, mission_id: str) -> dict[str, Any]:
        now = self._now_text()
        with self._connect() as connection:
            row = connection.execute("SELECT status FROM missions WHERE id = ?", (mission_id,)).fetchone()
            if not row:
                raise KeyError("Mission wurde nicht gefunden.")
            if row["status"] in {"success", "cancelled"}:
                raise ValueError("Diese Mission ist bereits abgeschlossen.")
            connection.execute(
                """
                UPDATE missions SET status = 'running', error = '', updated_at = ?,
                    started_at = COALESCE(started_at, ?), finished_at = NULL
                WHERE id = ?
                """,
                (now, now, mission_id),
            )
            connection.execute(
                "UPDATE mission_steps SET status = 'pending', error = '' WHERE mission_id = ? AND status = 'failed'",
                (mission_id,),
            )
        return self.get_mission(mission_id) or {}

    def pause_mission(self, mission_id: str) -> dict[str, Any]:
        with self._connect() as connection:
            cursor = connection.execute(
                "UPDATE missions SET status = 'paused', updated_at = ? WHERE id = ? AND status IN ('pending', 'running', 'failed')",
                (self._now_text(), mission_id),
            )
        if cursor.rowcount == 0 and not self.get_mission(mission_id):
            raise KeyError("Mission wurde nicht gefunden.")
        return self.get_mission(mission_id) or {}

    def cancel_mission(self, mission_id: str) -> dict[str, Any]:
        now = self._now_text()
        with self._connect() as connection:
            cursor = connection.execute(
                """
                UPDATE missions SET status = 'cancelled', updated_at = ?, finished_at = ?
                WHERE id = ? AND status NOT IN ('success', 'cancelled')
                """,
                (now, now, mission_id),
            )
            connection.execute(
                "UPDATE mission_steps SET status = 'skipped', finished_at = ? WHERE mission_id = ? AND status = 'pending'",
                (now, mission_id),
            )
        if cursor.rowcount == 0 and not self.get_mission(mission_id):
            raise KeyError("Mission wurde nicht gefunden.")
        return self.get_mission(mission_id) or {}

    def claim_next_step(self) -> dict[str, Any] | None:
        now = self._now_text()
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                """
                SELECT s.* FROM mission_steps s
                JOIN missions m ON m.id = s.mission_id
                WHERE m.status = 'running' AND s.status = 'pending'
                ORDER BY m.created_at, s.step_index
                LIMIT 1
                """
            ).fetchone()
            if not row:
                return None
            cursor = connection.execute(
                "UPDATE mission_steps SET status = 'running', started_at = ?, error = '' WHERE id = ? AND status = 'pending'",
                (now, row["id"]),
            )
            if cursor.rowcount == 0:
                return None
            connection.execute(
                "UPDATE missions SET current_step = ?, updated_at = ? WHERE id = ?",
                (int(row["step_index"]), now, row["mission_id"]),
            )
            claimed = connection.execute("SELECT * FROM mission_steps WHERE id = ?", (row["id"],)).fetchone()
        return self._step_item(claimed) if claimed else None

    def finish_step(self, step_id: int, result: dict[str, Any]) -> dict[str, Any] | None:
        now = self._now_text()
        with self._connect() as connection:
            row = connection.execute("SELECT mission_id FROM mission_steps WHERE id = ?", (step_id,)).fetchone()
            if not row:
                return None
            mission_id = row["mission_id"]
            connection.execute(
                "UPDATE mission_steps SET status = 'success', result_json = ?, error = '', finished_at = ? WHERE id = ?",
                (self._json(result), now, step_id),
            )
            pending = connection.execute(
                "SELECT COUNT(*) FROM mission_steps WHERE mission_id = ? AND status IN ('pending', 'running')",
                (mission_id,),
            ).fetchone()[0]
            if int(pending) == 0:
                connection.execute(
                    "UPDATE missions SET status = 'success', error = '', updated_at = ?, finished_at = ? WHERE id = ?",
                    (now, now, mission_id),
                )
            else:
                connection.execute("UPDATE missions SET updated_at = ? WHERE id = ?", (now, mission_id))
        return self.get_mission(mission_id)

    def fail_step(self, step_id: int, error: str) -> dict[str, Any] | None:
        now = self._now_text()
        clean_error = str(error or "Unbekannter Fehler")[:2_000]
        with self._connect() as connection:
            row = connection.execute("SELECT mission_id FROM mission_steps WHERE id = ?", (step_id,)).fetchone()
            if not row:
                return None
            mission_id = row["mission_id"]
            connection.execute(
                "UPDATE mission_steps SET status = 'failed', error = ?, finished_at = ? WHERE id = ?",
                (clean_error, now, step_id),
            )
            connection.execute(
                "UPDATE missions SET status = 'failed', error = ?, updated_at = ?, finished_at = ? WHERE id = ?",
                (clean_error, now, now, mission_id),
            )
        return self.get_mission(mission_id)

    def _message_item(self, row: sqlite3.Row, *, include_body: bool = False) -> dict[str, Any]:
        body = str(row["body"] or "")
        item = {
            "id": int(row["id"]),
            "source": row["source"],
            "external_id": row["external_id"],
            "sender_name": row["sender_name"],
            "sender_address": row["sender_address"],
            "conversation": row["conversation"],
            "subject": row["subject"],
            "preview": body[:240] + ("…" if len(body) > 240 else ""),
            "received_at": row["received_at"],
            "unread": bool(row["unread"]),
            "announced": bool(row["announced"]),
            "replied": bool(row["replied_at"]),
            "read_at": row["read_at"],
            "replied_at": row["replied_at"],
            "metadata": self._parse_json(row["metadata_json"], {}),
        }
        if include_body:
            item["body"] = body
        return item

    def upsert_message(
        self,
        *,
        source: str,
        external_id: str,
        sender_name: str,
        sender_address: str = "",
        conversation: str = "",
        subject: str = "",
        body: str,
        received_at: str = "",
        unread: bool = True,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        clean_source = str(source or "").casefold()
        if clean_source not in MESSAGE_SOURCES:
            raise ValueError("Unbekannte Nachrichtenquelle.")
        clean_external_id = str(external_id or "").strip()[:500]
        clean_sender = re.sub(r"\s+", " ", str(sender_name or "Unbekannt").strip())[:200]
        clean_body = str(body or "").strip()[:100_000]
        if not clean_external_id or not clean_body:
            raise ValueError("Nachricht benötigt eine externe ID und Inhalt.")
        when = str(received_at or "").strip()[:80] or self._now_text()
        now = self._now_text()
        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO unified_messages(
                    source, external_id, sender_name, sender_address, conversation,
                    subject, body, received_at, unread, metadata_json, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(source, external_id) DO UPDATE SET
                    sender_name = excluded.sender_name,
                    sender_address = excluded.sender_address,
                    conversation = excluded.conversation,
                    subject = excluded.subject,
                    body = excluded.body,
                    received_at = excluded.received_at,
                    unread = excluded.unread,
                    metadata_json = excluded.metadata_json,
                    updated_at = excluded.updated_at
                """,
                (
                    clean_source,
                    clean_external_id,
                    clean_sender,
                    str(sender_address or "").strip()[:500],
                    str(conversation or "").strip()[:300],
                    str(subject or "").strip()[:500],
                    clean_body,
                    when,
                    int(bool(unread)),
                    self._json(metadata or {}),
                    now,
                    now,
                ),
            )
            row = connection.execute(
                "SELECT * FROM unified_messages WHERE source = ? AND external_id = ?",
                (clean_source, clean_external_id),
            ).fetchone()
        return self._message_item(row, include_body=True) if row else {}

    def list_messages(
        self,
        *,
        unread_only: bool = False,
        source: str = "",
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        clauses: list[str] = []
        values: list[object] = []
        if unread_only:
            clauses.append("unread = 1")
        if source:
            clean_source = source.casefold()
            if clean_source not in MESSAGE_SOURCES:
                raise ValueError("Unbekannte Nachrichtenquelle.")
            clauses.append("source = ?")
            values.append(clean_source)
        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        values.append(max(1, min(200, int(limit))))
        with self._connect() as connection:
            rows = connection.execute(
                f"SELECT * FROM unified_messages{where} ORDER BY unread DESC, received_at DESC, id DESC LIMIT ?",
                values,
            ).fetchall()
        return [self._message_item(row) for row in rows]

    def search_messages(
        self,
        *,
        terms: list[str] | None = None,
        sources: list[str] | None = None,
        query: str = "",
        unread_only: bool = False,
        limit: int = 10,
        include_body: bool = True,
    ) -> list[dict[str, Any]]:
        """Search the unified inbox by contact, address, chat/group name, subject, or content."""
        clean_sources = list(dict.fromkeys(str(item).casefold() for item in (sources or [])))
        if any(item not in MESSAGE_SOURCES for item in clean_sources):
            raise ValueError("Unbekannte Nachrichtenquelle.")
        clauses: list[str] = []
        values: list[object] = []
        if unread_only:
            clauses.append("unread = 1")
        if clean_sources:
            placeholders = ",".join("?" for _ in clean_sources)
            clauses.append(f"source IN ({placeholders})")
            values.extend(clean_sources)
        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        # Fetch a bounded candidate window, then apply accent-insensitive identity matching in Python.
        values.append(500)
        with self._connect() as connection:
            rows = connection.execute(
                f"SELECT * FROM unified_messages{where} ORDER BY received_at DESC, id DESC LIMIT ?",
                values,
            ).fetchall()

        wanted_terms = [
            normalize_message_identity(item)
            for item in (terms or [])
            if normalize_message_identity(item)
        ]
        wanted_query = normalize_message_identity(query)
        result: list[dict[str, Any]] = []
        for row in rows:
            identity_blob = normalize_message_identity(
                " ".join(
                    (
                        str(row["sender_name"] or ""),
                        str(row["sender_address"] or ""),
                        str(row["conversation"] or ""),
                        str(row["subject"] or ""),
                    )
                )
            )
            body_blob = normalize_message_identity(
                f"{row['subject'] or ''} {row['body'] or ''}"
            )
            if wanted_terms and not any(
                term in identity_blob or identity_blob in term
                for term in wanted_terms
            ):
                continue
            if wanted_query and wanted_query not in body_blob:
                continue
            result.append(self._message_item(row, include_body=include_body))
            if len(result) >= max(1, min(50, int(limit))):
                break
        return result

    def get_message(self, message_id: int, *, mark_read: bool = False) -> dict[str, Any] | None:
        with self._connect() as connection:
            if mark_read:
                connection.execute(
                    "UPDATE unified_messages SET unread = 0, read_at = COALESCE(read_at, ?), updated_at = ? WHERE id = ?",
                    (self._now_text(), self._now_text(), message_id),
                )
            row = connection.execute("SELECT * FROM unified_messages WHERE id = ?", (message_id,)).fetchone()
        return self._message_item(row, include_body=True) if row else None

    def mark_announced(self, message_ids: list[int]) -> int:
        ids = sorted({int(item) for item in message_ids if int(item) > 0})[:100]
        if not ids:
            return 0
        placeholders = ",".join("?" for _ in ids)
        with self._connect() as connection:
            cursor = connection.execute(
                f"UPDATE unified_messages SET announced = 1, updated_at = ? WHERE id IN ({placeholders})",
                [self._now_text(), *ids],
            )
        return int(cursor.rowcount)

    def mark_replied(self, message_id: int) -> dict[str, Any] | None:
        now = self._now_text()
        with self._connect() as connection:
            connection.execute(
                "UPDATE unified_messages SET replied_at = ?, unread = 0, read_at = COALESCE(read_at, ?), updated_at = ? WHERE id = ?",
                (now, now, now, message_id),
            )
            row = connection.execute("SELECT * FROM unified_messages WHERE id = ?", (message_id,)).fetchone()
        return self._message_item(row, include_body=True) if row else None

    def unread_summary(self) -> dict[str, Any]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT source, COUNT(*) AS count FROM unified_messages WHERE unread = 1 GROUP BY source"
            ).fetchall()
            total = connection.execute("SELECT COUNT(*) FROM unified_messages WHERE unread = 1").fetchone()[0]
            unannounced = connection.execute(
                "SELECT COUNT(*) FROM unified_messages WHERE unread = 1 AND announced = 0"
            ).fetchone()[0]
        by_source = {source: 0 for source in sorted(MESSAGE_SOURCES)}
        by_source.update({str(row["source"]): int(row["count"]) for row in rows})
        return {"total": int(total), "unannounced": int(unannounced), "by_source": by_source}

    def overview(self) -> dict[str, Any]:
        with self._connect() as connection:
            mission_rows = connection.execute(
                "SELECT status, COUNT(*) AS count FROM missions GROUP BY status"
            ).fetchall()
        mission_counts = {str(row["status"]): int(row["count"]) for row in mission_rows}
        return {
            "messages": self.unread_summary(),
            "missions": mission_counts,
            "session_locked": windows_session_locked(),
            "generated_at": self._now_text(),
        }
