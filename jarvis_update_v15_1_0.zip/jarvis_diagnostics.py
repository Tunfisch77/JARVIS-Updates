from __future__ import annotations

import importlib.util
import json
import os
import shutil
import sqlite3
import subprocess
import sys
from datetime import datetime
from pathlib import Path

from persistent_storage import jarvis_local_directory


REQUIRED_MODULES = ("dotenv", "fastapi", "uvicorn", "psutil", "playwright")


def main() -> int:
    root = Path(__file__).resolve().parent
    local = jarvis_local_directory()
    checks: list[dict[str, object]] = []
    for module in REQUIRED_MODULES:
        checks.append({"name": f"Python-Modul {module}", "ok": importlib.util.find_spec(module) is not None})
    database = root / "data" / "jarvis.db"
    if database.exists():
        try:
            with sqlite3.connect(database) as connection:
                result = connection.execute("PRAGMA quick_check").fetchone()[0]
            checks.append({"name": "Datenbank", "ok": result == "ok", "detail": result})
        except sqlite3.Error as exc:
            checks.append({"name": "Datenbank", "ok": False, "detail": str(exc)})
    checks.extend([
        {"name": "Lokaler Datenordner", "ok": local.exists(), "detail": str(local)},
        {"name": "Freier Speicher", "ok": shutil.disk_usage(root).free >= 500 * 1024 * 1024},
        {"name": "Updater", "ok": (root / "jarvis_updater.py").exists()},
    ])
    missing = [item for item in checks if not item["ok"] and str(item["name"]).startswith("Python-Modul")]
    repaired = False
    if missing and "--repair" in sys.argv:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "-r", str(root / "requirements.txt")],
            cwd=root,
            check=False,
        )
        repaired = result.returncode == 0
    report_dir = local / "diagnostics"
    report_dir.mkdir(parents=True, exist_ok=True)
    report = report_dir / f"diagnose-{datetime.now():%Y%m%d-%H%M%S}.json"
    report.write_text(json.dumps({"checks": checks, "repair_attempted": repaired}, ensure_ascii=False, indent=2), encoding="utf-8")
    for item in checks:
        print(("[OK] " if item["ok"] else "[FEHLER] ") + str(item["name"]))
    print(f"\nBericht: {report}")
    return 0 if all(item["ok"] for item in checks) else 1


if __name__ == "__main__":
    raise SystemExit(main())
