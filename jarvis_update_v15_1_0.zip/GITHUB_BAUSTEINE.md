# GitHub-Bausteine für JARVIS

Stand: 28.07.2026

## v12.1.0

- **OpenAI GPT-5.6 Model Guidance geprüft:** `gpt-5.6-sol` ist die aktuelle Frontier-Variante; für Routing und Extraktion bleibt `reasoning.effort=low` passend. JARVIS setzt den Orchestrator explizit auf Sol und misst die Zuverlässigkeit mit konkreten One-Shot-Tests. Quelle: https://developers.openai.com/api/docs/guides/latest-model
- **OpenAI Function Calling geprüft:** Strikte Aktionsschemata, gezielte Werkzeugwahl und genau ein Aufruf pro Turn sind die passenden Muster für zuverlässige Aktionen. Der v12.1-Planer liefert strikt geprüfte Felder; der Browser führt eine gebundene Aktion direkt aus, statt sie erneut vom Realtime-Modell interpretieren zu lassen. Quelle: https://developers.openai.com/api/docs/guides/function-calling
- **OpenAI Agents SDK geprüft:** Guardrails, Freigaben, Sessions und Tracing bestätigen die Trennung aus Interpretation, Berechtigung, Ausführung und geprüftem Ergebnis. JARVIS behält seine lokale, leichtere Umsetzung ohne eine zweite Agenten-Laufzeit. Quelle: https://github.com/openai/openai-agents-python
- **LangGraph erneut geprüft:** Durable Execution und explizite Zustandsübergänge bestätigen den neuen Ablauf `VALIDATE → AUTHORIZE → EXECUTE → RECEIPT`. Eine zusätzliche LangGraph-Abhängigkeit ist dafür nicht nötig. Quelle: https://github.com/langchain-ai/langgraph

## v12.0.0

- **OpenAI Agents SDK geprüft:** Sessions, Guardrails, Human-in-the-loop und Tracing passen zum Ziel, zufällige Werkzeugwahl nachvollziehbar zu machen. v12 übernimmt die Muster als gebundenes Kontextpaket, bestehende Bestätigungen und einen lokalen Entscheidungs-Trace, ohne den vorhandenen Realtime-Stack auszutauschen. Quelle: https://github.com/openai/openai-agents-python
- **LangGraph geprüft:** Durable Execution, Zustandsübergänge und Unterbrechungen bestätigen die vorhandene JARVIS-Richtung mit gespeicherten Missionen, sicheren Wiederholungen und Bestätigungspunkten. Eine zusätzliche LangGraph-Laufzeit wird nicht erzwungen, weil dieselben Kernzustände bereits lokal implementiert sind. Quelle: https://github.com/langchain-ai/langgraph
- **Mem0 geprüft:** Die aktuelle Multi-Signal-Idee kombiniert Keyword-, Entity-, Temporal- und semantische Signale. v12 verbessert sein lokales, kostenloses Ranking mit Wortabdeckung, zusammenhängenden Begriffen, Wichtigkeit, Nutzung und Aktualität; erkannte Kontakte und Gruppen werden separat als Entitäten gebunden. Eine fremde Cloud oder zusätzliche Embedding-Datenbank ist für den Grundbetrieb nicht nötig. Quelle: https://github.com/mem0ai/mem0
- **Ergebnis:** Mehr Kontextqualität und bessere Fehlersuche ohne drei große neue Laufzeit-Abhängigkeiten, zusätzliche API-Schlüssel oder einen zweiten Agenten-Orchestrator.

## v11.0.8

- Regelbasierte, verbindliche Route für persönliche Nachrichtenfragen vor der Realtime-Antwort.
- Quellenübergreifende Prüfung kann nicht mehr durch eine allgemeine KI-Zugriffsverweigerung übersprungen werden.
- OpenAdapt installiert und prüft Playwright sowie Chromium in derselben isolierten Umgebung.
- OpenAdapt-Bereitschaft benötigt einen erfolgreichen Browser-Setup-Marker.

## v11.0.7

- Gemeinsame Abfrage aller verbundenen Nachrichtenquellen bei allgemeinen Nachrichtenfragen.
- Verlaufssuche für gelesene und ungelesene Gmail-, Outlook- und WhatsApp-Nachrichten.
- Kontakt-, Alias-, E-Mail- und WhatsApp-Gruppenauflösung für natürliche Sprachfragen.
- Vereinfachtes Kontaktformular mit kompakten Pflichtfeldern und einklappbaren Zusatzangaben.

## v11.0.6

- Aktiver lokaler Projektpfad wird in jede neue Realtime-Sitzung übernommen.
- Der aktive Projektpfad wird beim Start einer neuen Version aus dem vorherigen Nachbarordner übernommen.
- Folgeänderungen verwenden verbindlich den lokalen Projekt-Editor statt einer falschen ZIP-Aufforderung.
- Einheitliche JARVIS-Systemdialoge ersetzen die nativen Browser-Bestätigungsfenster.
- „Alles aktivieren“ aktiviert alle bereiten Module in einem bestätigten Schritt.

## v11.0.5

- Sicherer Editor für bestehende lokale Projektordner mit aktivem Projektpfad, Backup, Rollback und Prüfung
- Unsichtbare Outlook-/WhatsApp-Web-Abfragen im Headless-Modus
- Serverseitiger Nachrichten-Hintergrunddienst unabhängig von der geöffneten Oberfläche

## v11.0.4

- Projektziele sind nicht mehr an den Desktop gebunden.
- Der Nutzer muss einen vollständigen absoluten Zielpfad inklusive neuem Projektordner nennen.
- Ohne Pfadangabe fragt JARVIS zuerst nach, statt einen Speicherort zu erraten.
- Benutzerdefinierte Zielpfade werden vor Bestätigung und Dateierstellung validiert; vorhandene Ordner bleiben geschützt.

## v11.0.3

- Eigener sicherer Desktop Project Builder statt fehleranfälliger Explorer-/Editor-Klickfolgen.
- Vollständige Neuprojekte werden durch das starke Dateimodell erzeugt, atomar geschrieben und bytegenau geprüft.
- Allgemeine Desktop-Pläne können nach der sichtbaren Bestätigung direkt aus dem Gespräch ausgeführt werden.
- Realtime-Nachrichtenereignisse enthalten immer den von der API verlangten `item.type`.

## v11.0.2

- LiteLLM ist auf die verifizierte universelle Windows-Version `1.91.4` festgelegt.
- Für LiteLLM sind Quellcode-Builds deaktiviert; Visual Studio Build Tools werden nicht benötigt.
- Installationsberichte werden durchgehend als UTF-8 gespeichert und lassen sich normal öffnen.

## v11.0.1

Alle 45 ausgewählten Bausteine sind nun in der Agent-OS-Modul-Matrix erfasst und über stabile Grundmodule, optionale Python-Gruppen oder klar getrennte lokale Dienste angebunden. Die Matrix unterscheidet bewusst zwischen:

- **bereit:** Code beziehungsweise benötigte Abhängigkeit ist vorhanden;
- **aktiv:** JARVIS darf den Adapter verwenden;
- **Setup nötig:** ein externes Programm, Modell, Konto oder lokaler Dienst fehlt;
- **kritisch:** nur im Entwicklerprofil und nach ausdrücklicher Aktivierung.

Der Desktop-Agent führt nicht automatisch 45 fremde Systeme gleichzeitig aus. Er nutzt pro Aufgabe den stabilsten verfügbaren Weg: direkte API, Windows UI Automation, Playwright und erst danach einen ausdrücklich aktivierten visuellen Fallback.

## Bereits bis v10.0.0 umgesetzt

- **OpenAI Realtime Agents:** Das schnelle Realtime-Modell bleibt für Gespräche zuständig; schwierige Aufgaben gehen an ein stärkeres Modell. Die neue Werkzeugverwaltung folgt dem Function-Calling-Muster und kann mehrere Aufrufe abarbeiten. Quelle: https://github.com/openai/openai-realtime-agents
- **Mem0-Idee, bewusst leicht umgesetzt:** Persönliche Erinnerungen und Gesprächsverlauf werden lokal gespeichert und pro Frage nach Wortüberschneidung, Wichtigkeit und Aktualität bewertet. Für die Grundstruktur wird SQLite statt Mem0, Embeddings und einer Vektordatenbank verwendet. Das spart RAM, Tokens und zusätzliche Dienste. Quelle: https://github.com/mem0ai/mem0
- **Home Assistant:** Lesen und Steuern ist als abgesicherte REST-Integration vorbereitet. Ohne Home Assistant bleibt der Rest der App funktionsfähig. Quelle: https://github.com/home-assistant/core
- **Frigate:** JARVIS kann später lokale Erkennungsereignisse der Raumkameras abfragen. Die v9.0 sendet keine Dauerbilder. Quelle: https://github.com/blakeblackshear/frigate
- **Software-only Kontrollzentrum:** Speicherverwaltung, Timer, Berechtigungen, Persönlichkeitsprofile, Diagnose, modulare Fähigkeiten und ein kompletter Gerätesimulator funktionieren schon ohne Komponenten.
- **OpenAI Web Search:** Aktuelle Internetinformationen werden über eine schmale Realtime-Funktion an die Responses-Websuche delegiert. Quellen erscheinen klickbar im Chat; der Zugriff bleibt lesend und begrenzt.
- **OpenAI File Inputs + Datei-Arbeitsmodus:** Fotos, Dokumente, Tabellen, Codedateien und kontrolliert entpackte ZIP-Projekte können ohne dauerhafte lokale Ablage analysiert werden. Erzeugte oder bearbeitete Dateien kommen als kurzlebige Einzeldownloads und Ergebnis-ZIP zurück; komplexe PDF-/Office-/Bildausgaben entstehen im abgeschotteten Code-Interpreter. Datei-Aufgaben verwenden immer das stärkste konfigurierte Modell.
- **KaTeX:** Mathematische LaTeX-Ausgaben werden mit lokal gebündeltem Renderer und lokalen Schriftdateien als echte Brüche, Wurzeln, Potenzen und Gleichungen dargestellt. Quelle: https://github.com/KaTeX/KaTeX
- **Stimmenisolierung:** Browser-Rausch- und Echounterdrückung werden mit OpenAI Far-Field Noise Reduction und einem einstellbaren VAD-Profil kombiniert. Laufende Antworten werden erst nach einem geprüften Sprachtranskript unterbrochen.
- **Gemeinsamer Analysekontext:** Ergebnisse der separaten Datei-/Bildanalyse werden als stiller Kontext in die laufende Realtime-Unterhaltung übernommen. Dadurch kann JARVIS spätere Folgefragen beantworten, ohne die vollständige Analyse vorzulesen.
- **Pausieren und Fortsetzen:** Eine laufende WebRTC-Sprachantwort kann lokal pausiert werden. Der ungehörte Audioteil wird aus dem Realtime-Kontext entfernt; ein anschließendes „Weiter“ setzt die inhaltliche Antwort an dieser Stelle fort.
- **Brains & Safety:** Kontext-Ranking, vorsichtige Absichtserkennung, ruhige Vorschlagskarten, LAN-Authentifizierung, einmalige Aktionsbestätigungen, Entity-Allowlist, Smart-Home-Risikostufen, Idempotency und persistente lokale Rate Limits sind ohne neue Hardware nutzbar.
- **Stability & Recovery:** Persistente Auftragswarteschlange, begrenzte Wiederholungen, Circuit Breaker, automatische SQLite-Backups, validierte Wiederherstellung, Safe Mode, Start-Selbsttest, Modell-Fallbacklisten und Token-Budgets sind ohne Zusatzhardware eingebaut.
- **Richtiger Code-Workspace:** Persistente ZIP-Projekte, lokaler Editor, Secret-Isolierung, statische Prüfungen ohne Codeausführung, Diffs, Snapshots, optimistische Konfliktprüfung, bestätigte KI-Änderungen und vollständiger Projektexport sind ohne Zusatzhardware eingebaut.
- **Autonomie & Konten:** Strukturierte Einzelaktionen laufen optional ohne wiederholte Bestätigung. Experimentelle getrennte Webprofile senden WhatsApp-Testnachrichten und Outlook-Schulmails automatisch; Gmail/privat bleibt über lokales OAuth verbunden. Microsoft Graph bleibt für freigegebene Schul-Tenants optional.
- **Aktionszentrum & Routinen:** Externe Aktionen werden mit Status, Bestätigung, Fehler und gezielter Wiederholung protokolliert. Lokale Routinen können wiederkehrende WhatsApp- oder E-Mail-Nachrichten ausführen; von JARVIS geöffnete WhatsApp-Fenster werden nach Erfolg automatisch geschlossen.

## Einbauen, sobald die Hardware vorhanden ist

1. **OHF Linux Voice Assistant**
   - Aktuelle Basis für einen Linux-Sprachsatelliten mit Home Assistant.
   - Unterstützt lokales Wakeword, Gesprächsfortsetzung, Timer und Audioverbesserung.
   - Passt später zum ReSpeaker und zum Linux-Zweit-PC.
   - https://github.com/OHF-Voice/linux-voice-assistant

2. **openWakeWord**
   - Echtes lokales „Hey Jarvis“, bevor Audio an OpenAI geht.
   - Vortrainiertes `hey jarvis`-Modell, einstellbarer Schwellenwert und optionaler Sprachfilter.
   - Erst mit dem endgültigen Mikrofon einbauen und im echten Zimmer kalibrieren.
   - https://github.com/dscripka/openWakeWord

3. **Silero VAD**
   - Erkennt lokal, ob wirklich gesprochen wird.
   - Reduziert falsche Aktivierungen und unnötige Audioverarbeitung.
   - openWakeWord kann Silero bereits als zusätzlichen Filter verwenden.
   - https://github.com/snakers4/silero-vad

4. **Faster-Whisper**
   - Lokale Spracherkennung als Ausfallmodus, wenn OpenAI oder das Internet nicht verfügbar ist.
   - Auf dem Ryzen-PC später sinnvoll mit CPU-INT8 und einem kleinen deutschen Modell testen.
   - Nicht standardmäßig installiert, weil Modelle groß sind und Realtime bereits transkribiert.
   - https://github.com/SYSTRAN/faster-whisper

5. **Piper**
   - Lokale Sprachausgabe für Offline-Meldungen wie „Internetverbindung getrennt“.
   - Die aktuelle Weiterentwicklung steht unter GPL; daher als separater Dienst betreiben und nicht in den JARVIS-Code kopieren.
   - https://github.com/OHF-Voice/piper1-gpl

6. **CompreFace**
   - Docker-basierte Gesichtserkennung für die Türkamera.
   - REST-API, CPU-Unterstützung und lokale Speicherung der Gesichter.
   - Erst Phase 1 mit einer Kamera stabil testen, bevor weitere Kameras hinzukommen.
   - https://github.com/exadel-inc/CompreFace

7. **Frigate + Coral**
   - Bewegungs- und Objekterkennung für die späteren IP-Kameras.
   - Ereignisbasierte Speicherung statt jede Sekunde dauerhaft auszuwerten.
   - Die API-Anbindung für letzte Ereignisse und deren Simulation ist in v9.0 bereits vorhanden.
   - https://github.com/blakeblackshear/frigate

## Bewusst noch nicht eingebaut

- **Mem0 + Qdrant:** Für semantische Langzeiterinnerungen stark, aber für deine jetzige Grundstruktur unnötig schwer. SQLite reicht zum Testen.
- **LiveKit Agents:** Leistungsfähig für verteilte Sprachagenten, würde deine kleine FastAPI-App aber unnötig komplett umbauen.
- **Altes Wyoming Satellite:** Das Repository ist veraltet und wurde durch OHF Linux Voice Assistant ersetzt.
- **Beliebige JARVIS-Repositories:** Viele sind einfache Demo-Skripte mit fest programmierten Befehlen. Sie würden deine bestehende Realtime-Struktur eher verschlechtern.

## Sinnvolle Reihenfolge

1. v10.0.0 ohne Hardware testen: Command Center, Missionen, Unified Inbox, Einstellungssuche, Bildschirmfreigabe, Aktionszentrum, Auto-Close sowie WhatsApp, Outlook, Gmail und alle bisherigen Funktionen.
2. Türkamera + CompreFace stabilisieren.
3. ReSpeaker anschließen und lokales openWakeWord kalibrieren.
4. Home Assistant real verbinden und Geräte-IDs festlegen.
5. Frigate mit genau einer Kamera und Coral testen.
6. Erst danach weitere Kameras und Lautsprecher ergänzen.
