from __future__ import annotations

import json
import re
import threading
import time
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any


class GeneratedBundleStore:
    """Small disk-backed store for short-lived generated download bundles."""

    _ID_PATTERN = re.compile(r"^[A-Za-z0-9_-]{16,100}$")

    def __init__(
        self,
        root: Path,
        *,
        ttl_seconds: int = 900,
        max_bundles: int = 30,
        max_total_bytes: int = 250 * 1024 * 1024,
    ) -> None:
        self.root = root
        self.ttl_seconds = max(60, ttl_seconds)
        self.max_bundles = max(1, max_bundles)
        self.max_total_bytes = max(25 * 1024 * 1024, max_total_bytes)
        self._lock = threading.RLock()
        self.root.mkdir(parents=True, exist_ok=True)
        self.cleanup()

    def _paths(self, bundle_id: str) -> tuple[Path, Path]:
        if not self._ID_PATTERN.fullmatch(bundle_id):
            raise KeyError(bundle_id)
        return self.root / f"{bundle_id}.json", self.root / f"{bundle_id}.zip"

    def _manifests(self) -> list[tuple[Path, dict[str, Any]]]:
        items: list[tuple[Path, dict[str, Any]]] = []
        for path in self.root.glob("*.json"):
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            if isinstance(data, dict):
                items.append((path, data))
        return items

    def cleanup(self) -> None:
        with self._lock:
            now = time.time()
            live: list[tuple[Path, Path, dict[str, Any], int]] = []
            for manifest_path, manifest in self._manifests():
                bundle_id = str(manifest.get("bundle_id", ""))
                try:
                    _, zip_path = self._paths(bundle_id)
                except KeyError:
                    manifest_path.unlink(missing_ok=True)
                    continue
                expires_at = float(manifest.get("expires_at", 0))
                if expires_at <= now or not zip_path.is_file():
                    manifest_path.unlink(missing_ok=True)
                    zip_path.unlink(missing_ok=True)
                    continue
                try:
                    size = zip_path.stat().st_size
                except OSError:
                    size = 0
                live.append((manifest_path, zip_path, manifest, size))

            live.sort(key=lambda item: float(item[2].get("created_at", 0)))
            total = sum(item[3] for item in live)
            while len(live) > self.max_bundles or total > self.max_total_bytes:
                manifest_path, zip_path, _, size = live.pop(0)
                manifest_path.unlink(missing_ok=True)
                zip_path.unlink(missing_ok=True)
                total -= size
            live_zip_paths = {item[1] for item in live}
            for orphan in self.root.glob("*.zip"):
                if orphan not in live_zip_paths:
                    orphan.unlink(missing_ok=True)

    def save(self, bundle_id: str, files: list[dict[str, object]]) -> dict[str, Any]:
        manifest_path, zip_path = self._paths(bundle_id)
        created_at = time.time()
        expires_at = created_at + self.ttl_seconds
        public_files: list[dict[str, Any]] = []
        temporary_zip = zip_path.with_suffix(".zip.tmp")
        temporary_manifest = manifest_path.with_suffix(".json.tmp")
        with self._lock:
            with zipfile.ZipFile(temporary_zip, "w", compression=zipfile.ZIP_DEFLATED) as archive:
                for index, item in enumerate(files):
                    path = str(item["path"])
                    data = bytes(item["data"])
                    archive.writestr(path, data)
                    public_files.append(
                        {
                            "path": path,
                            "name": PurePosixPath(path).name,
                            "size": len(data),
                            "index": index,
                        }
                    )
            manifest = {
                "bundle_id": bundle_id,
                "created_at": created_at,
                "expires_at": expires_at,
                "files": public_files,
            }
            temporary_manifest.write_text(json.dumps(manifest, ensure_ascii=False), encoding="utf-8")
            temporary_zip.replace(zip_path)
            temporary_manifest.replace(manifest_path)
            self.cleanup()
        return manifest

    def get(self, bundle_id: str) -> dict[str, Any]:
        manifest_path, zip_path = self._paths(bundle_id)
        with self._lock:
            try:
                manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError) as exc:
                raise KeyError(bundle_id) from exc
            if not isinstance(manifest, dict) or float(manifest.get("expires_at", 0)) <= time.time():
                manifest_path.unlink(missing_ok=True)
                zip_path.unlink(missing_ok=True)
                raise KeyError(bundle_id)
            if not zip_path.is_file():
                raise KeyError(bundle_id)
            return manifest

    def read_zip(self, bundle_id: str) -> bytes:
        self.get(bundle_id)
        _, zip_path = self._paths(bundle_id)
        try:
            return zip_path.read_bytes()
        except OSError as exc:
            raise KeyError(bundle_id) from exc

    def read_file(self, bundle_id: str, file_index: int) -> tuple[dict[str, Any], bytes]:
        manifest = self.get(bundle_id)
        files = manifest.get("files")
        if not isinstance(files, list) or file_index < 0 or file_index >= len(files):
            raise KeyError(file_index)
        item = files[file_index]
        if not isinstance(item, dict) or not isinstance(item.get("path"), str):
            raise KeyError(file_index)
        _, zip_path = self._paths(bundle_id)
        try:
            with zipfile.ZipFile(zip_path) as archive:
                data = archive.read(item["path"])
        except (OSError, KeyError, zipfile.BadZipFile) as exc:
            raise KeyError(file_index) from exc
        if len(data) != int(item.get("size", -1)):
            raise KeyError(file_index)
        return item, data

    def clear(self) -> None:
        """Delete only this store's generated bundle files (mainly useful in tests)."""
        with self._lock:
            for suffix in ("*.json", "*.zip", "*.tmp"):
                for path in self.root.glob(suffix):
                    path.unlink(missing_ok=True)
