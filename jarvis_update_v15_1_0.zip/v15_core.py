from __future__ import annotations

import base64
import binascii
import os
import re
import shutil
import struct
import subprocess
import tempfile
import unicodedata
import webbrowser
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Callable, Final
from urllib.parse import urlparse


PC_AGENT_VERSION: Final = "15.1.0"
MAX_SCREEN_BYTES: Final = 8 * 1024 * 1024

BLOCKED_OPEN_SUFFIXES: Final = {
    ".bat",
    ".cmd",
    ".com",
    ".cpl",
    ".hta",
    ".inf",
    ".ins",
    ".isp",
    ".js",
    ".jse",
    ".lnk",
    ".msh",
    ".msh1",
    ".msh2",
    ".mshxml",
    ".msi",
    ".msp",
    ".mst",
    ".pif",
    ".ps1",
    ".ps1xml",
    ".ps2",
    ".ps2xml",
    ".psc1",
    ".psc2",
    ".reg",
    ".scr",
    ".sct",
    ".url",
    ".vb",
    ".vbe",
    ".vbs",
    ".ws",
    ".wsc",
    ".wsf",
    ".wsh",
}

PROGRAM_ALIASES: Final[dict[str, dict[str, object]]] = {
    "datei explorer": {"mode": "command", "value": ["explorer.exe"], "label": "Datei-Explorer"},
    "dateiexplorer": {"mode": "command", "value": ["explorer.exe"], "label": "Datei-Explorer"},
    "editor": {"mode": "command", "value": ["notepad.exe"], "label": "Editor"},
    "einstellungen": {"mode": "uri", "value": "ms-settings:", "label": "Windows-Einstellungen"},
    "explorer": {"mode": "command", "value": ["explorer.exe"], "label": "Datei-Explorer"},
    "fotos": {"mode": "uri", "value": "ms-photos:", "label": "Fotos"},
    "kamera": {
        "mode": "uri",
        "value": "microsoft.windows.camera:",
        "label": "Windows-Kamera",
    },
    "notepad": {"mode": "command", "value": ["notepad.exe"], "label": "Editor"},
    "paint": {"mode": "command", "value": ["mspaint.exe"], "label": "Paint"},
    "rechner": {"mode": "command", "value": ["calc.exe"], "label": "Rechner"},
    "task manager": {"mode": "command", "value": ["taskmgr.exe"], "label": "Task-Manager"},
    "taskmanager": {"mode": "command", "value": ["taskmgr.exe"], "label": "Task-Manager"},
    "terminal": {
        "mode": "command",
        "value": ["wt.exe"],
        "label": "Windows Terminal",
        "terminal": True,
    },
}


class PcAgentError(RuntimeError):
    pass


def normalize_pc_target(value: object) -> str:
    decomposed = unicodedata.normalize("NFKD", str(value or "").casefold())
    without_marks = "".join(
        character for character in decomposed if not unicodedata.combining(character)
    )
    return " ".join(re.findall(r"[^\W_]+", without_marks, flags=re.UNICODE))


def _clean_target(value: object) -> str:
    target = str(value or "").strip()
    if len(target) >= 2 and target[0] == target[-1] and target[0] in {'"', "'"}:
        target = target[1:-1].strip()
    if not target or len(target) > 1_000 or "\x00" in target or "\r" in target or "\n" in target:
        raise PcAgentError("Das PC-Ziel ist leer oder ungültig.")
    return target


def _jpeg_dimensions(data: bytes) -> tuple[int, int] | None:
    if not data.startswith(b"\xff\xd8"):
        return None
    offset = 2
    while offset + 9 < len(data):
        if data[offset] != 0xFF:
            offset += 1
            continue
        marker = data[offset + 1]
        offset += 2
        if marker in {0xD8, 0xD9}:
            continue
        if offset + 2 > len(data):
            return None
        length = int.from_bytes(data[offset : offset + 2], "big")
        if length < 2 or offset + length > len(data):
            return None
        if marker in {
            0xC0,
            0xC1,
            0xC2,
            0xC3,
            0xC5,
            0xC6,
            0xC7,
            0xC9,
            0xCA,
            0xCB,
            0xCD,
            0xCE,
            0xCF,
        }:
            height = int.from_bytes(data[offset + 3 : offset + 5], "big")
            width = int.from_bytes(data[offset + 5 : offset + 7], "big")
            return (width, height) if width and height else None
        offset += length
    return None


def screen_image_metadata(data: bytes) -> dict[str, object]:
    if data.startswith(b"\x89PNG\r\n\x1a\n") and len(data) >= 24:
        width, height = struct.unpack(">II", data[16:24])
        mime_type = "image/png"
    elif data.startswith(b"\xff\xd8\xff"):
        dimensions = _jpeg_dimensions(data)
        width, height = dimensions or (0, 0)
        mime_type = "image/jpeg"
    elif data.startswith(b"RIFF") and len(data) >= 16 and data[8:12] == b"WEBP":
        width, height = 0, 0
        mime_type = "image/webp"
    else:
        raise PcAgentError("Das Bildschirmbild ist kein gültiges PNG-, JPEG- oder WebP-Bild.")
    if len(data) > MAX_SCREEN_BYTES:
        raise PcAgentError("Das Bildschirmbild ist größer als 8 MB.")
    if width > 32_768 or height > 32_768:
        raise PcAgentError("Das Bildschirmbild hat ungültige Abmessungen.")
    return {
        "mime_type": mime_type,
        "width": width,
        "height": height,
        "bytes": len(data),
    }


def decode_screen_data_url(value: str) -> tuple[bytes, dict[str, object]]:
    raw = str(value or "").strip()
    match = re.fullmatch(
        r"data:(image/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=\r\n]+)",
        raw,
        flags=re.IGNORECASE,
    )
    if not match:
        raise PcAgentError("Das übergebene Bildschirmbild ist ungültig.")
    try:
        data = base64.b64decode(match.group(2), validate=True)
    except (ValueError, binascii.Error) as exc:
        raise PcAgentError("Das übergebene Bildschirmbild ist beschädigt.") from exc
    metadata = screen_image_metadata(data)
    if metadata["mime_type"] != match.group(1).casefold():
        raise PcAgentError("Dateityp und Inhalt des Bildschirmbilds stimmen nicht überein.")
    return data, metadata


class PcAgentController:
    """Safe Windows program/file launcher and one-shot screen capture."""

    def __init__(
        self,
        capability_manager: Any,
        base_dir: Path,
        *,
        platform_name: str | None = None,
        startfile: Callable[[str], object] | None = None,
    ) -> None:
        self.capability_manager = capability_manager
        self.base_dir = Path(base_dir)
        self.platform_name = platform_name or os.name
        self._startfile = startfile

    def _terminal_allowed(self) -> bool:
        settings = self.capability_manager.settings()
        return bool(settings.get("allow_terminal"))

    @staticmethod
    def _is_url(target: str) -> bool:
        parsed = urlparse(target)
        return parsed.scheme.casefold() in {"http", "https"} and bool(parsed.netloc)

    @staticmethod
    def _path_result(path: Path, requested_kind: str) -> dict[str, object]:
        if path.is_dir():
            if requested_kind == "file":
                raise PcAgentError("Das angegebene Ziel ist ein Ordner und keine Datei.")
            return {
                "mode": "path",
                "kind": "folder",
                "value": str(path),
                "label": path.name or str(path),
            }
        if not path.is_file():
            raise PcAgentError("Die angegebene Datei oder der Ordner wurde nicht gefunden.")
        suffix = path.suffix.casefold()
        if suffix in BLOCKED_OPEN_SUFFIXES:
            raise PcAgentError(
                "Skripte, Installer, Verknüpfungen und andere ausführbare Hilfsdateien "
                "werden vom PC-Agenten nicht direkt gestartet."
            )
        is_program = suffix == ".exe"
        if requested_kind == "folder":
            raise PcAgentError("Das angegebene Ziel ist eine Datei und kein Ordner.")
        if requested_kind == "program" and not is_program:
            raise PcAgentError("Das angegebene Ziel ist kein Windows-Programm.")
        return {
            "mode": "path",
            "kind": "program" if is_program else "file",
            "value": str(path),
            "label": path.name,
        }

    def _start_menu_matches(self, target: str) -> list[Path]:
        if self.platform_name != "nt":
            return []
        roots: list[Path] = []
        for environment_name in ("APPDATA", "PROGRAMDATA"):
            raw = os.getenv(environment_name, "").strip()
            if raw:
                roots.append(Path(raw) / "Microsoft" / "Windows" / "Start Menu" / "Programs")
        wanted = normalize_pc_target(target)
        exact: list[Path] = []
        partial: list[Path] = []
        checked = 0
        for root in roots:
            if not root.is_dir():
                continue
            try:
                candidates = root.rglob("*.lnk")
                for candidate in candidates:
                    checked += 1
                    if checked > 8_000:
                        break
                    name = normalize_pc_target(candidate.stem)
                    if name == wanted:
                        exact.append(candidate)
                    elif wanted and wanted in name:
                        partial.append(candidate)
            except OSError:
                continue
        return exact or partial[:12]

    def resolve_target(self, target: str, requested_kind: str = "auto") -> dict[str, object]:
        clean = _clean_target(target)
        kind = str(requested_kind or "auto").casefold()
        if kind not in {"auto", "program", "file", "folder", "url"}:
            raise PcAgentError("Unbekannter PC-Zieltyp.")
        if self._is_url(clean):
            if kind not in {"auto", "url"}:
                raise PcAgentError("Das angegebene Ziel ist eine Webseite.")
            return {
                "mode": "url",
                "kind": "url",
                "value": clean,
                "label": urlparse(clean).netloc,
            }

        alias = PROGRAM_ALIASES.get(normalize_pc_target(clean))
        if alias:
            if kind in {"file", "folder", "url"}:
                raise PcAgentError("Das angegebene Ziel ist ein Programm.")
            if alias.get("terminal") and not self._terminal_allowed():
                raise PcAgentError(
                    "Das Terminal ist in den Agent-OS-Sicherheitseinstellungen deaktiviert."
                )
            return {**alias, "kind": "program"}

        expanded = os.path.expandvars(clean)
        candidate = Path(expanded).expanduser()
        if candidate.is_absolute() or candidate.exists():
            try:
                resolved = candidate.resolve(strict=True)
            except (OSError, RuntimeError) as exc:
                raise PcAgentError("Die angegebene Datei oder der Ordner wurde nicht gefunden.") from exc
            return self._path_result(resolved, kind)
        if kind in {"file", "folder"} or any(separator in clean for separator in ("/", "\\")):
            raise PcAgentError(
                "Die Datei oder der Ordner wurde nicht gefunden. Gib dafür den vollständigen Pfad an."
            )

        if self.platform_name == "nt":
            executable = shutil.which(clean)
            if executable and Path(executable).suffix.casefold() == ".exe":
                return {
                    "mode": "command",
                    "kind": "program",
                    "value": [executable],
                    "label": Path(executable).stem,
                }
            matches = self._start_menu_matches(clean)
            if len(matches) == 1:
                return {
                    "mode": "shortcut",
                    "kind": "program",
                    "value": str(matches[0]),
                    "label": matches[0].stem,
                }
            if len(matches) > 1:
                names = ", ".join(item.stem for item in matches[:4])
                raise PcAgentError(
                    f"Mehrere Programme passen zu „{clean}“: {names}. Nenne den exakten Programmnamen."
                )
        raise PcAgentError(
            "Dieses Programm wurde nicht eindeutig gefunden. Nenne den exakten Namen oder den vollständigen Pfad."
        )

    def open_target(self, target: str, requested_kind: str = "auto") -> dict[str, object]:
        if self.platform_name != "nt":
            raise PcAgentError("Der PC-Agent kann Programme und Dateien nur unter Windows öffnen.")
        resolved = self.resolve_target(target, requested_kind)
        mode = str(resolved["mode"])
        value = resolved["value"]
        try:
            if mode == "url":
                opened = webbrowser.open(str(value), new=0, autoraise=True)
                if opened is False:
                    raise OSError("Kein Browser hat das Ziel angenommen.")
            elif mode == "command":
                command = [str(part) for part in value] if isinstance(value, list) else [str(value)]
                subprocess.Popen(command, shell=False, close_fds=True)
            else:
                startfile = self._startfile or getattr(os, "startfile", None)
                if not callable(startfile):
                    raise OSError("Windows ShellExecute ist nicht verfügbar.")
                startfile(str(value))
        except OSError as exc:
            raise PcAgentError(f"„{resolved['label']}“ konnte nicht geöffnet werden.") from exc
        return {
            "ok": True,
            "version": PC_AGENT_VERSION,
            "mode": mode,
            "kind": resolved["kind"],
            "label": resolved["label"],
            "target": str(value) if not isinstance(value, list) else str(resolved["label"]),
            "requires_user_action": False,
        }

    @staticmethod
    def _native_capture_script() -> str:
        return (
            "Add-Type -AssemblyName System.Windows.Forms; "
            "Add-Type -AssemblyName System.Drawing; "
            "$bounds=[System.Windows.Forms.SystemInformation]::VirtualScreen; "
            "$bitmap=New-Object System.Drawing.Bitmap $bounds.Width,$bounds.Height; "
            "$graphics=[System.Drawing.Graphics]::FromImage($bitmap); "
            "try { "
            "$graphics.CopyFromScreen($bounds.Left,$bounds.Top,0,0,$bounds.Size); "
            "$bitmap.Save($env:JARVIS_SCREEN_PATH,[System.Drawing.Imaging.ImageFormat]::Png) "
            "} finally { $graphics.Dispose(); $bitmap.Dispose() }"
        )

    def capture_native_screen(self) -> tuple[bytes, dict[str, object]]:
        if self.platform_name != "nt":
            raise PcAgentError("Die native Bildschirmaufnahme ist nur unter Windows verfügbar.")
        powershell = shutil.which("powershell.exe") or shutil.which("powershell")
        if not powershell:
            raise PcAgentError("Windows PowerShell wurde für die Bildschirmaufnahme nicht gefunden.")
        with tempfile.TemporaryDirectory(prefix="jarvis-screen-") as directory:
            output = Path(directory) / "screen.png"
            environment = {
                key: value
                for key, value in os.environ.items()
                if key.upper() in {"SYSTEMROOT", "WINDIR", "TEMP", "TMP", "PATH"}
            }
            environment["JARVIS_SCREEN_PATH"] = str(output)
            try:
                completed = subprocess.run(
                    [
                        powershell,
                        "-NoLogo",
                        "-NoProfile",
                        "-NonInteractive",
                        "-Command",
                        self._native_capture_script(),
                    ],
                    check=False,
                    capture_output=True,
                    timeout=20,
                    env=environment,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )
            except (OSError, subprocess.TimeoutExpired) as exc:
                raise PcAgentError("Der Bildschirm konnte nicht aufgenommen werden.") from exc
            if completed.returncode != 0 or not output.is_file():
                raise PcAgentError("Windows konnte kein Bildschirmbild erzeugen.")
            try:
                data = output.read_bytes()
            except OSError as exc:
                raise PcAgentError("Das Bildschirmbild konnte nicht gelesen werden.") from exc
        metadata = screen_image_metadata(data)
        return data, {
            **metadata,
            "source": "native_fullscreen",
            "captured_at": datetime.now(UTC).isoformat(timespec="seconds"),
            "persisted": False,
        }

    def screen_bytes(self, image_data_url: str = "") -> tuple[bytes, dict[str, object]]:
        if image_data_url:
            data, metadata = decode_screen_data_url(image_data_url)
            return data, {
                **metadata,
                "source": "browser_selection",
                "captured_at": datetime.now(UTC).isoformat(timespec="seconds"),
                "persisted": False,
            }
        return self.capture_native_screen()

    def visible_windows(self, limit: int = 12) -> list[dict[str, object]]:
        if self.platform_name != "nt":
            return []
        try:
            import ctypes
            from ctypes import wintypes

            user32 = ctypes.windll.user32
            foreground = int(user32.GetForegroundWindow())
            results: list[dict[str, object]] = []
            callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

            def collect(handle: int, _parameter: int) -> bool:
                if len(results) >= max(1, min(40, int(limit))):
                    return False
                if not user32.IsWindowVisible(handle):
                    return True
                length = min(512, int(user32.GetWindowTextLengthW(handle)))
                if length <= 0:
                    return True
                buffer = ctypes.create_unicode_buffer(length + 1)
                user32.GetWindowTextW(handle, buffer, length + 1)
                title = " ".join(buffer.value.split())[:300]
                if title:
                    results.append({"title": title, "active": int(handle) == foreground})
                return True

            callback = callback_type(collect)
            user32.EnumWindows(callback, 0)
            return results
        except Exception:
            return []

    @staticmethod
    def program_catalog() -> list[dict[str, str]]:
        seen: set[str] = set()
        items: list[dict[str, str]] = []
        for alias, specification in PROGRAM_ALIASES.items():
            label = str(specification["label"])
            if label in seen:
                continue
            seen.add(label)
            items.append({"alias": alias, "label": label})
        return items
