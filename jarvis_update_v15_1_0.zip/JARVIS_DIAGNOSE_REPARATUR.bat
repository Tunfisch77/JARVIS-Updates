@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title JARVIS Diagnose und Reparatur
if not exist ".venv\Scripts\python.exe" (
  echo Die Python-Umgebung fehlt. Starte MODULE_INSTALLIEREN.bat.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" jarvis_diagnostics.py --repair
echo.
echo Die Diagnose ist abgeschlossen.
pause
