from __future__ import annotations

import ast
import difflib
import hashlib
import io
import json
import re
import secrets
import shutil
import stat
import threading
import tomllib
import zipfile
from datetime import UTC, datetime
from html.parser import HTMLParser
from pathlib import Path, PurePosixPath
from typing import Any
from xml.etree import ElementTree


class WorkspaceError(ValueError):
    pass


class _StrictHtmlParser(HTMLParser):
    def error(self, message: str) -> None:  # pragma: no cover - kept for older Python implementations
        raise WorkspaceError(message)


class CodeWorkspaceManager:
    """Persistent, non-executing project workspace with snapshots and reviewed changes."""

    MAX_ARCHIVE_BYTES = 25 * 1024 * 1024
    MAX_EXPANDED_BYTES = 80 * 1024 * 1024
    MAX_ENTRY_BYTES = 10 * 1024 * 1024
    MAX_ENTRIES = 500
    MAX_COMPRESSION_RATIO = 120
    MAX_EDITABLE_BYTES = 2 * 1024 * 1024
    MAX_PROPOSAL_BYTES = 10 * 1024 * 1024
    MAX_SNAPSHOTS = 10
    MAX_AI_FILES = 60
    MAX_AI_BYTES = 2 * 1024 * 1024
    ID_PATTERN = re.compile(r"^[A-Za-z0-9_-]{16,100}$")

    EDITABLE_SUFFIXES = {
        ".c", ".cfg", ".conf", ".cpp", ".cs", ".css", ".csv", ".dart", ".env.example",
        ".go", ".gradle", ".h", ".hpp", ".htm", ".html", ".ini", ".java", ".js", ".json",
        ".jsx", ".kt", ".kts", ".lua", ".mjs", ".md", ".php", ".properties", ".py", ".r",
        ".rb", ".rs", ".scala", ".scss", ".sh", ".sql", ".svelte", ".svg", ".swift", ".tex",
        ".toml", ".ts", ".tsx", ".txt", ".vue", ".xml", ".yaml", ".yml",
    }
    EDITABLE_NAMES = {
        ".dockerignore", ".editorconfig", ".env.example", ".env.sample", ".env.template", ".gitignore",
        "dockerfile", "gemfile", "makefile", "procfile", "rakefile",
    }
    SENSITIVE_NAMES = {
        ".env", ".npmrc", ".pypirc", "authorized_keys", "credentials", "id_dsa", "id_ecdsa",
        "id_ed25519", "id_rsa", "known_hosts", "secrets.json", "gmail_token.json",
        "google_client_secret.json", "outlook_token_cache.json",
    }
    SENSITIVE_SUFFIXES = {".key", ".kdbx", ".p12", ".pem", ".pfx"}
    SKIPPED_DIRECTORIES = {
        ".git", ".gradle", ".idea", ".mypy_cache", ".next", ".pytest_cache", ".tox", ".venv",
        ".vscode", "__pycache__", "build", "coverage", "dist", "node_modules", "target", "vendor", "venv",
    }
    WINDOWS_RESERVED_NAMES = {
        "aux", "clock$", "con", "nul", "prn",
        *(f"com{index}" for index in range(1, 10)),
        *(f"lpt{index}" for index in range(1, 10)),
    }

    def __init__(self, root: Path) -> None:
        self.root = root
        self._lock = threading.RLock()
        self.root.mkdir(parents=True, exist_ok=True)
        self._cleanup_temporary_directories()

    @staticmethod
    def _now() -> str:
        return datetime.now(UTC).isoformat(timespec="seconds")

    def _cleanup_temporary_directories(self) -> None:
        for path in self.root.glob(".import-*"):
            if path.is_dir():
                shutil.rmtree(path, ignore_errors=True)

    @classmethod
    def normalize_path(cls, raw_path: str) -> str:
        value = str(raw_path or "").replace("\\", "/").strip().strip("/")
        if not value or len(value) > 500 or "\x00" in value:
            raise WorkspaceError("Ungültiger Projektpfad.")
        path = PurePosixPath(value)
        if path.is_absolute() or any(part in {"", ".", ".."} for part in path.parts):
            raise WorkspaceError("Unsicherer Projektpfad.")
        if any(":" in part or any(ord(char) < 32 for char in part) for part in path.parts):
            raise WorkspaceError("Der Projektpfad enthält nicht erlaubte Zeichen.")
        if any(part.endswith((" ", ".")) or part.split(".", 1)[0].casefold() in cls.WINDOWS_RESERVED_NAMES for part in path.parts):
            raise WorkspaceError("Der Projektpfad ist unter Windows nicht sicher verwendbar.")
        if path.parts[0].casefold() == ".jarvis":
            raise WorkspaceError("Der interne .jarvis-Pfad ist reserviert.")
        return path.as_posix()

    @classmethod
    def is_sensitive_path(cls, raw_path: str) -> bool:
        path = PurePosixPath(str(raw_path).replace("\\", "/"))
        lowered_parts = {part.casefold() for part in path.parts}
        name = path.name.casefold()
        if name in {".env.example", ".env.sample", ".env.template"}:
            return False
        return (
            name in cls.SENSITIVE_NAMES
            or name.startswith(".env")
            or name.startswith("credentials.")
            or name.startswith("secrets.")
            or path.suffix.casefold() in cls.SENSITIVE_SUFFIXES
            or bool(lowered_parts & {".aws", ".gnupg", ".ssh", "secrets"})
        )

    @classmethod
    def is_editable_path(cls, raw_path: str) -> bool:
        path = PurePosixPath(str(raw_path))
        name = path.name.casefold()
        return not cls.is_sensitive_path(raw_path) and (
            name in cls.EDITABLE_NAMES or path.suffix.casefold() in cls.EDITABLE_SUFFIXES
        )

    def _workspace_root(self, workspace_id: str) -> Path:
        if not self.ID_PATTERN.fullmatch(workspace_id):
            raise WorkspaceError("Ungültige Workspace-ID.")
        path = self.root / workspace_id
        if not path.is_dir():
            raise WorkspaceError("Code-Workspace wurde nicht gefunden.")
        return path

    def _project_root(self, workspace_id: str) -> Path:
        project = self._workspace_root(workspace_id) / "project"
        if not project.is_dir():
            raise WorkspaceError("Der Projektordner fehlt.")
        return project

    @classmethod
    def _safe_join(cls, root: Path, raw_path: str) -> tuple[str, Path]:
        relative = cls.normalize_path(raw_path)
        root_resolved = root.resolve()
        target = root.joinpath(*PurePosixPath(relative).parts)
        try:
            target.resolve(strict=False).relative_to(root_resolved)
        except ValueError as exc:
            raise WorkspaceError("Projektpfad verlässt den Workspace.") from exc
        return relative, target

    @staticmethod
    def _atomic_json(path: Path, payload: dict[str, Any]) -> None:
        temporary = path.with_suffix(path.suffix + ".tmp")
        temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        temporary.replace(path)

    def _metadata(self, workspace_id: str) -> dict[str, Any]:
        path = self._workspace_root(workspace_id) / "metadata.json"
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise WorkspaceError("Workspace-Metadaten sind beschädigt.") from exc
        if not isinstance(payload, dict) or payload.get("id") != workspace_id:
            raise WorkspaceError("Workspace-Metadaten sind ungültig.")
        return payload

    def _save_metadata(self, workspace_id: str, payload: dict[str, Any]) -> None:
        payload["updated_at"] = self._now()
        self._atomic_json(self._workspace_root(workspace_id) / "metadata.json", payload)

    @staticmethod
    def _clean_project_name(name: str) -> str:
        cleaned = " ".join(str(name).split()).strip()[:120]
        return cleaned or "Code-Projekt"

    @classmethod
    def _archive_member_path(cls, name: str) -> str:
        return cls.normalize_path(name)

    def import_zip(self, data: bytes, *, name: str) -> dict[str, Any]:
        if not data or len(data) > self.MAX_ARCHIVE_BYTES:
            raise WorkspaceError("Das Projekt-ZIP ist leer oder größer als 25 MB.")
        workspace_id = secrets.token_urlsafe(18)
        temporary_root = self.root / f".import-{workspace_id}"
        final_root = self.root / workspace_id
        project_root = temporary_root / "project"
        project_root.mkdir(parents=True, exist_ok=False)
        warnings: list[str] = []
        file_count = 0
        total_bytes = 0
        seen: set[str] = set()
        try:
            try:
                archive = zipfile.ZipFile(io.BytesIO(data))
            except zipfile.BadZipFile as exc:
                raise WorkspaceError("Die Datei ist kein gültiges ZIP-Projekt.") from exc
            with archive:
                members = archive.infolist()
                if len(members) > self.MAX_ENTRIES:
                    raise WorkspaceError("Das ZIP enthält mehr als 500 Einträge.")
                for member in members:
                    raw_name = member.filename.replace("\\", "/").rstrip("/")
                    if not raw_name:
                        continue
                    relative = self._archive_member_path(raw_name)
                    parts = {part.casefold() for part in PurePosixPath(relative).parts}
                    if parts & self.SKIPPED_DIRECTORIES:
                        if not member.is_dir():
                            warnings.append(f"Übersprungen: {relative}")
                        continue
                    mode = member.external_attr >> 16
                    file_type = stat.S_IFMT(mode)
                    if stat.S_ISLNK(mode) or (file_type and not stat.S_ISREG(mode) and not stat.S_ISDIR(mode)):
                        raise WorkspaceError(f"Unsicherer ZIP-Eintrag: {relative}")
                    key = relative.casefold()
                    if key in seen:
                        raise WorkspaceError(f"Doppelter Projektpfad: {relative}")
                    seen.add(key)
                    _, destination = self._safe_join(project_root, relative)
                    if member.is_dir():
                        destination.mkdir(parents=True, exist_ok=True)
                        continue
                    if member.flag_bits & 0x1:
                        raise WorkspaceError(f"Verschlüsselter ZIP-Eintrag: {relative}")
                    if member.file_size > self.MAX_ENTRY_BYTES:
                        raise WorkspaceError(f"Projektdatei ist größer als 10 MB: {relative}")
                    if member.file_size > 1024 * 1024 and member.file_size / max(1, member.compress_size) > self.MAX_COMPRESSION_RATIO:
                        raise WorkspaceError(f"Unsicheres Kompressionsverhältnis: {relative}")
                    total_bytes += member.file_size
                    if total_bytes > self.MAX_EXPANDED_BYTES:
                        raise WorkspaceError("Das Projekt ist entpackt größer als 80 MB.")
                    payload = archive.read(member)
                    if len(payload) != member.file_size:
                        raise WorkspaceError(f"Projektdatei ist beschädigt: {relative}")
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    destination.write_bytes(payload)
                    file_count += 1
            if not file_count:
                raise WorkspaceError("Das ZIP enthält keine importierbaren Projektdateien.")
            (temporary_root / "snapshots").mkdir()
            (temporary_root / "proposals").mkdir()
            now = self._now()
            metadata = {
                "id": workspace_id,
                "name": self._clean_project_name(name),
                "created_at": now,
                "updated_at": now,
                "source_size": len(data),
                "warnings": warnings[:100],
                "snapshots": [],
            }
            self._atomic_json(temporary_root / "metadata.json", metadata)
            temporary_root.replace(final_root)
            baseline = self.create_snapshot(workspace_id, label="Import-Basis")
            metadata = self._metadata(workspace_id)
            metadata["baseline_snapshot_id"] = baseline["id"]
            self._save_metadata(workspace_id, metadata)
            return self.get_workspace(workspace_id)
        except Exception:
            shutil.rmtree(temporary_root, ignore_errors=True)
            shutil.rmtree(final_root, ignore_errors=True)
            raise

    def _project_files(self, workspace_id: str) -> list[tuple[str, Path]]:
        project = self._project_root(workspace_id)
        files: list[tuple[str, Path]] = []
        for path in project.rglob("*"):
            if path.is_symlink():
                raise WorkspaceError("Der Workspace enthält einen unerlaubten symbolischen Link.")
            if path.is_file():
                files.append((path.relative_to(project).as_posix(), path))
        return sorted(files, key=lambda item: item[0].casefold())

    @staticmethod
    def _is_utf8(path: Path, *, limit: int) -> bool:
        try:
            if path.stat().st_size > limit:
                return False
            path.read_text(encoding="utf-8")
            return True
        except (OSError, UnicodeDecodeError):
            return False

    def list_files(self, workspace_id: str) -> list[dict[str, Any]]:
        items: list[dict[str, Any]] = []
        for relative, path in self._project_files(workspace_id):
            sensitive = self.is_sensitive_path(relative)
            editable = self.is_editable_path(relative) and self._is_utf8(path, limit=self.MAX_EDITABLE_BYTES)
            items.append(
                {
                    "path": relative,
                    "name": PurePosixPath(relative).name,
                    "size": path.stat().st_size,
                    "sensitive": sensitive,
                    "editable": editable,
                }
            )
        return items

    def get_workspace(self, workspace_id: str) -> dict[str, Any]:
        metadata = self._metadata(workspace_id)
        files = self.list_files(workspace_id)
        return {
            **metadata,
            "file_count": len(files),
            "total_bytes": sum(int(item["size"]) for item in files),
            "sensitive_files": sum(1 for item in files if item["sensitive"]),
            "editable_files": sum(1 for item in files if item["editable"]),
        }

    def list_workspaces(self) -> list[dict[str, Any]]:
        items: list[dict[str, Any]] = []
        for path in self.root.iterdir():
            if path.is_dir() and self.ID_PATTERN.fullmatch(path.name):
                try:
                    items.append(self.get_workspace(path.name))
                except WorkspaceError:
                    continue
        return sorted(items, key=lambda item: str(item.get("updated_at", "")), reverse=True)

    def read_text(self, workspace_id: str, raw_path: str) -> dict[str, Any]:
        project = self._project_root(workspace_id)
        relative, path = self._safe_join(project, raw_path)
        if self.is_sensitive_path(relative):
            raise WorkspaceError("Sensible Projektdateien werden im Editor nicht angezeigt.")
        if not path.is_file() or path.is_symlink():
            raise WorkspaceError("Projektdatei wurde nicht gefunden.")
        if not self.is_editable_path(relative) or path.stat().st_size > self.MAX_EDITABLE_BYTES:
            raise WorkspaceError("Diese Datei ist nicht als UTF-8-Textdatei editierbar.")
        try:
            content = path.read_text(encoding="utf-8")
        except UnicodeDecodeError as exc:
            raise WorkspaceError("Diese Datei ist keine UTF-8-Textdatei.") from exc
        return {"path": relative, "content": content, "size": len(content.encode("utf-8"))}

    def write_text(self, workspace_id: str, raw_path: str, content: str) -> dict[str, Any]:
        project = self._project_root(workspace_id)
        relative, path = self._safe_join(project, raw_path)
        if not self.is_editable_path(relative):
            raise WorkspaceError("Dieser Dateityp ist nicht im Code-Editor freigegeben.")
        data = content.encode("utf-8")
        if len(data) > self.MAX_EDITABLE_BYTES:
            raise WorkspaceError("Eine editierbare Datei darf maximal 2 MB groß sein.")
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(f".{path.name}.jarvis-tmp")
        temporary.write_bytes(data)
        temporary.replace(path)
        metadata = self._metadata(workspace_id)
        self._save_metadata(workspace_id, metadata)
        return self.read_text(workspace_id, relative)

    def delete_path(self, workspace_id: str, raw_path: str) -> bool:
        project = self._project_root(workspace_id)
        relative, path = self._safe_join(project, raw_path)
        if self.is_sensitive_path(relative):
            raise WorkspaceError("Sensible Dateien werden nicht über den Editor gelöscht.")
        if not path.exists() or path.is_symlink():
            return False
        if path.is_dir():
            shutil.rmtree(path)
        else:
            path.unlink()
        self._save_metadata(workspace_id, self._metadata(workspace_id))
        return True

    def rename_path(self, workspace_id: str, source_path: str, target_path: str) -> dict[str, str]:
        project = self._project_root(workspace_id)
        source_relative, source = self._safe_join(project, source_path)
        target_relative, target = self._safe_join(project, target_path)
        if self.is_sensitive_path(source_relative) or self.is_sensitive_path(target_relative):
            raise WorkspaceError("Sensible Dateien werden nicht über den Editor umbenannt.")
        if not source.exists() or source.is_symlink():
            raise WorkspaceError("Quellpfad wurde nicht gefunden.")
        if target.exists():
            raise WorkspaceError("Der Zielpfad existiert bereits.")
        target.parent.mkdir(parents=True, exist_ok=True)
        source.replace(target)
        self._save_metadata(workspace_id, self._metadata(workspace_id))
        return {"source": source_relative, "target": target_relative}

    def create_snapshot(self, workspace_id: str, *, label: str = "Manuell") -> dict[str, Any]:
        with self._lock:
            workspace = self._workspace_root(workspace_id)
            project = self._project_root(workspace_id)
            snapshot_id = secrets.token_urlsafe(12)
            snapshot_root = workspace / "snapshots" / snapshot_id
            shutil.copytree(project, snapshot_root, symlinks=False)
            metadata = self._metadata(workspace_id)
            snapshots = list(metadata.get("snapshots", []))
            item = {"id": snapshot_id, "label": self._clean_project_name(label), "created_at": self._now()}
            snapshots.append(item)
            while len(snapshots) > self.MAX_SNAPSHOTS:
                removed = snapshots.pop(0)
                shutil.rmtree(workspace / "snapshots" / str(removed.get("id", "")), ignore_errors=True)
            metadata["snapshots"] = snapshots
            self._save_metadata(workspace_id, metadata)
            return item

    def restore_snapshot(self, workspace_id: str, snapshot_id: str) -> dict[str, Any]:
        with self._lock:
            if not self.ID_PATTERN.fullmatch(snapshot_id):
                raise WorkspaceError("Ungültige Snapshot-ID.")
            workspace = self._workspace_root(workspace_id)
            source = workspace / "snapshots" / snapshot_id
            if not source.is_dir():
                raise WorkspaceError("Snapshot wurde nicht gefunden.")
            safety = self.create_snapshot(workspace_id, label="Vor Wiederherstellung")
            project = workspace / "project"
            replacement = workspace / ".restore-project"
            shutil.rmtree(replacement, ignore_errors=True)
            shutil.copytree(source, replacement, symlinks=False)
            shutil.rmtree(project)
            replacement.replace(project)
            self._save_metadata(workspace_id, self._metadata(workspace_id))
            return {"ok": True, "restored_snapshot_id": snapshot_id, "safety_snapshot": safety}

    @staticmethod
    def _file_hash(path: Path) -> str:
        if not path.is_file():
            return "missing"
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
        return digest.hexdigest()

    @staticmethod
    def _unified_diff(path: str, before: str, after: str) -> str:
        return "".join(
            difflib.unified_diff(
                before.splitlines(keepends=True),
                after.splitlines(keepends=True),
                fromfile=f"a/{path}",
                tofile=f"b/{path}",
                n=3,
            )
        )[:250_000]

    def diff_from_snapshot(self, workspace_id: str, snapshot_id: str | None = None) -> dict[str, Any]:
        workspace = self._workspace_root(workspace_id)
        metadata = self._metadata(workspace_id)
        selected = snapshot_id or str(metadata.get("baseline_snapshot_id", ""))
        if not self.ID_PATTERN.fullmatch(selected):
            raise WorkspaceError("Vergleichs-Snapshot fehlt.")
        before_root = workspace / "snapshots" / selected
        if not before_root.is_dir():
            raise WorkspaceError("Vergleichs-Snapshot wurde nicht gefunden.")
        project = self._project_root(workspace_id)
        before = {path.relative_to(before_root).as_posix(): path for path in before_root.rglob("*") if path.is_file()}
        after = {path.relative_to(project).as_posix(): path for path in project.rglob("*") if path.is_file()}
        changes: list[dict[str, Any]] = []
        for relative in sorted(set(before) | set(after), key=str.casefold):
            old = before.get(relative)
            new = after.get(relative)
            if old and new and self._file_hash(old) == self._file_hash(new):
                continue
            status = "modified" if old and new else "added" if new else "deleted"
            diff = ""
            if not self.is_sensitive_path(relative) and self.is_editable_path(relative):
                try:
                    old_text = old.read_text(encoding="utf-8") if old else ""
                    new_text = new.read_text(encoding="utf-8") if new else ""
                    if len(old_text.encode("utf-8")) <= self.MAX_EDITABLE_BYTES and len(new_text.encode("utf-8")) <= self.MAX_EDITABLE_BYTES:
                        diff = self._unified_diff(relative, old_text, new_text)
                except UnicodeDecodeError:
                    pass
            changes.append({"path": relative, "status": status, "diff": diff, "sensitive": self.is_sensitive_path(relative)})
        return {"snapshot_id": selected, "changes": changes, "count": len(changes)}

    def collect_ai_files(self, workspace_id: str) -> dict[str, Any]:
        included: list[dict[str, str]] = []
        skipped: list[str] = []
        total = 0
        for relative, path in self._project_files(workspace_id):
            if self.is_sensitive_path(relative) or not self.is_editable_path(relative):
                skipped.append(relative)
                continue
            try:
                data = path.read_bytes()
                content = data.decode("utf-8")
            except (OSError, UnicodeDecodeError):
                skipped.append(relative)
                continue
            if len(data) > self.MAX_EDITABLE_BYTES or len(included) >= self.MAX_AI_FILES or total + len(data) > self.MAX_AI_BYTES:
                skipped.append(relative)
                continue
            included.append({"path": relative, "content": content})
            total += len(data)
        if not included:
            raise WorkspaceError("Der Workspace enthält keine sicheren UTF-8-Dateien für die KI-Analyse.")
        return {"files": included, "skipped": skipped, "total_bytes": total}

    def create_proposal(
        self,
        workspace_id: str,
        *,
        instruction: str,
        summary: str,
        changes: object,
        model: str,
    ) -> dict[str, Any]:
        if not isinstance(changes, list) or len(changes) > 30:
            raise WorkspaceError("Der KI-Vorschlag enthält zu viele oder ungültige Änderungen.")
        project = self._project_root(workspace_id)
        normalized: list[dict[str, Any]] = []
        total = 0
        seen: set[str] = set()
        for raw in changes:
            if not isinstance(raw, dict):
                raise WorkspaceError("Der KI-Vorschlag ist ungültig.")
            relative, path = self._safe_join(project, str(raw.get("path", "")))
            if relative.casefold() in seen:
                raise WorkspaceError(f"Doppelte KI-Änderung: {relative}")
            seen.add(relative.casefold())
            if not self.is_editable_path(relative):
                raise WorkspaceError(f"KI-Änderung an nicht freigegebener Datei: {relative}")
            action = str(raw.get("action", "upsert"))
            if action not in {"upsert", "delete"}:
                raise WorkspaceError(f"Ungültige KI-Aktion für {relative}.")
            content = str(raw.get("content", "")) if action == "upsert" else ""
            encoded = content.encode("utf-8")
            total += len(encoded)
            if len(encoded) > self.MAX_EDITABLE_BYTES or total > self.MAX_PROPOSAL_BYTES:
                raise WorkspaceError("Der KI-Vorschlag ist zu groß.")
            before = ""
            if path.is_file():
                try:
                    before = path.read_text(encoding="utf-8")
                except UnicodeDecodeError as exc:
                    raise WorkspaceError(f"Bestehende Datei ist nicht als UTF-8 editierbar: {relative}") from exc
            normalized.append(
                {
                    "path": relative,
                    "action": action,
                    "content": content,
                    "base_hash": self._file_hash(path),
                    "diff": self._unified_diff(relative, before, content if action == "upsert" else ""),
                }
            )
        if not normalized:
            raise WorkspaceError("Die KI hat keine Dateiänderung vorgeschlagen.")
        proposal_id = secrets.token_urlsafe(18)
        payload = {
            "id": proposal_id,
            "workspace_id": workspace_id,
            "instruction": " ".join(instruction.split())[:20_000],
            "summary": " ".join(summary.split())[:4_000],
            "model": model[:120],
            "status": "pending",
            "created_at": self._now(),
            "changes": normalized,
        }
        self._atomic_json(self._workspace_root(workspace_id) / "proposals" / f"{proposal_id}.json", payload)
        proposal_paths = sorted((self._workspace_root(workspace_id) / "proposals").glob("*.json"), key=lambda item: item.stat().st_mtime)
        while len(proposal_paths) > 10:
            proposal_paths.pop(0).unlink(missing_ok=True)
        return payload

    def get_proposal(self, workspace_id: str, proposal_id: str) -> dict[str, Any]:
        if not self.ID_PATTERN.fullmatch(proposal_id):
            raise WorkspaceError("Ungültige Vorschlags-ID.")
        path = self._workspace_root(workspace_id) / "proposals" / f"{proposal_id}.json"
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise WorkspaceError("Änderungsvorschlag wurde nicht gefunden.") from exc
        if not isinstance(payload, dict) or payload.get("workspace_id") != workspace_id:
            raise WorkspaceError("Änderungsvorschlag ist ungültig.")
        return payload

    def apply_proposal(self, workspace_id: str, proposal_id: str) -> dict[str, Any]:
        with self._lock:
            proposal = self.get_proposal(workspace_id, proposal_id)
            if proposal.get("status") != "pending":
                raise WorkspaceError("Dieser Vorschlag wurde bereits verarbeitet.")
            project = self._project_root(workspace_id)
            for change in proposal.get("changes", []):
                _, path = self._safe_join(project, str(change.get("path", "")))
                if self._file_hash(path) != change.get("base_hash"):
                    raise WorkspaceError(f"Datei wurde seit dem Vorschlag verändert: {change.get('path')}")
            snapshot = self.create_snapshot(workspace_id, label="Vor KI-Änderung")
            for change in proposal.get("changes", []):
                _, path = self._safe_join(project, str(change["path"]))
                if change["action"] == "delete":
                    path.unlink(missing_ok=True)
                else:
                    path.parent.mkdir(parents=True, exist_ok=True)
                    temporary = path.with_name(f".{path.name}.jarvis-tmp")
                    temporary.write_text(str(change["content"]), encoding="utf-8")
                    temporary.replace(path)
            proposal["status"] = "applied"
            proposal["applied_at"] = self._now()
            proposal["safety_snapshot_id"] = snapshot["id"]
            self._atomic_json(self._workspace_root(workspace_id) / "proposals" / f"{proposal_id}.json", proposal)
            self._save_metadata(workspace_id, self._metadata(workspace_id))
            return proposal

    def run_safe_checks(self, workspace_id: str) -> dict[str, Any]:
        results: list[dict[str, Any]] = []
        checked = 0
        for relative, path in self._project_files(workspace_id):
            suffix = PurePosixPath(relative).suffix.casefold()
            if self.is_sensitive_path(relative) or not self.is_editable_path(relative):
                continue
            try:
                text = path.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                continue
            try:
                if suffix == ".py":
                    ast.parse(text, filename=relative)
                elif suffix == ".json":
                    json.loads(text)
                elif suffix == ".toml":
                    tomllib.loads(text)
                elif suffix in {".xml", ".svg"}:
                    ElementTree.fromstring(text)
                elif suffix in {".html", ".htm"}:
                    parser = _StrictHtmlParser()
                    parser.feed(text)
                    parser.close()
                elif suffix in {".css", ".scss"}:
                    if text.count("{") != text.count("}"):
                        raise ValueError("Anzahl der geschweiften Klammern stimmt nicht überein")
                else:
                    continue
                results.append({"path": relative, "ok": True, "message": "Syntax plausibel"})
            except (SyntaxError, ValueError, tomllib.TOMLDecodeError, ElementTree.ParseError) as exc:
                results.append({"path": relative, "ok": False, "message": str(exc)[:500]})
            checked += 1
        failures = [item for item in results if not item["ok"]]
        return {
            "ok": not failures,
            "checked": checked,
            "failures": len(failures),
            "results": results,
            "execution_policy": "static-only",
            "message": "Projektcode wurde nicht ausgeführt.",
        }

    def export_zip(self, workspace_id: str) -> bytes:
        project = self._project_root(workspace_id)
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for relative, path in self._project_files(workspace_id):
                archive.write(path, relative)
            for directory in sorted((item for item in project.rglob("*") if item.is_dir()), key=lambda item: item.as_posix()):
                if not any(directory.iterdir()):
                    archive.writestr(directory.relative_to(project).as_posix().rstrip("/") + "/", b"")
        data = buffer.getvalue()
        if len(data) > self.MAX_ARCHIVE_BYTES * 2:
            raise WorkspaceError("Das exportierte Projekt-ZIP ist zu groß.")
        return data

    def delete_workspace(self, workspace_id: str) -> bool:
        with self._lock:
            path = self._workspace_root(workspace_id)
            shutil.rmtree(path)
            return True

    def stats(self) -> dict[str, int]:
        items = self.list_workspaces()
        return {
            "workspaces": len(items),
            "files": sum(int(item.get("file_count", 0)) for item in items),
            "bytes": sum(int(item.get("total_bytes", 0)) for item in items),
        }
