from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import stat
import sys
import tempfile
import urllib.error
import urllib.request
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any


APP_VERSION = "15.1.0"
DEFAULT_MANIFEST_URL = "https://raw.githubusercontent.com/Tunfisch77/JARVIS-Updates/main/manifest.json"
PROTECTED_TOP_LEVEL = {".env", ".venv", "data", ".update_backups", ".installed_version", ".update.lock"}
MAX_DOWNLOAD_BYTES = 250 * 1024 * 1024


class UpdateError(RuntimeError):
    pass


def _status(message: str) -> None:
    print(f"[JARVIS UPDATE] {message}", flush=True)


def _version_tuple(value: str) -> tuple[int, ...]:
    if not re.fullmatch(r"v?\d+\.\d+\.\d+", value.strip()):
        raise UpdateError(f"Ungültige Versionsnummer: {value}")
    try:
        return tuple(int(part) for part in value.strip().lstrip("v").split("."))
    except ValueError as exc:
        raise UpdateError(f"Ungültige Versionsnummer: {value}") from exc


def _download(url: str, destination: Path) -> int:
    request = urllib.request.Request(url, headers={"User-Agent": f"JARVIS-Updater/{APP_VERSION}"})
    try:
        with urllib.request.urlopen(request, timeout=30) as response, destination.open("wb") as output:
            total = 0
            while chunk := response.read(1024 * 1024):
                total += len(chunk)
                if total > MAX_DOWNLOAD_BYTES:
                    raise UpdateError("Das Update ist unerwartet groß und wurde abgebrochen.")
                output.write(chunk)
            return total
    except (OSError, urllib.error.URLError) as exc:
        raise UpdateError(f"Download fehlgeschlagen: {exc}") from exc


def _load_manifest(source: str, temporary_directory: Path) -> tuple[dict[str, Any], str]:
    if source.startswith(("https://", "http://")):
        manifest_file = temporary_directory / "manifest.json"
        _download(source, manifest_file)
        base_url = source.rsplit("/", 1)[0] + "/"
    else:
        manifest_file = Path(source).resolve()
        base_url = manifest_file.parent.as_uri() + "/"
    try:
        manifest = json.loads(manifest_file.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise UpdateError("Das Update-Manifest ist nicht lesbar oder ungültig.") from exc
    if manifest.get("format") != "jarvis-update-v1":
        raise UpdateError("Das Update-Manifest hat ein unbekanntes Format.")
    return manifest, base_url


def _safe_members(archive: zipfile.ZipFile) -> list[zipfile.ZipInfo]:
    members: list[zipfile.ZipInfo] = []
    seen: set[str] = set()
    expanded = 0
    for info in archive.infolist():
        path = PurePosixPath(info.filename)
        if (path.is_absolute() or ".." in path.parts or not path.parts
                or "\\" in info.filename or ":" in info.filename
                or any(part.endswith((".", " ")) or part.split(".")[0].upper() in
                       {"CON", "PRN", "AUX", "NUL", *[f"COM{i}" for i in range(1, 10)],
                        *[f"LPT{i}" for i in range(1, 10)]} for part in path.parts)):
            raise UpdateError("Das Update enthält einen unsicheren Dateipfad.")
        key = str(path).casefold()
        if key in seen:
            raise UpdateError("Das Update enthält doppelte Dateipfade.")
        seen.add(key)
        expanded += info.file_size
        if expanded > MAX_DOWNLOAD_BYTES or len(seen) > 10000:
            raise UpdateError("Das entpackte Update ist unerwartet groß.")
        if path.parts and path.parts[0].lower() in PROTECTED_TOP_LEVEL:
            raise UpdateError(f"Das Update versucht geschützte Daten zu ändern: {path.parts[0]}")
        mode = info.external_attr >> 16
        if stat.S_ISLNK(mode):
            raise UpdateError("Das Update enthält einen nicht erlaubten symbolischen Link.")
        members.append(info)
    return members


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _copy_snapshot(app_directory: Path, backup_directory: Path, changed: list[str]) -> None:
    for relative in changed:
        source = app_directory / relative
        if source.is_file():
            target = backup_directory / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)


def _same_file(first: Path, second: Path) -> bool:
    if not first.is_file() or not second.is_file():
        return False
    try:
        return first.stat().st_size == second.stat().st_size and _sha256(first) == _sha256(second)
    except OSError:
        return False


def _installed_version(app_directory: Path) -> str:
    versions = [APP_VERSION]
    marker = app_directory / ".installed_version"
    try:
        value = marker.read_text(encoding="ascii").strip()
        _version_tuple(value)
        versions.append(value)
    except (OSError, UpdateError, UnicodeError):
        pass
    return max(versions, key=_version_tuple)


def _validate_staged_package(stage: Path, manifest: dict[str, Any]) -> None:
    required = manifest.get("required_files")
    if isinstance(required, list):
        for item in required:
            relative = PurePosixPath(str(item))
            if relative.is_absolute() or ".." in relative.parts or not (stage / relative).is_file():
                raise UpdateError(f"Im Update fehlt eine notwendige Datei: {item}")
    markers = manifest.get("version_markers")
    if isinstance(markers, dict):
        for name, marker in markers.items():
            relative = PurePosixPath(str(name))
            path = stage / relative
            if relative.is_absolute() or ".." in relative.parts or not path.is_file():
                raise UpdateError(f"Versionsprüfung nicht möglich: {name}")
            try:
                content = path.read_text(encoding="utf-8")
            except (OSError, UnicodeError) as exc:
                raise UpdateError(f"Versionsprüfung nicht möglich: {name}") from exc
            if str(marker) not in content:
                raise UpdateError(f"Die Datei {name} gehört nicht zur angekündigten Version.")


def install_update(app_directory: Path, manifest_source: str, *, check_only: bool = False) -> dict[str, Any]:
    app_directory = app_directory.resolve()
    lock = app_directory / ".update.lock"
    try:
        handle = lock.open("x")
    except FileExistsError as exc:
        raise UpdateError("Ein Update läuft bereits. Bei einem abgebrochenen Update JARVIS schließen und .update.lock entfernen.") from exc
    try:
        handle.write(str(os.getpid()))
        handle.close()
        return _install_update(app_directory, manifest_source, check_only=check_only)
    except (OSError, zipfile.BadZipFile, RuntimeError) as exc:
        if isinstance(exc, UpdateError):
            raise
        raise UpdateError(f"Update fehlgeschlagen: {exc}") from exc
    finally:
        handle.close()
        lock.unlink(missing_ok=True)


def _install_update(app_directory: Path, manifest_source: str, *, check_only: bool = False) -> dict[str, Any]:
    with tempfile.TemporaryDirectory(prefix="jarvis-update-") as raw_temp:
        temporary = Path(raw_temp)
        _status("Manifest wird geladen ...")
        manifest, base_url = _load_manifest(manifest_source, temporary)
        latest = str(manifest.get("version", ""))
        current = _installed_version(app_directory)
        if _version_tuple(latest) <= _version_tuple(current):
            return {"updated": False, "version": current, "message": f"JARVIS v{current} ist bereits aktuell."}
        package = manifest.get("package")
        expected_hash = str(manifest.get("sha256", "")).lower()
        if not package or len(expected_hash) != 64:
            raise UpdateError("Im Manifest fehlen Paketname oder SHA-256-Prüfsumme.")
        if check_only:
            return {"updated": False, "available": True, "version": latest, "current_version": current}

        _status(f"Update v{current} -> v{latest} gefunden.")
        package_file = temporary / "update.zip"
        package_source = str(package)
        if not package_source.startswith(("https://", "http://")):
            package_source = base_url + package_source
        if package_source.startswith("file:"):
            from urllib.parse import unquote, urlparse
            shutil.copy2(Path(unquote(urlparse(package_source).path)), package_file)
            downloaded = package_file.stat().st_size
        else:
            _status("Programmpaket wird heruntergeladen ...")
            downloaded = _download(package_source, package_file)
        expected_size = manifest.get("size_bytes")
        if isinstance(expected_size, int) and downloaded != expected_size:
            raise UpdateError(
                f"Die Paketgröße stimmt nicht ({downloaded} statt {expected_size} Bytes)."
            )
        _status(f"{downloaded:,} Bytes geladen. SHA-256 wird geprüft ...")
        if _sha256(package_file) != expected_hash:
            raise UpdateError("Die Prüfsumme stimmt nicht. Das Update wurde nicht installiert.")

        stage = temporary / "stage"
        with zipfile.ZipFile(package_file) as archive:
            members = _safe_members(archive)
            archive.extractall(stage, members=members)
        _validate_staged_package(stage, manifest)
        packaged = [info.filename.rstrip("/") for info in members if not info.is_dir()]
        changed = [
            relative
            for relative in packaged
            if not _same_file(stage / relative, app_directory / relative)
        ]
        for relative in packaged:
            target = app_directory / relative
            if not target.resolve().is_relative_to(app_directory):
                raise UpdateError("Ein Installationspfad zeigt außerhalb des JARVIS-Ordners.")
            if any(part.is_symlink() for part in [target, *target.parents] if part != app_directory):
                raise UpdateError("Ein Installationspfad enthält einen symbolischen Link.")
        if not changed:
            raise UpdateError("Das angekündigte Update enthält keine neuen Programmdateien.")
        _status(f"{len(changed)} geänderte Programmdatei(en) werden installiert ...")
        backup = app_directory / ".update_backups" / current
        if backup.exists():
            shutil.rmtree(backup)
        _copy_snapshot(app_directory, backup, changed)
        applied: list[Path] = []
        temporary_targets: list[Path] = []
        marker = app_directory / ".installed_version"
        try:
            for relative in changed:
                source = stage / relative
                target = app_directory / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                temporary_target = target.with_name(target.name + ".update-new")
                temporary_targets.append(temporary_target)
                shutil.copy2(source, temporary_target)
                os.replace(temporary_target, target)
                applied.append(target)
                if not _same_file(source, target):
                    raise OSError(f"Dateiprüfung fehlgeschlagen: {relative}")
            marker_temp = marker.with_name(marker.name + ".update-new")
            temporary_targets.append(marker_temp)
            marker_temp.write_text(latest, encoding="ascii")
            os.replace(marker_temp, marker)
        except OSError as exc:
            for target in reversed(applied):
                relative = target.relative_to(app_directory)
                old = backup / relative
                if old.exists():
                    shutil.copy2(old, target)
                else:
                    target.unlink(missing_ok=True)
            raise UpdateError("Installation fehlgeschlagen; der alte Stand wurde wiederhergestellt.") from exc
        finally:
            for temporary_target in temporary_targets:
                temporary_target.unlink(missing_ok=True)
        _status(f"Installation verifiziert: JARVIS v{latest}.")
        return {
            "updated": True,
            "version": latest,
            "previous_version": current,
            "files": len(changed),
            "packaged_files": len(packaged),
            "download_bytes": downloaded,
            "backup": str(backup),
        }


def configured_manifest(app_directory: Path) -> str:
    environment = os.getenv("JARVIS_UPDATE_MANIFEST_URL", "").strip()
    if environment:
        return environment
    config_file = app_directory / "update_config.json"
    if config_file.exists():
        try:
            return str(json.loads(config_file.read_text(encoding="utf-8")).get("manifest_url") or "").strip() or DEFAULT_MANIFEST_URL
        except (OSError, json.JSONDecodeError):
            pass
    return DEFAULT_MANIFEST_URL


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", default="")
    parser.add_argument("--check", action="store_true")
    arguments = parser.parse_args()
    app_directory = Path(__file__).resolve().parent
    manifest = arguments.manifest or configured_manifest(app_directory)
    if not manifest:
        print("UPDATE NOCH NICHT VERBUNDEN")
        print("In update_config.json fehlt die feste Download-Adresse.")
        return 2
    try:
        result = install_update(app_directory, manifest, check_only=arguments.check)
    except UpdateError as exc:
        print(f"UPDATE-FEHLER: {exc}")
        return 1
    if "message" in result:
        print(result["message"])
    elif result.get("updated"):
        print(
            f"UPDATE ERFOLGREICH: JARVIS v{result['version']} "
            f"({result['files']} Programmdateien installiert)."
        )
    else:
        print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
