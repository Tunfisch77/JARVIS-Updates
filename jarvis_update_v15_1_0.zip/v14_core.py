from __future__ import annotations

import re
import unicodedata
from datetime import UTC, datetime
from typing import Any, Final, Iterable


COMMUNICATION_SOURCES: Final = ("whatsapp", "gmail", "outlook", "snapchat")
COMMUNICATION_PRIORITIES: Final = ("urgent", "important", "normal")

_PRIORITY_RANK: Final = {"urgent": 3, "important": 2, "normal": 1}
_URGENT_SIGNALS: Final = (
    ("notfall", 8, "Notfall"),
    ("dringend", 6, "Dringend"),
    ("sofort", 5, "Sofort"),
    ("frist", 5, "Frist"),
    ("deadline", 5, "Deadline"),
    ("heute", 3, "Heute"),
    ("ruckruf", 3, "Rückruf"),
    ("prufung", 3, "Prüfung"),
    ("bewerbung", 3, "Bewerbung"),
    ("rechnung", 3, "Rechnung"),
    ("zahlung", 3, "Zahlung"),
    ("termin", 2, "Termin"),
    ("wichtig", 2, "Als wichtig bezeichnet"),
)
_LOW_PRIORITY_SIGNALS: Final = (
    "newsletter",
    "werbung",
    "angebot",
    "unsubscribe",
    "abmelden",
    "no reply",
    "noreply",
    "automatische antwort",
)
_TRUSTED_RELATION_SIGNALS: Final = (
    "familie",
    "mutter",
    "vater",
    "eltern",
    "bruder",
    "schwester",
    "partner",
    "freund",
    "freundin",
    "schule",
    "lehrer",
    "arbeit",
    "chef",
)


def normalize_text(value: object) -> str:
    decomposed = unicodedata.normalize("NFKD", str(value or "").casefold())
    without_marks = "".join(
        character for character in decomposed if not unicodedata.combining(character)
    )
    return " ".join(re.findall(r"[^\W_]+", without_marks, flags=re.UNICODE))


def _parse_received_at(value: object) -> datetime | None:
    raw = str(value or "").strip()
    if not raw:
        return None
    try:
        parsed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def _message_identity_values(message: dict[str, Any]) -> set[str]:
    return {
        normalized
        for normalized in (
            normalize_text(message.get("sender_name")),
            normalize_text(message.get("sender_address")),
            normalize_text(message.get("conversation")),
        )
        if normalized
    }


def _contact_priority_context(
    message: dict[str, Any],
    contacts: Iterable[dict[str, Any]],
) -> tuple[int, list[str]]:
    message_identities = _message_identity_values(message)
    if not message_identities:
        return 0, []
    for contact in contacts:
        aliases = contact.get("aliases") if isinstance(contact.get("aliases"), list) else []
        contact_values = {
            normalize_text(value)
            for value in (
                contact.get("name"),
                contact.get("email"),
                contact.get("whatsapp_number"),
                contact.get("whatsapp_chat_name"),
                *aliases,
            )
            if str(value or "").strip()
        }
        if not any(
            left == right or left in right or right in left
            for left in message_identities
            for right in contact_values
        ):
            continue
        relationship = normalize_text(
            f"{contact.get('relationship', '')} {contact.get('organization', '')}"
        )
        if any(signal in relationship for signal in _TRUSTED_RELATION_SIGNALS):
            return 3, ["Wichtiger Kontakt"]
        return 1, ["Gespeicherter Kontakt"]
    return 0, []


def message_thread_key(message: dict[str, Any]) -> str:
    source = str(message.get("source") or "unknown").casefold()
    identity = (
        normalize_text(message.get("conversation"))
        or normalize_text(message.get("sender_address"))
        or normalize_text(message.get("sender_name"))
        or str(message.get("id") or "unknown")
    )
    return f"{source}:{identity}"


def classify_message(
    message: dict[str, Any],
    *,
    contacts: Iterable[dict[str, Any]] = (),
    now: datetime | None = None,
) -> dict[str, Any]:
    current = (now or datetime.now(UTC)).astimezone(UTC)
    score = 0
    reasons: list[str] = []
    unread = bool(message.get("unread"))
    if unread:
        score += 2
        reasons.append("Ungelesen")
    if message.get("replied"):
        score -= 2

    contact_score, contact_reasons = _contact_priority_context(message, contacts)
    score += contact_score
    reasons.extend(contact_reasons)

    searchable = normalize_text(
        " ".join(
            str(message.get(key) or "")
            for key in ("sender_name", "sender_address", "conversation", "subject", "preview", "body")
        )
    )
    for signal, weight, label in _URGENT_SIGNALS:
        if signal in searchable:
            score += weight
            reasons.append(label)
    if "?" in str(message.get("preview") or message.get("body") or ""):
        score += 1
        reasons.append("Direkte Frage")
    if any(signal in searchable for signal in _LOW_PRIORITY_SIGNALS):
        score -= 4
        reasons.append("Automatischer oder werblicher Inhalt")

    received = _parse_received_at(message.get("received_at"))
    if received:
        age_hours = max(0.0, (current - received).total_seconds() / 3_600)
        if age_hours <= 6:
            score += 2
            reasons.append("Sehr aktuell")
        elif age_hours <= 24:
            score += 1
            reasons.append("Heute eingegangen")
        elif age_hours >= 24 * 7:
            score -= 2

    if score >= 10:
        priority = "urgent"
        priority_label = "DRINGEND"
    elif score >= 5:
        priority = "important"
        priority_label = "WICHTIG"
    else:
        priority = "normal"
        priority_label = "NORMAL"

    enriched = dict(message)
    enriched.update(
        {
            "priority": priority,
            "priority_label": priority_label,
            "priority_score": score,
            "priority_reasons": list(dict.fromkeys(reasons))[:5],
            "thread_key": message_thread_key(message),
            "needs_attention": bool(
                unread and (priority in {"urgent", "important"} or "Direkte Frage" in reasons)
            ),
        }
    )
    return enriched


def _matches_query(message: dict[str, Any], query: str) -> bool:
    wanted = normalize_text(query)
    if not wanted:
        return True
    haystack = normalize_text(
        " ".join(
            str(message.get(key) or "")
            for key in (
                "sender_name",
                "sender_address",
                "conversation",
                "subject",
                "preview",
                "body",
            )
        )
    )
    return all(token in haystack for token in wanted.split())


def _sort_timestamp(message: dict[str, Any]) -> float:
    parsed = _parse_received_at(message.get("received_at"))
    return parsed.timestamp() if parsed else 0.0


def build_communication_hub(
    messages: Iterable[dict[str, Any]],
    *,
    contacts: Iterable[dict[str, Any]] = (),
    connections: Iterable[dict[str, Any]] = (),
    sources: Iterable[str] = (),
    priority: str = "all",
    unread_only: bool = False,
    query: str = "",
    limit: int = 100,
    now: datetime | None = None,
) -> dict[str, Any]:
    selected_sources = {
        str(source).casefold()
        for source in sources
        if str(source).casefold() in COMMUNICATION_SOURCES
    }
    wanted_priority = str(priority or "all").casefold()
    if wanted_priority not in {"all", *COMMUNICATION_PRIORITIES}:
        raise ValueError("Unbekannter Prioritätsfilter.")

    contact_list = list(contacts)
    enriched = [
        classify_message(message, contacts=contact_list, now=now)
        for message in messages
        if not selected_sources
        or str(message.get("source") or "").casefold() in selected_sources
    ]
    filtered = [
        message
        for message in enriched
        if (not unread_only or bool(message.get("unread")))
        and (wanted_priority == "all" or message.get("priority") == wanted_priority)
        and _matches_query(message, query)
    ]
    filtered.sort(
        key=lambda message: (
            _PRIORITY_RANK.get(str(message.get("priority")), 0),
            int(bool(message.get("unread"))),
            _sort_timestamp(message),
            int(message.get("id") or 0),
        ),
        reverse=True,
    )
    page = filtered[: max(1, min(200, int(limit)))]

    by_source = {source: 0 for source in COMMUNICATION_SOURCES}
    unread_by_source = {source: 0 for source in COMMUNICATION_SOURCES}
    by_priority = {name: 0 for name in COMMUNICATION_PRIORITIES}
    unread_by_priority = {name: 0 for name in COMMUNICATION_PRIORITIES}
    unread = 0
    attention = 0
    thread_ids: set[str] = set()
    for message in enriched:
        source = str(message.get("source") or "")
        if source in by_source:
            by_source[source] += 1
            if bool(message.get("unread")):
                unread_by_source[source] += 1
        message_priority = str(message.get("priority") or "normal")
        if message_priority in by_priority:
            by_priority[message_priority] += 1
            if bool(message.get("unread")):
                unread_by_priority[message_priority] += 1
        unread += int(bool(message.get("unread")))
        attention += int(bool(message.get("needs_attention")))
        thread_ids.add(str(message.get("thread_key") or ""))

    connection_items = [dict(item) for item in connections]
    connected = sum(bool(item.get("connected")) for item in connection_items)
    digest = communication_digest(enriched)
    return {
        "version": "14.0.0",
        "items": page,
        "count": len(page),
        "matched": len(filtered),
        "summary": {
            "total": len(enriched),
            "unread": unread,
            "attention": attention,
            "threads": len(thread_ids),
            "by_source": by_source,
            "unread_by_source": unread_by_source,
            "by_priority": by_priority,
            "unread_by_priority": unread_by_priority,
            "connected_sources": connected,
            "configured_sources": len(connection_items),
        },
        "connections": connection_items,
        "digest": digest,
        "filters": {
            "sources": sorted(selected_sources),
            "priority": wanted_priority,
            "unread_only": unread_only,
            "query": query,
        },
    }


def communication_digest(messages: Iterable[dict[str, Any]]) -> dict[str, Any]:
    items = [dict(message) for message in messages]
    unread = [message for message in items if bool(message.get("unread"))]
    urgent = [message for message in unread if message.get("priority") == "urgent"]
    important = [message for message in unread if message.get("priority") == "important"]
    attention = [message for message in unread if bool(message.get("needs_attention"))]
    attention.sort(
        key=lambda message: (
            _PRIORITY_RANK.get(str(message.get("priority")), 0),
            _sort_timestamp(message),
        ),
        reverse=True,
    )
    top_items = [
        {
            "id": item.get("id"),
            "source": item.get("source"),
            "sender_name": item.get("sender_name"),
            "subject": item.get("subject"),
            "priority": item.get("priority"),
            "received_at": item.get("received_at"),
        }
        for item in attention[:5]
    ]
    if not unread:
        text = "Keine ungelesenen Nachrichten."
    elif urgent:
        text = (
            f"{len(unread)} ungelesen. {len(urgent)} davon dringend"
            f" und {len(important)} wichtig. Zuerst: "
            f"{str(urgent[0].get('sender_name') or 'unbekannter Absender')}."
        )
    elif important:
        text = (
            f"{len(unread)} ungelesen. {len(important)} davon wichtig. Zuerst: "
            f"{str(important[0].get('sender_name') or 'unbekannter Absender')}."
        )
    else:
        text = f"{len(unread)} ungelesene Nachrichten, aktuell keine als dringend eingestuft."
    return {
        "text": text,
        "unread": len(unread),
        "urgent": len(urgent),
        "important": len(important),
        "attention": len(attention),
        "top_items": top_items,
    }


def local_reply_draft(
    message: dict[str, Any],
    *,
    tone: str = "auto",
    instruction: str = "",
) -> str:
    requested = " ".join(str(instruction or "").split())
    if requested:
        return requested[:4_000]
    sender = " ".join(str(message.get("sender_name") or "").split())
    first_name = sender.split()[0] if sender else ""
    selected_tone = str(tone or "auto").casefold()
    if selected_tone == "formal" or (
        selected_tone == "auto" and str(message.get("source") or "") in {"gmail", "outlook"}
    ):
        return (
            "Guten Tag,\n\nvielen Dank für Ihre Nachricht. Ich habe sie erhalten "
            "und melde mich so bald wie möglich mit einer Rückmeldung.\n\nFreundliche Grüße"
        )
    if selected_tone == "short":
        return f"Danke{f', {first_name}' if first_name else ''}! Ich melde mich so bald wie möglich."
    greeting = f"Hey {first_name}" if first_name else "Hey"
    return (
        f"{greeting}, danke für deine Nachricht. Ich habe sie gesehen "
        "und melde mich so bald wie möglich."
    )
