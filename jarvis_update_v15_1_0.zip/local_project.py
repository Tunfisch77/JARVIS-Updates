from __future__ import annotations

import ast
import hashlib
import json
import os
import re
import secrets
import shutil
import threading
import tomllib
from datetime import UTC, datetime
from html.parser import HTMLParser
from pathlib import Path, PurePosixPath
from typing import Any
from xml.etree import ElementTree

from code_workspace import CodeWorkspaceManager


class LocalProjectError(ValueError):
    pass


class _StrictHtmlParser(HTMLParser):
    def error(self, message: str) -> None:  # pragma: no cover - compatibility with old Python
        raise LocalProjectError(message)


class LocalProjectManager:
    """Safely edit a real project folder after JARVIS created or selected it."""

    MAX_FILES = 80
    MAX_AI_BYTES = 3 * 1024 * 1024
    MAX_FILE_BYTES = 2 * 1024 * 1024
    MAX_CHANGE_BYTES = 10 * 1024 * 1024
    MAX_CHANGES = 40
    MAX_BACKUPS_PER_PROJECT = 10
    ACTIVE_SETTING = "active_code_project"
    SKIPPED_DIRECTORIES = {
        ".git",
        ".gradle",
        ".idea",
        ".mypy_cache",
        ".next",
        ".pytest_cache",
        ".tox",
        ".venv",
        ".vscode",
        "__pycache__",
        "build",
        "coverage",
        "dist",
        "node_modules",
        "target",
        "vendor",
        "venv",
    }
    EDITABLE_SUFFIXES = set(CodeWorkspaceManager.EDITABLE_SUFFIXES) | {".bat"}
    EDITABLE_NAMES = set(CodeWorkspaceManager.EDITABLE_NAMES)
    WINDOWS_RESERVED_NAMES = set(CodeWorkspaceManager.WINDOWS_RESERVED_NAMES)
    START_SCRIPT_HINT = re.compile(
        r"(?:\.bat\b|batch(?:datei)?\b|start(?:datei|skript)?\b)",
        flags=re.IGNORECASE,
    )
    SAFE_BATCH_LINES = (
        re.compile(r"^@?echo off$", re.IGNORECASE),
        re.compile(r"^echo [^&|<>^]{1,500}$", re.IGNORECASE),
        re.compile(r'^cd /d "%~dp0"$', re.IGNORECASE),
        re.compile(r"^(?:setlocal|endlocal|pause|popd)$", re.IGNORECASE),
        re.compile(r"^exit /b(?: 0)?$", re.IGNORECASE),
        re.compile(r'^(?:py(?: -3)?|python|"\.venv\\Scripts\\python\.exe") "[A-Za-z0-9ÄÖÜäöüß_ ./\\-]+\.py"$', re.IGNORECASE),
        re.compile(r'^(?:py(?: -3)?|python|"\.venv\\Scripts\\python\.exe") [A-Za-z0-9ÄÖÜäöüß_./\\-]+\.py$', re.IGNORECASE),
        re.compile(r"^npm (?:start|run [A-Za-z0-9:_-]+)$", re.IGNORECASE),
        re.compile(r'^node "?[A-Za-z0-9ÄÖÜäöüß_ ./\\-]+\.js"?$', re.IGNORECASE),
        re.compile(r'^start "" "?[A-Za-z0-9ÄÖÜäöüß_ ./\\-]+\.(?:html?|url)"?$', re.IGNORECASE),
        re.compile(r"^(?:rem\b.*|::.*)$", re.IGNORECASE),
    )

    def __init__(self, state_store: Any, backup_root: Path) -> None:
        self.state_store = state_store
        self.backup_root = backup_root
        self.backup_root.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()

    @staticmethod
    def _now() -> str:
        return datetime.now(UTC).isoformat(timespec="seconds")

    @classmethod
    def _safe_relative_path(cls, raw_path: str) -> str:
        value = str(raw_path or "").replace("\\", "/").strip().strip("/")
        if not value or len(value) > 500 or "\x00" in value:
            raise LocalProjectError("Die Änderung enthält einen ungültigen Projektpfad.")
        path = PurePosixPath(value)
        if path.is_absolute() or any(part in {"", ".", ".."} for part in path.parts):
            raise LocalProjectError("Ein Änderungspfad würde den Projektordner verlassen.")
        for part in path.parts:
            if (
                ":" in part
                or any(ord(char) < 32 for char in part)
                or part.endswith((" ", "."))
                or part.split(".", 1)[0].casefold() in cls.WINDOWS_RESERVED_NAMES
            ):
                raise LocalProjectError("Die Änderung enthält einen unter Windows ungültigen Pfad.")
        return path.as_posix()

    @classmethod
    def _editable_path(cls, raw_path: str) -> bool:
        path = PurePosixPath(raw_path)
        name = path.name.casefold()
        return (
            not CodeWorkspaceManager.is_sensitive_path(raw_path)
            and (name in cls.EDITABLE_NAMES or path.suffix.casefold() in cls.EDITABLE_SUFFIXES)
        )

    @staticmethod
    def _hash(path: Path) -> str:
        if not path.is_file():
            return "missing"
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
        return digest.hexdigest()

    @staticmethod
    def _atomic_json(path: Path, payload: dict[str, Any]) -> None:
        temporary = path.with_suffix(path.suffix + ".tmp")
        temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        temporary.replace(path)

    def _resolve_explicit_project(self, raw_path: str) -> Path:
        value = os.path.expandvars(str(raw_path or "").strip().strip('"').strip("'"))
        if not value or len(value) > 1_000 or "\x00" in value or any(char in value for char in "*?"):
            raise LocalProjectError("Der Projektpfad fehlt oder ist ungültig.")
        candidate = Path(value).expanduser()
        if not candidate.is_absolute():
            raise LocalProjectError("Bitte gib einen vollständigen absoluten Projektpfad an.")
        try:
            project = candidate.resolve(strict=True)
        except OSError as exc:
            raise LocalProjectError("Der angegebene Projektordner wurde nicht gefunden.") from exc
        if not project.is_dir() or project.is_symlink() or project == project.parent:
            raise LocalProjectError("Der angegebene Pfad ist kein sicherer Projektordner.")
        return project

    def active_project(self) -> dict[str, Any] | None:
        item = self.state_store.get_setting(self.ACTIVE_SETTING)
        if not isinstance(item, dict) or not str(item.get("path") or "").strip():
            return None
        try:
            project = self._resolve_explicit_project(str(item["path"]))
        except LocalProjectError:
            return None
        return {
            "path": str(project),
            "name": str(item.get("name") or project.name),
            "updated_at": str(item.get("updated_at") or ""),
        }

    def remember_project(self, raw_path: str) -> dict[str, Any]:
        project = self._resolve_explicit_project(raw_path)
        item = {"path": str(project), "name": project.name, "updated_at": self._now()}
        self.state_store.set_setting(self.ACTIVE_SETTING, item)
        return item

    def resolve_project(self, raw_path: str = "") -> Path:
        if str(raw_path or "").strip():
            return self._resolve_explicit_project(raw_path)
        active = self.active_project()
        if not active:
            raise LocalProjectError(
                "Es ist noch kein aktives Projekt gespeichert. Bitte nenne einmal den vollständigen Projektpfad."
            )
        return self._resolve_explicit_project(str(active["path"]))

    @classmethod
    def _safe_join(cls, root: Path, raw_path: str) -> tuple[str, Path]:
        relative = cls._safe_relative_path(raw_path)
        target = root.joinpath(*PurePosixPath(relative).parts)
        try:
            target.resolve(strict=False).relative_to(root.resolve())
        except ValueError as exc:
            raise LocalProjectError("Ein Änderungspfad verlässt den Projektordner.") from exc
        return relative, target

    def collect_ai_files(self, raw_path: str = "") -> dict[str, Any]:
        project = self.resolve_project(raw_path)
        included: list[dict[str, str]] = []
        skipped: list[str] = []
        base_hashes: dict[str, str] = {}
        total = 0
        for current, directories, filenames in os.walk(project, topdown=True, followlinks=False):
            current_path = Path(current)
            directories[:] = [
                name
                for name in directories
                if name.casefold() not in self.SKIPPED_DIRECTORIES
                and not (current_path / name).is_symlink()
            ]
            for name in sorted(filenames, key=str.casefold):
                path = current_path / name
                relative = path.relative_to(project).as_posix()
                if path.is_symlink() or not self._editable_path(relative):
                    skipped.append(relative)
                    continue
                base_hashes[relative] = self._hash(path)
                try:
                    data = path.read_bytes()
                    content = data.decode("utf-8")
                except (OSError, UnicodeDecodeError):
                    skipped.append(relative)
                    continue
                if (
                    len(data) > self.MAX_FILE_BYTES
                    or len(included) >= self.MAX_FILES
                    or total + len(data) > self.MAX_AI_BYTES
                ):
                    skipped.append(relative)
                    continue
                included.append({"path": relative, "content": content})
                total += len(data)
        if not included:
            raise LocalProjectError("Der Projektordner enthält keine sicheren UTF-8-Code- oder Textdateien.")
        self.remember_project(str(project))
        return {
            "path": str(project),
            "name": project.name,
            "files": included,
            "skipped": skipped,
            "base_hashes": base_hashes,
            "total_bytes": total,
        }

    @classmethod
    def _validate_batch(cls, content: str, instruction: str) -> None:
        if not cls.START_SCRIPT_HINT.search(instruction):
            raise LocalProjectError("Eine Batch-Datei wird nur erstellt, wenn der Nutzer sie ausdrücklich verlangt.")
        encoded = content.encode("utf-8")
        if not encoded or len(encoded) > 32 * 1024:
            raise LocalProjectError("Die Batch-Datei ist leer oder zu groß.")
        for raw_line in content.splitlines():
            line = raw_line.strip()
            if not line:
                continue
            if any(token in line for token in ("&", "|", ">", "<", "^", "%COMSPEC%", "%PATH%")):
                raise LocalProjectError("Die Batch-Datei enthält nicht freigegebene Shell-Steuerzeichen.")
            if not any(pattern.fullmatch(line) for pattern in cls.SAFE_BATCH_LINES):
                raise LocalProjectError(f"Nicht freigegebener Batch-Befehl: {line[:120]}")

    @classmethod
    def _check_text(cls, relative: str, content: str) -> dict[str, Any]:
        suffix = PurePosixPath(relative).suffix.casefold()
        try:
            if suffix == ".py":
                ast.parse(content, filename=relative)
            elif suffix == ".json":
                json.loads(content)
            elif suffix == ".toml":
                tomllib.loads(content)
            elif suffix in {".xml", ".svg"}:
                ElementTree.fromstring(content)
            elif suffix in {".html", ".htm"}:
                parser = _StrictHtmlParser()
                parser.feed(content)
                parser.close()
            elif suffix in {".css", ".scss"} and content.count("{") != content.count("}"):
                raise ValueError("Anzahl der geschweiften Klammern stimmt nicht überein")
            return {"path": relative, "ok": True, "message": "Syntax plausibel"}
        except (SyntaxError, ValueError, tomllib.TOMLDecodeError, ElementTree.ParseError) as exc:
            return {"path": relative, "ok": False, "message": str(exc)[:500]}

    def _backup_directory(self, project: Path) -> Path:
        key = hashlib.sha256(str(project).casefold().encode("utf-8")).hexdigest()[:20]
        root = self.backup_root / key
        root.mkdir(parents=True, exist_ok=True)
        return root

    def _create_change_backup(
        self,
        project: Path,
        changes: list[dict[str, Any]],
    ) -> tuple[Path, dict[str, Any]]:
        backup_id = f"{datetime.now(UTC).strftime('%Y%m%dT%H%M%SZ')}-{secrets.token_hex(5)}"
        backup = self._backup_directory(project) / backup_id
        files_root = backup / "files"
        files_root.mkdir(parents=True, exist_ok=False)
        entries: list[dict[str, Any]] = []
        for change in changes:
            relative, target = self._safe_join(project, str(change["path"]))
            existed = target.is_file()
            entry = {
                "path": relative,
                "existed": existed,
                "sha256": self._hash(target),
            }
            if existed:
                destination = files_root.joinpath(*PurePosixPath(relative).parts)
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(target, destination)
            entries.append(entry)
        manifest = {
            "id": backup_id,
            "project_path": str(project),
            "created_at": self._now(),
            "entries": entries,
        }
        self._atomic_json(backup / "manifest.json", manifest)
        backups = sorted(
            (item for item in backup.parent.iterdir() if item.is_dir()),
            key=lambda item: item.stat().st_mtime,
        )
        while len(backups) > self.MAX_BACKUPS_PER_PROJECT:
            shutil.rmtree(backups.pop(0), ignore_errors=True)
        return backup, manifest

    def _restore_change_backup(self, project: Path, backup: Path, manifest: dict[str, Any]) -> None:
        files_root = backup / "files"
        for entry in manifest.get("entries", []):
            relative, target = self._safe_join(project, str(entry.get("path") or ""))
            if bool(entry.get("existed")):
                source = files_root.joinpath(*PurePosixPath(relative).parts)
                target.parent.mkdir(parents=True, exist_ok=True)
                temporary = target.with_name(f".{target.name}.jarvis-rollback")
                shutil.copy2(source, temporary)
                temporary.replace(target)
            else:
                target.unlink(missing_ok=True)

    def apply_changes(
        self,
        raw_path: str,
        changes: object,
        *,
        instruction: str,
        expected_hashes: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        project = self.resolve_project(raw_path)
        if not isinstance(changes, list) or not 1 <= len(changes) <= self.MAX_CHANGES:
            raise LocalProjectError("Die KI hat keine gültige Anzahl an Projektänderungen geliefert.")
        normalized: list[dict[str, Any]] = []
        seen: set[str] = set()
        total = 0
        for raw in changes:
            if not isinstance(raw, dict):
                raise LocalProjectError("Eine Projektänderung ist ungültig.")
            relative, target = self._safe_join(project, str(raw.get("path") or ""))
            key = relative.casefold()
            if key in seen:
                raise LocalProjectError(f"Doppelte Projektänderung: {relative}")
            seen.add(key)
            if not self._editable_path(relative):
                raise LocalProjectError(f"Nicht freigegebener Projektdateityp: {relative}")
            action = str(raw.get("action") or "upsert").casefold()
            if action not in {"upsert", "delete"}:
                raise LocalProjectError(f"Ungültige Aktion für {relative}.")
            if target.exists() and (target.is_dir() or target.is_symlink()):
                raise LocalProjectError(f"JARVIS bearbeitet keine Ordner oder Verknüpfungen: {relative}")
            if expected_hashes is not None:
                expected_hash = str(expected_hashes.get(relative, "missing"))
                if self._hash(target) != expected_hash:
                    raise LocalProjectError(
                        f"{relative} wurde während der KI-Bearbeitung verändert und deshalb nicht überschrieben."
                    )
            content = str(raw.get("content") or "") if action == "upsert" else ""
            encoded = content.encode("utf-8")
            if len(encoded) > self.MAX_FILE_BYTES:
                raise LocalProjectError(f"Die Änderung für {relative} ist größer als 2 MB.")
            total += len(encoded)
            if total > self.MAX_CHANGE_BYTES:
                raise LocalProjectError("Die Projektänderungen sind zusammen größer als 10 MB.")
            if PurePosixPath(relative).suffix.casefold() == ".bat" and action == "upsert":
                self._validate_batch(content, instruction)
            normalized.append(
                {
                    "path": relative,
                    "target": target,
                    "action": action,
                    "content": content,
                    "data": encoded,
                }
            )

        with self._lock:
            backup, manifest = self._create_change_backup(project, normalized)
            applied: list[dict[str, Any]] = []
            checks: list[dict[str, Any]] = []
            try:
                for change in normalized:
                    target = change["target"]
                    if change["action"] == "delete":
                        target.unlink(missing_ok=True)
                        if target.exists():
                            raise LocalProjectError(f"{change['path']} konnte nicht gelöscht werden.")
                        applied.append({"path": change["path"], "action": "delete", "sha256": "missing"})
                        continue
                    target.parent.mkdir(parents=True, exist_ok=True)
                    temporary = target.with_name(f".{target.name}.jarvis-{secrets.token_hex(4)}")
                    temporary.write_bytes(change["data"])
                    if temporary.read_bytes() != change["data"]:
                        raise LocalProjectError(f"{change['path']} konnte nicht bytegenau geprüft werden.")
                    temporary.replace(target)
                    if target.read_bytes() != change["data"]:
                        raise LocalProjectError(f"{change['path']} wurde nach dem Schreiben verändert.")
                    check = self._check_text(change["path"], change["content"])
                    checks.append(check)
                    if not check["ok"]:
                        raise LocalProjectError(
                            f"Syntaxprüfung für {change['path']} fehlgeschlagen: {check['message']}"
                        )
                    applied.append(
                        {
                            "path": change["path"],
                            "action": "upsert",
                            "bytes": len(change["data"]),
                            "sha256": hashlib.sha256(change["data"]).hexdigest(),
                        }
                    )
            except Exception:
                self._restore_change_backup(project, backup, manifest)
                raise
        active = self.remember_project(str(project))
        return {
            "ok": True,
            "project": active,
            "changes": applied,
            "change_count": len(applied),
            "checks": checks,
            "backup_id": str(manifest["id"]),
            "verification": "Alle Änderungen wurden geschrieben, bytegenau geprüft und statisch validiert.",
        }
