from __future__ import annotations

import os


KEYRING_SERVICE = "JARVIS VisionVoice v11"
SECRET_ENVIRONMENT_KEYS = (
    "OPENAI_API_KEY",
    "HOME_ASSISTANT_TOKEN",
    "TELEGRAM_BOT_TOKEN",
    "WHATSAPP_CLOUD_ACCESS_TOKEN",
    "JARVIS_SMTP_PASSWORD",
    "GOOGLE_CLIENT_SECRET",
    "MS_CLIENT_SECRET",
    "LANGFUSE_SECRET_KEY",
    "SPOTIPY_CLIENT_SECRET",
    "JARVIS_WWEBJS_TOKEN",
)


def load_keyring_environment() -> list[str]:
    """Fill missing process-only environment values from the OS credential vault."""
    try:
        import keyring
    except ImportError:
        return []
    loaded: list[str] = []
    for key in SECRET_ENVIRONMENT_KEYS:
        if os.getenv(key, "").strip():
            continue
        try:
            value = keyring.get_password(KEYRING_SERVICE, key)
        except Exception:
            continue
        if value:
            os.environ[key] = value
            loaded.append(key)
    return loaded
