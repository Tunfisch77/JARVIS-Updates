@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" call "%~dp0MODULE_INSTALLIEREN.bat" --auto
if not exist ".venv\Scripts\python.exe" exit /b 1
".venv\Scripts\python.exe" -c "import dotenv, playwright, google_auth_oauthlib, msal" >nul 2>&1
if errorlevel 1 (
  echo Fehlende Grundmodule werden jetzt nachinstalliert...
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt
  if errorlevel 1 exit /b 1
)
set "JARVIS_BROWSER_CHANNEL=brave"
echo Verbinde das private Gmail-Konto mit JARVIS...
".venv\Scripts\python.exe" integrations_setup.py gmail --browser brave
pause
