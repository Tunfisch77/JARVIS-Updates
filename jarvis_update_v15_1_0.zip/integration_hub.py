from __future__ import annotations

import asyncio
import hashlib
import ipaddress
import json
import os
import re
import smtplib
import ssl
import subprocess
import threading
import time
import unicodedata
from dataclasses import dataclass, field
from datetime import datetime
from email.message import EmailMessage
from pathlib import Path
from typing import Any, Callable
from urllib.parse import quote, urlencode, urlparse
from zoneinfo import ZoneInfo

import httpx

from browser_runtime import launch_persistent_browser
from mail_accounts import (
    ACCOUNT_AUTO,
    ACCOUNT_GMAIL,
    ACCOUNT_OUTLOOK,
    AccountIntegrationError,
    ConnectedAccounts,
)
from persistent_storage import migrate_legacy_path, persistent_path


class IntegrationError(ValueError):
    pass


def _bool(value: str, default: bool = False) -> bool:
    cleaned = str(value or "").strip().casefold()
    if not cleaned:
        return default
    return cleaned in {"1", "true", "yes", "on"}


def _json_mapping(value: str) -> dict[str, str]:
    if not str(value or "").strip():
        return {}
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError:
        return {}
    if not isinstance(parsed, dict):
        return {}
    return {
        str(key).strip().casefold(): str(item).strip()
        for key, item in parsed.items()
        if str(key).strip() and str(item).strip()
    }


def normalize_phone(value: str) -> str:
    cleaned = re.sub(r"[\s()+./-]", "", str(value or "").strip())
    if not re.fullmatch(r"\d{7,15}", cleaned):
        raise IntegrationError("Die WhatsApp-Nummer muss im internationalen Format stehen, z. B. +436601234567.")
    if cleaned.startswith("0"):
        raise IntegrationError("Verwende die internationale Nummer mit Ländervorwahl statt einer führenden Null.")
    try:
        import phonenumbers

        parsed = phonenumbers.parse(f"+{cleaned}", None)
        if not phonenumbers.is_possible_number(parsed):
            raise IntegrationError("Diese internationale Telefonnummer ist nicht plausibel.")
        cleaned = phonenumbers.format_number(
            parsed,
            phonenumbers.PhoneNumberFormat.E164,
        ).lstrip("+")
    except ImportError:
        pass
    except phonenumbers.NumberParseException as exc:
        raise IntegrationError("Diese internationale Telefonnummer konnte nicht gelesen werden.") from exc
    return cleaned


def normalize_email(value: str) -> str:
    cleaned = str(value or "").strip()
    if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", cleaned) or len(cleaned) > 254:
        raise IntegrationError("Ungültige E-Mail-Adresse.")
    return cleaned


def normalize_telegram_chat_id(value: str) -> str:
    cleaned = str(value or "").strip()
    if not re.fullmatch(r"-?\d{3,30}", cleaned):
        raise IntegrationError("Telegram benötigt eine numerische Chat-ID.")
    return cleaned


def normalize_identity(value: str) -> str:
    """Normalize spoken/written names without exposing or changing their stored spelling."""
    decomposed = unicodedata.normalize("NFKD", str(value or "").casefold())
    without_marks = "".join(character for character in decomposed if not unicodedata.combining(character))
    return " ".join(re.findall(r"[^\W_]+", without_marks, flags=re.UNICODE))


def _identity(value: str) -> str:
    return normalize_identity(value)


def _persistent_profile(
    env: dict[str, str],
    variable: str,
    *,
    base_dir: Path,
    legacy_relative: str,
    central_relative: str,
) -> Path:
    configured = str(env.get(variable, "") or "").strip()
    if configured:
        path = Path(os.path.expandvars(configured)).expanduser()
        return path if path.is_absolute() else base_dir / path
    return migrate_legacy_path(
        base_dir / legacy_relative,
        persistent_path(central_relative, env),
    )


@dataclass(slots=True)
class IntegrationConfig:
    whatsapp_mode: str = "draft"
    whatsapp_access_token: str = ""
    whatsapp_phone_number_id: str = ""
    whatsapp_graph_version: str = "v25.0"
    whatsapp_web_auto_send: bool = False
    whatsapp_profile_dir: Path = Path("data/whatsapp_web_profile")
    snapchat_profile_dir: Path = Path("data/snapchat_web_profile")
    whatsapp_desktop_auto_send: bool = False
    browser_channel: str = "auto"
    telegram_bot_token: str = ""
    email_mode: str = "draft"
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_password: str = ""
    smtp_from: str = ""
    smtp_tls: bool = True
    timezone: str = "Europe/Vienna"
    webhooks: dict[str, str] = field(default_factory=dict)
    allow_local_webhooks: bool = False
    launch_targets: dict[str, str] = field(default_factory=dict)
    close_launched_apps: bool = True

    @classmethod
    def from_environment(
        cls,
        environment: dict[str, str] | None = None,
        *,
        base_dir: Path | None = None,
    ) -> "IntegrationConfig":
        env = environment or os.environ
        root = base_dir or Path.cwd()
        try:
            smtp_port = int(env.get("JARVIS_SMTP_PORT", "587"))
        except ValueError:
            smtp_port = 587
        return cls(
            whatsapp_mode=env.get("JARVIS_WHATSAPP_MODE", "desktop").strip().casefold(),
            whatsapp_access_token=env.get("WHATSAPP_CLOUD_ACCESS_TOKEN", "").strip(),
            whatsapp_phone_number_id=env.get("WHATSAPP_PHONE_NUMBER_ID", "").strip(),
            whatsapp_graph_version=env.get("WHATSAPP_GRAPH_VERSION", "v25.0").strip(),
            whatsapp_web_auto_send=_bool(env.get("JARVIS_WHATSAPP_WEB_AUTO_SEND", "true"), True),
            whatsapp_profile_dir=_persistent_profile(
                env,
                "JARVIS_WHATSAPP_PROFILE_DIR",
                base_dir=root,
                legacy_relative="data/whatsapp_web_profile",
                central_relative="browser_profiles/whatsapp",
            ),
            snapchat_profile_dir=_persistent_profile(
                env,
                "JARVIS_SNAPCHAT_PROFILE_DIR",
                base_dir=root,
                legacy_relative="data/snapchat_web_profile",
                central_relative="browser_profiles/snapchat",
            ),
            whatsapp_desktop_auto_send=_bool(
                env.get("JARVIS_WHATSAPP_DESKTOP_AUTO_SEND", "true"),
                True,
            ),
            browser_channel=env.get("JARVIS_BROWSER_CHANNEL", "auto").strip() or "auto",
            telegram_bot_token=env.get("TELEGRAM_BOT_TOKEN", "").strip(),
            email_mode=env.get("JARVIS_EMAIL_MODE", "draft").strip().casefold(),
            smtp_host=env.get("JARVIS_SMTP_HOST", "").strip(),
            smtp_port=max(1, min(65535, smtp_port)),
            smtp_user=env.get("JARVIS_SMTP_USER", "").strip(),
            smtp_password=env.get("JARVIS_SMTP_PASSWORD", "").strip(),
            smtp_from=env.get("JARVIS_SMTP_FROM", "").strip(),
            smtp_tls=_bool(env.get("JARVIS_SMTP_TLS", "true"), True),
            timezone=env.get("JARVIS_TIMEZONE", "Europe/Vienna").strip() or "Europe/Vienna",
            webhooks=_json_mapping(env.get("JARVIS_WEBHOOKS_JSON", "")),
            allow_local_webhooks=_bool(env.get("JARVIS_ALLOW_LOCAL_WEBHOOKS", "false")),
            launch_targets=_json_mapping(env.get("JARVIS_LAUNCH_TARGETS_JSON", "")),
            close_launched_apps=_bool(env.get("JARVIS_CLOSE_LAUNCHED_APPS", "true"), True),
        )


class IntegrationHub:
    BUILTIN_LAUNCH_TARGETS: dict[str, str] = {
        "google": "https://www.google.com/",
        "youtube": "https://www.youtube.com/",
        "gmail": "https://mail.google.com/",
        "kalender": "https://calendar.google.com/",
        "maps": "https://maps.google.com/",
        "spotify": "https://open.spotify.com/",
        "rechner": "app:calculator",
        "editor": "app:notepad",
        "explorer": "app:explorer",
        "einstellungen": "uri:ms-settings:",
    }
    WINDOWS_APPS: dict[str, list[str]] = {
        "calculator": ["calc.exe"],
        "notepad": ["notepad.exe"],
        "explorer": ["explorer.exe"],
    }
    SAFE_URI_SCHEMES = {"https", "http", "mailto", "spotify", "ms-settings"}

    def __init__(
        self,
        contact_supplier: Callable[[], list[dict[str, Any]]],
        config: IntegrationConfig,
        connected_accounts: ConnectedAccounts | None = None,
        *,
        group_supplier: Callable[[], list[dict[str, Any]]] | None = None,
        usage_recorder: Callable[..., None] | None = None,
    ) -> None:
        self.contact_supplier = contact_supplier
        self.group_supplier = group_supplier or (lambda: [])
        self.usage_recorder = usage_recorder
        self.config = config
        self.connected_accounts = connected_accounts
        self._whatsapp_lock = threading.Lock()
        self._snapchat_lock = threading.Lock()
        self.configuration_warnings: list[str] = []
        try:
            self.timezone = ZoneInfo(config.timezone)
        except Exception:
            self.timezone = ZoneInfo("Europe/Vienna")
            self.configuration_warnings.append(
                f"Unbekannte Zeitzone '{config.timezone}'; Europe/Vienna wird verwendet."
            )
        self.webhooks = self._validated_webhooks(config.webhooks)
        self.launch_targets = dict(self.BUILTIN_LAUNCH_TARGETS)
        for name, target in config.launch_targets.items():
            if self._safe_action_url(target):
                self.launch_targets[name] = target

    def _validated_webhooks(self, items: dict[str, str]) -> dict[str, str]:
        validated: dict[str, str] = {}
        for name, url in items.items():
            parsed = urlparse(url)
            if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
                continue
            hostname = parsed.hostname.casefold()
            is_local = hostname in {"localhost", "localhost.localdomain"}
            try:
                address = ipaddress.ip_address(hostname)
                is_local = is_local or address.is_private or address.is_loopback or address.is_link_local
            except ValueError:
                pass
            if is_local and not self.config.allow_local_webhooks:
                continue
            validated[name] = url
        return validated

    @classmethod
    def _safe_action_url(cls, value: str) -> bool:
        parsed = urlparse(str(value or ""))
        return parsed.scheme.casefold() in cls.SAFE_URI_SCHEMES and bool(parsed.scheme)

    def open_action_url(self, value: str) -> bool:
        """Open an allowlisted URL through Windows ShellExecute without a command shell."""
        action_url = str(value or "").strip()
        if not self._safe_action_url(action_url):
            raise IntegrationError("Die vorbereitete Aktion verwendet kein freigegebenes Protokoll.")
        if os.name != "nt":
            return False
        startfile = getattr(os, "startfile", None)
        if not callable(startfile):
            return False
        try:
            startfile(action_url)
        except OSError as exc:
            raise IntegrationError("Die vorbereitete Aktion konnte nicht automatisch geöffnet werden.") from exc
        return True

    def contacts(self) -> list[dict[str, Any]]:
        return self.contact_supplier()

    def whatsapp_groups(self) -> list[dict[str, Any]]:
        return self.group_supplier()

    @staticmethod
    def _matches(item: dict[str, Any], target: str, *, extra_fields: tuple[str, ...] = ()) -> bool:
        wanted = _identity(target)
        aliases = item.get("aliases") if isinstance(item.get("aliases"), list) else []
        candidates = [item.get("name", ""), *aliases, *(item.get(field, "") for field in extra_fields)]
        return bool(wanted) and wanted in {_identity(str(candidate)) for candidate in candidates if str(candidate).strip()}

    def _contact(self, target: str) -> dict[str, Any] | None:
        wanted = _identity(target)
        matches: list[dict[str, Any]] = []
        for item in self.contacts():
            if self._matches(item, wanted, extra_fields=("whatsapp_chat_name",)):
                matches.append(item)
        if len(matches) > 1:
            raise IntegrationError("Der Kontakt ist nicht eindeutig. Verwende den genauen Namen.")
        if matches:
            return matches[0]
        return self._fuzzy_unique(self.contacts(), wanted, extra_fields=("whatsapp_chat_name",))

    def _whatsapp_group(self, target: str) -> dict[str, Any] | None:
        matches = [item for item in self.whatsapp_groups() if self._matches(item, target, extra_fields=("chat_name",))]
        if len(matches) > 1:
            raise IntegrationError("Die WhatsApp-Gruppe ist nicht eindeutig. Verwende den genauen gespeicherten Namen.")
        if matches:
            return matches[0]
        return self._fuzzy_unique(self.whatsapp_groups(), _identity(target), extra_fields=("chat_name",))

    @staticmethod
    def _fuzzy_unique(
        items: list[dict[str, Any]],
        wanted: str,
        *,
        extra_fields: tuple[str, ...] = (),
    ) -> dict[str, Any] | None:
        """Accept only a very strong, clearly unique RapidFuzz match."""
        if len(wanted) < 4:
            return None
        try:
            from rapidfuzz import fuzz
        except ImportError:
            return None
        scored: list[tuple[float, dict[str, Any]]] = []
        for item in items:
            aliases = item.get("aliases") if isinstance(item.get("aliases"), list) else []
            candidates = [
                item.get("name", ""),
                *aliases,
                *(item.get(field, "") for field in extra_fields),
            ]
            score = max(
                (
                    float(fuzz.WRatio(wanted, _identity(str(candidate))))
                    for candidate in candidates
                    if str(candidate).strip()
                ),
                default=0.0,
            )
            scored.append((score, item))
        scored.sort(key=lambda value: value[0], reverse=True)
        if not scored or scored[0][0] < 92:
            return None
        if len(scored) > 1 and scored[0][0] - scored[1][0] < 5:
            raise IntegrationError("Mehrere Kontakte klingen ähnlich. Verwende den genauen Namen.")
        return scored[0][1]

    def resolve_whatsapp_target(self, target: str, target_kind: str = "auto") -> dict[str, Any]:
        kind = str(target_kind or "auto").strip().casefold()
        if kind not in {"auto", "contact", "group"}:
            raise IntegrationError("WhatsApp-Zieltyp muss auto, contact oder group sein.")
        contact = self._contact(target) if kind in {"auto", "contact"} else None
        group = self._whatsapp_group(target) if kind in {"auto", "group"} else None
        if contact and group:
            raise IntegrationError("Dieser Name gehört zu einem Kontakt und einer Gruppe. Sage ausdrücklich Kontakt oder Gruppe.")
        if group:
            chat_name = str(group.get("chat_name") or group.get("name") or "").strip()
            if not chat_name:
                raise IntegrationError("Für diese WhatsApp-Gruppe fehlt der exakte Chatname.")
            return {
                "recipient": chat_name,
                "contact_name": "",
                "display_name": str(group.get("name") or chat_name),
                "target_kind": "group",
                "target_id": int(group.get("id") or 0),
                "chat_name": chat_name,
            }
        if kind == "group":
            raise IntegrationError("Diese WhatsApp-Gruppe ist nicht gespeichert. Lege sie zuerst im Kontrollzentrum an.")
        value = contact.get("whatsapp_number", "") if contact else target
        chat_name = str(contact.get("whatsapp_chat_name") or contact.get("name") or "").strip() if contact else ""
        if str(value).strip():
            recipient = normalize_phone(str(value))
            address_mode = "phone"
        elif contact and chat_name:
            recipient = chat_name
            address_mode = "chat_name"
        else:
            recipient = normalize_phone(str(value))
            address_mode = "phone"
        return {
            "recipient": recipient,
            "contact_name": str(contact.get("name", "")) if contact else "",
            "display_name": str(contact.get("name", "")) if contact else recipient,
            "target_kind": "contact",
            "target_id": int(contact.get("id") or 0) if contact else 0,
            "chat_name": chat_name,
            "address_mode": address_mode,
        }

    def resolve_recipient(self, target: str, channel: str) -> dict[str, Any]:
        contact = self._contact(target)
        if channel == "whatsapp":
            return self.resolve_whatsapp_target(target, "auto")
        elif channel == "email":
            value = contact.get("email", "") if contact else target
            recipient = normalize_email(str(value))
        elif channel == "telegram":
            value = contact.get("telegram_chat_id", "") if contact else target
            recipient = normalize_telegram_chat_id(str(value))
        else:
            raise IntegrationError("Unbekannter Kommunikationskanal.")
        return {
            "recipient": recipient,
            "contact_name": str(contact.get("name", "")) if contact else "",
            "target_kind": "contact",
            "target_id": int(contact.get("id") or 0) if contact else 0,
        }

    def status(self) -> dict[str, Any]:
        whatsapp_cloud = bool(
            self.config.whatsapp_mode == "cloud"
            and self.config.whatsapp_access_token
            and self.config.whatsapp_phone_number_id
            and re.fullmatch(r"v\d+\.\d+", self.config.whatsapp_graph_version)
        )
        smtp_ready = bool(
            self.config.email_mode == "smtp"
            and self.config.smtp_host
            and self.config.smtp_from
            and self.config.smtp_password
        )
        whatsapp_web = bool(self.config.whatsapp_mode == "web" and self.config.whatsapp_web_auto_send)
        whatsapp_desktop = bool(
            self.config.whatsapp_mode == "desktop" and self.config.whatsapp_desktop_auto_send
        )
        whatsapp_inbox = (self.config.whatsapp_profile_dir / ".jarvis_connected").is_file()
        accounts = self.connected_accounts.status() if self.connected_accounts else {}
        account_connected = any(
            accounts.get(name, {}).get("status") == "connected"
            for name in (ACCOUNT_GMAIL, ACCOUNT_OUTLOOK)
        )
        return {
            "status": "connected",
            "contacts": len(self.contacts()),
            "whatsapp_groups": len(self.whatsapp_groups()),
            "whatsapp": {
                "status": (
                    "connected"
                    if self.config.whatsapp_mode == "draft" or whatsapp_cloud or whatsapp_web or whatsapp_desktop
                    else "not_configured"
                ),
                "inbox_status": "connected" if whatsapp_inbox else "not_configured",
                "content_access": whatsapp_inbox,
                "mode": (
                    "cloud"
                    if whatsapp_cloud
                    else "desktop_auto"
                    if whatsapp_desktop
                    else "web_auto"
                    if whatsapp_web
                    else "draft"
                ),
            },
            "snapchat": {
                "status": (
                    "connected"
                    if (self.config.snapchat_profile_dir / ".jarvis_connected").is_file()
                    else "not_configured"
                ),
                "mode": "web_metadata_only",
                "content_access": False,
            },
            "telegram": {"status": "connected" if self.config.telegram_bot_token else "not_configured"},
            "email": {
                "status": "connected" if account_connected or self.config.email_mode == "draft" or smtp_ready else "not_configured",
                "mode": "account_router" if account_connected else ("smtp" if smtp_ready else "draft"),
                "accounts": accounts,
            },
            "calendar": {
                "status": "connected",
                "mode": "account_router" if account_connected else "draft",
                "timezone": self.timezone.key,
                "accounts": accounts,
            },
            "webhooks": {"status": "connected" if self.webhooks else "not_configured", "names": sorted(self.webhooks)},
            "pc_launcher": {"status": "connected", "targets": sorted(self.launch_targets)},
            "automation": {"close_launched_apps": bool(self.config.close_launched_apps)},
            "warnings": list(self.configuration_warnings),
        }

    async def whatsapp_message(self, target: str, message: str, target_kind: str = "auto") -> dict[str, Any]:
        body = str(message or "").strip()
        if not body or len(body) > 4_000:
            raise IntegrationError("Die WhatsApp-Nachricht muss zwischen 1 und 4000 Zeichen lang sein.")
        resolved = self.resolve_whatsapp_target(target, target_kind)
        recipient = resolved["recipient"]
        status = self.status()["whatsapp"]
        if self.config.whatsapp_mode == "cloud" and status["status"] != "connected":
            raise IntegrationError("WhatsApp-Cloud-Modus ist gewählt, aber Access Token oder Phone Number ID fehlt.")
        if status["mode"] == "desktop_auto":
            desktop_result = await asyncio.to_thread(
                self._send_whatsapp_desktop,
                resolved["target_kind"],
                recipient,
                resolved["chat_name"],
                body,
            )
            self._record_usage(resolved, "whatsapp")
            return {
                "ok": True,
                "mode": "desktop_auto",
                "channel": "whatsapp",
                "recipient": recipient,
                "contact_name": resolved["contact_name"],
                "display_name": resolved["display_name"],
                "target_kind": resolved["target_kind"],
                "requires_user_action": False,
                "verification": "desktop_send_command_completed",
                "result_summary": "WhatsApp hat den Sendebefehl ausgeführt.",
                **desktop_result,
            }
        if status["mode"] == "web_auto":
            if resolved["target_kind"] == "group":
                raise IntegrationError("WhatsApp-Gruppen werden über die Desktop-App gesendet.")
            if resolved.get("address_mode") != "phone":
                raise IntegrationError("WhatsApp Web benötigt für Kontakte eine internationale Nummer.")
            web_result = await asyncio.to_thread(self._send_whatsapp_web, recipient, body)
            self._record_usage(resolved, "whatsapp")
            return {
                "ok": True,
                "mode": "web_auto",
                "channel": "whatsapp",
                "recipient": recipient,
                "contact_name": resolved["contact_name"],
                "display_name": resolved["display_name"],
                "target_kind": resolved["target_kind"],
                "requires_user_action": False,
                "verification": "whatsapp_web_composer_cleared",
                "result_summary": "WhatsApp Web hat die Nachricht abgesendet.",
                **web_result,
            }
        if status["mode"] != "cloud":
            if resolved["target_kind"] == "group":
                raise IntegrationError("Gruppenentwürfe benötigen die WhatsApp-Desktop-Automation.")
            if resolved.get("address_mode") != "phone":
                raise IntegrationError("Ein WhatsApp-Entwurf benötigt für Kontakte eine internationale Nummer.")
            return {
                "ok": True,
                "mode": "draft",
                "channel": "whatsapp",
                "recipient": recipient,
                "contact_name": resolved["contact_name"],
                "action_url": f"https://wa.me/{recipient}?{urlencode({'text': body})}",
                "requires_user_action": True,
                "message": "WhatsApp wurde mit der fertigen Nachricht vorbereitet. Der Nutzer muss nur noch auf Senden drücken.",
                "verification": "draft_prepared",
                "app_closed": False,
            }

        url = (
            f"https://graph.facebook.com/{self.config.whatsapp_graph_version}/"
            f"{self.config.whatsapp_phone_number_id}/messages"
        )
        payload = {
            "messaging_product": "whatsapp",
            "recipient_type": "individual",
            "to": recipient,
            "type": "text",
            "text": {"preview_url": False, "body": body},
        }
        if resolved["target_kind"] == "group":
            raise IntegrationError("Die WhatsApp Cloud API kann diese gespeicherte private Gruppe nicht adressieren.")
        if resolved.get("address_mode") != "phone":
            raise IntegrationError("Die WhatsApp Cloud API benötigt für Kontakte eine internationale Nummer.")
        try:
            async with httpx.AsyncClient(timeout=20.0, follow_redirects=False) as client:
                response = await client.post(
                    url,
                    headers={"Authorization": f"Bearer {self.config.whatsapp_access_token}"},
                    json=payload,
                )
        except httpx.HTTPError as exc:
            raise IntegrationError("WhatsApp Cloud API ist derzeit nicht erreichbar.") from exc
        if response.is_error:
            raise IntegrationError(f"WhatsApp Cloud API hat die Nachricht abgelehnt (HTTP {response.status_code}).")
        data = response.json() if response.content else {}
        messages = data.get("messages", []) if isinstance(data, dict) else []
        message_id = messages[0].get("id", "") if messages and isinstance(messages[0], dict) else ""
        return {
            "ok": True,
            "mode": "cloud",
            "channel": "whatsapp",
            "recipient": recipient,
            "contact_name": resolved["contact_name"],
            "message_id": message_id,
            "requires_user_action": False,
            "verification": "provider_message_id" if message_id else "provider_accepted",
            "result_summary": "WhatsApp Cloud hat die Nachricht angenommen.",
            "app_closed": False,
        }

    def _record_usage(self, resolved: dict[str, Any], channel: str = "") -> None:
        if not self.usage_recorder:
            return
        target_id = int(resolved.get("target_id") or 0)
        if target_id:
            try:
                self.usage_recorder(str(resolved.get("target_kind") or ""), target_id, channel)
            except TypeError:
                self.usage_recorder(str(resolved.get("target_kind") or ""), target_id)

    @staticmethod
    def _windows_key_combo(*virtual_keys: int) -> None:
        """Press a short key combination through the Windows user32 API."""
        import ctypes

        key_up = 0x0002
        user32 = ctypes.windll.user32
        for virtual_key in virtual_keys:
            user32.keybd_event(virtual_key, 0, 0, 0)
        for virtual_key in reversed(virtual_keys):
            user32.keybd_event(virtual_key, 0, key_up, 0)

    @staticmethod
    def _windows_clipboard_text() -> str | None:
        """Read Unicode text from the clipboard without an extra Python package."""
        import ctypes
        from ctypes import wintypes

        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32
        clipboard_unicode = 13
        user32.GetClipboardData.restype = wintypes.HANDLE
        kernel32.GlobalLock.restype = ctypes.c_void_p

        opened = False
        for _ in range(20):
            if user32.OpenClipboard(None):
                opened = True
                break
            time.sleep(0.05)
        if not opened:
            return None
        try:
            handle = user32.GetClipboardData(clipboard_unicode)
            if not handle:
                return None
            pointer = kernel32.GlobalLock(handle)
            if not pointer:
                return None
            try:
                return ctypes.wstring_at(pointer)
            finally:
                kernel32.GlobalUnlock(handle)
        finally:
            user32.CloseClipboard()

    @staticmethod
    def _windows_set_clipboard_text(value: str) -> None:
        """Put Unicode text on the Windows clipboard without pyperclip."""
        import ctypes
        from ctypes import wintypes

        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32
        clipboard_unicode = 13
        moveable_memory = 0x0002
        buffer = ctypes.create_unicode_buffer(str(value))
        size = ctypes.sizeof(buffer)

        kernel32.GlobalAlloc.argtypes = (wintypes.UINT, ctypes.c_size_t)
        kernel32.GlobalAlloc.restype = wintypes.HGLOBAL
        kernel32.GlobalLock.argtypes = (wintypes.HGLOBAL,)
        kernel32.GlobalLock.restype = ctypes.c_void_p
        kernel32.GlobalUnlock.argtypes = (wintypes.HGLOBAL,)
        kernel32.GlobalFree.argtypes = (wintypes.HGLOBAL,)
        user32.SetClipboardData.argtypes = (wintypes.UINT, wintypes.HANDLE)
        user32.SetClipboardData.restype = wintypes.HANDLE

        opened = False
        for _ in range(20):
            if user32.OpenClipboard(None):
                opened = True
                break
            time.sleep(0.05)
        if not opened:
            raise OSError("Die Windows-Zwischenablage ist gerade gesperrt.")

        memory_handle = None
        try:
            if not user32.EmptyClipboard():
                raise OSError("Die Windows-Zwischenablage konnte nicht geleert werden.")
            memory_handle = kernel32.GlobalAlloc(moveable_memory, size)
            if not memory_handle:
                raise MemoryError("Windows konnte keinen Zwischenablagespeicher reservieren.")
            pointer = kernel32.GlobalLock(memory_handle)
            if not pointer:
                raise OSError("Windows konnte den Zwischenablagespeicher nicht sperren.")
            try:
                ctypes.memmove(pointer, ctypes.addressof(buffer), size)
            finally:
                kernel32.GlobalUnlock(memory_handle)
            if not user32.SetClipboardData(clipboard_unicode, memory_handle):
                raise OSError("Windows hat den Zwischenablagetext nicht übernommen.")
            memory_handle = None  # Windows owns the memory after SetClipboardData succeeds.
        finally:
            user32.CloseClipboard()
            if memory_handle:
                kernel32.GlobalFree(memory_handle)

    @staticmethod
    def _windows_find_whatsapp_window(timeout: float = 25.0) -> int:
        """Find the visible WhatsApp window by title or owning process."""
        import ctypes
        from ctypes import wintypes

        try:
            import psutil
        except ImportError:
            psutil = None

        user32 = ctypes.windll.user32
        callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        user32.EnumWindows.argtypes = (callback_type, wintypes.LPARAM)
        user32.EnumWindows.restype = wintypes.BOOL
        user32.IsWindowVisible.argtypes = (wintypes.HWND,)
        user32.IsWindowVisible.restype = wintypes.BOOL
        user32.GetWindowTextLengthW.argtypes = (wintypes.HWND,)
        user32.GetWindowTextLengthW.restype = ctypes.c_int
        user32.GetWindowTextW.argtypes = (wintypes.HWND, wintypes.LPWSTR, ctypes.c_int)
        user32.GetWindowTextW.restype = ctypes.c_int
        user32.GetWindowThreadProcessId.argtypes = (wintypes.HWND, ctypes.POINTER(wintypes.DWORD))
        user32.GetWindowThreadProcessId.restype = wintypes.DWORD
        user32.GetForegroundWindow.restype = wintypes.HWND
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            matches: list[int] = []

            @callback_type
            def collect_window(window_handle: int, _: int) -> bool:
                if not user32.IsWindowVisible(window_handle):
                    return True
                length = user32.GetWindowTextLengthW(window_handle)
                title_buffer = ctypes.create_unicode_buffer(max(1, length + 1))
                user32.GetWindowTextW(window_handle, title_buffer, len(title_buffer))
                title = title_buffer.value.casefold()
                process_name = ""
                if psutil is not None:
                    process_id = wintypes.DWORD()
                    user32.GetWindowThreadProcessId(window_handle, ctypes.byref(process_id))
                    try:
                        process_name = psutil.Process(process_id.value).name().casefold()
                    except (psutil.Error, OSError):
                        process_name = ""
                if "whatsapp" in title or "whatsapp" in process_name:
                    matches.append(int(window_handle))
                return True

            user32.EnumWindows(collect_window, 0)
            if matches:
                foreground = int(user32.GetForegroundWindow() or 0)
                return foreground if foreground in matches else matches[0]
            time.sleep(0.25)
        raise OSError("Es wurde innerhalb von 25 Sekunden kein WhatsApp-Fenster gefunden.")

    @classmethod
    def _windows_focus_whatsapp(cls, timeout: float = 25.0) -> int:
        """Restore and focus WhatsApp so the following keystrokes reach the app."""
        import ctypes
        from ctypes import wintypes

        user32 = ctypes.windll.user32
        user32.ShowWindow.argtypes = (wintypes.HWND, ctypes.c_int)
        user32.BringWindowToTop.argtypes = (wintypes.HWND,)
        user32.SetForegroundWindow.argtypes = (wintypes.HWND,)
        window_handle = cls._windows_find_whatsapp_window(timeout)
        user32.ShowWindow(window_handle, 9)  # SW_RESTORE
        user32.BringWindowToTop(window_handle)
        user32.keybd_event(0x12, 0, 0, 0)  # ALT briefly unlocks foreground activation.
        user32.keybd_event(0x12, 0, 0x0002, 0)
        user32.SetForegroundWindow(window_handle)
        time.sleep(0.35)
        return window_handle

    @classmethod
    def _windows_existing_whatsapp_window(cls) -> int:
        """Return an already visible WhatsApp window without making absence an error."""
        try:
            return cls._windows_find_whatsapp_window(0.35)
        except Exception:
            return 0

    @staticmethod
    def _windows_close_window(window_handle: int) -> bool:
        """Close only the exact window JARVIS opened for the finished action."""
        if not window_handle:
            return False
        try:
            import ctypes
            from ctypes import wintypes

            user32 = ctypes.windll.user32
            user32.IsWindow.argtypes = (wintypes.HWND,)
            user32.IsWindow.restype = wintypes.BOOL
            user32.PostMessageW.argtypes = (wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM)
            user32.PostMessageW.restype = wintypes.BOOL
            return bool(user32.IsWindow(window_handle) and user32.PostMessageW(window_handle, 0x0010, 0, 0))
        except Exception:
            return False

    def _send_whatsapp_desktop(
        self,
        target_kind: str,
        recipient: str,
        chat_name: str,
        body: str,
    ) -> dict[str, bool]:
        """Send a text through WhatsApp Desktop using only built-in Windows APIs."""
        if os.name != "nt":
            raise IntegrationError("WhatsApp Desktop kann nur unter Windows automatisch gesteuert werden.")
        startfile = getattr(os, "startfile", None)
        if not callable(startfile):
            raise IntegrationError("Windows kann das WhatsApp-Protokoll nicht öffnen.")
        stage = "WhatsApp öffnen"
        previous_clipboard: str | None = None
        existing_window = self._windows_existing_whatsapp_window()
        opened_by_jarvis = not bool(existing_window)
        app_closed = False
        with self._whatsapp_lock:
            try:
                search_by_name = target_kind == "group" or not str(recipient).isdigit()
                if search_by_name:
                    startfile("whatsapp:")
                else:
                    startfile(f"whatsapp://send?phone={recipient}&text={quote(body, safe='')}")

                stage = "WhatsApp-Fenster aktivieren"
                window_handle = self._windows_focus_whatsapp(25.0)
                time.sleep(2.0)

                if search_by_name:
                    stage = "Chat suchen"
                    previous_clipboard = self._windows_clipboard_text()
                    self._windows_key_combo(0x11, 0x4E)  # CTRL+N
                    time.sleep(0.8)
                    self._windows_set_clipboard_text(chat_name)
                    self._windows_key_combo(0x11, 0x56)  # CTRL+V
                    time.sleep(1.5)
                    self._windows_key_combo(0x0D)  # ENTER
                    time.sleep(1.0)

                    stage = "Nachricht einfügen und senden"
                    self._windows_set_clipboard_text(body)
                    self._windows_key_combo(0x11, 0x56)  # CTRL+V
                    time.sleep(0.25)
                    self._windows_key_combo(0x0D)  # ENTER
                else:
                    stage = "Nachricht senden"
                    self._windows_key_combo(0x0D)  # ENTER
                time.sleep(0.8)
                if self.config.close_launched_apps and opened_by_jarvis:
                    app_closed = self._windows_close_window(window_handle)
                    if app_closed:
                        time.sleep(0.35)
            except IntegrationError:
                raise
            except Exception as exc:
                raise IntegrationError(
                    f"WhatsApp Desktop konnte beim Schritt '{stage}' nicht gesteuert werden: {exc}"
                ) from exc
            finally:
                if previous_clipboard is not None:
                    try:
                        time.sleep(0.2)
                        self._windows_set_clipboard_text(previous_clipboard)
                    except Exception:
                        pass
        return {
            "app_opened_by_jarvis": opened_by_jarvis,
            "app_closed": app_closed,
        }

    def _send_whatsapp_web(self, recipient: str, body: str) -> dict[str, bool]:
        """Send one text message through a dedicated persistent WhatsApp Web profile."""
        try:
            from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
            from playwright.sync_api import sync_playwright
        except ImportError as exc:
            raise IntegrationError("Playwright fehlt. Starte zuerst INSTALLIEREN.bat.") from exc
        profile = self.config.whatsapp_profile_dir.resolve()
        profile.mkdir(parents=True, exist_ok=True)
        with self._whatsapp_lock:
            try:
                with sync_playwright() as playwright:
                    context = launch_persistent_browser(
                        playwright,
                        profile,
                        preference=self.config.browser_channel,
                        headless=False,
                    )
                    try:
                        page = context.pages[0] if context.pages else context.new_page()
                        page.goto(
                            f"https://web.whatsapp.com/send?phone={recipient}&{urlencode({'text': body})}",
                            wait_until="domcontentloaded",
                            timeout=45_000,
                        )
                        composer = page.locator("footer div[contenteditable='true']").last
                        composer.wait_for(state="visible", timeout=30_000)
                        sent = False
                        for selector in (
                            "button[aria-label='Send']",
                            "button[aria-label='Senden']",
                            "button:has(span[data-icon='send'])",
                        ):
                            button = page.locator(selector).last
                            if button.count() and button.is_visible():
                                button.click()
                                sent = True
                                break
                        if not sent:
                            composer.press("Enter")
                        page.wait_for_timeout(1_000)
                    finally:
                        context.close()
                return {"app_opened_by_jarvis": True, "app_closed": True}
            except PlaywrightTimeoutError as exc:
                raise IntegrationError(
                    "WhatsApp Web ist nicht angemeldet oder die Seite hat sich geändert. Starte WHATSAPP_VERBINDEN.bat."
                ) from exc
            except IntegrationError:
                raise
            except Exception as exc:
                raise IntegrationError(
                    "WhatsApp Web konnte die Nachricht nicht automatisch senden. Prüfe den Browser und die einmalige QR-Anmeldung."
                ) from exc

    def _list_unread_whatsapp_web(self, limit: int = 20) -> list[dict[str, Any]]:
        """Read notification previews in a hidden browser from the private WhatsApp Web profile."""
        try:
            from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
            from playwright.sync_api import sync_playwright
        except ImportError as exc:
            raise IntegrationError("Playwright fehlt. Starte zuerst INSTALLIEREN.bat.") from exc
        profile = self.config.whatsapp_profile_dir.resolve()
        profile.mkdir(parents=True, exist_ok=True)
        with self._whatsapp_lock:
            try:
                with sync_playwright() as playwright:
                    context = launch_persistent_browser(
                        playwright,
                        profile,
                        preference=self.config.browser_channel,
                        headless=True,
                    )
                    try:
                        page = context.pages[0] if context.pages else context.new_page()
                        page.goto("https://web.whatsapp.com/", wait_until="domcontentloaded", timeout=45_000)
                        page.locator("#pane-side").wait_for(state="visible", timeout=30_000)
                        badges = page.locator(
                            "#pane-side span[aria-label*='unread message'], "
                            "#pane-side span[aria-label*='ungelesene Nachricht'], "
                            "#pane-side span[aria-label*='ungelesenen Nachrichten']"
                        )
                        messages: list[dict[str, Any]] = []
                        seen: set[str] = set()
                        for index in range(min(badges.count(), max(1, min(50, int(limit))))):
                            badge = badges.nth(index)
                            row = badge.locator("xpath=ancestor::div[@role='row'][1]")
                            if not row.count():
                                row = badge.locator("xpath=ancestor::div[@tabindex='-1'][1]")
                            text = str(row.inner_text() if row.count() else "").strip()
                            lines = [re.sub(r"\s+", " ", item).strip() for item in text.splitlines() if item.strip()]
                            if not lines:
                                continue
                            chat_name = lines[0]
                            body = lines[-1] if len(lines) > 1 else "Neue WhatsApp-Nachricht"
                            external_id = hashlib.sha256(f"{chat_name}\0{text}".encode("utf-8")).hexdigest()
                            if external_id in seen:
                                continue
                            seen.add(external_id)
                            messages.append(
                                {
                                    "source": "whatsapp",
                                    "external_id": external_id,
                                    "sender_name": chat_name,
                                    "sender_address": chat_name,
                                    "conversation": chat_name,
                                    "subject": "",
                                    "body": body,
                                    "received_at": datetime.now(self.timezone).isoformat(timespec="seconds"),
                                }
                            )
                        return messages
                    finally:
                        context.close()
            except PlaywrightTimeoutError as exc:
                raise IntegrationError(
                    "WhatsApp Web ist nicht angemeldet oder die Oberfläche hat sich geändert. Starte WHATSAPP_VERBINDEN.bat."
                ) from exc
            except IntegrationError:
                raise
            except Exception as exc:
                raise IntegrationError("WhatsApp-Nachrichten konnten nicht gelesen werden.") from exc

    async def unread_whatsapp_messages(self, limit: int = 20) -> list[dict[str, Any]]:
        return await asyncio.to_thread(self._list_unread_whatsapp_web, limit)

    def _list_snapchat_web_notifications(
        self,
        rules: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Inspect only unread metadata for selected Snapchat chats without opening a chat."""
        if not rules:
            return []
        try:
            from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
            from playwright.sync_api import sync_playwright
        except ImportError as exc:
            raise IntegrationError("Playwright fehlt. Starte zuerst INSTALLIEREN.bat.") from exc
        profile = self.config.snapchat_profile_dir.resolve()
        profile.mkdir(parents=True, exist_ok=True)
        marker = profile / ".jarvis_connected"
        if not marker.is_file():
            raise IntegrationError(
                "Snapchat Web ist noch nicht verbunden. Starte SNAPCHAT_VERBINDEN.bat."
            )
        with self._snapchat_lock:
            try:
                with sync_playwright() as playwright:
                    context = launch_persistent_browser(
                        playwright,
                        profile,
                        preference=self.config.browser_channel,
                        headless=True,
                    )
                    try:
                        page = context.pages[0] if context.pages else context.new_page()
                        page.goto("https://web.snapchat.com/", wait_until="domcontentloaded", timeout=45_000)
                        page.wait_for_timeout(2_000)
                        current_url = str(page.url or "")
                        parsed = urlparse(current_url)
                        hostname = str(parsed.hostname or "").casefold()
                        path = str(parsed.path or "").casefold().rstrip("/")
                        is_snapchat_web = (
                            parsed.scheme == "https"
                            and (
                                hostname == "web.snapchat.com"
                                or (
                                    hostname in {"www.snapchat.com", "snapchat.com"}
                                    and (path == "/web" or path.startswith("/web/"))
                                )
                            )
                        )
                        if not is_snapchat_web:
                            raise IntegrationError(
                                "Snapchat Web ist nicht angemeldet. Starte SNAPCHAT_VERBINDEN.bat."
                            )
                        results: list[dict[str, Any]] = []
                        rows = page.locator(
                            "[role='listitem'], [role='button'], button, "
                            "[data-testid*='conversation'], [data-testid*='chat']"
                        )
                        for rule in rules[:50]:
                            target = " ".join(str(rule.get("target") or "").split())
                            if not target:
                                continue
                            wanted = _identity(target)
                            matched = None
                            candidates = rows.filter(has_text=target)
                            for index in range(min(candidates.count(), 40)):
                                candidate = candidates.nth(index)
                                try:
                                    text = str(candidate.inner_text() or "").strip()
                                except Exception:
                                    continue
                                first_lines = [
                                    re.sub(r"\s+", " ", line).strip()
                                    for line in text.splitlines()
                                    if line.strip()
                                ]
                                if any(_identity(line) == wanted for line in first_lines[:3]):
                                    matched = candidate
                                    break
                            if matched is None:
                                results.append(
                                    {
                                        "rule_id": int(rule.get("id") or 0),
                                        "target": target,
                                        "unread": False,
                                        "fingerprint": "",
                                        "event_type": "snap",
                                    }
                                )
                                continue
                            metadata_parts: list[str] = []
                            try:
                                aria = str(matched.get_attribute("aria-label") or "")
                                if aria:
                                    metadata_parts.append(aria)
                            except Exception:
                                pass
                            unread_marker = False
                            for selector in (
                                "[aria-label*='unread' i]",
                                "[aria-label*='new snap' i]",
                                "[aria-label*='neuer snap' i]",
                                "[data-testid*='unread' i]",
                                "[data-testid*='new' i]",
                            ):
                                try:
                                    nodes = matched.locator(selector)
                                    if nodes.count():
                                        unread_marker = True
                                        metadata_parts.append(selector)
                                except Exception:
                                    continue
                            metadata = " ".join(metadata_parts)
                            normalized_metadata = normalize_identity(metadata)
                            unread = bool(
                                unread_marker
                                or
                                re.search(
                                    r"\b(?:unread|ungelesen|new snap|neuer snap|new chat|neue nachricht|neu)\b",
                                    normalized_metadata,
                                )
                            )
                            allowed_events = {
                                str(item).casefold()
                                for item in (rule.get("event_types") or [])
                                if str(item).casefold() in {"snap", "message"}
                            }
                            event_type = (
                                "snap"
                                if "snap" in normalized_metadata or allowed_events == {"snap"}
                                else "message"
                            )
                            fingerprint = (
                                hashlib.sha256(
                                    f"{wanted}\0{event_type}\0{normalized_metadata or 'unread-marker'}".encode("utf-8")
                                ).hexdigest()
                                if unread
                                else ""
                            )
                            results.append(
                                {
                                    "rule_id": int(rule.get("id") or 0),
                                    "target": target,
                                    "unread": unread,
                                    "fingerprint": fingerprint,
                                    "event_type": event_type,
                                    "received_at": datetime.now(self.timezone).isoformat(timespec="seconds"),
                                }
                            )
                        return results
                    finally:
                        context.close()
            except PlaywrightTimeoutError as exc:
                raise IntegrationError(
                    "Snapchat Web ist nicht angemeldet oder die Oberfläche hat sich geändert. "
                    "Starte SNAPCHAT_VERBINDEN.bat."
                ) from exc
            except IntegrationError:
                raise
            except Exception as exc:
                raise IntegrationError(
                    "Snapchat-Benachrichtigungen konnten nicht im Hintergrund geprüft werden."
                ) from exc

    async def snapchat_notifications(
        self,
        rules: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        return await asyncio.to_thread(self._list_snapchat_web_notifications, rules)

    def _message_chat_name(self, target: str) -> str:
        requested = str(target or "").strip()
        if not requested:
            return ""
        group = self._whatsapp_group(requested)
        if group:
            return str(group.get("chat_name") or group.get("name") or requested).strip()
        contact = self._contact(requested)
        if contact:
            return str(
                contact.get("whatsapp_chat_name")
                or contact.get("name")
                or requested
            ).strip()
        return requested

    def _list_recent_whatsapp_web(self, target: str, limit: int = 20) -> list[dict[str, Any]]:
        """Read recent incoming messages from one exact WhatsApp chat without showing a window."""
        chat_name = self._message_chat_name(target)
        if not chat_name:
            return self._list_unread_whatsapp_web(limit)
        try:
            from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
            from playwright.sync_api import sync_playwright
        except ImportError as exc:
            raise IntegrationError("Playwright fehlt. Starte zuerst INSTALLIEREN.bat.") from exc
        profile = self.config.whatsapp_profile_dir.resolve()
        profile.mkdir(parents=True, exist_ok=True)
        with self._whatsapp_lock:
            try:
                with sync_playwright() as playwright:
                    context = launch_persistent_browser(
                        playwright,
                        profile,
                        preference=self.config.browser_channel,
                        headless=True,
                    )
                    try:
                        page = context.pages[0] if context.pages else context.new_page()
                        page.goto("https://web.whatsapp.com/", wait_until="domcontentloaded", timeout=45_000)
                        page.locator("#pane-side").wait_for(state="visible", timeout=30_000)
                        row = page.locator("#pane-side [role='row']").filter(has_text=chat_name).first
                        if not row.count():
                            rows = page.locator("#pane-side [role='row']")
                            wanted = _identity(chat_name)
                            for index in range(min(rows.count(), 100)):
                                candidate = rows.nth(index)
                                first_line = str(candidate.inner_text() or "").splitlines()[0].strip()
                                if _identity(first_line) == wanted:
                                    row = candidate
                                    break
                        if not row.count():
                            raise IntegrationError(
                                f"Der WhatsApp-Chat „{chat_name}“ wurde nicht gefunden. Prüfe den gespeicherten Chatnamen."
                            )
                        row.click()
                        page.locator("#main").wait_for(state="visible", timeout=15_000)
                        bubbles = page.locator("#main div.message-in")
                        result: list[dict[str, Any]] = []
                        count = bubbles.count()
                        for index in range(count - 1, max(-1, count - 1 - max(1, min(50, int(limit)))), -1):
                            bubble = bubbles.nth(index)
                            text_parts = bubble.locator("span.selectable-text").all_inner_texts()
                            body = "\n".join(str(item).strip() for item in text_parts if str(item).strip()).strip()
                            if not body:
                                continue
                            metadata_node = bubble.locator("[data-pre-plain-text]").first
                            pre_plain = (
                                str(metadata_node.get_attribute("data-pre-plain-text") or "")
                                if metadata_node.count()
                                else ""
                            )
                            sender_match = re.search(r"\]\s*([^:]+):\s*$", pre_plain)
                            sender_name = sender_match.group(1).strip() if sender_match else chat_name
                            message_node = bubble.locator("xpath=ancestor-or-self::*[@data-id][1]")
                            raw_id = str(message_node.get_attribute("data-id") or "") if message_node.count() else ""
                            external_id = raw_id or hashlib.sha256(
                                f"{chat_name}\0{pre_plain}\0{body}".encode("utf-8")
                            ).hexdigest()
                            result.append(
                                {
                                    "source": "whatsapp",
                                    "external_id": external_id,
                                    "sender_name": sender_name or chat_name,
                                    "sender_address": "",
                                    "conversation": chat_name,
                                    "subject": "",
                                    "body": body,
                                    "received_at": datetime.now(self.timezone).isoformat(timespec="seconds"),
                                    "unread": False,
                                    "metadata": {
                                        "is_group": bool(self._whatsapp_group(target)),
                                        "whatsapp_timestamp": pre_plain,
                                        "history_lookup": True,
                                    },
                                }
                            )
                        return list(reversed(result))
                    finally:
                        context.close()
            except PlaywrightTimeoutError as exc:
                raise IntegrationError(
                    "WhatsApp Web ist nicht angemeldet oder die Oberfläche hat sich geändert. Starte WHATSAPP_VERBINDEN.bat."
                ) from exc
            except IntegrationError:
                raise
            except Exception as exc:
                raise IntegrationError("Der WhatsApp-Chatverlauf konnte nicht gelesen werden.") from exc

    async def recent_whatsapp_messages(self, target: str, limit: int = 20) -> list[dict[str, Any]]:
        return await asyncio.to_thread(self._list_recent_whatsapp_web, target, limit)

    async def whatsapp_chat_reply(self, chat_name: str, message: str) -> dict[str, Any]:
        """Reply to the exact chat name captured from the unified inbox."""
        target = str(chat_name or "").strip()
        body = str(message or "").strip()
        if not target or not body:
            raise IntegrationError("Für die WhatsApp-Antwort fehlen Chatname oder Nachricht.")
        desktop_result = await asyncio.to_thread(
            self._send_whatsapp_desktop,
            "contact",
            "",
            target,
            body,
        )
        return {
            "ok": True,
            "mode": "desktop_auto",
            "target": target,
            "target_kind": "inbox_chat",
            "requires_user_action": False,
            "verification": "desktop_send_command_completed",
            "result_summary": "WhatsApp Desktop hat die Antwort gesendet.",
            **desktop_result,
        }

    async def telegram_message(self, target: str, message: str) -> dict[str, Any]:
        body = str(message or "").strip()
        if not body or len(body) > 4_096:
            raise IntegrationError("Die Telegram-Nachricht muss zwischen 1 und 4096 Zeichen lang sein.")
        if not self.config.telegram_bot_token:
            raise IntegrationError("TELEGRAM_BOT_TOKEN fehlt in der .env-Datei.")
        resolved = self.resolve_recipient(target, "telegram")
        try:
            async with httpx.AsyncClient(timeout=20.0, follow_redirects=False) as client:
                response = await client.post(
                    f"https://api.telegram.org/bot{self.config.telegram_bot_token}/sendMessage",
                    json={"chat_id": resolved["recipient"], "text": body},
                )
        except httpx.HTTPError as exc:
            raise IntegrationError("Telegram ist derzeit nicht erreichbar.") from exc
        if response.is_error:
            raise IntegrationError(f"Telegram hat die Nachricht abgelehnt (HTTP {response.status_code}).")
        data = response.json() if response.content else {}
        result = data.get("result", {}) if isinstance(data, dict) else {}
        self._record_usage(resolved, "telegram")
        return {
            "ok": True,
            "channel": "telegram",
            "recipient": resolved["recipient"],
            "contact_name": resolved["contact_name"],
            "message_id": result.get("message_id") if isinstance(result, dict) else None,
            "requires_user_action": False,
            "verification": "provider_message_id",
            "result_summary": "Telegram hat die Nachricht bestätigt.",
            "app_closed": False,
        }

    async def email_message(
        self,
        target: str,
        subject: str,
        message: str,
        account: str = ACCOUNT_AUTO,
    ) -> dict[str, Any]:
        body = str(message or "").strip()
        title = str(subject or "").strip()
        if not title or len(title) > 200 or not body or len(body) > 50_000:
            raise IntegrationError("E-Mail-Betreff oder Nachricht ist leer beziehungsweise zu lang.")
        resolved = self.resolve_recipient(target, "email")
        contact = self._contact(target)
        preference = str(contact.get("preferred_email_account", ACCOUNT_AUTO)) if contact else ACCOUNT_AUTO
        selected = (
            self.connected_accounts.route(account, recipient=resolved["recipient"], contact_preference=preference)
            if self.connected_accounts
            else ACCOUNT_AUTO
        )
        if self.connected_accounts and selected in {ACCOUNT_GMAIL, ACCOUNT_OUTLOOK}:
            connected = self.connected_accounts.status().get(selected, {}).get("status") == "connected"
            if connected or account != ACCOUNT_AUTO:
                try:
                    result = (
                        await asyncio.to_thread(
                            self.connected_accounts.send_gmail,
                            resolved["recipient"],
                            title,
                            body,
                        )
                        if selected == ACCOUNT_GMAIL
                        else await self.connected_accounts.send_outlook(resolved["recipient"], title, body)
                    )
                except AccountIntegrationError as exc:
                    raise IntegrationError(str(exc)) from exc
                self._record_usage(resolved, "email")
                return {
                    **result,
                    "channel": "email",
                    "recipient": resolved["recipient"],
                    "contact_name": resolved["contact_name"],
                    "verification": result.get("verification") or (
                        "provider_message_id" if result.get("message_id") else "provider_completed"
                    ),
                    "result_summary": result.get("result_summary") or "E-Mail erfolgreich versendet.",
                    "app_closed": bool(result.get("app_closed")),
                }
        status = self.status()["email"]
        if self.config.email_mode == "smtp" and status["status"] != "connected":
            raise IntegrationError("SMTP-Modus ist gewählt, aber Host, Absender oder Passwort fehlt.")
        if status["mode"] != "smtp":
            query = urlencode({"subject": title, "body": body})
            return {
                "ok": True,
                "mode": "draft",
                "channel": "email",
                "recipient": resolved["recipient"],
                "contact_name": resolved["contact_name"],
                "action_url": f"mailto:{resolved['recipient']}?{query}",
                "requires_user_action": True,
                "message": "Die E-Mail wurde im Standard-Mailprogramm vorbereitet.",
                "verification": "draft_prepared",
                "app_closed": False,
            }
        await asyncio.to_thread(self._send_smtp, resolved["recipient"], title, body)
        self._record_usage(resolved, "email")
        return {
            "ok": True,
            "mode": "smtp",
            "channel": "email",
            "recipient": resolved["recipient"],
            "contact_name": resolved["contact_name"],
            "requires_user_action": False,
            "verification": "smtp_server_accepted",
            "result_summary": "Der SMTP-Server hat die E-Mail angenommen.",
            "app_closed": False,
        }

    def _send_smtp(self, recipient: str, subject: str, body: str) -> None:
        message = EmailMessage()
        message["From"] = self.config.smtp_from
        message["To"] = recipient
        message["Subject"] = subject
        message.set_content(body)
        try:
            if self.config.smtp_port == 465:
                server_context = smtplib.SMTP_SSL(
                    self.config.smtp_host,
                    self.config.smtp_port,
                    timeout=20,
                    context=ssl.create_default_context(),
                )
            else:
                server_context = smtplib.SMTP(self.config.smtp_host, self.config.smtp_port, timeout=20)
            with server_context as server:
                server.ehlo()
                if self.config.smtp_tls and self.config.smtp_port != 465:
                    server.starttls(context=ssl.create_default_context())
                    server.ehlo()
                if self.config.smtp_user:
                    server.login(self.config.smtp_user, self.config.smtp_password)
                server.send_message(message)
        except (OSError, smtplib.SMTPException) as exc:
            raise IntegrationError("Die E-Mail konnte über SMTP nicht gesendet werden.") from exc

    def calendar_event(
        self,
        title: str,
        start: str,
        end: str,
        description: str = "",
        location: str = "",
        attendees: list[str] | None = None,
    ) -> dict[str, Any]:
        name = str(title or "").strip()
        if not name or len(name) > 300:
            raise IntegrationError("Der Kalendertermin braucht einen gültigen Titel.")
        start_at = self._parse_datetime(start)
        end_at = self._parse_datetime(end)
        if end_at <= start_at:
            raise IntegrationError("Das Terminende muss nach dem Beginn liegen.")
        query: dict[str, str] = {
            "action": "TEMPLATE",
            "text": name,
            "dates": f"{start_at.astimezone(ZoneInfo('UTC')).strftime('%Y%m%dT%H%M%SZ')}/"
            f"{end_at.astimezone(ZoneInfo('UTC')).strftime('%Y%m%dT%H%M%SZ')}",
            "details": str(description or "")[:5_000],
            "location": str(location or "")[:500],
        }
        clean_attendees = [normalize_email(item) for item in (attendees or [])[:20]]
        if clean_attendees:
            query["add"] = ",".join(clean_attendees)
        return {
            "ok": True,
            "mode": "draft",
            "channel": "calendar",
            "action_url": f"https://calendar.google.com/calendar/render?{urlencode(query)}",
            "requires_user_action": True,
            "title": name,
            "start": start_at.isoformat(),
            "end": end_at.isoformat(),
            "message": "Der Termin wurde in Google Kalender vorbereitet und muss dort gespeichert werden.",
        }

    async def connected_calendar_event(
        self,
        title: str,
        start: str,
        end: str,
        description: str = "",
        location: str = "",
        attendees: list[str] | None = None,
        account: str = ACCOUNT_AUTO,
    ) -> dict[str, Any]:
        if not self.connected_accounts:
            return self.calendar_event(title, start, end, description, location, attendees)
        name = str(title or "").strip()
        if not name or len(name) > 300:
            raise IntegrationError("Der Kalendertermin braucht einen gültigen Titel.")
        start_at = self._parse_datetime(start)
        end_at = self._parse_datetime(end)
        if end_at <= start_at:
            raise IntegrationError("Das Terminende muss nach dem Beginn liegen.")
        clean_attendees = [normalize_email(item) for item in (attendees or [])[:20]]
        selected = self.connected_accounts.route(account)
        connected = self.connected_accounts.status().get(selected, {}).get("status") == "connected"
        if not connected and account == ACCOUNT_AUTO:
            return self.calendar_event(title, start, end, description, location, clean_attendees)
        try:
            if selected == ACCOUNT_GMAIL:
                result = await asyncio.to_thread(
                    self.connected_accounts.create_google_event,
                    title=name,
                    start=start_at,
                    end=end_at,
                    description=str(description or "")[:5_000],
                    location=str(location or "")[:500],
                    attendees=clean_attendees,
                    timezone=self.timezone.key,
                )
            else:
                result = await self.connected_accounts.create_outlook_event(
                    title=name,
                    start=start_at,
                    end=end_at,
                    description=str(description or "")[:5_000],
                    location=str(location or "")[:500],
                    attendees=clean_attendees,
                    timezone=self.connected_accounts.config.outlook_timezone,
                )
        except AccountIntegrationError as exc:
            raise IntegrationError(str(exc)) from exc
        return {
            **result,
            "channel": "calendar",
            "title": name,
            "start": start_at.isoformat(),
            "end": end_at.isoformat(),
        }

    def _parse_datetime(self, value: str) -> datetime:
        raw = str(value or "").strip()
        try:
            parsed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        except ValueError:
            try:
                import dateparser

                parsed = dateparser.parse(
                    raw,
                    languages=["de", "en"],
                    settings={
                        "TIMEZONE": str(self.timezone),
                        "RETURN_AS_TIMEZONE_AWARE": True,
                        "PREFER_DATES_FROM": "future",
                    },
                )
            except ImportError:
                parsed = None
            if parsed is None:
                raise IntegrationError(
                    "Datum und Uhrzeit müssen eindeutig sein, z. B. ISO-Format oder „morgen um 15 Uhr“."
                )
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=self.timezone)
        return parsed

    async def trigger_webhook(self, name: str, payload: dict[str, Any]) -> dict[str, Any]:
        key = _identity(name)
        url = self.webhooks.get(key)
        if not url:
            raise IntegrationError("Dieser Webhook ist nicht in JARVIS_WEBHOOKS_JSON freigegeben.")
        safe_payload = payload if isinstance(payload, dict) else {}
        encoded = json.dumps(safe_payload, ensure_ascii=False, default=str).encode("utf-8")
        if len(encoded) > 32_000:
            raise IntegrationError("Webhook-Daten sind größer als 32 KB.")
        try:
            async with httpx.AsyncClient(timeout=20.0, follow_redirects=False) as client:
                response = await client.post(url, json=safe_payload, headers={"User-Agent": "JARVIS-Integration-Hub/9.6"})
        except httpx.HTTPError as exc:
            raise IntegrationError("Der konfigurierte Webhook ist derzeit nicht erreichbar.") from exc
        if response.is_error:
            raise IntegrationError(f"Der Webhook meldete HTTP {response.status_code}.")
        return {"ok": True, "hook_name": key, "status_code": response.status_code}

    def launch(self, target: str) -> dict[str, Any]:
        key = _identity(target)
        configured = self.launch_targets.get(key)
        if not configured:
            raise IntegrationError("Dieses Startziel ist nicht freigegeben.")
        if configured.startswith("app:"):
            app_name = configured.removeprefix("app:")
            command = self.WINDOWS_APPS.get(app_name)
            if not command or os.name != "nt":
                raise IntegrationError("Diese lokale Anwendung kann nur unter Windows gestartet werden.")
            try:
                subprocess.Popen(command, shell=False, close_fds=True)
            except OSError as exc:
                raise IntegrationError("Die lokale Anwendung konnte nicht gestartet werden.") from exc
            return {"ok": True, "mode": "local_app", "target": key, "requires_user_action": False}
        action_url = configured.removeprefix("uri:")
        if not self._safe_action_url(action_url):
            raise IntegrationError("Das Startziel verwendet kein freigegebenes Protokoll.")
        return {
            "ok": True,
            "mode": "url",
            "target": key,
            "action_url": action_url,
            "requires_user_action": True,
            "message": "Das Ziel ist vorbereitet und kann im Aktionsfeld geöffnet werden.",
        }
