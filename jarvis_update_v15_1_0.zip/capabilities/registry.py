from __future__ import annotations

from dataclasses import asdict, dataclass


@dataclass(frozen=True, slots=True)
class Capability:
    key: str
    label: str
    category: str
    description: str
    tool_name: str | None = None
    ready: bool = True
    default_enabled: bool = True
    requires: tuple[str, ...] = ()


class CapabilityRegistry:
    def __init__(self) -> None:
        self._items: dict[str, Capability] = {}

    def register(self, capability: Capability) -> None:
        if capability.key in self._items:
            raise ValueError(f"Fähigkeit ist bereits registriert: {capability.key}")
        self._items[capability.key] = capability

    def list(self, overrides: dict[str, bool] | None = None) -> list[dict[str, object]]:
        overrides = overrides or {}
        result: list[dict[str, object]] = []
        for item in self._items.values():
            data = asdict(item)
            data["enabled"] = bool(overrides.get(item.key, item.default_enabled)) and item.ready
            result.append(data)
        return result

    def enabled_tools(self, overrides: dict[str, bool] | None = None) -> set[str]:
        return {
            str(item["tool_name"])
            for item in self.list(overrides)
            if item["enabled"] and item["tool_name"]
        }

    def get(self, key: str) -> Capability | None:
        return self._items.get(key)
